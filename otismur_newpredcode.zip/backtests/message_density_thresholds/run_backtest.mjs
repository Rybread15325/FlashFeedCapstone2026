#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import {
  candidateTickers,
  causalRollingMean,
  dedupeKey,
  etParts,
  eventSec,
  findBarAtOrAfter,
  findBarAtOrBefore,
  floorMinute,
  isRegularSession,
  marketCapTier,
  nextRealBarAfter,
  pctReturn,
  rollingTimeCorrelation,
  sameEtDate,
  summarizeTrades,
  thresholdCrossed,
  trailingSum,
} from './features.mjs'

const require = createRequire(new URL('../../Infrastructure/server/package.json', import.meta.url))
const { MongoClient } = require('mongodb')

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')
const CONFIG_PATH = path.join(ROOT, 'backtests/message_density_thresholds/config.json')
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
const outputDir = path.join(ROOT, config.outputDir)
fs.mkdirSync(outputDir, { recursive: true })
const startedAt = Date.now()
const progress = label => console.error(`[backtest +${((Date.now() - startedAt) / 1000).toFixed(1)}s] ${label}`)

const minuteRange = (start, end) => {
  const out = []
  for (let t = start; t <= end; t += 60) out.push(t)
  return out
}

function csvEscape(value) {
  if (value == null) return ''
  const text = typeof value === 'object' ? JSON.stringify(value) : String(value)
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

function writeCsv(file, rows) {
  const allKeys = []
  const seen = new Set()
  for (const row of rows) {
    for (const key of Object.keys(row)) {
      if (!seen.has(key)) {
        seen.add(key)
        allKeys.push(key)
      }
    }
  }
  const body = [
    allKeys.join(','),
    ...rows.map(row => allKeys.map(key => csvEscape(row[key])).join(',')),
  ].join('\n')
  fs.writeFileSync(path.join(outputDir, file), body + '\n')
}

function pct(value, decimals = 4) {
  return value == null || !Number.isFinite(Number(value)) ? null : Number(Number(value).toFixed(decimals))
}

function buildStatsRows(group, tradesByName) {
  return Object.entries(tradesByName).map(([name, trades]) => ({
    group,
    name,
    ...summarizeTrades(trades),
  }))
}

async function loadPriceBars(db) {
  const snapshots = await db.collection(config.priceCollection)
    .find({}, { projection: { _id: 0, snapshot_sec: 1, snapshot_at: 1, source: 1, rows: 1 } })
    .sort({ snapshot_sec: 1 })
    .toArray()

  const byTicker = new Map()
  let expandedRows = 0
  for (const snapshot of snapshots) {
    const minute = floorMinute(snapshot.snapshot_sec ?? snapshot.snapshot_at)
    if (!minute || !Array.isArray(snapshot.rows)) continue
    for (const row of snapshot.rows) {
      const ticker = String(row.ticker || '').toUpperCase().trim()
      const price = Number(row.price)
      if (!ticker || !Number.isFinite(price) || price <= 0) continue
      expandedRows += 1
      const source = row.quote_source || snapshot.source || 'finviz_momentum_snapshots'
      const tier = marketCapTier(row.market_cap, source)
      const bar = {
        ticker,
        minute,
        close: price,
        price,
        changePct: Number(row.change_pct),
        relVolume: Number(row.rel_volume),
        volume: Number(row.volume),
        rank: Number(row.rank),
        marketCap: Number(row.market_cap),
        tier,
        source,
        quoteUpdatedAt: row.quote_updated_at || null,
      }
      if (!byTicker.has(ticker)) byTicker.set(ticker, new Map())
      byTicker.get(ticker).set(minute, bar)
    }
  }

  const final = new Map()
  for (const [ticker, minuteMap] of byTicker.entries()) {
    const bars = [...minuteMap.values()].sort((a, b) => a.minute - b.minute)
    const uniquePrices = new Set(bars.map(bar => bar.close)).size
    if (bars.length >= config.minPriceBarsPerTicker && uniquePrices >= 2) final.set(ticker, bars)
  }

  let priceStartSec = Infinity
  let priceEndSec = -Infinity
  for (const bars of final.values()) {
    if (bars[0]) priceStartSec = Math.min(priceStartSec, bars[0].minute)
    if (bars[bars.length - 1]) priceEndSec = Math.max(priceEndSec, bars[bars.length - 1].minute)
  }
  return {
    barsByTicker: final,
    diagnostics: {
      snapshots: snapshots.length,
      expandedRows,
      eligibleTickers: final.size,
      priceStartSec: Number.isFinite(priceStartSec) ? priceStartSec : null,
      priceEndSec: Number.isFinite(priceEndSec) ? priceEndSec : null,
      droppedStaticOrSparseTickers: byTicker.size - final.size,
    },
  }
}

async function loadSocialEvents(db, priceTickers, startSec, endSec) {
  const tickerSet = new Set(priceTickers)
  const startLookback = startSec - 6 * 3600
  const docs = await db.collection(config.socialCollection)
    .find({}, {
      projection: {
        _id: 1, id: 1, platform: 1, collector: 1, source: 1, ticker: 1, symbol: 1,
        cashtag: 1, tickers_mentioned: 1, text: 1, content: 1, title: 1, summary: 1,
        url: 1, link: 1, source_url: 1, fetched_at: 1, detected_at: 1, timestamp: 1,
        created_at: 1, publish_date: 1,
      },
    })
    .toArray()

  const rawByTickerMinute = new Map()
  const dedupByTickerMinute = new Map()
  const tickerTotals = new Map()
  const duplicateGroups = new Map()
  const platformCounts = new Map()
  let inRangeDocs = 0
  let missingTickerCandidates = 0
  let multiTickerDocs = 0
  let futureDatedDocs = 0
  let publishAfterFetchDocs = 0
  const nowSec = Math.floor(Date.now() / 1000)

  const inc = (map, key, amount = 1) => map.set(key, (map.get(key) || 0) + amount)
  for (const doc of docs) {
    const sec = eventSec(doc)
    if (!sec) continue
    if (sec > nowSec + 300) futureDatedDocs += 1
    const published = eventSec({ fetched_at: doc.publish_date })
    const fetched = eventSec({ fetched_at: doc.fetched_at })
    if (published && fetched && published > fetched + 300) publishAfterFetchDocs += 1
    if (sec < startLookback || sec > endSec + 3600) continue
    const minute = floorMinute(sec)
    const candidates = candidateTickers(doc).filter(t => tickerSet.has(t))
    if (!candidates.length) {
      missingTickerCandidates += 1
      continue
    }
    if (candidates.length > 1) multiTickerDocs += 1
    inRangeDocs += 1
    inc(platformCounts, doc.platform || doc.collector || 'Unknown')
    const dk = dedupeKey(doc)
    inc(duplicateGroups, dk)
    for (const ticker of candidates) {
      const key = `${ticker}|${minute}`
      inc(rawByTickerMinute, key)
      const dedupSet = dedupByTickerMinute.get(key) || new Set()
      dedupSet.add(dk)
      dedupByTickerMinute.set(key, dedupSet)
      inc(tickerTotals, ticker)
    }
  }

  return {
    rawByTickerMinute,
    dedupByTickerMinute,
    tickerTotals,
    diagnostics: {
      totalSocialDocs: docs.length,
      inBacktestRangeMatchedDocs: inRangeDocs,
      missingTickerCandidateDocsInRange: missingTickerCandidates,
      multiTickerMatchedDocsInRange: multiTickerDocs,
      futureDatedDocs,
      publishAfterFetchDocs,
      duplicateMessageGroupsInRange: [...duplicateGroups.values()].filter(n => n > 1).length,
      platformCounts: Object.fromEntries([...platformCounts.entries()].sort((a, b) => b[1] - a[1])),
    },
  }
}

function buildTickerContext(ticker, bars, social) {
  const first = bars[0].minute
  const last = bars[bars.length - 1].minute
  const minutes = minuteRange(first - 6 * 3600, last)
  const rawCounts = minutes.map(minute => social.rawByTickerMinute.get(`${ticker}|${minute}`) || 0)
  const dedupCounts = minutes.map(minute => (social.dedupByTickerMinute.get(`${ticker}|${minute}`)?.size || 0))
  const indexByMinute = new Map(minutes.map((minute, i) => [minute, i]))
  const regularBars = bars.filter(bar => isRegularSession(bar.minute))
  const regularBarsByDate = new Map()
  const barsByDate = new Map()
  for (const bar of bars) {
    const date = etParts(bar.minute).date
    if (!barsByDate.has(date)) barsByDate.set(date, [])
    barsByDate.get(date).push(bar)
    if (isRegularSession(bar.minute)) {
      if (!regularBarsByDate.has(date)) regularBarsByDate.set(date, [])
      regularBarsByDate.get(date).push(bar)
    }
  }
  return {
    ticker,
    bars,
    regularBars,
    barsByDate,
    regularBarsByDate,
    first,
    last,
    minutes,
    rawCounts,
    dedupCounts,
    indexByMinute,
    correlationCache: new Map(),
    smoothCache: new Map(),
  }
}

function firstBarAfter(sortedBars, sec) {
  let lo = 0
  let hi = sortedBars.length
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2)
    if (sortedBars[mid].minute <= sec) lo = mid + 1
    else hi = mid
  }
  return sortedBars[lo] || null
}

function barsFrom(sortedBars, sec) {
  let lo = 0
  let hi = sortedBars.length
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2)
    if (sortedBars[mid].minute < sec) lo = mid + 1
    else hi = mid
  }
  return sortedBars.slice(lo)
}

function densityAt(context, smoothed, minute) {
  const i = context.indexByMinute.get(minute)
  return i == null ? 0 : smoothed[i] || 0
}

function smoothedForWindow(context, windowMinutes) {
  if (!context.smoothCache.has(windowMinutes)) {
    context.smoothCache.set(windowMinutes, causalRollingMean(context.rawCounts, windowMinutes))
  }
  return context.smoothCache.get(windowMinutes)
}

function correlationForWindow(context, windowMinutes) {
  if (!context.correlationCache.has(windowMinutes)) {
    const smoothed = smoothedForWindow(context, windowMinutes)
    const densityByMinute = new Map(context.minutes.map((minute, i) => [minute, smoothed[i] || 0]))
    const corrByMinute = rollingTimeCorrelation(context.bars, densityByMinute, windowMinutes, config.minCorrelationObservations)
    context.correlationCache.set(windowMinutes, corrByMinute)
  }
  return context.correlationCache.get(windowMinutes)
}

function countTrailing(context, minute, lookbackMinutes) {
  const end = context.indexByMinute.get(minute)
  if (end == null) return 0
  const start = Math.max(0, end - lookbackMinutes + 1)
  let total = 0
  for (let i = start; i <= end; i += 1) total += context.rawCounts[i] || 0
  return total
}

function minuteDuplicateInfo(context, minute) {
  const i = context.indexByMinute.get(minute)
  if (i == null) return { raw: 0, dedup: 0, duplicateDriven: false }
  const raw = context.rawCounts[i] || 0
  const dedup = context.dedupCounts[i] || 0
  return {
    raw,
    dedup,
    duplicateDriven: raw >= 3 && dedup > 0 && dedup <= 2,
  }
}

function historicalReturnPct(bars, bar, minutes) {
  return pctReturn(findBarAtOrBefore(bars, bar.minute - minutes * 60)?.close, bar.close)
}

function passesQualityGate(context, bar, smoothed, gate = null) {
  if (!gate) return true
  const requireMaxPreMove = (minutes, maxPct) => {
    if (maxPct == null) return true
    const value = historicalReturnPct(context.bars, bar, minutes)
    return Number.isFinite(value) && value <= maxPct
  }
  if (!requireMaxPreMove(15, gate.maxPre15Pct)) return false
  if (!requireMaxPreMove(30, gate.maxPre30Pct)) return false
  if (!requireMaxPreMove(60, gate.maxPre60Pct)) return false
  if (gate.minTrailing60Messages != null && countTrailing(context, bar.minute, 60) < gate.minTrailing60Messages) return false

  const current = densityAt(context, smoothed, bar.minute)
  if (gate.minSmoothedDensity != null && current < gate.minSmoothedDensity) return false
  if (gate.minDensityRise30Multiple != null) {
    const prior = densityAt(context, smoothed, bar.minute - 30 * 60)
    if (!(prior > 0) || current / prior < gate.minDensityRise30Multiple) return false
  }
  return true
}

function signalDiagnostics(context, bars, signalBar, entryBar, exitBars) {
  const before = minutes => pctReturn(findBarAtOrBefore(bars, signalBar.minute - minutes * 60)?.close, signalBar.close)
  const forward = minutes => pctReturn(signalBar.close, findBarAtOrAfter(bars, signalBar.minute + minutes * 60)?.close)
  const prices = exitBars.map(bar => bar.close)
  const mfe = prices.length ? pctReturn(entryBar.close, Math.max(...prices)) : null
  const mae = prices.length ? pctReturn(entryBar.close, Math.min(...prices)) : null
  let timeToMfeMinutes = null
  if (prices.length) {
    const peak = Math.max(...prices)
    const peakBar = exitBars.find(bar => bar.close === peak)
    if (peakBar) timeToMfeMinutes = Math.round((peakBar.minute - entryBar.minute) / 60)
  }
  const pre60 = before(60)
  const halfMoveBeforeEntry = Number.isFinite(pre60) && Number.isFinite(mfe) && pre60 > 0 && mfe > 0 && pre60 > mfe
  const dup = minuteDuplicateInfo(context, signalBar.minute)
  return {
    preReturn15mPct: pct(before(15)),
    preReturn30mPct: pct(before(30)),
    preReturn60mPct: pct(pre60),
    forwardReturn15mPct: pct(forward(15)),
    forwardReturn30mPct: pct(forward(30)),
    forwardReturn60mPct: pct(forward(60)),
    forwardReturn2hPct: pct(forward(120)),
    forwardReturn4hPct: pct(forward(240)),
    forwardReturnEodPct: pctReturn(signalBar.close, exitBars[exitBars.length - 1]?.close),
    mfePct: pct(mfe),
    maePct: pct(mae),
    timeToMfeMinutes,
    alreadyUpMoreThan3PctBeforeEntry: Number.isFinite(pre60) && pre60 > 3,
    halfMoveBeforeEntry,
    signalMinuteRawMessages: dup.raw,
    signalMinuteDedupMessages: dup.dedup,
    duplicateDriven: dup.duplicateDriven,
  }
}

function simulateSignal({ context, signalBar, ruleName, group, thresholdC, correlation, previousCorrelation, trailingStopPct, tier, extra = {} }) {
  const bars = context.bars
  const regularOnly = config.sessionMode === 'regular'
  const entryBar = firstBarAfter(regularOnly ? context.regularBars : bars, signalBar.minute)
  if (!entryBar || !sameEtDate(signalBar.minute, entryBar.minute)) return null

  const date = etParts(entryBar.minute).date
  const daySource = regularOnly ? (context.regularBarsByDate.get(date) || []) : (context.barsByDate.get(date) || [])
  const dayBars = barsFrom(daySource, entryBar.minute)
  if (!dayBars.length) return null

  const entry = entryBar.close
  let peak = entry
  let exitBar = dayBars[dayBars.length - 1]
  let exitReason = 'eod_flatten'
  const protective = entry * (1 - config.protectiveStopPct / 100)
  for (const bar of dayBars.slice(1)) {
    peak = Math.max(peak, bar.close)
    const trailing = peak * (1 - trailingStopPct / 100)
    const hitProtective = bar.close <= protective
    const hitTrailing = bar.close <= trailing
    if (hitProtective || hitTrailing) {
      exitBar = bar
      exitReason = hitProtective ? 'protective_stop_close_based' : 'trailing_stop_close_based'
      if (hitProtective && hitTrailing) exitReason = 'protective_and_trailing_same_close'
      break
    }
  }

  const exitBars = dayBars.filter(bar => bar.minute >= entryBar.minute && bar.minute <= exitBar.minute)
  const grossReturnPct = pctReturn(entry, exitBar.close)
  const slippagePct = Number(config.slippagePctByTier[tier] ?? config.slippagePctByTier.Unknown ?? 0)
  const netReturnPct = grossReturnPct == null ? null : grossReturnPct - slippagePct * 2
  const diag = signalDiagnostics(context, bars, signalBar, entryBar, exitBars)
  const entryLagMinutes = Math.round((entryBar.minute - signalBar.minute) / 60)
  return {
    group,
    ruleName,
    ticker: context.ticker,
    tier,
    signalEtDate: etParts(signalBar.minute).date,
    signalSec: signalBar.minute,
    signalTimeEt: `${String(etParts(signalBar.minute).hour).padStart(2, '0')}:${String(etParts(signalBar.minute).minute).padStart(2, '0')}`,
    entrySec: entryBar.minute,
    exitSec: exitBar.minute,
    entryLagMinutes,
    entryPrice: pct(entry),
    exitPrice: pct(exitBar.close),
    exitReason,
    grossReturnPct: pct(grossReturnPct),
    netReturnPct: pct(netReturnPct),
    slippagePctOneWay: slippagePct,
    trailingStopPct,
    protectiveStopPct: config.protectiveStopPct,
    thresholdC: thresholdC ?? null,
    correlation: pct(correlation, 6),
    previousCorrelation: pct(previousCorrelation, 6),
    changePctAtSignal: pct(signalBar.changePct),
    relVolumeAtSignal: pct(signalBar.relVolume),
    rankAtSignal: signalBar.rank,
    holdingMinutes: Math.round((exitBar.minute - entryBar.minute) / 60),
    ...diag,
    ...extra,
  }
}

function runCorrelationRule(context, rule, { group, ruleName, tierFilter = null, qualityGate = null } = {}) {
  const bars = context.bars
  const smoothed = smoothedForWindow(context, rule.windowMinutes)
  const corrByMinute = correlationForWindow(context, rule.windowMinutes)
  const trades = []
  let openUntil = 0
  for (let i = 1; i < bars.length; i += 1) {
    const bar = bars[i]
    if (bar.minute <= openUntil) continue
    const tier = bar.tier || 'Unknown'
    if (tierFilter && tier !== tierFilter) continue
    if (config.sessionMode === 'regular' && !isRegularSession(bar.minute)) continue
    const current = corrByMinute.get(bar.minute)
    const previous = corrByMinute.get(bars[i - 1].minute)
    if (!thresholdCrossed(previous, current, rule.thresholdC)) continue
    if (!passesQualityGate(context, bar, smoothed, qualityGate)) continue
    const trade = simulateSignal({
      context,
      signalBar: bar,
      ruleName,
      group,
      thresholdC: rule.thresholdC,
      correlation: current,
      previousCorrelation: previous,
      trailingStopPct: rule.trailingStopPct,
      tier,
      extra: {
        windowMinutes: rule.windowMinutes,
        densitySmoothedAtSignal: pct(densityAt(context, smoothed, bar.minute), 6),
      },
    })
    if (!trade) continue
    trades.push(trade)
    openUntil = trade.exitSec + config.cooldownMinutes * 60
  }
  return trades
}

function runNanoRule(context, rule, { group, ruleName, qualityGate = null } = {}) {
  const bars = context.bars
  const smoothed = smoothedForWindow(context, rule.windowMinutes)
  const trades = []
  let openUntil = 0
  for (const bar of bars) {
    if (bar.minute <= openUntil) continue
    if (bar.tier !== 'Nano') continue
    if (config.sessionMode === 'regular' && !isRegularSession(bar.minute)) continue
    const current = densityAt(context, smoothed, bar.minute)
    const prior = densityAt(context, smoothed, bar.minute - 60 * 60)
    const trailing60 = countTrailing(context, bar.minute, 60)
    if (!(prior > 0) || trailing60 < rule.minTrailing60Messages) continue
    const rise = current / prior
    if (rise < rule.densityRiseMultiple) continue
    if (!passesQualityGate(context, bar, smoothed, qualityGate)) continue
    const trade = simulateSignal({
      context,
      signalBar: bar,
      ruleName,
      group,
      trailingStopPct: rule.trailingStopPct,
      tier: 'Nano',
      extra: {
        windowMinutes: rule.windowMinutes,
        densitySmoothedAtSignal: pct(current, 6),
        densitySmoothed60mAgo: pct(prior, 6),
        densityRiseMultiple: pct(rise),
        trailing60Messages: trailing60,
      },
    })
    if (!trade) continue
    trades.push(trade)
    openUntil = trade.exitSec + config.cooldownMinutes * 60
  }
  return trades
}

function runTierRules(contexts) {
  const byName = {}
  for (const [name, rule] of Object.entries(config.tierRules)) byName[name] = []
  for (const context of contexts) {
    for (const [name, rule] of Object.entries(config.tierRules)) {
      if (rule.entrySignal === 'density_rise_3x_60m') {
        byName[name].push(...runNanoRule(context, { ...rule, name }, { group: 'tier_exact', ruleName: name }))
      } else {
        byName[name].push(...runCorrelationRule(context, rule, { group: 'tier_exact', ruleName: name, tierFilter: name }))
      }
    }
  }
  return byName
}

function runPooledRules(contexts) {
  const byName = Object.fromEntries(config.pooledRules.map(rule => [rule.name, []]))
  for (const context of contexts) {
    for (const rule of config.pooledRules) {
      byName[rule.name].push(...runCorrelationRule(context, rule, { group: 'pooled_exact', ruleName: rule.name }))
    }
  }
  return byName
}

function runSensitivity(contexts) {
  const rows = []
  for (const windowMinutes of config.sensitivity.windowsMinutes) {
    for (const thresholdC of config.sensitivity.thresholds) {
      const rule = { windowMinutes, thresholdC, trailingStopPct: 2 }
      let trades = []
      for (const context of contexts) trades.push(...runCorrelationRule(context, rule, { group: 'sensitivity_corr', ruleName: `corr_w${windowMinutes}_c${thresholdC}_trail2` }))
      rows.push({ family: 'corr_threshold_window_oat', windowMinutes, thresholdC, trailingStopPct: 2, ...summarizeTrades(trades) })
    }
  }
  for (const trailingStopPct of config.sensitivity.trailingStopsPct) {
    const rule = { windowMinutes: 240, thresholdC: 0.7, trailingStopPct }
    let trades = []
    for (const context of contexts) trades.push(...runCorrelationRule(context, rule, { group: 'sensitivity_trail', ruleName: `corr_w240_c0.7_trail${trailingStopPct}` }))
    rows.push({ family: 'trailing_stop_oat_w240_c0.7', windowMinutes: 240, thresholdC: 0.7, trailingStopPct, ...summarizeTrades(trades) })
  }
  for (const densityRiseMultiple of config.sensitivity.nanoRiseMultiples) {
    for (const minTrailing60Messages of config.sensitivity.nanoMinTrailing60Messages) {
      const rule = { windowMinutes: 360, densityRiseMultiple, minTrailing60Messages, trailingStopPct: 15 }
      let trades = []
      for (const context of contexts) trades.push(...runNanoRule(context, rule, { group: 'sensitivity_nano', ruleName: `nano_r${densityRiseMultiple}_m${minTrailing60Messages}_trail15` }))
      rows.push({ family: 'nano_density_oat', windowMinutes: 360, densityRiseMultiple, minTrailing60Messages, trailingStopPct: 15, ...summarizeTrades(trades) })
    }
  }
  return rows
}

function runSubmittedTierAggregate(contexts, name, qualityGate) {
  const trades = []
  for (const context of contexts) {
    for (const [ruleName, rule] of Object.entries(config.tierRules)) {
      if (rule.entrySignal === 'density_rise_3x_60m') {
        trades.push(...runNanoRule(context, { ...rule, name: ruleName }, { group: 'improvement', ruleName: `${name}:${ruleName}`, qualityGate }))
      } else {
        trades.push(...runCorrelationRule(context, rule, { group: 'improvement', ruleName: `${name}:${ruleName}`, tierFilter: ruleName, qualityGate }))
      }
    }
  }
  return trades
}

function runSubmittedPooledAggregate(contexts, name, qualityGate) {
  const trades = []
  for (const context of contexts) {
    for (const rule of config.pooledRules) {
      trades.push(...runCorrelationRule(context, rule, { group: 'improvement', ruleName: `${name}:${rule.name}`, qualityGate }))
    }
  }
  return trades
}

function runImprovementTests(contexts) {
  const out = {
    submitted_tier_pre60le3: runSubmittedTierAggregate(contexts, 'submitted_tier_pre60le3', { maxPre60Pct: 3 }),
    submitted_tier_pre60le5_msg3: runSubmittedTierAggregate(contexts, 'submitted_tier_pre60le5_msg3', { maxPre60Pct: 5, minTrailing60Messages: 3 }),
    submitted_pooled_pre60le3: runSubmittedPooledAggregate(contexts, 'submitted_pooled_pre60le3', { maxPre60Pct: 3 }),
    submitted_pooled_pre60le5_msg3: runSubmittedPooledAggregate(contexts, 'submitted_pooled_pre60le5_msg3', { maxPre60Pct: 5, minTrailing60Messages: 3 }),
  }

  const localVariants = [
    { name: 'local_w120_c0.8_t2_pre60le3', rule: { windowMinutes: 120, thresholdC: 0.8, trailingStopPct: 2 }, gate: { maxPre60Pct: 3 } },
    { name: 'local_w120_c0.8_t2_pre60le5', rule: { windowMinutes: 120, thresholdC: 0.8, trailingStopPct: 2 }, gate: { maxPre60Pct: 5 } },
    { name: 'local_w120_c0.8_t2_pre60le5_msg3', rule: { windowMinutes: 120, thresholdC: 0.8, trailingStopPct: 2 }, gate: { maxPre60Pct: 5, minTrailing60Messages: 3 } },
    { name: 'local_w120_c0.8_t3_pre60le5_msg3', rule: { windowMinutes: 120, thresholdC: 0.8, trailingStopPct: 3 }, gate: { maxPre60Pct: 5, minTrailing60Messages: 3 } },
    { name: 'local_w120_c0.85_t2_pre60le5', rule: { windowMinutes: 120, thresholdC: 0.85, trailingStopPct: 2 }, gate: { maxPre60Pct: 5 } },
    { name: 'local_w180_c0.2_t2_pre60le3', rule: { windowMinutes: 180, thresholdC: 0.2, trailingStopPct: 2 }, gate: { maxPre60Pct: 3 } },
    { name: 'local_w180_c-0.2_t2_pre60le3', rule: { windowMinutes: 180, thresholdC: -0.2, trailingStopPct: 2 }, gate: { maxPre60Pct: 3 } },
    { name: 'local_w240_c-0.2_t2_pre60le3', rule: { windowMinutes: 240, thresholdC: -0.2, trailingStopPct: 2 }, gate: { maxPre60Pct: 3 } },
  ]
  for (const variant of localVariants) {
    const trades = []
    for (const context of contexts) trades.push(...runCorrelationRule(context, variant.rule, { group: 'improvement', ruleName: variant.name, qualityGate: variant.gate }))
    out[variant.name] = trades
  }

  const nanoVariants = [
    { name: 'nano20_pre60le3', rule: { windowMinutes: 360, densityRiseMultiple: 3, minTrailing60Messages: 5, trailingStopPct: 20 }, gate: { maxPre60Pct: 3 } },
    { name: 'nano20_pre60le5_msg3', rule: { windowMinutes: 360, densityRiseMultiple: 3, minTrailing60Messages: 5, trailingStopPct: 20 }, gate: { maxPre60Pct: 5, minTrailing60Messages: 3 } },
    { name: 'nano20_r2.5_pre60le5_msg5', rule: { windowMinutes: 360, densityRiseMultiple: 2.5, minTrailing60Messages: 5, trailingStopPct: 20 }, gate: { maxPre60Pct: 5 } },
  ]
  for (const variant of nanoVariants) {
    const trades = []
    for (const context of contexts) trades.push(...runNanoRule(context, variant.rule, { group: 'improvement', ruleName: variant.name, qualityGate: variant.gate }))
    out[variant.name] = trades
  }
  return out
}

function optimizationParamGrid() {
  const grid = config.optimizationGrid || {}
  const windows = grid.windowsMinutes || [60, 90, 120, 180, 240, 300, 360]
  const thresholds = grid.thresholds || [-0.2, 0, 0.1, 0.2, 0.3, 0.4, 0.6, 0.8]
  const trailingStops = grid.trailingStopsPct || [1.5, 2, 3, 5]
  const maxPre60Values = grid.maxPre60Pct || [1, 2, 3, 5]
  const minTrailing60Messages = grid.minTrailing60Messages || [0, 3]
  const minRelVolumeValues = grid.minRelVolumeAtSignal || [0]
  const maxAbsChangePctValues = grid.maxAbsChangePctAtSignal || [null]
  const out = []
  for (const windowMinutes of windows) {
    for (const thresholdC of thresholds) {
      for (const trailingStopPct of trailingStops) {
        for (const maxPre60Pct of maxPre60Values) {
          for (const minMsgs of minTrailing60Messages) {
            for (const minRelVolumeAtSignal of minRelVolumeValues) {
              for (const maxAbsChangePctAtSignal of maxAbsChangePctValues) {
                out.push({
                  name: [
                    `opt_w${windowMinutes}`,
                    `c${String(thresholdC).replace('-', 'm')}`,
                    `t${trailingStopPct}`,
                    `pre60le${maxPre60Pct}`,
                    minMsgs ? `msg${minMsgs}` : 'msg0',
                    minRelVolumeAtSignal ? `rv${minRelVolumeAtSignal}` : null,
                    maxAbsChangePctAtSignal ? `abschg${maxAbsChangePctAtSignal}` : null,
                  ].filter(Boolean).join('_'),
                  rule: { windowMinutes, thresholdC, trailingStopPct },
                  gate: {
                    maxPre60Pct,
                    minTrailing60Messages: minMsgs || null,
                    minRelVolumeAtSignal: minRelVolumeAtSignal || null,
                    maxAbsChangePctAtSignal: maxAbsChangePctAtSignal || null,
                  },
                })
              }
            }
          }
        }
      }
    }
  }
  return out
}

function passesOptimizationGate(bar, gate = {}) {
  if (gate.minRelVolumeAtSignal != null && Number(bar.relVolume) < Number(gate.minRelVolumeAtSignal)) return false
  if (gate.maxAbsChangePctAtSignal != null && Math.abs(Number(bar.changePct || 0)) > Number(gate.maxAbsChangePctAtSignal)) return false
  return true
}

function runCorrelationRuleWithSignalGate(context, rule, { group, ruleName, qualityGate = null } = {}) {
  const bars = context.bars
  const smoothed = smoothedForWindow(context, rule.windowMinutes)
  const corrByMinute = correlationForWindow(context, rule.windowMinutes)
  const trades = []
  let openUntil = 0
  for (let i = 1; i < bars.length; i += 1) {
    const bar = bars[i]
    if (bar.minute <= openUntil) continue
    if (config.sessionMode === 'regular' && !isRegularSession(bar.minute)) continue
    if (!passesOptimizationGate(bar, qualityGate)) continue
    const current = corrByMinute.get(bar.minute)
    const previous = corrByMinute.get(bars[i - 1].minute)
    if (!thresholdCrossed(previous, current, rule.thresholdC)) continue
    if (!passesQualityGate(context, bar, smoothed, qualityGate)) continue
    const trade = simulateSignal({
      context,
      signalBar: bar,
      ruleName,
      group,
      thresholdC: rule.thresholdC,
      correlation: current,
      previousCorrelation: previous,
      trailingStopPct: rule.trailingStopPct,
      tier: bar.tier || 'Unknown',
      extra: {
        windowMinutes: rule.windowMinutes,
        densitySmoothedAtSignal: pct(densityAt(context, smoothed, bar.minute), 6),
        minTrailing60Messages: qualityGate?.minTrailing60Messages ?? null,
        maxPre60Pct: qualityGate?.maxPre60Pct ?? null,
        minRelVolumeAtSignal: qualityGate?.minRelVolumeAtSignal ?? null,
        maxAbsChangePctAtSignal: qualityGate?.maxAbsChangePctAtSignal ?? null,
      },
    })
    if (!trade) continue
    trades.push(trade)
    openUntil = trade.exitSec + config.cooldownMinutes * 60
  }
  return trades
}

function runOptimizationGrid(contexts) {
  const variants = optimizationParamGrid()
  const byName = {}
  for (const variant of variants) {
    const trades = []
    for (const context of contexts) {
      trades.push(...runCorrelationRuleWithSignalGate(context, variant.rule, {
        group: 'optimization',
        ruleName: variant.name,
        qualityGate: variant.gate,
      }))
    }
    byName[variant.name] = trades
  }
  return byName
}

function runBaselineRule(contexts, name, predicate, trailingStopPct = 5) {
  const trades = []
  for (const context of contexts) {
    let openUntil = 0
    for (let i = 1; i < context.bars.length; i += 1) {
      const bar = context.bars[i]
      if (bar.minute <= openUntil) continue
      if (config.sessionMode === 'regular' && !isRegularSession(bar.minute)) continue
      if (!predicate(bar, context.bars[i - 1])) continue
      const trade = simulateSignal({
        context,
        signalBar: bar,
        ruleName: name,
        group: 'baseline',
        trailingStopPct,
        tier: bar.tier || 'Unknown',
      })
      if (!trade) continue
      trades.push(trade)
      openUntil = trade.exitSec + config.cooldownMinutes * 60
    }
  }
  return trades
}

function seededRandom(seed) {
  let state = seed >>> 0
  return () => {
    state = (1664525 * state + 1013904223) >>> 0
    return state / 2 ** 32
  }
}

function runBaselines(contexts, targetCount) {
  const out = {
    momentum_alone: runBaselineRule(
      contexts,
      'momentum_alone',
      (bar, prev) => Number(prev?.changePct) <= config.baselines.momentumChangePct && Number(bar.changePct) > config.baselines.momentumChangePct,
      5,
    ),
    relvol_alone: runBaselineRule(
      contexts,
      'relvol_alone',
      (bar, prev) => Number(prev?.relVolume) <= config.baselines.relVolumeThreshold && Number(bar.relVolume) > config.baselines.relVolumeThreshold,
      5,
    ),
    screener_top_rank: runBaselineRule(
      contexts,
      'screener_top_rank',
      (bar, prev) => Number(bar.rank) > 0 &&
        Number(bar.rank) <= config.baselines.topRankThreshold &&
        (!prev || !Number.isFinite(Number(prev.rank)) || Number(prev.rank) > config.baselines.topRankThreshold),
      5,
    ),
  }

  const rng = seededRandom(42)
  const randomTrades = []
  const flatBars = contexts.flatMap(context => context.bars.filter(bar => config.sessionMode !== 'regular' || isRegularSession(bar.minute)).map(bar => ({ context, bar })))
  for (let i = 0; i < targetCount && flatBars.length; i += 1) {
    const picked = flatBars[Math.floor(rng() * flatBars.length)]
    const trade = simulateSignal({
      context: picked.context,
      signalBar: picked.bar,
      ruleName: 'random_matched_count',
      group: 'baseline',
      trailingStopPct: 5,
      tier: picked.bar.tier || 'Unknown',
    })
    if (trade) randomTrades.push(trade)
  }
  out.random_matched_count = randomTrades
  return out
}

function splitStats(trades) {
  const sorted = [...trades].sort((a, b) => a.signalSec - b.signalSec)
  const n = sorted.length
  const a = Math.floor(n * 0.6)
  const b = Math.floor(n * 0.8)
  return {
    development_60pct: summarizeTrades(sorted.slice(0, a)),
    validation_20pct: summarizeTrades(sorted.slice(a, b)),
    untouched_test_20pct: summarizeTrades(sorted.slice(b)),
  }
}

function temporalSplitStats(trades, startSec, endSec) {
  const span = Number(endSec) - Number(startSec)
  if (!Number.isFinite(span) || span <= 0) return splitStats(trades)
  const a = Number(startSec) + span * 0.6
  const b = Number(startSec) + span * 0.8
  return {
    development_60pct: summarizeTrades(trades.filter(t => Number(t.signalSec) < a)),
    validation_20pct: summarizeTrades(trades.filter(t => Number(t.signalSec) >= a && Number(t.signalSec) < b)),
    untouched_test_20pct: summarizeTrades(trades.filter(t => Number(t.signalSec) >= b)),
  }
}

function optimizationScore(stats, walk) {
  const trades = Number(stats.trades || 0)
  if (!trades) return -999
  const meanNet = Number(stats.meanNetReturnPct ?? -999)
  const pf = Number(stats.profitFactor ?? 0)
  const dd = Math.abs(Number(stats.maxDrawdownPctPoints ?? 0))
  const val = walk?.validation_20pct || {}
  const test = walk?.untouched_test_20pct || {}
  const valMean = Number(val.meanNetReturnPct ?? -999)
  const testMean = Number(test.meanNetReturnPct ?? -999)
  const sampleBonus = Math.min(1.5, Math.log10(Math.max(1, trades)) * 0.75)
  const pfBonus = Math.min(1.5, Math.max(0, pf - 1) * 0.75)
  const consistencyPenalty = (valMean <= 0 ? 2 : 0) + (testMean <= 0 ? 2 : 0)
  const sparsePenalty = trades < 20 ? 2 : trades < 35 ? 0.75 : 0
  const drawdownPenalty = Math.min(3, dd / 50)
  return Number((meanNet + sampleBonus + pfBonus - consistencyPenalty - sparsePenalty - drawdownPenalty).toFixed(4))
}

function promotionRows(tradesByName, startSec, endSec) {
  return Object.entries(tradesByName)
    .map(([name, trades]) => {
      const stats = summarizeTrades(trades)
      const sequenceWalk = splitStats(trades)
      const temporalWalk = temporalSplitStats(trades, startSec, endSec)
      const val = sequenceWalk.validation_20pct
      const test = sequenceWalk.untouched_test_20pct
      const temporalVal = temporalWalk.validation_20pct
      const temporalTest = temporalWalk.untouched_test_20pct
      const robustEnough = Number(stats.trades || 0) >= 20 &&
        Number(stats.meanNetReturnPct ?? -999) > 0 &&
        Number(stats.profitFactor ?? 0) >= 1.15 &&
        Number(val.trades || 0) >= 3 &&
        Number(test.trades || 0) >= 3 &&
        Number(val.meanNetReturnPct ?? -999) > 0 &&
        Number(test.meanNetReturnPct ?? -999) > 0 &&
        (Number(temporalTest.trades || 0) === 0 || Number(temporalTest.meanNetReturnPct ?? -999) > 0)
      const score = optimizationScore(stats, sequenceWalk)
      return {
        name,
        promotionStatus: robustEnough ? 'promote_candidate' : 'watch_or_reject',
        optimizationScore: score,
        trades: stats.trades,
        winRate: stats.winRate,
        meanNetReturnPct: stats.meanNetReturnPct,
        medianNetReturnPct: stats.medianNetReturnPct,
        profitFactor: stats.profitFactor,
        maxDrawdownPctPoints: stats.maxDrawdownPctPoints,
        devTrades: sequenceWalk.development_60pct.trades,
        devMeanNetReturnPct: sequenceWalk.development_60pct.meanNetReturnPct,
        devProfitFactor: sequenceWalk.development_60pct.profitFactor,
        validationTrades: val.trades,
        validationMeanNetReturnPct: val.meanNetReturnPct,
        validationProfitFactor: val.profitFactor,
        testTrades: test.trades,
        testMeanNetReturnPct: test.meanNetReturnPct,
        testProfitFactor: test.profitFactor,
        temporalDevTrades: temporalWalk.development_60pct.trades,
        temporalDevMeanNetReturnPct: temporalWalk.development_60pct.meanNetReturnPct,
        temporalValidationTrades: temporalVal.trades,
        temporalValidationMeanNetReturnPct: temporalVal.meanNetReturnPct,
        temporalTestTrades: temporalTest.trades,
        temporalTestMeanNetReturnPct: temporalTest.meanNetReturnPct,
        exitCounts: stats.exitCounts,
      }
    })
    .sort((a, b) => {
      const ap = a.promotionStatus === 'promote_candidate' ? 1 : 0
      const bp = b.promotionStatus === 'promote_candidate' ? 1 : 0
      return bp - ap || Number(b.optimizationScore) - Number(a.optimizationScore)
    })
}

function buildReport(summary, statsRows, sensitivityRows, promotion = []) {
  const fmtDate = sec => sec ? `${new Date(sec * 1000).toISOString()} (${etParts(sec).date} ET)` : 'n/a'
  const lines = []
  lines.push('# Message-Density Threshold Audit And Backtest')
  lines.push('')
  lines.push('## Audit Summary')
  lines.push(`- Price source: Mongo \`${config.priceCollection}\` snapshots, expanded into per-ticker real snapshot bars. No durable Yahoo/candle collection was found, so this is a snapshot-bar backtest, not a full exchange one-minute OHLC backtest.`)
  lines.push(`- Price coverage: ${fmtDate(summary.price.priceStartSec)} to ${fmtDate(summary.price.priceEndSec)}.`)
  lines.push(`- Eligible tickers: ${summary.price.eligibleTickers}; dropped sparse/static tickers: ${summary.price.droppedStaticOrSparseTickers}.`)
  lines.push(`- Social source: Mongo \`${config.socialCollection}\`; platforms in range: ${JSON.stringify(summary.social.platformCounts)}.`)
  lines.push('- Density unit used by the app/backend: messages per minute (`message_count / bucket_minutes`). Screener rows use count divided by the selected rolling window.')
  lines.push('- Missing social minutes are omitted by the UI/backend series; this backtest fills missing social minutes as 0 messages for causal trailing density.')
  lines.push('- Price bars are not fabricated or forward-filled. Signals execute at the next real regular-session snapshot bar.')
  lines.push('- Look-ahead finding: `app/src/lib/chartAgg.ts` uses centered `smoothSame` for chart overlays. This report does not use it for deployable results; all backtest smoothing is trailing/causal.')
  lines.push('- Duplicate risk: raw message counts and per-minute dedup event counts are both recorded. Duplicate-driven signals are flagged when 3+ raw messages collapse to 1-2 dedup events.')
  lines.push('- Market-cap tier caveat: FinViz market cap values are normalized as millions when sourced from FinViz. If older rows use mixed units, tier assignment has classification risk.')
  lines.push('- Stop caveat: FinViz snapshots provide close-like prices, not intrabar OHLC. Stops are close-based and therefore cannot prove true intrabar stop ordering.')
  lines.push('')
  lines.push('## Exact Submitted Config Results')
  for (const row of statsRows.filter(r => r.group === 'tier_exact' || r.group === 'pooled_exact')) {
    lines.push(`- ${row.group}/${row.name}: trades=${row.trades}, winRate=${row.winRate}, meanNet=${row.meanNetReturnPct}, PF=${row.profitFactor}, exits=${JSON.stringify(row.exitCounts)}`)
  }
  lines.push('')
  lines.push('## Baselines')
  for (const row of statsRows.filter(r => r.group === 'baseline')) {
    lines.push(`- ${row.name}: trades=${row.trades}, winRate=${row.winRate}, meanNet=${row.meanNetReturnPct}, PF=${row.profitFactor}`)
  }
  lines.push('')
  lines.push('## Robustness Snapshot')
  const top = [...sensitivityRows].filter(r => r.trades >= 5).sort((a, b) => (b.meanNetReturnPct ?? -999) - (a.meanNetReturnPct ?? -999)).slice(0, 10)
  if (top.length) {
    for (const row of top) lines.push(`- ${row.family}: window=${row.windowMinutes}, C=${row.thresholdC ?? ''}, trail=${row.trailingStopPct}, nanoRise=${row.densityRiseMultiple ?? ''}, min60=${row.minTrailing60Messages ?? ''}, trades=${row.trades}, meanNet=${row.meanNetReturnPct}, winRate=${row.winRate}`)
  } else {
    lines.push('- No sensitivity setting produced at least 5 trades in the available snapshot data.')
  }
  lines.push('')
  lines.push('## Improvement Tests')
  const improved = statsRows
    .filter(r => r.group === 'improvement')
    .filter(r => r.trades >= 5)
    .sort((a, b) => (b.meanNetReturnPct ?? -999) - (a.meanNetReturnPct ?? -999))
  if (improved.length) {
    for (const row of improved.slice(0, 12)) {
      lines.push(`- ${row.name}: trades=${row.trades}, winRate=${row.winRate}, meanNet=${row.meanNetReturnPct}, PF=${row.profitFactor}, exits=${JSON.stringify(row.exitCounts)}`)
    }
  } else {
    lines.push('- No improved variant produced at least 5 trades in the available snapshot data.')
  }
  lines.push('')
  lines.push('## Optimization Promotion Candidates')
  const promoted = promotion.filter(row => row.promotionStatus === 'promote_candidate').slice(0, 10)
  const topWatched = promotion.slice(0, 10)
  if (promoted.length) {
    for (const row of promoted) {
      lines.push(`- PROMOTE ${row.name}: score=${row.optimizationScore}, trades=${row.trades}, meanNet=${row.meanNetReturnPct}, PF=${row.profitFactor}, valMean=${row.validationMeanNetReturnPct}, testMean=${row.testMeanNetReturnPct}`)
    }
  } else {
    lines.push('- No parameter set passed the full promotion gate. Top watch/reject rows are listed below for diagnosis.')
  }
  for (const row of topWatched) {
    lines.push(`- ${row.promotionStatus} ${row.name}: score=${row.optimizationScore}, trades=${row.trades}, meanNet=${row.meanNetReturnPct}, PF=${row.profitFactor}, valMean=${row.validationMeanNetReturnPct}, testMean=${row.testMeanNetReturnPct}`)
  }
  lines.push('')
  lines.push('## Files')
  lines.push('- `tier_exact_trades.csv`, `pooled_exact_trades.csv`, `baseline_trades.csv`, `improved_trades.csv`')
  lines.push('- `strategy_summary.csv`, `sensitivity_summary.csv`, `improvement_summary.csv`, `optimization_summary.csv`, `promotion_candidates.csv`, `summary.json`')
  return lines.join('\n') + '\n'
}

async function main() {
  const client = new MongoClient(config.mongoUri)
  await client.connect()
  try {
    const db = client.db(config.database)
    progress('loading price snapshots')
    const price = await loadPriceBars(db)
    const priceTickers = [...price.barsByTicker.keys()].slice(0, config.maxTickers)
    const barsByTicker = new Map(priceTickers.map(t => [t, price.barsByTicker.get(t)]))
    progress(`loading social events for ${priceTickers.length} tickers`)
    const social = await loadSocialEvents(db, priceTickers, price.diagnostics.priceStartSec, price.diagnostics.priceEndSec)
    progress('building ticker contexts')
    const contexts = [...barsByTicker.entries()].map(([ticker, bars]) => buildTickerContext(ticker, bars, social))

    progress('running exact tier rules')
    const tier = runTierRules(contexts)
    progress('running exact pooled rules')
    const pooled = runPooledRules(contexts)
    const exactTierTrades = Object.values(tier).flat().sort((a, b) => a.signalSec - b.signalSec)
    const exactPooledTrades = Object.values(pooled).flat().sort((a, b) => a.signalSec - b.signalSec)
    progress('running sensitivity rules')
    const sensitivityRows = runSensitivity(contexts)
    progress('running improvement tests')
    const improvements = runImprovementTests(contexts)
    const improvementTrades = Object.values(improvements).flat().sort((a, b) => a.signalSec - b.signalSec)
    progress('running optimization grid')
    const optimization = runOptimizationGrid(contexts)
    const optimizationRows = buildStatsRows('optimization', optimization)
    const promotion = promotionRows(optimization, price.diagnostics.priceStartSec, price.diagnostics.priceEndSec)
    const bestPromotionName = promotion[0]?.name || null
    const bestPromotionTrades = bestPromotionName ? (optimization[bestPromotionName] || []) : []
    progress('running baselines')
    const baselines = runBaselines(contexts, exactTierTrades.length || exactPooledTrades.length || 50)
    const baselineTrades = Object.values(baselines).flat().sort((a, b) => a.signalSec - b.signalSec)
    const statsRows = [
      ...buildStatsRows('tier_exact', tier),
      ...buildStatsRows('pooled_exact', pooled),
      ...buildStatsRows('improvement', improvements),
      ...optimizationRows,
      ...buildStatsRows('baseline', baselines),
    ]

    const allExact = [...exactTierTrades, ...exactPooledTrades]
    const signalAudit = {
      exactSignalCount: allExact.length,
      duplicateDrivenPct: allExact.length ? pct(allExact.filter(t => t.duplicateDriven).length / allExact.length * 100) : null,
      alreadyUpMoreThan3PctBeforeEntryPct: allExact.length ? pct(allExact.filter(t => t.alreadyUpMoreThan3PctBeforeEntry).length / allExact.length * 100) : null,
      halfMoveBeforeEntryPct: allExact.length ? pct(allExact.filter(t => t.halfMoveBeforeEntry).length / allExact.length * 100) : null,
    }

    const summary = {
      generatedAt: new Date().toISOString(),
      config,
      price: price.diagnostics,
      social: social.diagnostics,
      exactTier: Object.fromEntries(Object.entries(tier).map(([k, v]) => [k, summarizeTrades(v)])),
      exactPooled: Object.fromEntries(Object.entries(pooled).map(([k, v]) => [k, summarizeTrades(v)])),
      improvements: Object.fromEntries(Object.entries(improvements).map(([k, v]) => [k, summarizeTrades(v)])),
      improvementWalkForward: Object.fromEntries(Object.entries(improvements).map(([k, v]) => [k, splitStats(v)])),
      optimization: Object.fromEntries(Object.entries(optimization).map(([k, v]) => [k, summarizeTrades(v)])),
      optimizationPromotion: promotion.slice(0, 50),
      bestOptimizationCandidate: promotion[0] || null,
      baselines: Object.fromEntries(Object.entries(baselines).map(([k, v]) => [k, summarizeTrades(v)])),
      signalAudit,
      walkForward: splitStats(allExact),
    }

    writeCsv('tier_exact_trades.csv', exactTierTrades)
    writeCsv('pooled_exact_trades.csv', exactPooledTrades)
    writeCsv('improved_trades.csv', improvementTrades)
    writeCsv('baseline_trades.csv', baselineTrades)
    writeCsv('best_optimization_trades.csv', bestPromotionTrades.sort((a, b) => a.signalSec - b.signalSec))
    writeCsv('strategy_summary.csv', statsRows)
    writeCsv('improvement_summary.csv', buildStatsRows('improvement', improvements))
    writeCsv('optimization_summary.csv', optimizationRows)
    writeCsv('promotion_candidates.csv', promotion)
    writeCsv('sensitivity_summary.csv', sensitivityRows)
    fs.writeFileSync(path.join(outputDir, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
    fs.writeFileSync(path.join(outputDir, 'report.md'), buildReport(summary, statsRows, sensitivityRows, promotion))
    progress('wrote outputs')

    console.log(JSON.stringify({
      ok: true,
      outputDir,
      eligibleTickers: price.diagnostics.eligibleTickers,
      exactTierTrades: exactTierTrades.length,
      exactPooledTrades: exactPooledTrades.length,
      improvementTrades: improvementTrades.length,
      optimizationVariants: Object.keys(optimization).length,
      bestOptimizationCandidate: promotion[0] || null,
      baselineTrades: baselineTrades.length,
      sensitivityRows: sensitivityRows.length,
      signalAudit,
    }, null, 2))
  } finally {
    await client.close()
  }
}

main().catch(err => {
  console.error(err)
  process.exitCode = 1
})
