# Message-Density Threshold Audit And Backtest

## Audit Summary
- Price source: Mongo `finviz_momentum_snapshots` snapshots, expanded into per-ticker real snapshot bars. No durable Yahoo/candle collection was found, so this is a snapshot-bar backtest, not a full exchange one-minute OHLC backtest.
- Price coverage: 2026-06-28T01:31:00.000Z (2026-06-27 ET) to 2026-07-07T17:16:00.000Z (2026-07-07 ET).
- Eligible tickers: 478; dropped sparse/static tickers: 480.
- Social source: Mongo `socials`; platforms in range: {"StockTwits":19860,"Bluesky":650}.
- Density unit used by the app/backend: messages per minute (`message_count / bucket_minutes`). Screener rows use count divided by the selected rolling window.
- Missing social minutes are omitted by the UI/backend series; this backtest fills missing social minutes as 0 messages for causal trailing density.
- Price bars are not fabricated or forward-filled. Signals execute at the next real regular-session snapshot bar.
- Look-ahead finding: `app/src/lib/chartAgg.ts` uses centered `smoothSame` for chart overlays. This report does not use it for deployable results; all backtest smoothing is trailing/causal.
- Duplicate risk: raw message counts and per-minute dedup event counts are both recorded. Duplicate-driven signals are flagged when 3+ raw messages collapse to 1-2 dedup events.
- Market-cap tier caveat: FinViz market cap values are normalized as millions when sourced from FinViz. If older rows use mixed units, tier assignment has classification risk.
- Stop caveat: FinViz snapshots provide close-like prices, not intrabar OHLC. Stops are close-based and therefore cannot prove true intrabar stop ordering.

## Exact Submitted Config Results
- tier_exact/Mega: trades=26, winRate=0.1538, meanNet=-2.2115, PF=0.2538, exits={"trailing_stop_close_based":15,"protective_and_trailing_same_close":9,"eod_flatten":2}
- tier_exact/Large: trades=0, winRate=null, meanNet=null, PF=0, exits={}
- tier_exact/Mid: trades=0, winRate=null, meanNet=null, PF=0, exits={}
- tier_exact/Small: trades=2, winRate=0.5, meanNet=-0.537, PF=0.755, exits={"eod_flatten":1,"protective_and_trailing_same_close":1}
- tier_exact/Nano15: trades=56, winRate=0.1607, meanNet=-2.8572, PF=0.3387, exits={"eod_flatten":11,"protective_stop_close_based":40,"trailing_stop_close_based":3,"protective_and_trailing_same_close":2}
- tier_exact/Nano20: trades=56, winRate=0.1786, meanNet=-1.7495, PF=0.5912, exits={"eod_flatten":14,"protective_stop_close_based":42}
- pooled_exact/pooled_2h_c0.7_trail2: trades=49, winRate=0.2245, meanNet=-0.901, PF=0.5448, exits={"trailing_stop_close_based":35,"protective_and_trailing_same_close":9,"eod_flatten":5}
- pooled_exact/pooled_3h_c0.7_trail2: trades=35, winRate=0.2571, meanNet=-0.9443, PF=0.5626, exits={"trailing_stop_close_based":24,"protective_and_trailing_same_close":9,"eod_flatten":2}
- pooled_exact/pooled_4h_c0.7_trail2: trades=32, winRate=0.2813, meanNet=-0.9532, PF=0.5773, exits={"trailing_stop_close_based":24,"protective_and_trailing_same_close":8}
- pooled_exact/pooled_5h_c0.4_trail2: trades=53, winRate=0.2642, meanNet=-1.3799, PF=0.3817, exits={"trailing_stop_close_based":40,"protective_and_trailing_same_close":10,"eod_flatten":3}
- pooled_exact/pooled_6h_c0.0_trail8: trades=40, winRate=0.275, meanNet=-1.9369, PF=0.3545, exits={"protective_stop_close_based":21,"protective_and_trailing_same_close":2,"trailing_stop_close_based":8,"eod_flatten":9}

## Baselines
- momentum_alone: trades=266, winRate=0.2406, meanNet=-1.2033, PF=0.4035
- relvol_alone: trades=58, winRate=0.2759, meanNet=-1.4987, PF=0.4033
- screener_top_rank: trades=288, winRate=0.2153, meanNet=-1.8506, PF=0.3845
- random_matched_count: trades=139, winRate=0.3381, meanNet=-0.5561, PF=0.6082

## Robustness Snapshot
- corr_threshold_window_oat: window=120, C=0.8, trail=2, nanoRise=, min60=, trades=33, meanNet=0.0211, winRate=0.2727
- corr_threshold_window_oat: window=240, C=0.9, trail=2, nanoRise=, min60=, trades=9, meanNet=-0.0392, winRate=0.3333
- corr_threshold_window_oat: window=180, C=-0.2, trail=2, nanoRise=, min60=, trades=58, meanNet=-0.2899, winRate=0.3276
- corr_threshold_window_oat: window=240, C=-0.2, trail=2, nanoRise=, min60=, trades=46, meanNet=-0.4785, winRate=0.3913
- corr_threshold_window_oat: window=180, C=0.2, trail=2, nanoRise=, min60=, trades=67, meanNet=-0.5897, winRate=0.4179
- corr_threshold_window_oat: window=360, C=0.2, trail=2, nanoRise=, min60=, trades=54, meanNet=-0.5978, winRate=0.2963
- corr_threshold_window_oat: window=300, C=0.9, trail=2, nanoRise=, min60=, trades=8, meanNet=-0.7126, winRate=0.25
- corr_threshold_window_oat: window=360, C=0.9, trail=2, nanoRise=, min60=, trades=9, meanNet=-0.7815, winRate=0.3333
- corr_threshold_window_oat: window=360, C=0.7, trail=2, nanoRise=, min60=, trades=29, meanNet=-0.783, winRate=0.2414
- corr_threshold_window_oat: window=360, C=-0.2, trail=2, nanoRise=, min60=, trades=38, meanNet=-0.8905, winRate=0.2632

## Improvement Tests
- local_w120_c0.8_t2_pre60le5_msg3: trades=7, winRate=0.4286, meanNet=1.1562, PF=1.6527, exits={"trailing_stop_close_based":5,"eod_flatten":1,"protective_and_trailing_same_close":1}
- local_w120_c0.8_t3_pre60le5_msg3: trades=7, winRate=0.4286, meanNet=0.8259, PF=1.4161, exits={"trailing_stop_close_based":5,"eod_flatten":1,"protective_and_trailing_same_close":1}
- local_w180_c0.2_t2_pre60le3: trades=37, winRate=0.5676, meanNet=0.4691, PF=1.5373, exits={"trailing_stop_close_based":27,"eod_flatten":9,"protective_and_trailing_same_close":1}
- local_w120_c0.8_t2_pre60le3: trades=13, winRate=0.3077, meanNet=0.3175, PF=1.24, exits={"eod_flatten":5,"trailing_stop_close_based":7,"protective_and_trailing_same_close":1}
- local_w240_c-0.2_t2_pre60le3: trades=29, winRate=0.4483, meanNet=0.191, PF=1.1346, exits={"trailing_stop_close_based":18,"eod_flatten":6,"protective_and_trailing_same_close":5}
- local_w120_c0.8_t2_pre60le5: trades=15, winRate=0.2667, meanNet=-0.1698, PF=0.8933, exits={"trailing_stop_close_based":8,"eod_flatten":5,"protective_and_trailing_same_close":2}
- local_w180_c-0.2_t2_pre60le3: trades=41, winRate=0.3171, meanNet=-0.4112, PF=0.7632, exits={"trailing_stop_close_based":27,"eod_flatten":7,"protective_and_trailing_same_close":7}
- local_w120_c0.85_t2_pre60le5: trades=5, winRate=0.2, meanNet=-1.0961, PF=0.4323, exits={"trailing_stop_close_based":3,"protective_and_trailing_same_close":1,"eod_flatten":1}
- submitted_pooled_pre60le3: trades=86, winRate=0.2442, meanNet=-1.269, PF=0.4198, exits={"protective_and_trailing_same_close":11,"trailing_stop_close_based":50,"protective_stop_close_based":8,"eod_flatten":17}
- submitted_pooled_pre60le5_msg3: trades=72, winRate=0.2361, meanNet=-1.5213, PF=0.4181, exits={"trailing_stop_close_based":42,"protective_stop_close_based":7,"protective_and_trailing_same_close":15,"eod_flatten":8}
- nano20_r2.5_pre60le5_msg5: trades=44, winRate=0.2045, meanNet=-2.3324, PF=0.4484, exits={"protective_stop_close_based":30,"eod_flatten":14}
- nano20_pre60le5_msg3: trades=40, winRate=0.2, meanNet=-2.3385, PF=0.4305, exits={"protective_stop_close_based":28,"eod_flatten":12}

## Optimization Promotion Candidates
- PROMOTE opt_w120_c0.4_t5_pre60le1_msg3: score=3.9774, trades=20, meanNet=2.5002, PF=3.1563, valMean=2.0836, testMean=1.6656
- PROMOTE opt_w120_c0.4_t3_pre60le1_msg3: score=3.0188, trades=20, meanNet=1.9123, PF=2.5057, valMean=1.9529, testMean=1.1596
- PROMOTE opt_w90_c0.3_t5_pre60le5_msg3: score=2.4151, trades=43, meanNet=1.1071, PF=1.6192, valMean=1.3805, testMean=1.0701
- PROMOTE opt_w90_c0.3_t5_pre60le3_msg3: score=2.024, trades=41, meanNet=0.8393, PF=1.4756, valMean=2.1184, testMean=1.0701
- PROMOTE opt_w180_c0.2_t2_pre60le3_msg0: score=1.7827, trades=37, meanNet=0.4691, PF=1.5373, valMean=1.4009, testMean=0.4956
- PROMOTE opt_w90_c0.3_t5_pre60le2_msg3: score=1.6846, trades=38, meanNet=0.6726, PF=1.3858, valMean=1.3673, testMean=1.6458
- PROMOTE opt_w90_c0.3_t5_pre60le1_msg3: score=1.6279, trades=34, meanNet=1.1464, PF=1.7504, valMean=2.6984, testMean=1.0291
- PROMOTE opt_w90_c0.1_t5_pre60le1_msg3: score=1.5721, trades=40, meanNet=0.6979, PF=1.3376, valMean=2.0811, testMean=1.5666
- PROMOTE opt_w180_c0.2_t2_pre60le2_msg0: score=1.5421, trades=33, meanNet=0.7027, PF=1.8843, valMean=1.7402, testMean=0.3758
- PROMOTE opt_w90_c0.3_t3_pre60le3_msg3: score=1.4864, trades=42, meanNet=0.4862, PF=1.3252, valMean=0.0053, testMean=0.887
- promote_candidate opt_w120_c0.4_t5_pre60le1_msg3: score=3.9774, trades=20, meanNet=2.5002, PF=3.1563, valMean=2.0836, testMean=1.6656
- promote_candidate opt_w120_c0.4_t3_pre60le1_msg3: score=3.0188, trades=20, meanNet=1.9123, PF=2.5057, valMean=1.9529, testMean=1.1596
- promote_candidate opt_w90_c0.3_t5_pre60le5_msg3: score=2.4151, trades=43, meanNet=1.1071, PF=1.6192, valMean=1.3805, testMean=1.0701
- promote_candidate opt_w90_c0.3_t5_pre60le3_msg3: score=2.024, trades=41, meanNet=0.8393, PF=1.4756, valMean=2.1184, testMean=1.0701
- promote_candidate opt_w180_c0.2_t2_pre60le3_msg0: score=1.7827, trades=37, meanNet=0.4691, PF=1.5373, valMean=1.4009, testMean=0.4956
- promote_candidate opt_w90_c0.3_t5_pre60le2_msg3: score=1.6846, trades=38, meanNet=0.6726, PF=1.3858, valMean=1.3673, testMean=1.6458
- promote_candidate opt_w90_c0.3_t5_pre60le1_msg3: score=1.6279, trades=34, meanNet=1.1464, PF=1.7504, valMean=2.6984, testMean=1.0291
- promote_candidate opt_w90_c0.1_t5_pre60le1_msg3: score=1.5721, trades=40, meanNet=0.6979, PF=1.3376, valMean=2.0811, testMean=1.5666
- promote_candidate opt_w180_c0.2_t2_pre60le2_msg0: score=1.5421, trades=33, meanNet=0.7027, PF=1.8843, valMean=1.7402, testMean=0.3758
- promote_candidate opt_w90_c0.3_t3_pre60le3_msg3: score=1.4864, trades=42, meanNet=0.4862, PF=1.3252, valMean=0.0053, testMean=0.887

## Files
- `tier_exact_trades.csv`, `pooled_exact_trades.csv`, `baseline_trades.csv`, `improved_trades.csv`
- `strategy_summary.csv`, `sensitivity_summary.csv`, `improvement_summary.csv`, `optimization_summary.csv`, `promotion_candidates.csv`, `summary.json`
