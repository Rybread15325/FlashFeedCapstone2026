'use client'
import useSWR from 'swr'
import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { clsx } from 'clsx'
import { CandlestickChart } from './CandlestickChart'
import { overlaySeries, type SocialSeries } from '@/lib/chartAgg'

const fetcher = (url: string) => fetch(url).then(r => r.json())
const STORAGE_KEY = 'flashfeed:chartsGridWatchlist:v2'
const SETTINGS_KEY = 'flashfeed:chartsGridSettings:v2'
const DEFAULT_TICKERS = ['SDOT', 'PCLA', 'IVF', 'WSHP', 'CRIS', 'INLF', 'ILLR', 'LVWR']

const TIMEFRAMES: Array<{ key: string; label: string }> = [
  { key: '1m', label: '1m' },
  { key: '3m', label: '3m' },
  { key: '5m', label: '5m' },
  { key: '10m', label: '10m' },
  { key: '15m', label: '15m' },
  { key: '30m', label: '30m' },
  { key: '1h', label: '1h' },
  { key: '2h', label: '2h' },
  { key: '1d', label: '1D' },
]
const TF_MINUTES: Record<string, number> = {
  '1m': 1,
  '3m': 3,
  '5m': 5,
  '10m': 10,
  '15m': 15,
  '30m': 30,
  '1h': 60,
  '2h': 120,
  '1d': 1440,
}
const OVERLAY_TFS = new Set(['1m', '3m', '5m', '10m', '15m', '30m', '1h'])

const REFRESH: Array<{ key: string; label: string; ms: number }> = [
  { key: 'off', label: 'Off', ms: 0 },
  { key: '10s', label: '10s', ms: 10_000 },
  { key: '60s', label: '1m', ms: 60_000 },
]

const LAYOUTS: Array<{ key: string; label: string; cols: number; height: number; className: string }> = [
  { key: '2', label: '2 col', cols: 2, height: 300, className: 'grid-cols-1 xl:grid-cols-2' },
  { key: '3', label: '3 col', cols: 3, height: 240, className: 'grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3' },
  { key: '4', label: '4 col', cols: 4, height: 210, className: 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4' },
]

function normalizeTickers(value: string): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  value
    .toUpperCase()
    .split(/[\s,;]+/)
    .map(t => t.trim())
    .filter(Boolean)
    .forEach(ticker => {
      if (!/^[A-Z][A-Z0-9.-]{0,7}$/.test(ticker) || seen.has(ticker)) return
      seen.add(ticker)
      out.push(ticker)
    })
  return out.slice(0, 24)
}

function compact(value: unknown): string {
  const n = Number(value || 0)
  if (!Number.isFinite(n) || n === 0) return '--'
  if (Math.abs(n) >= 1e9) return `${(n / 1e9).toFixed(1)}B`
  if (Math.abs(n) >= 1e6) return `${(n / 1e6).toFixed(1)}M`
  if (Math.abs(n) >= 1e3) return `${(n / 1e3).toFixed(0)}K`
  return n.toLocaleString()
}

function ageLabel(sec?: number | string | null): string {
  const n = Number(sec || 0)
  if (!Number.isFinite(n) || n <= 0) return '--'
  const ts = n > 1_000_000_000_000 ? Math.floor(n / 1000) : n
  const age = Math.max(0, Math.floor(Date.now() / 1000) - ts)
  if (age < 60) return 'now'
  if (age < 3600) return `${Math.floor(age / 60)}m`
  if (age < 86_400) return `${Math.floor(age / 3600)}h`
  return `${Math.floor(age / 86_400)}d`
}

export function ChartsGridPage() {
  const { data: momentum } = useSWR('/api/momentum?limit=16&window_minutes=1440', fetcher, { refreshInterval: 30_000 })
  const [input, setInput] = useState('')
  const [tickers, setTickers] = useState<string[]>(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')
      return Array.isArray(stored) && stored.length ? normalizeTickers(stored.join(',')) : DEFAULT_TICKERS
    } catch {
      return DEFAULT_TICKERS
    }
  })
  const [tf, setTf] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').tf || '5m' } catch { return '5m' }
  })
  const [refresh, setRefresh] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').refresh || 'off' } catch { return 'off' }
  })
  const [layout, setLayout] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').layout || '3' } catch { return '3' }
  })
  const [showBollinger, setShowBollinger] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').showBollinger !== false } catch { return true }
  })
  const [showDensity, setShowDensity] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').showDensity !== false } catch { return true }
  })
  const [showSentiment, setShowSentiment] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}').showSentiment !== false } catch { return true }
  })
  const [nonce, setNonce] = useState(0)

  const momentumTickers = useMemo(() => {
    const rows = Array.isArray(momentum?.tickers) ? momentum.tickers : []
    return normalizeTickers(rows.map((row: any) => row.ticker).join(','))
  }, [momentum])
  const activeLayout = LAYOUTS.find(item => item.key === layout) || LAYOUTS[1]

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tickers))
  }, [tickers])

  useEffect(() => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({ tf, refresh, layout, showBollinger, showDensity, showSentiment }))
  }, [tf, refresh, layout, showBollinger, showDensity, showSentiment])

  useEffect(() => {
    const ms = REFRESH.find(r => r.key === refresh)?.ms ?? 0
    if (!ms) return
    const id = window.setInterval(() => setNonce(n => n + 1), ms)
    return () => window.clearInterval(id)
  }, [refresh])

  const addTickers = () => {
    const next = normalizeTickers([...tickers, ...normalizeTickers(input)].join(','))
    if (next.length) setTickers(next)
    setInput('')
  }

  const removeTicker = (ticker: string) => {
    setTickers(current => current.filter(t => t !== ticker))
  }

  const loadMomentum = () => {
    if (momentumTickers.length) setTickers(momentumTickers.slice(0, 16))
  }

  const clearWatchlist = () => setTickers([])

  return (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-white font-semibold text-lg">Charts Grid</h1>
          <p className="text-xs text-neutral mt-0.5">
            Custom multi-chart watchlist using the same candlestick engine as Single Chart.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral">{tickers.length} symbols</span>
          <Link
            to="/charts"
            className="text-xs px-3 py-1.5 rounded border border-border text-neutral hover:text-white hover:border-accent transition-colors"
          >
            Single chart
          </Link>
        </div>
      </div>

      <section className="rounded-lg border border-border bg-surface p-3">
        <div className="grid gap-3 xl:grid-cols-[minmax(300px,1fr)_auto]">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <input
                value={input}
                onChange={event => setInput(event.target.value.toUpperCase())}
                onKeyDown={event => { if (event.key === 'Enter') addTickers() }}
                placeholder="Add symbols: NVDA, TSLA, AAPL"
                className="min-w-0 flex-1 rounded border border-border bg-bg px-3 py-2 text-sm text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-accent"
              />
              <button onClick={addTickers} className="rounded bg-accent px-3 py-2 text-xs font-medium text-white hover:bg-sky-400">
                Add
              </button>
              <button onClick={loadMomentum} className="rounded border border-border px-3 py-2 text-xs text-neutral hover:border-accent hover:text-white">
                Use Momentum
              </button>
              <button onClick={clearWatchlist} className="rounded border border-border px-3 py-2 text-xs text-neutral hover:border-red-400 hover:text-red-300">
                Clear
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {tickers.map(ticker => (
                <button
                  key={ticker}
                  onClick={() => removeTicker(ticker)}
                  title={`Remove ${ticker}`}
                  className="rounded border border-accent/30 bg-accent/10 px-2 py-1 text-xs font-mono text-accent hover:border-red-400 hover:bg-red-500/10 hover:text-red-300"
                >
                  {ticker} x
                </button>
              ))}
              {!tickers.length && <span className="text-xs text-neutral">Add symbols or load the current Momentum movers.</span>}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 xl:justify-end">
            <Segment label="Timeframe">
              {TIMEFRAMES.map(item => (
                <button key={item.key} onClick={() => setTf(item.key)}
                  className={clsx('px-2.5 py-1 text-xs transition-colors', tf === item.key ? 'bg-accent text-white' : 'bg-bg text-neutral hover:text-white')}>
                  {item.label}
                </button>
              ))}
            </Segment>
            <Segment label="Layout">
              {LAYOUTS.map(item => (
                <button key={item.key} onClick={() => setLayout(item.key)}
                  className={clsx('px-2.5 py-1 text-xs transition-colors', layout === item.key ? 'bg-accent text-white' : 'bg-bg text-neutral hover:text-white')}>
                  {item.label}
                </button>
              ))}
            </Segment>
            <Segment label="Refresh">
              {REFRESH.map(item => (
                <button key={item.key} onClick={() => setRefresh(item.key)}
                  className={clsx('px-2.5 py-1 text-xs transition-colors', refresh === item.key ? 'bg-accent text-white' : 'bg-bg text-neutral hover:text-white')}>
                  {item.label}
                </button>
              ))}
            </Segment>
            <label className="flex items-center gap-1.5 text-xs text-neutral cursor-pointer select-none">
              <input type="checkbox" checked={showBollinger} onChange={event => setShowBollinger(event.target.checked)} className="accent-sky-500" />
              Bollinger
            </label>
            <label className="flex items-center gap-1.5 text-xs text-neutral cursor-pointer select-none">
              <input type="checkbox" checked={showDensity} onChange={event => setShowDensity(event.target.checked)} className="accent-orange-500" />
              Density
            </label>
            <label className="flex items-center gap-1.5 text-xs text-neutral cursor-pointer select-none">
              <input type="checkbox" checked={showSentiment} onChange={event => setShowSentiment(event.target.checked)} className="accent-green-500" />
              Sentiment
            </label>
          </div>
        </div>
      </section>

      {tickers.length ? (
        <div className={clsx('grid gap-3', activeLayout.className)}>
          {tickers.map(ticker => (
            <WatchChartTile
              key={`${ticker}-${tf}`}
              ticker={ticker}
              tf={tf}
              nonce={nonce}
              height={activeLayout.height}
              showBollinger={showBollinger}
              showDensity={showDensity}
              showSentiment={showSentiment}
              onRemove={() => removeTicker(ticker)}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-surface py-16 text-center text-sm text-neutral">
          Your grid is empty. Add tickers above or load Momentum movers.
        </div>
      )}
    </div>
  )
}

function WatchChartTile({ ticker, tf, nonce, height, showBollinger, showDensity, showSentiment, onRemove }: {
  ticker: string
  tf: string
  nonce: number
  height: number
  showBollinger: boolean
  showDensity: boolean
  showSentiment: boolean
  onRemove: () => void
}) {
  const { data, isLoading, error } = useSWR(`/api/charts/${encodeURIComponent(ticker)}?tf=${tf}&_r=${nonce}`, fetcher, {
    refreshInterval: 0,
    revalidateOnFocus: false,
  })
  const candles = Array.isArray(data?.candles) ? data.candles : []
  const firstCandleTime = Number(candles[0]?.time || 0)
  const lastCandleTime = Number(candles[candles.length - 1]?.time || 0)
  const overlayEnabled = OVERLAY_TFS.has(tf) && (showDensity || showSentiment) && firstCandleTime > 0 && lastCandleTime > firstCandleTime
  const overlayWindowMinutes = Math.max(1440, Math.min(10080, Math.ceil((lastCandleTime - firstCandleTime) / 60) + 120))
  const socialKey = overlayEnabled
    ? `/api/chart/social?ticker=${encodeURIComponent(ticker)}&window_minutes=${overlayWindowMinutes}&bucket_minutes=1&start_sec=${firstCandleTime}&end_sec=${lastCandleTime}&_r=${nonce}`
    : null
  const { data: socialPayload } = useSWR(socialKey, fetcher, {
    refreshInterval: 0,
    revalidateOnFocus: false,
  })
  const socialSeries: SocialSeries | null = socialPayload?.messages ? {
    labels: socialPayload.labels || [],
    density: socialPayload.density || [],
    times: socialPayload.times || [],
    sent_labels: socialPayload.sent_labels || socialPayload.labels || [],
    scores_smooth: socialPayload.scores_smooth || socialPayload.scores || [],
    sent_times: socialPayload.sent_times || socialPayload.times || [],
  } : null
  const overlays = useMemo(() => {
    if (!overlayEnabled || !candles.length || !socialSeries) return { density: [], sentiment: [] }
    return overlaySeries(candles as any, socialSeries, TF_MINUTES[tf] || 5, 15)
  }, [candles, socialSeries, tf, overlayEnabled])
  const last = candles[candles.length - 1]
  const first = candles[0]
  const secondLast = candles.length >= 2 ? candles[candles.length - 2] : null
  const lastClose = Number(last?.close || 0)
  const quote = data?.current_quote || null
  const quotePrice = Number(quote?.price)
  const quoteChange = Number(quote?.change_pct)
  const quoteVolume = Number(quote?.volume)
  // For daily/weekly timeframes, calculate change from the previous bar's close
  // (the first candle of a multi-year daily range is not today's open).
  // For intraday, use the first candle's open as session baseline.
  const isDailyTf = tf === '1d' || tf === '2d' || tf === '1w'
  let baseline = 0
  if (isDailyTf && secondLast?.close) {
    baseline = Number(secondLast.close) // yesterday close
  } else {
    baseline = Number(first?.open || first?.close || 0) // session open
  }
  const change = baseline ? ((lastClose - baseline) / baseline) * 100 : 0
  // Clamp extreme intraday changes (>100%) as likely data errors
  const candleDisplayChange = Math.abs(change) > 100 && !isDailyTf ? null : change
  const displayChange = Number.isFinite(quoteChange) ? quoteChange : candleDisplayChange
  const displayPrice = Number.isFinite(quotePrice) && quotePrice > 0 ? quotePrice : lastClose
  const up = (displayChange ?? 0) >= 0
  const displayVolume = Number.isFinite(quoteVolume) && quoteVolume > 0
    ? quoteVolume
    : Number(last?.volume || 0)
  const cacheRefreshedAt = null // Backend does not yet send cacheRefreshedAt; placeholder for future use

  return (
    <article className="overflow-hidden rounded-lg border border-border bg-surface">
      <div className="flex items-center justify-between gap-3 border-b border-border px-3 py-2">
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <Link to={`/charts?t=${encodeURIComponent(ticker)}`} className="font-mono text-base font-bold text-accent hover:text-sky-300">
              {ticker}
            </Link>
            <span className={clsx('font-mono text-xs', up ? 'text-emerald-400' : 'text-red-400')}>
              {Number.isFinite(displayChange) ? `${up ? '+' : ''}${displayChange?.toFixed(2)}%` : '--'}
            </span>
            <span className="text-[10px] text-neutral">{data?.n ?? candles.length} bars</span>
          </div>
          <div className="mt-0.5 flex items-center gap-3 text-[10px] text-neutral">
            <span className="font-mono">{displayPrice ? `$${displayPrice.toFixed(2)}` : '--'}</span>
            <span>Vol {compact(displayVolume)}</span>
            <span>Updated {ageLabel(last?.time)}</span>
            {cacheRefreshedAt && <span className="text-slate-600">· Refresh {cacheRefreshedAt} ago</span>}
          </div>
        </div>
        <div className="flex items-center gap-1">
          <span className="rounded border border-border bg-bg px-2 py-1 text-[10px] font-mono text-neutral">{tf}</span>
          <button onClick={onRemove} className="rounded border border-border px-2 py-1 text-[10px] text-neutral hover:border-red-400 hover:text-red-300">
            Remove
          </button>
        </div>
      </div>

      <div className="relative bg-bg" style={{ height }}>
        {isLoading ? (
          <div className="flex h-full items-center justify-center text-xs text-neutral animate-pulse">Loading chart...</div>
        ) : error || data?.error ? (
          <div className="flex h-full items-center justify-center text-xs text-red-300">Chart unavailable</div>
        ) : candles.length ? (
          <CandlestickChart
            candles={candles as any}
            bollinger={data?.bollinger as any}
            chartStyle="candles"
            showBollinger={showBollinger}
            newsEvents={[]}
            showMarkers={false}
            density={showDensity ? overlays.density : []}
            sentiment={showSentiment ? overlays.sentiment : []}
            showDensity={showDensity && overlays.density.length > 0}
            showSentiment={showSentiment && overlays.sentiment.length > 0}
            minHeight={0}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-xs text-neutral">No candle data</div>
        )}
      </div>
    </article>
  )
}

function Segment({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1">
      <span className="text-[10px] uppercase text-neutral">{label}</span>
      <div className="flex overflow-hidden rounded border border-border">
        {children}
      </div>
    </div>
  )
}
