'use client'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import useSWR from 'swr'
import { clsx } from 'clsx'
import * as THREE from 'three'

const fetcher = (url: string) => fetch(url).then(r => r.json())

type DecisionMapRow = {
  ticker: string
  company?: string
  price?: number
  marketCap?: number
  rawMarketCap?: number
  marketCapBucket?: string
  marketCapRelVolumeTarget?: number
  marketCapRelativeVolumeScore?: number
  dollarVolumeTarget?: number
  currentDollarVolume?: number
  liquidityScore?: number
  liquidityStatus?: 'excellent' | 'acceptable' | 'thin' | 'poor' | string
  liquidityDollarVolumeRatio?: number
  liquidityTargetDollarVolume?: number
  relativeVolumeBucket?: string
  priceChangePct: number
  regularPrice?: number
  regularChangePct?: number
  regularVolume?: number
  premarketPrice?: number
  premarketChangePct?: number
  premarketVolume?: number
  postmarketPrice?: number
  postmarketChangePct?: number
  postmarketVolume?: number
  activeSession?: 'premarket' | 'regular' | 'postmarket'
  relativeVolume: number
  currentVolume: number
  rollingVolume: number
  volumeAcceleration: number
  structuredNewsSentiment: number
  socialSentiment: number
  combinedSentiment: number
  articleCount: number
  socialCount: number
  catalystLabel?: string
  structuredArticleCount?: number
  unstructuredArticleCount?: number
  quadrant: 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'Neutral'
  alignmentStatus: string
  decisionState?: 'strong_bullish_candidate' | 'moderate_bullish_candidate' | 'aligned_bearish_candidate' | 'neutral_watchlist' | 'risky_uncertain' | 'weak_no_catalyst'
  supportLabel?: string
  activityScore: number
  convictionScore: number
  riskFlags: string[]
  reasons: string[]
  latestNewsTitles: Array<{ title: string; source?: string; publishedAt?: number; sentiment?: number }>
  newsSources?: string[]
  structuredNewsSources?: string[]
  unstructuredNewsSources?: string[]
  socialPlatforms?: string[]
  ticker_path?: Array<{ timestamp: number; x: number; y: number; z: number; combinedSentiment?: number; priceChangePct?: number; marketCapRelativeVolumeScore?: number; currentDollarVolume?: number; relativeVolume?: number; sentimentEstimated?: boolean }>
  path_points?: Array<{ timestamp: number; x: number; y: number; z: number; combinedSentiment?: number; priceChangePct?: number; marketCapRelativeVolumeScore?: number; currentDollarVolume?: number; relativeVolume?: number; sentimentEstimated?: boolean }>
  path_direction?: 'correct_direction' | 'wrong_direction' | 'neutral' | 'insufficient_history' | string
  path_direction_score?: number
  path_color?: 'blue' | 'red' | 'gray' | string
  path_explanation?: string
  path_points_count?: number
  path_window_minutes?: number
  time_lapse_available?: boolean
  screenerSource?: string
  screenerStatus?: string | null
  finvizAgeSeconds?: number | null
  lastUpdated?: string
}

type SortKey = 'convictionScore' | 'activityScore' | 'relativeVolume' | 'marketCapRelativeVolumeScore' | 'liquidityScore' | 'priceChangePct' | 'combinedSentiment' | 'ticker'
type PathPoint = NonNullable<DecisionMapRow['path_points']>[number]
type VolumePointLike = Partial<PathPoint> & Partial<DecisionMapRow>

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value))
}

function compact(n: number | null | undefined) {
  if (n == null || Number.isNaN(Number(n))) return '--'
  const value = Number(n)
  if (Math.abs(value) >= 1e9) return `${(value / 1e9).toFixed(1)}B`
  if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(1)}M`
  if (Math.abs(value) >= 1e3) return `${(value / 1e3).toFixed(1)}K`
  return value.toFixed(value < 10 ? 2 : 0)
}

function ageLabel(seconds?: number | null) {
  if (seconds == null || Number.isNaN(Number(seconds))) return '--'
  const s = Math.max(0, Number(seconds))
  if (s < 60) return 'now'
  if (s < 3600) return `${Math.floor(s / 60)}m`
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`
}

function colorForDecisionState(state?: string) {
  if (state === 'strong_bullish_candidate') return 0x10b981
  if (state === 'moderate_bullish_candidate') return 0x38bdf8
  if (state === 'aligned_bearish_candidate') return 0xf87171
  if (state === 'risky_uncertain') return 0xf59e0b
  if (state === 'weak_no_catalyst') return 0x64748b
  return 0xa78bfa
}

function marketCapColor(bucket?: string) {
  const key = String(bucket || '').toLowerCase()
  if (key.includes('mega')) return 0xf8fafc
  if (key.includes('large')) return 0x93c5fd
  if (key.includes('mid')) return 0xc084fc
  if (key.includes('small')) return 0xfbbf24
  if (key.includes('micro')) return 0xfb7185
  return 0x94a3b8
}

function dotClass(state: string) {
  if (state === 'strong_bullish_candidate') return 'bg-emerald-400'
  if (state === 'moderate_bullish_candidate') return 'bg-sky-400'
  if (state === 'aligned_bearish_candidate') return 'bg-red-400'
  if (state === 'risky_uncertain') return 'bg-amber-400'
  if (state === 'weak_no_catalyst') return 'bg-slate-500'
  return 'bg-violet-400'
}

function labelForDecisionState(state?: string) {
  if (state === 'strong_bullish_candidate') return 'Strong bullish candidate'
  if (state === 'moderate_bullish_candidate') return 'Moderate bullish candidate'
  if (state === 'aligned_bearish_candidate') return 'Aligned bearish mover'
  if (state === 'risky_uncertain') return 'Risky/uncertain'
  if (state === 'weak_no_catalyst') return 'Weak/no catalyst'
  return 'Neutral/watchlist'
}

function labelForQuadrant(q: string) {
  if (q === 'Q1') return 'Sentiment/price aligned bullish'
  if (q === 'Q3') return 'Sentiment/price aligned bearish'
  if (q === 'Q2') return 'Divergence: news not matching price'
  if (q === 'Q4') return 'Divergence: news not moving market'
  return 'Neutral/mixed'
}

function signedLogAxis(value: number, maxAbs: number, radius: number) {
  const n = Number(value || 0)
  const sign = n < 0 ? -1 : 1
  const magnitude = Math.min(maxAbs, Math.abs(n))
  return sign * (Math.log1p(magnitude) / Math.log1p(maxAbs)) * radius
}

function sentimentAxisValue(value: number) {
  return clamp(Number(value || 0), -1, 1) * 7
}

function priceAxisValue(value: number) {
  return signedLogAxis(Number(value || 0), 160, 4.8)
}

function volumeAxisValue(point: VolumePointLike, row?: DecisionMapRow | null) {
  return volumePressurePlotScore(point, row) / 100 * 7
}

function pointPosition(row: DecisionMapRow) {
  return new THREE.Vector3(
    sentimentAxisValue(row.combinedSentiment),
    priceAxisValue(row.priceChangePct),
    volumeAxisValue(row, row),
  )
}

function pathPointVector(point: PathPoint, row: DecisionMapRow) {
  const sentiment = Number.isFinite(Number(point.combinedSentiment))
    ? Number(point.combinedSentiment)
    : Number(point.x || 0) / 7
  const hasRawPriceChange = Number.isFinite(Number(point.priceChangePct))
  const hasRawVolume = Number.isFinite(Number(point.relativeVolume)) || Number.isFinite(Number(point.currentDollarVolume))
  const fallbackY = Number.isFinite(Number(point.y)) ? Number(point.y) : 0
  const fallbackZ = Number.isFinite(Number(point.z)) ? Number(point.z) : volumeAxisValue(row, row)
  return new THREE.Vector3(
    sentimentAxisValue(sentiment),
    hasRawPriceChange ? priceAxisValue(Number(point.priceChangePct)) : fallbackY,
    hasRawVolume ? volumeAxisValue(point, row) : fallbackZ,
  )
}

function marketCapBucketKey(row: DecisionMapRow) {
  const bucket = String(row.marketCapBucket || '').toLowerCase()
  if (bucket.includes('nano')) return 'nano'
  if (bucket.includes('micro')) return 'micro'
  if (bucket.includes('small')) return 'small'
  if (bucket.includes('mid')) return 'mid'
  if (bucket.includes('large')) return 'large'
  if (bucket.includes('mega')) return 'mega'

  const cap = Number(row.marketCap || row.rawMarketCap || 0)
  if (cap > 0 && cap < 50e6) return 'nano'
  if (cap > 0 && cap < 300e6) return 'micro'
  if (cap > 0 && cap < 2e9) return 'small'
  if (cap > 0 && cap < 10e9) return 'mid'
  if (cap > 0 && cap < 200e9) return 'large'
  if (cap >= 200e9) return 'mega'
  return 'unknown'
}

function marketCapPathSpan(row: DecisionMapRow) {
  const key = marketCapBucketKey(row)
  if (key === 'nano') return 8.6
  if (key === 'micro') return 8.0
  if (key === 'small') return 7.2
  if (key === 'mid') return 6.2
  if (key === 'large') return 5.4
  if (key === 'mega') return 4.8
  return 6.4
}

function bucketVolumeScale(row?: DecisionMapRow | null) {
  const key = row ? marketCapBucketKey(row) : 'unknown'
  if (key === 'mega') return { relTarget: 1.2, dollarTarget: 30_000_000, relCeiling: 18, dollarCeiling: 12 }
  if (key === 'large') return { relTarget: 1.5, dollarTarget: 15_000_000, relCeiling: 28, dollarCeiling: 18 }
  if (key === 'mid') return { relTarget: 1.8, dollarTarget: 8_000_000, relCeiling: 55, dollarCeiling: 26 }
  if (key === 'small') return { relTarget: 2.2, dollarTarget: 3_000_000, relCeiling: 120, dollarCeiling: 40 }
  if (key === 'micro') return { relTarget: 5, dollarTarget: 1_000_000, relCeiling: 650, dollarCeiling: 80 }
  if (key === 'nano') return { relTarget: 8, dollarTarget: 500_000, relCeiling: 1200, dollarCeiling: 120 }
  return { relTarget: 2, dollarTarget: 2_000_000, relCeiling: 90, dollarCeiling: 32 }
}

function volumePressurePlotScore(point: VolumePointLike, row?: DecisionMapRow | null) {
  const scale = bucketVolumeScale(row)
  const relVolume = Math.max(0, Number(point.relativeVolume ?? row?.relativeVolume ?? 0))
  const dollarVolume = Math.max(0, Number(point.currentDollarVolume ?? row?.currentDollarVolume ?? 0))
  const relRatio = relVolume / Math.max(0.001, scale.relTarget)
  const dollarRatio = dollarVolume / Math.max(1, scale.dollarTarget)
  const relPart = Math.log1p(relRatio) / Math.log1p(scale.relCeiling)
  const dollarPart = Math.log1p(dollarRatio) / Math.log1p(scale.dollarCeiling)
  return clamp((relPart * 0.74 + dollarPart * 0.26) * 100, 0, 100)
}

function autoZoomForMarketCap(row?: DecisionMapRow | null) {
  if (!row) return 1
  const key = marketCapBucketKey(row)
  if (key === 'nano') return 1.8
  if (key === 'micro') return 1.7
  if (key === 'small') return 1.55
  if (key === 'mid') return 1.35
  if (key === 'large') return 1.15
  if (key === 'mega') return 0.95
  return 1.25
}

function rowPath(row: DecisionMapRow): PathPoint[] {
  return ((row.path_points || row.ticker_path || []) as PathPoint[])
    .filter(point => Number.isFinite(point.x) && Number.isFinite(point.y) && Number.isFinite(point.z))
    .sort((a, b) => Number(a.timestamp || 0) - Number(b.timestamp || 0))
}

function resampleVectors(points: THREE.Vector3[], targetCount: number) {
  if (points.length < 2) return points.map(point => point.clone())
  const keyframes: THREE.Vector3[] = []
  for (const point of points) {
    const last = keyframes[keyframes.length - 1]
    if (!last || last.distanceTo(point) > 0.0008) keyframes.push(point)
  }
  if (keyframes.length < 2) return points.map(point => point.clone())

  const distances = [0]
  for (let i = 1; i < keyframes.length; i += 1) {
    distances.push(distances[i - 1] + keyframes[i - 1].distanceTo(keyframes[i]))
  }
  const totalDistance = distances[distances.length - 1]
  if (totalDistance <= 0.001) return points.map(point => point.clone())

  const count = Math.max(points.length, targetCount)
  const out: THREE.Vector3[] = []
  let segment = 0
  for (let i = 0; i < count; i += 1) {
    const travel = (i / Math.max(1, count - 1)) * totalDistance
    while (segment < distances.length - 2 && travel > distances[segment + 1]) segment += 1
    const start = keyframes[segment]
    const end = keyframes[Math.min(keyframes.length - 1, segment + 1)]
    const segmentDistance = Math.max(0.001, distances[segment + 1] - distances[segment])
    const t = clamp((travel - distances[segment]) / segmentDistance, 0, 1)
    const easedT = t * t * (3 - 2 * t)
    out.push(start.clone().lerp(end, easedT))
  }
  return out
}

function displayPathVectors(row: DecisionMapRow, amplify: boolean) {
  const path = rowPath(row).slice(-96)
  const raw = path.map(point => pathPointVector(point, row))
  if (!amplify || raw.length < 2) return raw
  const resampled = resampleVectors(raw, 120)
  const box = new THREE.Box3().setFromPoints(resampled)
  const span = Math.max(box.max.x - box.min.x, box.max.y - box.min.y, box.max.z - box.min.z, 0.001)
  const center = box.getCenter(new THREE.Vector3())
  const targetCenter = new THREE.Vector3(0, 0, 3.35)
  const scale = clamp(marketCapPathSpan(row) / span, 1, 300)
  return resampled.map(point => targetCenter.clone().add(point.clone().sub(center).multiplyScalar(scale)))
}

function journeyMovementSpan(row: DecisionMapRow) {
  const path = displayPathVectors(row, true)
  if (path.length < 2) return 0
  const box = new THREE.Box3().setFromPoints(path)
  return Math.max(box.max.x - box.min.x, box.max.y - box.min.y, box.max.z - box.min.z)
}

function interpolatedPathPosition(row: DecisionMapRow, progress: number | null | undefined, amplifyJourney: boolean) {
  const path = displayPathVectors(row, amplifyJourney)
  if (!amplifyJourney || !path.length) return pointPosition(row)
  if (path.length === 1) return path[0].clone()
  const rawProgress = progress == null ? path.length - 1 : progress
  const bounded = clamp(rawProgress, 0, path.length - 1)
  const index = Math.floor(bounded)
  const next = Math.min(path.length - 1, index + 1)
  const localT = bounded - index
  const easedT = localT * localT * (3 - 2 * localT)
  return path[index].clone().lerp(path[next], easedT)
}

function visibleTrailPoints(row: DecisionMapRow, progress: number | null | undefined, amplifyJourney: boolean) {
  const path = displayPathVectors(row, amplifyJourney)
  if (!amplifyJourney || progress == null || path.length < 2) return path
  const bounded = clamp(progress, 0, path.length - 1)
  const index = Math.floor(bounded)
  const points = path.slice(0, Math.min(path.length, index + 1))
  const current = interpolatedPathPosition(row, progress, amplifyJourney)
  if (!points.length || points[points.length - 1].distanceTo(current) > 0.001) points.push(current)
  return points
}

function visualPointPosition(row: DecisionMapRow, amplifyJourney: boolean) {
  const path = displayPathVectors(row, amplifyJourney)
  if (amplifyJourney && path.length) return path[path.length - 1].clone()
  return pointPosition(row)
}

function pathColorValue(color?: string) {
  if (color === 'blue') return 0x38bdf8
  if (color === 'red') return 0xf87171
  return 0x94a3b8
}

function liquidityClass(status?: string) {
  if (status === 'excellent') return 'text-emerald-300'
  if (status === 'acceptable') return 'text-sky-300'
  if (status === 'thin') return 'text-amber-300'
  if (status === 'poor') return 'text-red-300'
  return 'text-slate-300'
}

function bubbleSize(row: DecisionMapRow) {
  const pressurePart = volumePressurePlotScore(row, row) / 240
  const volumePart = Math.sqrt(Math.max(1, Number(row.rollingVolume || row.currentVolume || 1))) / 42000
  const accelerationPart = Math.log1p(Math.max(0, Number(row.volumeAcceleration || 0))) / 18
  return Math.max(0.12, Math.min(0.48, 0.12 + pressurePart + volumePart + accelerationPart))
}

function makeLabelSprite(text: string) {
  const canvas = document.createElement('canvas')
  canvas.width = 160
  canvas.height = 48
  const ctx = canvas.getContext('2d')
  if (ctx) {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = '700 22px ui-monospace, SFMono-Regular, Menlo, monospace'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillStyle = 'rgba(15, 23, 42, 0.82)'
    ctx.fillRect(20, 7, 120, 34)
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)'
    ctx.strokeRect(20.5, 7.5, 119, 33)
    ctx.fillStyle = '#e2e8f0'
    ctx.fillText(text, 80, 25)
  }
  const texture = new THREE.CanvasTexture(canvas)
  const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false })
  const sprite = new THREE.Sprite(material)
  sprite.scale.set(1.7, 0.5, 1)
  return sprite
}

function disposeObject(object: THREE.Object3D) {
  object.traverse(child => {
    const mesh = child as THREE.Mesh
    if (mesh.geometry) mesh.geometry.dispose()
    const material = mesh.material as THREE.Material | THREE.Material[] | undefined
    if (Array.isArray(material)) material.forEach(item => item.dispose())
    else material?.dispose()
  })
}

function ThreeDecisionMap({
  rows,
  zoom,
  resetKey,
  isLoading,
  selectedTicker,
  playbackProgress,
  onSelectTicker,
}: {
  rows: DecisionMapRow[]
  zoom: number
  resetKey: number
  isLoading: boolean
  selectedTicker?: string
  playbackProgress?: number | null
  onSelectTicker?: (ticker: string) => void
}) {
  const hostRef = useRef<HTMLDivElement | null>(null)
  const stateRef = useRef({ theta: -0.7, phi: 1.12, radius: 18, dragging: false, x: 0, y: 0 })
  const playbackRef = useRef<{ ticker?: string; progress: number | null }>({ ticker: selectedTicker, progress: playbackProgress ?? null })
  const [tooltip, setTooltip] = useState<{ x: number; y: number; row: DecisionMapRow } | null>(null)

  useEffect(() => {
    playbackRef.current = { ticker: selectedTicker, progress: playbackProgress ?? null }
  }, [selectedTicker, playbackProgress])

  useEffect(() => {
    const host = hostRef.current
    if (!host) return

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x0f172a)
    const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 1000)
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    renderer.setSize(host.clientWidth, host.clientHeight)
    host.appendChild(renderer.domElement)

    const group = new THREE.Group()
    scene.add(group)
    scene.add(new THREE.AmbientLight(0xffffff, 0.72))
    const light = new THREE.DirectionalLight(0xffffff, 1.2)
    light.position.set(8, 12, 8)
    scene.add(light)

    const grid = new THREE.GridHelper(16, 16, 0x334155, 0x1e293b)
    grid.position.z = 3.5
    grid.rotation.x = Math.PI / 2
    group.add(grid)

    const axes = new THREE.AxesHelper(7.8)
    group.add(axes)
    const xLabel = makeLabelSprite('Sentiment')
    xLabel.position.set(7.7, -5.6, 0)
    group.add(xLabel)
    const yLabel = makeLabelSprite('Price %')
    yLabel.position.set(-8.5, 4.8, 0)
    group.add(yLabel)
    const zLabel = makeLabelSprite('Vol Pressure')
    zLabel.position.set(-8.4, -5.4, 7)
    group.add(zLabel)

    const sphereGeometry = new THREE.SphereGeometry(1, 24, 16)
    const haloGeometry = new THREE.TorusGeometry(1.22, 0.045, 6, 24)
    const meshes: THREE.Mesh[] = []
    const trailGroup = new THREE.Group()
    group.add(trailGroup)
    let hoveredMesh: THREE.Mesh | null = null
    let hoveredTicker = ''
    let pointerDownX = 0
    let pointerDownY = 0
    let didDrag = false
    const clearTrailChildren = () => {
      while (trailGroup.children.length) {
        const child = trailGroup.children.pop()
        if (child) disposeObject(child)
      }
    }
    const clearTrail = () => {
      clearTrailChildren()
      if (hoveredMesh) {
        hoveredMesh.scale.setScalar(hoveredMesh.userData.baseSize || 1)
        const material = hoveredMesh.material as THREE.MeshStandardMaterial
        material.emissiveIntensity = 0.11
      }
      hoveredMesh = null
      hoveredTicker = ''
    }
    const showTrail = (row: DecisionMapRow, mesh: THREE.Mesh) => {
      if (hoveredMesh && hoveredMesh !== mesh) {
        hoveredMesh.scale.setScalar(hoveredMesh.userData.baseSize || 1)
        const previousMaterial = hoveredMesh.material as THREE.MeshStandardMaterial
        previousMaterial.emissiveIntensity = 0.11
      }
      clearTrailChildren()
      hoveredTicker = row.ticker
      hoveredMesh = mesh
      mesh.scale.setScalar((mesh.userData.baseSize || 1) * 1.55)
      const material = mesh.material as THREE.MeshStandardMaterial
      material.emissiveIntensity = 0.42
      const amplify = Boolean(selectedTicker && row.ticker === selectedTicker)
      const progress = amplify ? playbackRef.current.progress : null
      const points = visibleTrailPoints(row, progress, amplify)
      if (points.length < 2) return
      const color = pathColorValue(row.path_color)
      const geometry = new THREE.BufferGeometry().setFromPoints(points)
      const line = new THREE.Line(geometry, new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.95 }))
      trailGroup.add(line)
      const dotGeometry = new THREE.SphereGeometry(0.075, 12, 8)
      points.forEach((point, index) => {
        const dot = new THREE.Mesh(dotGeometry, new THREE.MeshBasicMaterial({
          color,
          transparent: true,
          opacity: index === points.length - 1 ? 1 : 0.45,
        }))
        dot.position.copy(point)
        dot.scale.setScalar(index === points.length - 1 ? 1.55 : 1)
        trailGroup.add(dot)
      })
      const start = points[0]
      const end = points[points.length - 1]
      if (amplify) {
        const marker = new THREE.Mesh(
          new THREE.SphereGeometry(0.22, 20, 12),
          new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 }),
        )
        marker.position.copy(end)
        trailGroup.add(marker)
      }
      const direction = new THREE.Vector3().subVectors(end, start)
      if (direction.length() > 0.01) {
        const arrow = new THREE.ArrowHelper(direction.clone().normalize(), end, 0.55, color, 0.2, 0.12)
        trailGroup.add(arrow)
      }
    }
    rows.slice(0, 140).forEach((row, index) => {
      const material = new THREE.MeshStandardMaterial({
        color: colorForDecisionState(row.decisionState),
        roughness: 0.42,
        metalness: 0.12,
        emissive: colorForDecisionState(row.decisionState),
        emissiveIntensity: 0.11,
      })
      const mesh = new THREE.Mesh(sphereGeometry, material)
      const isSelected = Boolean(selectedTicker && row.ticker === selectedTicker)
      mesh.position.copy(interpolatedPathPosition(row, isSelected ? playbackRef.current.progress : null, isSelected))
      const size = bubbleSize(row)
      mesh.scale.setScalar(size)
      mesh.userData.row = row
      mesh.userData.baseSize = size
      group.add(mesh)
      meshes.push(mesh)
      const halo = new THREE.Mesh(haloGeometry, new THREE.MeshBasicMaterial({
        color: marketCapColor(row.marketCapBucket),
        transparent: true,
        opacity: 0.82,
        depthTest: true,
      }))
      halo.position.copy(mesh.position)
      halo.scale.setScalar(size * 1.15)
      halo.rotation.x = Math.PI / 2
      group.add(halo)
      mesh.userData.halo = halo
      const showLabel = rows.length <= 18 || index < 14 || Boolean(selectedTicker && row.ticker === selectedTicker)
      if (showLabel) {
        const label = makeLabelSprite(row.ticker)
        label.position.copy(mesh.position).add(new THREE.Vector3(0, size + 0.32, 0))
        group.add(label)
        mesh.userData.label = label
      }
    })

    const raycaster = new THREE.Raycaster()
    const pointer = new THREE.Vector2()

    const updateCamera = () => {
      const s = stateRef.current
      const radius = s.radius / Math.max(0.7, zoom)
      camera.position.x = radius * Math.sin(s.phi) * Math.cos(s.theta)
      camera.position.y = radius * Math.cos(s.phi)
      camera.position.z = radius * Math.sin(s.phi) * Math.sin(s.theta)
      camera.lookAt(0, 0, 3)
    }

    const resize = () => {
      const width = Math.max(1, host.clientWidth)
      const height = Math.max(1, host.clientHeight)
      camera.aspect = width / height
      camera.updateProjectionMatrix()
      renderer.setSize(width, height)
    }

    const onPointerDown = (event: PointerEvent) => {
      stateRef.current.dragging = true
      stateRef.current.x = event.clientX
      stateRef.current.y = event.clientY
      pointerDownX = event.clientX
      pointerDownY = event.clientY
      didDrag = false
      host.setPointerCapture(event.pointerId)
    }
    const onPointerUp = (event: PointerEvent) => {
      const wasClick = !didDrag && Math.hypot(event.clientX - pointerDownX, event.clientY - pointerDownY) < 6
      stateRef.current.dragging = false
      try { host.releasePointerCapture(event.pointerId) } catch (_) {}
      if (wasClick) {
        const rect = renderer.domElement.getBoundingClientRect()
        pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
        pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
        raycaster.setFromCamera(pointer, camera)
        const hit = raycaster.intersectObjects(meshes, false)[0]
        if (hit?.object?.userData?.row) {
          const row = hit.object.userData.row as DecisionMapRow
          showTrail(row, hit.object as THREE.Mesh)
          setTooltip({ x: event.clientX - rect.left + 12, y: event.clientY - rect.top + 12, row })
          onSelectTicker?.(row.ticker)
        }
      }
    }
    const onPointerMove = (event: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect()
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

      if (stateRef.current.dragging) {
        const dx = event.clientX - stateRef.current.x
        const dy = event.clientY - stateRef.current.y
        if (Math.hypot(event.clientX - pointerDownX, event.clientY - pointerDownY) >= 6) didDrag = true
        stateRef.current.theta -= dx * 0.008
        stateRef.current.phi = Math.max(0.42, Math.min(2.25, stateRef.current.phi + dy * 0.006))
        stateRef.current.x = event.clientX
        stateRef.current.y = event.clientY
        clearTrail()
        setTooltip(null)
        updateCamera()
        return
      }

      raycaster.setFromCamera(pointer, camera)
      const hit = raycaster.intersectObjects(meshes, false)[0]
      if (hit?.object?.userData?.row) {
        showTrail(hit.object.userData.row, hit.object as THREE.Mesh)
        setTooltip({ x: event.clientX - rect.left + 12, y: event.clientY - rect.top + 12, row: hit.object.userData.row })
      } else {
        if (!selectedTicker) clearTrail()
        setTooltip(null)
      }
    }
    const onWheel = (event: WheelEvent) => {
      event.preventDefault()
      stateRef.current.radius = Math.max(8, Math.min(34, stateRef.current.radius + event.deltaY * 0.015))
      updateCamera()
    }
    const onPointerLeave = (event: PointerEvent) => {
      onPointerUp(event)
      if (!selectedTicker) clearTrail()
      setTooltip(null)
    }

    let frame = 0
    const render = () => {
      frame = requestAnimationFrame(render)
      meshes.forEach(mesh => {
        const row = mesh.userData.row as DecisionMapRow
        const isSelected = Boolean(selectedTicker && row.ticker === selectedTicker)
        if (!isSelected) return
        const target = interpolatedPathPosition(row, playbackRef.current.progress, true)
        mesh.position.lerp(target, 0.38)
        const halo = mesh.userData.halo as THREE.Mesh | undefined
        if (halo) halo.position.copy(mesh.position)
        const label = mesh.userData.label as THREE.Sprite | undefined
        if (label) label.position.copy(mesh.position).add(new THREE.Vector3(0, (mesh.userData.baseSize || 0.2) + 0.32, 0))
        if (hoveredTicker === row.ticker) showTrail(row, mesh)
      })
      renderer.render(scene, camera)
    }

    stateRef.current.theta = -0.7
    stateRef.current.phi = 1.12
    stateRef.current.radius = 18
    resize()
    updateCamera()
    if (selectedTicker) {
      const selectedMesh = meshes.find(mesh => mesh.userData.row?.ticker === selectedTicker)
      if (selectedMesh) showTrail(selectedMesh.userData.row, selectedMesh)
    }
    render()

    const observer = new ResizeObserver(resize)
    observer.observe(host)
    host.addEventListener('pointerdown', onPointerDown)
    host.addEventListener('pointerup', onPointerUp)
    host.addEventListener('pointerleave', onPointerLeave as EventListener)
    host.addEventListener('pointermove', onPointerMove)
    host.addEventListener('wheel', onWheel, { passive: false })

    return () => {
      cancelAnimationFrame(frame)
      observer.disconnect()
      host.removeEventListener('pointerdown', onPointerDown)
      host.removeEventListener('pointerup', onPointerUp)
      host.removeEventListener('pointerleave', onPointerLeave as EventListener)
      host.removeEventListener('pointermove', onPointerMove)
      host.removeEventListener('wheel', onWheel)
      disposeObject(group)
      sphereGeometry.dispose()
      haloGeometry.dispose()
      renderer.dispose()
      renderer.domElement.remove()
    }
  }, [rows, resetKey, zoom, selectedTicker, onSelectTicker])

  return (
    <div ref={hostRef} className="relative h-[560px] min-h-[420px] overflow-hidden rounded bg-bg border border-border">
      <div className="pointer-events-none absolute left-3 top-3 z-20 rounded border border-border bg-surface/90 px-2 py-1 text-[11px] text-neutral">
        {isLoading ? 'Loading real screener rows...' : `${rows.length} active screener-first rows`}
      </div>
      <div className="pointer-events-none absolute bottom-3 left-3 z-20 rounded border border-border bg-surface/90 px-2 py-1 text-[10px] text-slate-400">
        Drag rotate · wheel zoom · hover inspect · click isolate · play selected journey
      </div>
      {tooltip && (
        <div
          className="pointer-events-none absolute z-30 max-w-[360px] rounded border border-cyan-500/40 bg-slate-950/95 px-3 py-2 text-xs shadow-xl"
          style={{ left: tooltip.x, top: tooltip.y }}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="font-mono text-base font-semibold text-accent">{tooltip.row.ticker}</div>
            <div className="font-mono text-emerald-300">Score {tooltip.row.convictionScore}</div>
          </div>
          <div className="truncate text-slate-300">{tooltip.row.company || tooltip.row.screenerSource}</div>
          <div className="mt-1 text-[11px] text-slate-400">{labelForDecisionState(tooltip.row.decisionState)} · {tooltip.row.supportLabel}</div>
          <div className="mt-2 grid grid-cols-3 gap-2 font-mono text-[11px]">
            <div><span className="text-neutral">Sent</span><br />{tooltip.row.combinedSentiment.toFixed(2)}</div>
            <div><span className="text-neutral">{tooltip.row.activeSession || 'session'}</span><br />{tooltip.row.priceChangePct.toFixed(2)}%</div>
            <div><span className="text-neutral">Vol plot</span><br />{volumePressurePlotScore(tooltip.row, tooltip.row).toFixed(0)}/100</div>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2 font-mono text-[11px]">
            <div><span className="text-neutral">Mkt Cap</span><br />{tooltip.row.marketCapBucket || '--'}</div>
            <div><span className="text-neutral">Cap</span><br />${compact(tooltip.row.marketCap)}</div>
            <div><span className="text-neutral">RelVol</span><br />{tooltip.row.relativeVolume.toFixed(2)}x</div>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2 font-mono text-[11px]">
            <div><span className="text-neutral">Liquidity</span><br /><span className={liquidityClass(tooltip.row.liquidityStatus)}>{Number(tooltip.row.liquidityScore || 0).toFixed(0)}/100</span></div>
            <div><span className="text-neutral">$ Vol</span><br />${compact(tooltip.row.currentDollarVolume)}</div>
            <div><span className="text-neutral">Target</span><br />${compact(tooltip.row.liquidityTargetDollarVolume ?? tooltip.row.dollarVolumeTarget)}</div>
          </div>
          <div className="mt-1 text-[10px] text-slate-500">
            Z axis uses cap-aware log volume pressure; raw relative volume stays visible here.
          </div>
          <div className="mt-2 rounded border border-slate-700/70 bg-slate-900/70 px-2 py-1 text-[11px] text-slate-300">
            {tooltip.row.reasons?.slice(0, 3).join(' · ') || 'Screener-first mover row'}
          </div>
          <div className={clsx(
            'mt-2 rounded border px-2 py-1 text-[11px]',
            tooltip.row.path_color === 'blue'
              ? 'border-sky-400/50 bg-sky-500/10 text-sky-200'
              : tooltip.row.path_color === 'red'
                ? 'border-red-400/50 bg-red-500/10 text-red-200'
                : 'border-slate-600 bg-slate-900/70 text-slate-300'
          )}>
            Journey {tooltip.row.path_color === 'blue' ? 'improving' : tooltip.row.path_color === 'red' ? 'weakening' : 'neutral'} · {Number(tooltip.row.path_direction_score || 0).toFixed(2)}
            {tooltip.row.path_points_count ? ` · ${tooltip.row.path_points_count} pts` : ''}
            {tooltip.row.path_window_minutes ? ` / ${tooltip.row.path_window_minutes}m` : ''}
            <div className="mt-0.5 text-[10px] opacity-80">{tooltip.row.path_explanation || 'No path history yet.'}</div>
            {selectedTicker === tooltip.row.ticker && <div className="mt-0.5 text-[10px] text-sky-200/80">Selected ticker uses market-cap-scaled path movement; tooltip values remain raw.</div>}
          </div>
          <div className="mt-2 text-slate-300">{tooltip.row.catalystLabel || 'No catalyst'}</div>
          <div className="mt-1 text-[11px] text-neutral">{tooltip.row.latestNewsTitles?.[0]?.title || 'No recent headline'}</div>
          <div className="mt-2 grid grid-cols-2 gap-2 text-[10px] text-slate-400">
            <div>
              <span className="text-slate-500">Structured</span><br />
              {(tooltip.row.structuredNewsSources?.length ? tooltip.row.structuredNewsSources : tooltip.row.newsSources || []).slice(0, 3).join(', ') || 'none'}
            </div>
            <div>
              <span className="text-slate-500">Social/unstructured</span><br />
              {[...(tooltip.row.socialPlatforms || []), ...(tooltip.row.unstructuredNewsSources || [])].slice(0, 3).join(', ') || 'none'}
            </div>
          </div>
          <div className="mt-2 text-[10px] text-slate-500">FinViz age {ageLabel(tooltip.row.finvizAgeSeconds)} · last row update {tooltip.row.lastUpdated ? new Date(tooltip.row.lastUpdated).toLocaleTimeString() : '--'}</div>
        </div>
      )}
    </div>
  )
}

export function DecisionMapPanel() {
  const [minRelVolume, setMinRelVolume] = useState(1)
  const [minAbsChange, setMinAbsChange] = useState(0.5)
  const [minSentiment, setMinSentiment] = useState(0.12)
  const [windowHours, setWindowHours] = useState(24)
  const [universe, setUniverse] = useState('active_finviz')
  const [session, setSession] = useState('auto')
  const [marketCapBucket, setMarketCapBucket] = useState('all')
  const [relVolumeBucket, setRelVolumeBucket] = useState('all')
  const [sortKey, setSortKey] = useState<SortKey>('convictionScore')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [zoom, setZoom] = useState(1)
  const [resetKey, setResetKey] = useState(0)
  const [selectedTicker, setSelectedTicker] = useState('')
  const [isPlayingJourney, setIsPlayingJourney] = useState(false)
  const [playbackProgress, setPlaybackProgress] = useState<number | null>(null)

  const params = useMemo(() => new URLSearchParams({
    universe,
    path_points: '96',
    session,
    limit: '180',
    min_rel_volume: String(relVolumeBucket === 'all' ? minRelVolume : 0),
    min_abs_change: String(minAbsChange),
    positive_sentiment: String(minSentiment),
    negative_sentiment: String(-minSentiment),
    price_threshold: String(minAbsChange),
    market_cap_bucket: marketCapBucket,
    rel_volume_bucket: relVolumeBucket,
    news_window_hours: String(windowHours),
    social_window_hours: String(windowHours),
    sortBy: sortKey,
    orderDir: sortDir,
  }), [minRelVolume, minAbsChange, minSentiment, windowHours, universe, session, marketCapBucket, relVolumeBucket, sortKey, sortDir])

  const { data, isLoading, mutate } = useSWR(`/api/decision-map?${params.toString()}`, fetcher, { refreshInterval: 60_000 })
  const rows: DecisionMapRow[] = data?.rows ?? []
  const selectedRow = useMemo(
    () => rows.find(row => row.ticker === selectedTicker) || null,
    [rows, selectedTicker],
  )
  const selectedPath = useMemo(
    () => selectedRow ? rowPath(selectedRow) : [],
    [selectedRow],
  )
  const selectedVisualPath = useMemo(
    () => selectedRow ? displayPathVectors(selectedRow, true) : [],
    [selectedRow],
  )
  const selectedMovementSpan = useMemo(
    () => selectedRow ? journeyMovementSpan(selectedRow) : 0,
    [selectedRow],
  )
  const mapRows = useMemo(() => {
    if (!selectedRow) return rows
    return [selectedRow]
  }, [rows, selectedRow])

  useEffect(() => {
    if (!isPlayingJourney || selectedVisualPath.length < 2) return
    let frame = 0
    const startedAt = performance.now()
    const duration = clamp(selectedVisualPath.length * 130, 3200, 17000)
    const step = (now: number) => {
      const elapsed = now - startedAt
      const t = clamp(elapsed / duration, 0, 1)
      const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2
      setPlaybackProgress(eased * (selectedVisualPath.length - 1))
      if (t < 1) {
        frame = window.requestAnimationFrame(step)
      } else {
        setPlaybackProgress(selectedVisualPath.length - 1)
        setIsPlayingJourney(false)
      }
    }
    setPlaybackProgress(0)
    frame = window.requestAnimationFrame(step)
    return () => window.cancelAnimationFrame(frame)
  }, [isPlayingJourney, selectedVisualPath.length])

  const selectTicker = useCallback((ticker: string) => {
    setSelectedTicker(ticker)
    const row = rows.find(item => item.ticker === ticker)
    const path = row ? displayPathVectors(row, true) : []
    setPlaybackProgress(path.length ? path.length - 1 : null)
    setZoom(autoZoomForMarketCap(row))
    setIsPlayingJourney(false)
  }, [rows])

  const resetJourney = () => {
    setSelectedTicker('')
    setPlaybackProgress(null)
    setIsPlayingJourney(false)
    setZoom(1)
    setResetKey(v => v + 1)
  }

  const playJourney = () => {
    if (!selectedRow || selectedVisualPath.length < 2) return
    setPlaybackProgress(0)
    setIsPlayingJourney(true)
  }

  const sortedRows = useMemo(() => {
    const copy = [...rows]
    copy.sort((a, b) => {
      const av = a[sortKey]
      const bv = b[sortKey]
      if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(String(bv)) : String(bv).localeCompare(av)
      return sortDir === 'asc' ? Number(av || 0) - Number(bv || 0) : Number(bv || 0) - Number(av || 0)
    })
    return copy.slice(0, 40)
  }, [rows, sortDir, sortKey])

  const setSort = (key: SortKey) => {
    if (key === sortKey) setSortDir(v => v === 'asc' ? 'desc' : 'asc')
    else {
      setSortKey(key)
      setSortDir(key === 'ticker' ? 'asc' : 'desc')
    }
  }
  const playbackFrame = selectedVisualPath.length
    ? Math.min(selectedVisualPath.length, Math.floor(playbackProgress ?? selectedVisualPath.length - 1) + 1)
    : 0
  const selectedScaleLabel = selectedRow
    ? `${marketCapBucketKey(selectedRow)} cap lens · ${selectedMovementSpan.toFixed(1)}u move · ${zoom.toFixed(1)}x`
    : ''

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-cyan-500/30 bg-cyan-500/10 px-3 py-2 text-xs text-cyan-100">
        <div className="font-semibold">Screener-first active universe</div>
        <div className="mt-1 opacity-80">
          Rows start from current numerical screener activity, then attach structured news, social sentiment, catalysts, and rolling volume. No fake rows are generated.
        </div>
        <div className="mt-1 text-[11px] text-cyan-200/80">
          Map refresh: 60s · session: {data?.session || session} · FinViz age: {ageLabel(data?.freshness?.finviz?.ageSeconds)}
          {data?.freshness?.finviz?.isStale ? ' · stale stored mover context' : ' · fresh active mover context'}
        </div>
      </div>

      <section className="bg-surface border border-border rounded-lg overflow-hidden">
        <div className="px-3 py-2 border-b border-border flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="text-xs uppercase text-neutral font-medium">Three.js Decision Map</div>
            <div className="text-[11px] text-slate-400">X sentiment · Y session price change · Z cap-aware volume pressure · bubble participation · ring market-cap bucket</div>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px] text-neutral">
            {[
              'strong_bullish_candidate',
              'moderate_bullish_candidate',
              'neutral_watchlist',
              'risky_uncertain',
              'weak_no_catalyst',
            ].map(state => (
              <span key={state} className="inline-flex items-center gap-1">
                <span className={clsx('h-2 w-2 rounded-full', dotClass(state))} />
                {labelForDecisionState(state)}
              </span>
            ))}
            <button onClick={() => mutate()} className="rounded border border-border bg-bg px-2 py-1 text-slate-200 hover:text-white">Refresh</button>
          </div>
        </div>
        <div className="border-b border-border bg-bg/40 px-3 py-2 flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs text-slate-300">
            {selectedRow ? (
              <>
                <span className="font-mono text-accent font-semibold">{selectedRow.ticker}</span>
                <span className="text-neutral"> isolated · {selectedPath.length || 0} journey points</span>
                {selectedVisualPath.length > 0 && (
                  <span className="text-neutral"> · frame {playbackFrame}/{selectedVisualPath.length}</span>
                )}
                <span className="text-sky-300"> · {selectedScaleLabel}</span>
              </>
            ) : (
              <span>Click any ticker bubble or row to isolate one stock, then play its path through the 3D map.</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={playJourney}
              disabled={!selectedRow || selectedVisualPath.length < 2 || isPlayingJourney}
              className="rounded border border-sky-500/50 bg-sky-500/10 px-3 py-1 text-xs text-sky-100 hover:bg-sky-500/20 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isPlayingJourney ? 'Playing' : 'Play'}
            </button>
            <button
              type="button"
              onClick={resetJourney}
              className="rounded border border-border bg-bg px-3 py-1 text-xs text-slate-200 hover:text-white"
            >
              Reset
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[260px_minmax(0,1fr)] gap-0">
          <div className="border-b xl:border-b-0 xl:border-r border-border p-3 space-y-3">
            <Control label="Market cap" value={marketCapBucket}>
              <select value={marketCapBucket} onChange={e => setMarketCapBucket(e.target.value)} className="w-full bg-bg border border-border rounded px-2 py-1 text-xs text-slate-200">
                <option value="all">All buckets</option>
                <option value="mega">Mega cap</option>
                <option value="large">Large cap</option>
                <option value="mid">Mid cap</option>
                <option value="small">Small cap</option>
                <option value="micro">Micro cap</option>
                <option value="nano">Nano cap</option>
              </select>
            </Control>
            <Control label="Relative volume" value={relVolumeBucket === 'all' ? `${minRelVolume.toFixed(1)}x min` : relVolumeBucket}>
              <select value={relVolumeBucket} onChange={e => setRelVolumeBucket(e.target.value)} className="w-full bg-bg border border-border rounded px-2 py-1 text-xs text-slate-200">
                <option value="all">All, use min slider</option>
                <option value="low">Low (&lt;1x)</option>
                <option value="medium">Medium (1-3x)</option>
                <option value="high">High (3-10x)</option>
                <option value="extreme">Extreme (10x+)</option>
              </select>
              {relVolumeBucket === 'all' && <input type="range" min="0" max="10" step="0.1" value={minRelVolume} onChange={e => setMinRelVolume(Number(e.target.value))} className="mt-2 w-full" />}
            </Control>
            <Control label="Min abs price change" value={`${minAbsChange.toFixed(1)}%`}>
              <input type="range" min="0" max="15" step="0.1" value={minAbsChange} onChange={e => setMinAbsChange(Number(e.target.value))} className="w-full" />
            </Control>
            <Control label="Min sentiment strength" value={minSentiment.toFixed(2)}>
              <input type="range" min="0" max="0.7" step="0.01" value={minSentiment} onChange={e => setMinSentiment(Number(e.target.value))} className="w-full" />
            </Control>
            <Control label="News/social window" value={`${windowHours}h`}>
              <select value={windowHours} onChange={e => setWindowHours(Number(e.target.value))} className="w-full bg-bg border border-border rounded px-2 py-1 text-xs text-slate-200">
                <option value={6}>6h</option>
                <option value={12}>12h</option>
                <option value={24}>24h</option>
                <option value={48}>48h</option>
                <option value={72}>72h</option>
              </select>
            </Control>
            <Control label="Session movement" value={session}>
              <select value={session} onChange={e => setSession(e.target.value)} className="w-full bg-bg border border-border rounded px-2 py-1 text-xs text-slate-200">
                <option value="auto">Auto strongest session</option>
                <option value="premarket">Premarket</option>
                <option value="regular">Regular market</option>
                <option value="postmarket">Post-market</option>
              </select>
            </Control>
            <Control label="Universe" value={universe.replace('_', ' ')}>
              <select value={universe} onChange={e => setUniverse(e.target.value)} className="w-full bg-bg border border-border rounded px-2 py-1 text-xs text-slate-200">
                <option value="active_finviz">Active Finviz Elite</option>
                <option value="numeric_all">Finviz + TradingView numeric</option>
                <option value="tradingview">TradingView numeric</option>
              </select>
            </Control>
            <Control label="Zoom" value={`${zoom.toFixed(1)}x`}>
              <input type="range" min="0.7" max="1.8" step="0.05" value={zoom} onChange={e => setZoom(Number(e.target.value))} className="w-full" />
            </Control>
            <button
              className="w-full rounded border border-border bg-bg px-2 py-1 text-xs text-neutral hover:text-white"
              onClick={() => { setZoom(1); setResetKey(v => v + 1) }}
            >
              Reset View
            </button>
          </div>

          <div className="p-3">
            <ThreeDecisionMap
              rows={mapRows}
              zoom={zoom}
              resetKey={resetKey}
              isLoading={isLoading}
              selectedTicker={selectedTicker || undefined}
              playbackProgress={playbackProgress}
              onSelectTicker={selectTicker}
            />
          </div>
        </div>
      </section>

      <section className="bg-surface border border-border rounded-lg overflow-hidden">
        <div className="px-3 py-2 border-b border-border flex items-center justify-between">
          <div>
            <div className="text-xs uppercase text-neutral font-medium">Decision Rows</div>
            <div className="text-[11px] text-slate-400">High activity + catalyst confirmation should rise to the top.</div>
          </div>
          <div className="text-[11px] text-neutral">
            Q1 {data?.summary?.Q1 ?? 0} · Q3 {data?.summary?.Q3 ?? 0} · divergence {data?.summary?.divergence ?? 0}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-bg/50 border-b border-border">
              <tr>
                {[
                  ['ticker', 'Ticker'],
                  ['activeSession', 'Session'],
                  ['priceChangePct', 'Chg%'],
                  ['relativeVolume', 'Rel Vol'],
                  ['marketCapRelativeVolumeScore', 'Cap RelVol'],
                  ['liquidityScore', 'Liquidity'],
                  ['currentDollarVolume', '$ Vol'],
                  ['combinedSentiment', 'Sent'],
                  ['decisionState', 'State'],
                  ['activityScore', 'Activity'],
                  ['convictionScore', 'Score'],
                  ['catalystLabel', 'Catalyst'],
                  ['headline', 'Top headline'],
                ].map(([key, label]) => (
                  <th
                    key={key}
                    onClick={() => ['ticker', 'priceChangePct', 'relativeVolume', 'marketCapRelativeVolumeScore', 'liquidityScore', 'combinedSentiment', 'activityScore', 'convictionScore'].includes(key) && setSort(key as SortKey)}
                    className="px-3 py-2 text-left text-[10px] uppercase text-neutral whitespace-nowrap cursor-pointer hover:text-white"
                  >
                    {label}{sortKey === key ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/30">
              {sortedRows.map(row => (
                <tr
                  key={row.ticker}
                  onClick={() => selectTicker(row.ticker)}
                  className={clsx('hover:bg-bg/40 cursor-pointer', selectedTicker === row.ticker && 'bg-sky-500/10')}
                >
	                  <td className="px-3 py-2">
	                    <div className="font-mono font-semibold text-accent">{row.ticker}</div>
	                    <div className="text-[10px] text-neutral truncate max-w-[160px]">{row.company || row.screenerSource}</div>
	                  </td>
                  <td className="px-3 py-2">
                    <div className="font-mono text-slate-200">{row.activeSession || '--'}</div>
                    <div className="text-[10px] text-neutral">{row.marketCapBucket || '--'} · ${compact(row.marketCap)}</div>
                  </td>
	                  <td className={clsx('px-3 py-2 font-mono', row.priceChangePct >= 0 ? 'text-emerald-400' : 'text-red-400')}>
	                    {row.priceChangePct >= 0 ? '+' : ''}{row.priceChangePct.toFixed(2)}%
	                  </td>
	                  <td className="px-3 py-2 font-mono text-slate-200">{row.relativeVolume.toFixed(2)}x</td>
                  <td className="px-3 py-2">
                    <div className="font-mono text-slate-200">{Number(row.marketCapRelativeVolumeScore || 0).toFixed(0)}/100</div>
                    <div className="text-[10px] text-sky-300">{row.relativeVolumeBucket || 'bucket'}</div>
                    <div className="text-[10px] text-neutral">target {Number(row.marketCapRelVolumeTarget || 0).toFixed(1)}x</div>
                  </td>
                  <td className="px-3 py-2">
                    <div className={clsx('font-mono', liquidityClass(row.liquidityStatus))}>{Number(row.liquidityScore || 0).toFixed(0)}/100</div>
                    <div className="text-[10px] uppercase text-neutral">{row.liquidityStatus || 'unknown'}</div>
                    <div className="text-[10px] text-neutral">{Number(row.liquidityDollarVolumeRatio || 0).toFixed(2)}x target</div>
                  </td>
                  <td className="px-3 py-2">
                    <div className="font-mono text-slate-200">${compact(row.currentDollarVolume)}</div>
                    <div className="text-[10px] text-neutral">target ${compact(row.dollarVolumeTarget)}</div>
                  </td>
	                  <td className={clsx('px-3 py-2 font-mono', row.combinedSentiment >= minSentiment ? 'text-emerald-400' : row.combinedSentiment <= -minSentiment ? 'text-red-400' : 'text-neutral')}>
	                    {row.combinedSentiment.toFixed(2)}
	                  </td>
	                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1 text-slate-200">
                      <span className={clsx('h-2 w-2 rounded-full', dotClass(row.decisionState || 'neutral_watchlist'))} />
                      {labelForDecisionState(row.decisionState)}
                    </div>
	                    <div className="text-[10px] text-neutral">{row.quadrant} · {labelForQuadrant(row.quadrant)}</div>
	                  </td>
                  <td className="px-3 py-2 font-mono text-slate-200">{row.activityScore.toFixed(0)}</td>
                  <td className="px-3 py-2 font-mono text-emerald-300">{row.convictionScore}</td>
                  <td className="px-3 py-2">
	                    <div className="text-slate-200 whitespace-nowrap">{row.catalystLabel || 'No catalyst'}</div>
	                    <div className="text-[10px] text-neutral">{row.structuredArticleCount ?? row.articleCount} structured · {row.unstructuredArticleCount ?? 0} unstructured · {row.socialCount} social</div>
                  </td>
                  <td className="px-3 py-2">
                    <div className="max-w-[360px] truncate text-slate-300">{row.latestNewsTitles?.[0]?.title || 'No recent headline'}</div>
                    {row.riskFlags.length > 0 && <div className="mt-1 text-[10px] text-yellow-300 truncate">{row.riskFlags.slice(0, 3).join(', ')}</div>}
                  </td>
                </tr>
              ))}
              {!sortedRows.length && (
                <tr>
	                  <td colSpan={13} className="px-3 py-10 text-center text-neutral">
                    No real screener-first rows match the current thresholds.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

function Control({ label, value, children }: { label: string; value: string; children: ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 flex items-center justify-between gap-2">
        <span className="text-[10px] uppercase text-neutral">{label}</span>
        <span className="font-mono text-[11px] text-slate-300">{value}</span>
      </div>
      {children}
    </label>
  )
}
