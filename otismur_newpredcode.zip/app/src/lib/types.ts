export interface Article {
  id:             string
  article_id?:    string
  title:          string
  source:         string
  category?:      string | null
  publish_date:   number
  fetched_date?:  number
  detected_at?:   number
  ticker?:        string | null
  tickers?:       string[]
  company?:       string | null
  sentiment?:     'bullish' | 'bearish' | 'neutral' | null
  ml_confidence?: number | null
  url?:           string
  content?:       string
  positive_mover_match?: boolean
  matched_mover_tickers?: string[]
  ticker_match_method?: string
  ticker_match_confidence?: number
}

export interface ScreenerRow {
  ticker:               string
  company?:             string
  price?:               number | null
  change_pct?:          number
  volume?:              number
  market_cap?:          number
  market_cap_bucket?:   string
  sector?:              string
  industry?:            string
  country?:             string
  exchange?:            string
  index?:               string
  avg_sentiment?:       number
  social_sentiment?:    number
  social_message_sentiment?: number
  social_message_density?: number
  message_density_now?: number
  message_density_5m?: number
  message_density_15m?: number
  message_density_30m?: number
  message_density_60m?: number
  message_density_prev_window?: number
  message_density_change?: number
  message_density_change_pct?: number
  message_density_trend?: string
  message_density_rising?: boolean
  message_density_supported?: boolean
  message_density_score?: number
  message_density_live_score?: number
  message_density_carry_score?: number
  message_density_session_count?: number
  message_density_session_minutes?: number
  message_density_session_density?: number
  message_density_last_event_age_minutes?: number | null
  message_density_active_15m?: number
  message_density_active_60m?: number
  short_squeeze_score?: number
  short_squeeze_available?: boolean
  short_squeeze_reason?: string
  short_squeeze_components?: Record<string, unknown>
  float_or_short_interest_available?: boolean
  squeeze_proxy_used?: boolean
  squeeze_signal?: string
  structured_news_score?: number
  structured_news_available?: boolean
  best_structured_catalyst_headline?: string | null
  best_structured_catalyst_source?: string | null
  best_structured_catalyst_age_minutes?: number | null
  structured_catalyst_type?: string | null
  structured_catalyst_sentiment?: number | null
  structured_catalyst_confidence?: number | null
  stocktwits_message_sentiment?: number
  stocktwits_message_density?: number
  stocktwits_message_count?: number
  reddit_message_count?: number
  bluesky_message_count?: number
  twitter_message_count?: number
  structured_sentiment?: number
  message_count?:       number
  news_article_count?:  number
  bullish_count?:       number
  bearish_count?:       number
  neutral_count?:       number
  sources?:             string[]
  avg_volume?:          number
  pe_ratio?:            number | null
  forward_pe?:          number | null
  peg?:                 number | null
  ps_ratio?:            number | null
  pb_ratio?:            number | null
  dividend_yield?:      number | null
  eps_growth_this_y?:   number | null
  eps_growth_next_y?:   number | null
  sales_growth?:        number | null
  gross_margin?:        number | null
  operating_margin?:    number | null
  roe?:                 number | null
  debt_equity?:         number | null
  beta?:                number | null
  rsi?:                 number | null
  sma20?:               number | null
  sma50?:               number | null
  sma200?:              number | null
  perf_week?:           number | null
  perf_month?:          number | null
  perf_quarter?:        number | null
  perf_half?:           number | null
  perf_year?:           number | null
  perf_ytd?:            number | null
  atr?:                 number | null
  gap?:                 number | null
  high_52w?:            number | null
  low_52w?:             number | null
  analyst?:             string | null
  target_price?:        number | null
  inst_own?:            number | null
  insider_own?:         number | null
  float_short?:         number | null
  earnings_date?:       string | null
  quote_status?:        string
  quote_source?:        string | null
  quote_time?:          string | null
  quote_updated_at?:    number | string | null
  rolling_window_minutes?: number
  latest_publish?:      number | string | null
  latest_social?:       number | string | null
  prediction_status?:    'available' | 'no_prediction' | string
  prediction_direction?: string | null
  predicted_return?:     number | null
  stored_predicted_return?: number | null
  final_predicted_percent?: number | null
  prediction_confidence?: number | null
  prediction_debug?: Record<string, unknown> | null
  prediction_explanation?: string | null
  prediction_horizon_requested?: string
  prediction_generated_at?: number | string | null
  prediction?: {
    horizon?: string
    requested_horizon?: string
    horizon_supported?: boolean
    is_next_day_proxy?: boolean
    predictedReturn?: number | null
    predictedDirection?: string | null
    confidence?: number | null
    probabilityUp?: number | null
    modelVersion?: string | number | null
    model?: string | null
    generatedAt?: number | string | null
    generatedAtSec?: number | null
    source?: string
    decision?: string
  } | null
  catalysts?: Array<{
    type?: string
    source?: string
    title?: string
    publishedAt?: number | null
    url?: string
    sentiment?: string
    sentimentScore?: number
    relevanceScore?: number
    isSecFiling?: boolean
    filingContentStatus?: string | null
    filingContentLength?: number | null
    accessionNumber?: string | null
    formType?: string | null
  }>
  main_catalyst?: {
    type?: string
    source?: string
    title?: string
    publishedAt?: number | null
    sentiment?: string
    sentimentScore?: number
    isSecFiling?: boolean
    filingContentStatus?: string | null
  } | null
  filing_sentiment?: number
  filing_article_count?: number
  filing_used_count?: number
  sec_filing_contributed?: boolean
  final_prediction_score?: number
  signal_quality?: string
  risk_flags?: string[]
  high_conviction?: boolean
  high_conviction_rank?: number
  high_conviction_fallback?: boolean
  session?: string | null
  fallback_prediction_direction?: string | null
  fallback_confidence?: number | null
  evidence_score?: number | null
  model_mode?: string | null
  reason_included?: string | null
  catalyst_summary?: string | null
  generated_at?: number | string | null
  screener_snapshot_at?: number | string | null
  cache_status?: string | null
  change_percent?: number | null
  relative_volume?: number | null
  decision_candidate?: boolean
  decision_candidate_score?: number
  decision_candidate_source?: string
  professor_sendable?: boolean
  score_breakdown?: Record<string, unknown>
  dashboard_assessment?: Record<string, unknown>
  momentum_score?: number
  ai_score?: number
  correlation_score?: number
  ai_context?: Record<string, unknown> | null
  momentum_context?: Record<string, unknown> | null
  correlation_context?: Record<string, unknown> | null
  news_sentiment?: number
  stocktwits_sentiment?: number
  stocktwits_density?: number
}

export interface MomentumRow {
  ticker:           string
  company?:         string
  price?:           number | null
  change_pct?:      number
  active_session?:  string
  session_price?:   number | null
  session_change_pct?: number | null
  session_volume?:  number | null
  regular_change_pct?: number | null
  premarket_change_pct?: number | null
  postmarket_change_pct?: number | null
  market_cap?:      number | null
  market_cap_bucket?: string
  volume?:          number
  avg_volume?:      number
  rel_volume?:      number
  sentiment?:       number
  article_sentiment?: number
  structured_sentiment?: number
  unstructured_sentiment?: number
  social_sentiment?: number
  momentum_score?:  number
  article_count?:   number
  structured_article_count?: number
  unstructured_article_count?: number
  message_count?:   number
  bullish_count?:   number
  bearish_count?:   number
  neutral_count?:   number
  sources?:         string[]
  quote_status?:    string
  quote_source?:    string | null
  quote_time?:      string | null
  quote_updated_at?: number | string | null
  discovery_source?: string
  positive_mover?:   boolean
  finviz_rank?:      number
  latest_social?:    number | null
  latest_publish?:   number | string | null
  ai_numeric_rank?:   number
  trade_watch?: {
    trade_watch_score: number
    decision: string
    confidence: number
    agreement: number
    evidence_score: number
    quote_freshness?: number
    quote_age_minutes?: number | null
    support_count?: number
    score_breakdown?: {
      price_action?: number
      relative_volume?: number
      evidence?: number
      agreement?: number
      freshness?: number
      penalties?: number
    }
    reasons?: string[]
    risks?: string[]
  }
  bracket_order?: {
    candidate: boolean
    confidence: number
    direction: string
    entry_reference?: number | null
    stop_loss_pct?: number
    take_profit_pct?: number
    support_count?: number
    rationale?: string[]
    status?: string
  }
}

export interface SocialPost {
  id?:        string
  post_id?:   string
  platform:   'reddit' | 'twitter' | 'stocktwits' | 'bluesky'
  author:     string
  content:    string
  created_at: string
  ticker?:    string | null
  sentiment?: number | null
  url?:       string
}

export interface CorrelationEntry {
  ticker:      string
  correlation: number
  p_value:     number
  sample_size: number
  window_days?: number
  news_sentiment?: number
  social_sentiment?: number
  combined_sentiment?: number
  sentiment_pressure?: number
  news_pressure?: number
  social_pressure?: number
  price_momentum?: number
  robust_price_momentum?: number
  price_move_valid?: boolean
  flat_previous_close?: boolean
  change_pct?: number
  price?: number | null
  previous_close?: number | null
  article_count?: number
  social_count?: number
  evidence_count?: number
  reliability_weight?: number
  signal_score?: number
  confidence?: number
  evidence_quality?: 'high' | 'medium' | 'thin' | string
  direction?: 'aligned' | 'divergent' | string
  generated?: boolean
  signal_type?: string
  quote_source?: string | null
  quote_time?: string | null
  quote_updated_at?: number | string | null
  avg_abs_correlation?: number | null
  pearson_correlation?: number | null
}
