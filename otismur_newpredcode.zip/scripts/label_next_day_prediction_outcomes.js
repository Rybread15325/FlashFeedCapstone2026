#!/usr/bin/env node

const path = require('path')
const mongoose = require(path.join(__dirname, '..', 'Infrastructure', 'server', 'node_modules', 'mongoose'))

function argValue(name, fallback = '') {
  const prefix = `--${name}=`
  const inline = process.argv.find(arg => arg.startsWith(prefix))
  if (inline) return inline.slice(prefix.length)
  const index = process.argv.indexOf(`--${name}`)
  if (index >= 0 && process.argv[index + 1]) return process.argv[index + 1]
  return fallback
}

function toNumber(value, fallback) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function pct(from, to) {
  const a = Number(from)
  const b = Number(to)
  if (!a || !Number.isFinite(a) || !Number.isFinite(b)) return null
  return Number((((b - a) / a) * 100).toFixed(3))
}

async function fetchDailyCandles(ticker) {
  const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}`)
  url.searchParams.set('range', '2mo')
  url.searchParams.set('interval', '1d')
  url.searchParams.set('includePrePost', 'false')
  url.searchParams.set('events', 'history')
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'FeedFlashStockDashboard/0.1',
      Accept: 'application/json',
    },
  })
  if (!response.ok) throw new Error(`${ticker} chart provider HTTP ${response.status}`)
  const payload = await response.json()
  const result = payload?.chart?.result?.[0]
  const timestamps = result?.timestamp || []
  const quote = result?.indicators?.quote?.[0] || {}
  const candles = []
  for (let i = 0; i < timestamps.length; i += 1) {
    const open = Number(quote.open?.[i])
    const high = Number(quote.high?.[i])
    const low = Number(quote.low?.[i])
    const close = Number(quote.close?.[i])
    if (![open, high, low, close].every(Number.isFinite)) continue
    if (open <= 0 || high <= 0 || low <= 0 || close <= 0) continue
    candles.push({
      time: Number(timestamps[i]),
      open,
      high,
      low,
      close,
      volume: Number.isFinite(Number(quote.volume?.[i])) ? Number(quote.volume[i]) : 0,
    })
  }
  return candles
}

async function fetchIntradayCandles(ticker) {
  const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}`)
  url.searchParams.set('range', '7d')
  url.searchParams.set('interval', '5m')
  url.searchParams.set('includePrePost', 'true')
  url.searchParams.set('events', 'history')
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'FeedFlashStockDashboard/0.1',
      Accept: 'application/json',
    },
  })
  if (!response.ok) throw new Error(`${ticker} intraday chart provider HTTP ${response.status}`)
  const payload = await response.json()
  const result = payload?.chart?.result?.[0]
  const timestamps = result?.timestamp || []
  const quote = result?.indicators?.quote?.[0] || {}
  const candles = []
  for (let i = 0; i < timestamps.length; i += 1) {
    const close = Number(quote.close?.[i])
    if (!Number.isFinite(close) || close <= 0) continue
    const open = Number(quote.open?.[i])
    const high = Number(quote.high?.[i])
    const low = Number(quote.low?.[i])
    candles.push({
      time: Number(timestamps[i]),
      open: Number.isFinite(open) && open > 0 ? open : close,
      high: Number.isFinite(high) && high > 0 ? high : close,
      low: Number.isFinite(low) && low > 0 ? low : close,
      close,
      volume: Number.isFinite(Number(quote.volume?.[i])) ? Number(quote.volume[i]) : 0,
    })
  }
  return candles
}

function easternParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date)
  return Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, Number(part.value)]))
}

function sessionForSec(sec) {
  const parts = easternParts(new Date(Number(sec || 0) * 1000))
  const weekday = new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay()
  if (weekday === 0 || weekday === 6) return 'weekend'
  const minutes = parts.hour * 60 + parts.minute
  if (minutes >= 4 * 60 && minutes < 9 * 60 + 30) return 'premarket'
  if (minutes >= 9 * 60 + 30 && minutes < 16 * 60) return 'regular'
  if (minutes >= 16 * 60 && minutes < 20 * 60) return 'afterhours'
  return 'closed'
}

function dateKeyEt(sec) {
  const p = easternParts(new Date(Number(sec || 0) * 1000))
  return `${String(p.year).padStart(4, '0')}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`
}

function sessionTargetForRow(row = {}, snapshot = {}) {
  const session = row.prediction_session || snapshot.prediction_session_context?.session || row.prediction?.predictionSession || ''
  const target = row.prediction_target || snapshot.prediction_session_context?.target || row.prediction?.predictionTarget || ''
  if (target) return target
  if (session === 'premarket' || session === 'overnight' || session === 'weekend') return 'regular_session_risers'
  if (session === 'regular') return 'late_day_and_afterhours_continuation'
  if (session === 'afterhours' || session === 'closed_post_afterhours') return 'afterhours_and_next_premarket_risers'
  return 'next_regular_session'
}

function intradaySessionLabel(row, snapshotSec, candles, snapshot = {}) {
  const entryPrice = Number(row.price || row.prediction?.entry_price || row.entry_price || 0)
  if (!entryPrice) return null
  const target = sessionTargetForRow(row, snapshot)
  const after = candles.filter(candle => Number(candle.time || 0) > Number(snapshotSec || 0))
  if (!after.length) return { outcome_status: 'pending', reason: 'no_intraday_candles_after_snapshot' }
  const snapshotDate = dateKeyEt(snapshotSec)
  const targetCandles = after.filter(candle => {
    const session = sessionForSec(candle.time)
    const d = dateKeyEt(candle.time)
    if (target === 'regular_session_risers') return session === 'regular'
    if (target === 'late_day_and_afterhours_continuation') return d === snapshotDate && (session === 'regular' || session === 'afterhours')
    if (target === 'afterhours_and_next_premarket_risers') return session === 'afterhours' || session === 'premarket'
    return session === 'regular'
  })
  if (!targetCandles.length) return { outcome_status: 'pending', reason: `no_intraday_candles_for_${target}` }
  const first = targetCandles[0]
  const last = targetCandles[targetCandles.length - 1]
  const high = Math.max(...targetCandles.map(c => Number(c.high || c.close || 0)).filter(Number.isFinite))
  const low = Math.min(...targetCandles.map(c => Number(c.low || c.close || 0)).filter(Number.isFinite))
  const predictedReturn = Number(row.predicted_return)
  const predictedDirection = predictedReturn > 0 ? 'up' : predictedReturn < 0 ? 'down' : 'watch'
  const closeReturn = pct(entryPrice, last.close)
  const highReturn = pct(entryPrice, high)
  const lowReturn = pct(entryPrice, low)
  return {
    outcome_status: 'labeled',
    label_source: 'yahoo_5m_intraday_prepost',
    horizon: target,
    entry_price: Number(entryPrice.toFixed(4)),
    prediction_snapshot_sec: Number(snapshotSec || 0),
    label_start_sec: Number(first.time),
    label_end_sec: Number(last.time),
    first_price: Number(first.close.toFixed(4)),
    last_price: Number(last.close.toFixed(4)),
    high: Number(high.toFixed(4)),
    low: Number(low.toFixed(4)),
    close_return_pct: closeReturn,
    high_return_pct: highReturn,
    low_return_pct: lowReturn,
    max_gain_pct: highReturn,
    max_drawdown_pct: lowReturn,
    predicted_return: Number.isFinite(predictedReturn) ? predictedReturn : null,
    predicted_direction: predictedDirection,
    direction_correct_close: predictedDirection === 'up' ? closeReturn > 0 : predictedDirection === 'down' ? closeReturn < 0 : null,
    touched_positive: highReturn > 0,
    target_session: target,
    labeled_at: new Date(),
  }
}

function nextTradingDayLabel(row, snapshotSec, candles) {
  const entryPrice = Number(row.price || row.prediction?.entry_price || row.entry_price || 0)
  if (!entryPrice) return { outcome_status: 'unavailable', reason: 'missing_entry_price' }
  const next = candles.find(candle => Number(candle.time || 0) > Number(snapshotSec || 0) + 60 * 60)
  if (!next) return { outcome_status: 'pending', reason: 'no_next_daily_candle_yet' }

  const predictedReturn = Number(row.predicted_return)
  const predictedDirection = predictedReturn > 0 ? 'up' : predictedReturn < 0 ? 'down' : 'watch'
  const closeReturn = pct(entryPrice, next.close)
  const highReturn = pct(entryPrice, next.high)
  const lowReturn = pct(entryPrice, next.low)
  return {
    outcome_status: 'labeled',
    label_source: 'yahoo_daily_chart',
    horizon: 'next_trading_day',
    entry_price: Number(entryPrice.toFixed(4)),
    prediction_snapshot_sec: Number(snapshotSec || 0),
    label_candle_sec: Number(next.time),
    label_date_utc: new Date(Number(next.time) * 1000).toISOString().slice(0, 10),
    open: Number(next.open.toFixed(4)),
    high: Number(next.high.toFixed(4)),
    low: Number(next.low.toFixed(4)),
    close: Number(next.close.toFixed(4)),
    volume: Number(next.volume || 0),
    open_return_pct: pct(entryPrice, next.open),
    high_return_pct: highReturn,
    low_return_pct: lowReturn,
    close_return_pct: closeReturn,
    max_gain_pct: highReturn,
    max_drawdown_pct: lowReturn,
    predicted_return: Number.isFinite(predictedReturn) ? predictedReturn : null,
    predicted_direction: predictedDirection,
    direction_correct_close: predictedDirection === 'up' ? closeReturn > 0 : predictedDirection === 'down' ? closeReturn < 0 : null,
    touched_positive: highReturn > 0,
    labeled_at: new Date(),
  }
}

async function main() {
  const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI || argValue('mongo', 'mongodb://localhost:27017/feedflash')
  const limit = Math.max(1, Math.min(50, toNumber(argValue('limit', '10'), 10)))
  const snapshotId = argValue('snapshot', '')
  const includeRaw = argValue('includeRaw', 'true') !== 'false'
  const includeHigh = argValue('includeHigh', 'true') !== 'false'

  await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 10000 })
  const db = mongoose.connection.db
  const filter = snapshotId
    ? { _id: snapshotId }
    : { $or: [{ 'raw_rows.outcome.outcome_status': { $exists: false } }, { 'high_conviction_rows.outcome.outcome_status': { $exists: false } }] }
  const snapshots = await db.collection('daily_prediction_snapshots')
    .find(filter)
    .sort({ generated_at: -1 })
    .limit(limit)
    .toArray()

  const tickerCandles = new Map()
  const tickerIntradayCandles = new Map()
  const outcomes = []
  let labeled = 0
  let pending = 0

  for (const snapshot of snapshots) {
    const snapshotSec = Number(snapshot.generated_at_sec || Math.floor(new Date(snapshot.generated_at || 0).getTime() / 1000))
    const rowGroups = []
    if (includeRaw) rowGroups.push(['raw_rows', Array.isArray(snapshot.raw_rows) ? snapshot.raw_rows : []])
    if (includeHigh) rowGroups.push(['high_conviction_rows', Array.isArray(snapshot.high_conviction_rows) ? snapshot.high_conviction_rows : []])
    const updated = {}

    for (const [field, rows] of rowGroups) {
      const nextRows = []
      for (const row of rows) {
        if (row.outcome?.outcome_status === 'labeled') {
          nextRows.push(row)
          continue
        }
        const ticker = String(row.ticker || '').toUpperCase()
        if (!ticker) {
          nextRows.push(row)
          continue
        }
        if (!tickerCandles.has(ticker)) {
          try { tickerCandles.set(ticker, await fetchDailyCandles(ticker)) }
          catch (err) { tickerCandles.set(ticker, { error: String(err.message || err) }) }
        }
        if (!tickerIntradayCandles.has(ticker)) {
          try { tickerIntradayCandles.set(ticker, await fetchIntradayCandles(ticker)) }
          catch (err) { tickerIntradayCandles.set(ticker, { error: String(err.message || err) }) }
        }
        const candleResult = tickerCandles.get(ticker)
        const intradayResult = tickerIntradayCandles.get(ticker)
        const intradayOutcome = Array.isArray(intradayResult)
          ? intradaySessionLabel(row, snapshotSec, intradayResult, snapshot)
          : { outcome_status: 'unavailable', reason: intradayResult.error || 'intraday_chart_fetch_failed' }
        const outcome = intradayOutcome?.outcome_status === 'labeled'
          ? intradayOutcome
          : Array.isArray(candleResult)
            ? { ...nextTradingDayLabel(row, snapshotSec, candleResult), intraday_status: intradayOutcome?.outcome_status, intraday_reason: intradayOutcome?.reason }
            : { outcome_status: 'unavailable', reason: candleResult.error || 'chart_fetch_failed', intraday_status: intradayOutcome?.outcome_status, intraday_reason: intradayOutcome?.reason }
        if (outcome.outcome_status === 'labeled') labeled += 1
        if (outcome.outcome_status === 'pending') pending += 1
        const outcomeDoc = {
          _id: `${snapshot._id}:${field}:${ticker}`,
          snapshot_id: snapshot._id,
          date_key: snapshot.date_key,
          row_group: field,
          ticker,
          rank: row.rank,
          final_prediction_score: row.final_prediction_score,
          signal_quality: row.signal_quality,
          risk_flags: row.risk_flags || [],
          outcome,
          updated_at: new Date(),
        }
        await db.collection('prediction_outcomes').updateOne(
          { _id: outcomeDoc._id },
          { $set: outcomeDoc, $setOnInsert: { created_at: new Date() } },
          { upsert: true }
        )
        outcomes.push(outcomeDoc)
        nextRows.push({
          ...row,
          outcome,
          outcome_status: outcome.outcome_status,
          realized_return_pct: outcome.close_return_pct ?? null,
          realized_high_return_pct: outcome.high_return_pct ?? null,
          realized_low_return_pct: outcome.low_return_pct ?? null,
          realized_price: outcome.last_price ?? outcome.close ?? null,
          realized_at: outcome.label_end_sec
            ? new Date(Number(outcome.label_end_sec) * 1000)
            : outcome.label_candle_sec
              ? new Date(Number(outcome.label_candle_sec) * 1000)
              : null,
          direction_correct_close: outcome.direction_correct_close ?? null,
        })
      }
      updated[field] = nextRows
    }

    await db.collection('daily_prediction_snapshots').updateOne(
      { _id: snapshot._id },
      {
        $set: {
          ...updated,
          outcomes_labeled_at: new Date(),
          updated_at: new Date(),
        },
      }
    )
  }

  await db.collection('prediction_outcomes').createIndex({ snapshot_id: 1, ticker: 1 })
  await db.collection('prediction_outcomes').createIndex({ ticker: 1, 'outcome.label_candle_sec': -1 })

  console.log(JSON.stringify({
    ok: true,
    snapshots_checked: snapshots.length,
    outcomes_written: outcomes.length,
    labeled,
    pending,
    examples: outcomes.slice(0, 10).map(row => ({
      snapshot_id: row.snapshot_id,
      group: row.row_group,
      ticker: row.ticker,
      score: row.final_prediction_score,
      status: row.outcome.outcome_status,
      close_return_pct: row.outcome.close_return_pct,
      direction_correct_close: row.outcome.direction_correct_close,
      reason: row.outcome.reason,
    })),
  }, null, 2))

  await mongoose.disconnect()
}

main().catch(async err => {
  console.error(JSON.stringify({ ok: false, error: String(err.message || err) }, null, 2))
  try { await mongoose.disconnect() } catch (_) {}
  process.exit(1)
})
