import 'dotenv/config'
import express from 'express'
import mongoose from 'mongoose'
import cors    from 'cors'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { connectDB } from './db.js'
import Redis from 'ioredis'
import * as diskdb from './diskdb.js'   // hard-disk (on-disk SQLite) news store + retention sweeper

import articlesRouter    from './routes/articles.js'
import screenerRouter    from './routes/screener.js'
import decisionMapRouter from './routes/decisionMap.js'
import socialRouter      from './routes/social.js'
import correlationRouter from './routes/correlation.js'
import settingsRouter    from './routes/settings.js'
import { applySourceFilterMiddleware, approvedNewsSourceMongoFilter } from "./sourceFilter.js";

const app  = express()
const PORT = process.env.PORT || 3001
const SERVER_DIR = path.dirname(fileURLToPath(import.meta.url))
const PROJECT_ROOT = path.resolve(SERVER_DIR, '../..')
const MARKET_WINDOW_TIME_ZONE = process.env.MARKET_WINDOW_TIMEZONE || 'America/New_York'
const MARKET_WINDOW_CLOSE_HOUR = Number(process.env.MARKET_WINDOW_CLOSE_HOUR_ET || 17)
const TRACKED_TICKER_FILE_CANDIDATES = [
  path.join(process.cwd(), 'config', 'social_tickers_100.txt'),
  path.join(PROJECT_ROOT, 'config', 'social_tickers_100.txt'),
  path.join(SERVER_DIR, 'config', 'social_tickers_100.txt'),
]
const TRACKED_TICKER_LIMIT = Math.max(1, Number(process.env.TRACKED_TICKER_LIMIT || process.env.SOCIAL_MAX_TICKERS || 250))
const NON_STOCK_TICKERS = new Set([
  "BTC", "ETH", "LTC", "DOGE", "SOL", "ADA", "XRP", "BNB", "DOT", "AVAX",
  "MATIC", "SHIB", "TRX", "BCH", "LINK", "ATOM", "UNI", "ETC", "FIL",
  "USD", "USDT", "USDC", "SPOT",
])
const US_EXCHANGES = new Set(["NASDAQ", "NYSE", "AMEX"])
const TRACKED_MARKET_INDICES = [
  { symbol: "DJI", name: "Dow Jones Industrial Average", category: "index" },
  { symbol: "SPX", name: "S&P 500", category: "index" },
  { symbol: "IXIC", name: "Nasdaq Composite", category: "index" },
  { symbol: "RUT", name: "Russell 2000 Index", category: "index" },
  { symbol: "NYA", name: "NYSE Composite", category: "index" },
]
const TRACKED_MARKETS = [
  ...Array.from(US_EXCHANGES).map(symbol => ({ symbol, name: `${symbol} listed equities`, category: "exchange" })),
  ...TRACKED_MARKET_INDICES,
]
const MAX_SIGNAL_CHANGE_PCT = Math.max(10, Number(process.env.MAX_SIGNAL_CHANGE_PCT || 300))
const MIN_LIVE_MODEL_CONFIDENCE = Math.max(0, Math.min(1, Number(process.env.MIN_LIVE_MODEL_CONFIDENCE || 0.05)))
const PRIVATE_TRACKED_TICKERS = new Set(['SPACEX'])

// ── Middleware ────────────────────────────────────────────
const CORS_ORIGINS = (process.env.CORS_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean)
app.use(cors({ origin: CORS_ORIGINS }))
app.use(express.json({ limit: '2mb' }))
applySourceFilterMiddleware(app)

// ── RAM speed layer: Redis hot cache + Kafka→Redis feed reads ─────────────────
// Redis holds (a) a short-TTL cache of the expensive Mongo aggregations so the
// dashboard reads from RAM, and (b) the per-ticker hot window the Kafka consumer
// streams in (feed:{TICKER} ZSet → event:{id} hashes). If Redis is unavailable,
// every path transparently falls back to MongoDB — the app never breaks.
const REDIS_URL = process.env.REDIS_URL || 'redis://127.0.0.1:6379'
let redis = null
try {
  redis = new Redis(REDIS_URL, {
    lazyConnect: true,
    maxRetriesPerRequest: 2,
    enableOfflineQueue: false,
    enableAutoPipelining: true,
    keepAlive: 30000,
    retryStrategy: (n) => (n > 10 ? null : Math.min(n * 200, 2000)),
  })
  redis.on('error', () => {})                       // quiet; usage is guarded by status check
  redis.on('ready', () => console.log('  Redis   →  connected (RAM cache + hot feed active)'))
  redis.connect().catch(() => console.warn('  Redis   →  not reachable; serving from MongoDB only'))
} catch (e) {
  console.warn('  Redis   →  disabled:', e.message)
  redis = null
}
const redisReady = () => !!redis && redis.status === 'ready'
app.locals.redis = redis
app.locals.redisReady = redisReady

// Transparent response cache for the heaviest GETs — identical JSON shape, served
// from RAM within the TTL window. Only successful (200) responses are cached.
const CACHE_RULES = [
  { match: (p) => p.startsWith('/api/screener'), ttl: Number(process.env.CACHE_TTL_SCREENER || 30), staleTtl: Number(process.env.CACHE_STALE_TTL_SCREENER || 300) },
  { match: (p) => p === '/api/decision-map',    ttl: Number(process.env.CACHE_TTL_DECISION_MAP || 60), staleTtl: Number(process.env.CACHE_STALE_TTL_DECISION_MAP || 300) },
  { match: (p) => p === '/api/social/rolling',  ttl: Number(process.env.CACHE_TTL_SOCIAL || 15), staleTtl: Number(process.env.CACHE_STALE_TTL_SOCIAL || 120) },
  { match: (p) => p.startsWith('/api/charts/'), ttl: Number(process.env.CACHE_TTL_CHARTS || 20), staleTtl: Number(process.env.CACHE_STALE_TTL_CHARTS || 180) },
  { match: (p) => p === '/api/momentum',        ttl: Number(process.env.CACHE_TTL_MOMENTUM || 15), staleTtl: Number(process.env.CACHE_STALE_TTL_MOMENTUM || 120) },
  { match: (p) => p === '/api/correlation',     ttl: Number(process.env.CACHE_TTL_CORRELATION || 30), staleTtl: Number(process.env.CACHE_STALE_TTL_CORRELATION || 180) },
  { match: (p) => p === '/api/articles',        ttl: Number(process.env.CACHE_TTL_ARTICLES || 15), staleTtl: Number(process.env.CACHE_STALE_TTL_ARTICLES || 120) },
  { match: (p) => p.startsWith('/api/ai/'),     ttl: Number(process.env.CACHE_TTL_AI || 15), staleTtl: Number(process.env.CACHE_STALE_TTL_AI || 180) },
]
const cacheRuleFor = (p) => CACHE_RULES.find((rule) => rule.match(p)) || null
app.use(async (req, res, next) => {
  if (req.method !== 'GET' || !redisReady()) return next()
  if (req.query.fresh === '1') return next()
  const cacheRule = cacheRuleFor(req.path)
  const ttl = Number(cacheRule?.ttl || 0)
  if (!cacheRule || !ttl) return next()
  const key = 'cache:' + req.originalUrl
  const staleKey = `${key}:stale`
  try {
    const hit = await redis.get(key)
    if (hit) { res.set('X-Cache', 'HIT'); return res.type('application/json').send(hit) }
    if (req.query.fresh !== '1') {
      const stale = await redis.get(staleKey)
      if (stale) {
        res.set('X-Cache', 'STALE')
        res.set('X-Cache-Note', 'served recent stale cache; use fresh=1 to bypass')
        return res.type('application/json').send(stale)
      }
    }
  } catch (_) { /* fall through to compute from Mongo */ }
  const sendJson = res.json.bind(res)
  res.json = (body) => {
    if (res.statusCode === 200) {
      res.set('X-Cache', 'MISS')
      try {
        const serialized = JSON.stringify(body)
        redis.set(key, serialized, 'EX', ttl).catch(() => {})
        redis.set(staleKey, serialized, 'EX', Math.max(ttl, Number(cacheRule.staleTtl || ttl * 4))).catch(() => {})
      } catch (_) {}
    }
    return sendJson(body)
  }
  next()
})

// GET /api/feed/:ticker — RAM-speed read of the per-ticker hot window that the
// Kafka consumer streams into Redis (feed:{TICKER} ZSet → event:{id} hashes).
app.get('/api/feed/:ticker', async (req, res) => {
  const ticker = String(req.params.ticker || '').toUpperCase().trim()
  const limit = Math.min(Number(process.env.ARTICLES_MAX_LIMIT || 5000), Math.max(1, Number(req.query.limit) || 5000))
  if (!ticker) return res.status(400).json({ error: 'ticker required' })
  if (!redisReady()) {
    return res.status(503).json({ ticker, source: 'none', count: 0, events: [],
      note: 'Redis not connected — start Redis and the Kafka consumer to use the hot feed.' })
  }
  try {
    const ids = await redis.zrevrange(`feed:${ticker}`, 0, limit - 1)
    if (!ids || !ids.length) return res.json({ ticker, source: 'redis', count: 0, events: [] })
    const pipe = redis.pipeline()
    ids.forEach((id) => pipe.hgetall(`event:${id}`))
    const rows = await pipe.exec()
    const events = rows
      .map(([err, h]) => (err || !h || Object.keys(h).length === 0) ? null : h)
      .filter(Boolean)
      .map((h) => {
        let s = Number(h.sentiment_score)
        if (Number.isNaN(s) && h.payload) { try { s = Number(JSON.parse(h.payload).sentiment_score) } catch (_) {} }
        return { ...h, sentiment_score: Number.isNaN(s) ? null : s }
      })
    const svals = events.map((e) => e.sentiment_score).filter((n) => typeof n === 'number')
    const avg = svals.length ? +(svals.reduce((a, b) => a + b, 0) / svals.length).toFixed(3) : null
    res.json({ ticker, source: 'redis', count: events.length, avg_sentiment: avg, events })
  } catch (e) {
    res.status(500).json({ ticker, error: e.message, events: [] })
  }
})

// ── AI analysis: directional scores + market overview from recent news ────────
// The "AI score" aggregates the per-article sentiment (already produced by the
// FinBERT + LLM sentiment stage) over the last few days into a directional
// -100..+100 score per ticker. Results are cached in Redis (RAM) for speed.
const AI_ARTICLES_COLLECTION = process.env.ARTICLES_COLLECTION || 'articles'
function aiTimestampMs(value) {
  if (!value) return 0
  if (value instanceof Date) return value.getTime()
  const n = Number(value)
  if (Number.isFinite(n) && n > 0) return n > 1_000_000_000_000 ? n : n * 1000
  const ms = Date.parse(String(value))
  return Number.isFinite(ms) ? ms : 0
}
function aiArticleTimeMs(a) {
  return aiTimestampMs(a.publish_date) || aiTimestampMs(a.published_at) || aiTimestampMs(a.fetched_date) ||
    aiTimestampMs(a.detected_at) || aiTimestampMs(a.createdAt) || aiTimestampMs(a.updatedAt)
}
async function aiRecentArticles(db, days) {
  const cutoffMs = Date.now() - Math.max(1, days) * 86_400_000
  const projection = {
    ticker: 1, tickers: 1, symbol: 1, symbols: 1,
    sentiment: 1, sentiment_score: 1, finbert_score: 1, vader_score: 1, gemini_sentiment: 1,
    ml_confidence: 1, title: 1, source: 1,
    publish_date: 1, published_at: 1, fetched_date: 1, detected_at: 1, createdAt: 1, updatedAt: 1,
  }
  const docs = await db.collection(AI_ARTICLES_COLLECTION)
    .find({}, { projection })
    .sort({ _id: -1 })
    .limit(10000)
    .toArray()

  const usable = docs.filter(a => aiTickers(a).length && aiSentiment(a) !== null)
  const recent = usable.filter(a => {
    const ts = aiArticleTimeMs(a)
    return ts > 0 && ts >= cutoffMs
  })

  // If the stored timestamps are older/malformed, still show the latest real
  // ticker-tagged rows instead of a dead 0-count AI panel.
  return (recent.length ? recent : usable).slice(0, 8000)
}
function aiSentiment(a) {
  let v = a.sentiment_score ?? a.finbert_score ?? a.vader_score ?? a.gemini_sentiment
  if (v == null) v = a.sentiment                       // string label fallback ("bullish"/"bearish"/"neutral")
  if (typeof v === 'string') {
    const s = v.toLowerCase()
    if (s.includes('bull') || s.includes('positive')) return 0.6
    if (s.includes('bear') || s.includes('negative')) return -0.6
    if (s.includes('neutral')) return 0
    const n = parseFloat(v); return Number.isFinite(n) ? n : null
  }
  return Number.isFinite(v) ? v : null
}
function aiTickers(a) {
  // articles store `ticker` as a comma-separated string, e.g. "AAPL,MSFT"
  const out = []
  const push = (val) => String(val || '').split(/[,\s]+/).forEach((t) => {
    const k = t.trim().toUpperCase()
    if (k && k.length <= 6 && /^[A-Z][A-Z0-9.\-]*$/.test(k)) out.push(k)
  })
  if (Array.isArray(a.tickers)) a.tickers.forEach(push)
  else if (a.tickers) push(a.tickers)
  if (a.ticker) push(a.ticker)
  if (a.symbol) push(a.symbol)
  if (Array.isArray(a.symbols)) a.symbols.forEach(push)
  else if (a.symbols) push(a.symbols)
  return Array.from(new Set(out)).filter(t => !NON_STOCK_TICKERS.has(t))
}
function aiScoreTickers(arts) {
  const m = new Map()
  for (const a of arts) {
    const s = aiSentiment(a); if (s === null) continue
    for (const t of aiTickers(a)) {
      const k = String(t).toUpperCase().trim(); if (!k || k.length > 8) continue
      const e = m.get(k) || { sum: 0, n: 0, pos: 0, neg: 0 }
      e.sum += s; e.n += 1; if (s > 0.15) e.pos += 1; else if (s < -0.15) e.neg += 1
      m.set(k, e)
    }
  }
  return m
}

app.get('/api/ai/scores', async (req, res) => {
  const days = Math.min(14, Math.max(1, Number(req.query.days) || 3))
  const limit = Math.min(Number(process.env.ARTICLES_MAX_LIMIT || 5000), Math.max(1, Number(req.query.limit) || 5000))
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ error: 'MongoDB not connected', scores: [] })
    const arts = await aiRecentArticles(db, days)
    const scored = [...aiScoreTickers(arts).entries()]
      .map(([ticker, e]) => {
        const avg = e.sum / e.n
        const score = Math.round(Math.max(-100, Math.min(100, avg * 100)))
        return {
          ticker, score,
          direction: score > 8 ? 'up' : score < -8 ? 'down' : 'flat',
          confidence: +Math.min(1, e.n / 20).toFixed(2),
          article_count: e.n, bullish: e.pos, bearish: e.neg,
        }
      })
      .filter((x) => x.article_count >= 1)
      .sort((a, b) => Math.abs(b.score) - Math.abs(a.score))
      .slice(0, limit)
    res.json({ days, generated_at: Date.now(), model: 'news-sentiment-aggregate', scores: scored })
  } catch (e) {
    res.status(500).json({ error: e.message, scores: [] })
  }
})

app.get('/api/ai/overview', async (req, res) => {
  const days = Math.min(14, Math.max(1, Number(req.query.days) || 3))
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ error: 'MongoDB not connected' })
    const arts = await aiRecentArticles(db, days)
    const sents = arts.map(aiSentiment).filter((n) => n !== null)
    const avg = sents.length ? sents.reduce((a, b) => a + b, 0) / sents.length : 0
    const ranked = [...aiScoreTickers(arts).entries()]
      .filter(([, e]) => e.n >= 1)
      .map(([ticker, e]) => ({ ticker, avg: e.sum / e.n, n: e.n }))
    const bull = [...ranked].sort((a, b) => b.avg - a.avg).slice(0, 5)
    const bear = [...ranked].sort((a, b) => a.avg - b.avg).slice(0, 5)
    const mood = avg > 0.1 ? 'risk-on' : avg < -0.1 ? 'risk-off' : 'mixed'
    const summary =
      `Across ${arts.length} ticker-tagged articles in the last ${days} day(s), overall news sentiment is ` +
      `${mood} (avg ${avg.toFixed(2)}). ` +
      (bull.length ? `Strongest positive coverage: ${bull.map((b) => b.ticker).join(', ')}. ` : '') +
      (bear.length ? `Most negative: ${bear.map((b) => b.ticker).join(', ')}.` : '')
    res.json({
      days, generated_at: Date.now(), model: 'news-sentiment-aggregate',
      article_count: arts.length, avg_sentiment: +avg.toFixed(3), mood, summary,
      top_bullish: bull.map((b) => ({ ticker: b.ticker, score: Math.round(b.avg * 100), article_count: b.n })),
      top_bearish: bear.map((b) => ({ ticker: b.ticker, score: Math.round(b.avg * 100), article_count: b.n })),
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

app.get('/api/ai/rankings', async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: 'MongoDB not connected' })

    const days = Math.min(14, Math.max(1, Number(req.query.days) || 3))
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50))
    const socialWindow = Math.min(4320, Math.max(5, Number(req.query.window_minutes) || 1440))
    const minScore = Math.max(0, Math.min(100, Number(req.query.min_score) || 0))

    const [arts, tradeRows, model, signalRows] = await Promise.all([
      aiRecentArticles(db, days),
      loadEnrichedTradeWatchRows(db, { limit: Math.max(limit, 30), days, socialWindow }),
      loadLatestPredictionModel(db),
      db.collection('prediction_signals').find(
        {},
        {
          projection: {
            ticker: 1,
            signal_sec: 1,
            decision: 1,
            baseline_signal: 1,
            model_signal: 1,
            label_status: 1,
            labels: 1,
          },
        }
      ).sort({ signal_sec: -1 }).limit(500).toArray().catch(() => []),
    ])

    const newsMap = aiScoreTickers(arts)
    const latestSignalByTicker = new Map()
    for (const row of signalRows) {
      const ticker = String(row.ticker || '').toUpperCase()
      if (ticker && !latestSignalByTicker.has(ticker)) latestSignalByTicker.set(ticker, row)
    }

    const rows = tradeRows.map((row, index) => {
      const ticker = String(row.ticker || '').toUpperCase()
      const news = newsMap.get(ticker) || { sum: 0, n: 0, pos: 0, neg: 0 }
      const newsAvg = news.n ? news.sum / news.n : Number(row.article_sentiment || 0)
      const newsScore = clamp((newsAvg + 1) / 2)
      const tradeScore = Number(row.trade_watch?.trade_watch_score || 0)
      const socialCount = Number(row.message_count || 0)
      const articleCount = Number(row.article_count || 0)
      const evidenceScore = Number(row.trade_watch?.evidence_score || 0)
      const socialDensity = clamp(Math.log1p(socialCount) / Math.log1p(80))
      const features = predictionFeaturesFromMover(row, socialWindow)
      const modelSignal = applyPredictionModel(features, model)
      const baselineSignal = baselinePredictionFromMover(row)
      const storedSignal = latestSignalByTicker.get(ticker)
      const storedModelSignal = storedSignal?.model_signal
      const usableModelSignal = isLiveModelSignalEligible(modelSignal, model) ? modelSignal : null
      const usableStoredModelSignal = isLiveModelSignalEligible(storedModelSignal, model) ? storedModelSignal : null
      const activeSignal = usableModelSignal || usableStoredModelSignal || storedSignal?.baseline_signal || baselineSignal
      const probabilityUp = Number(activeSignal?.probability_up)
      const modelDirectionBoost = activeSignal?.direction === 'up'
        ? 0.08
        : activeSignal?.direction === 'down'
          ? -0.08
          : 0
      const predictionScore = Number.isFinite(probabilityUp)
        ? clamp(probabilityUp)
        : activeSignal?.direction === 'up'
          ? 0.62
          : activeSignal?.direction === 'down'
            ? 0.38
            : 0.5
      const quoteFreshness = Number(row.trade_watch?.quote_freshness ?? 0.5)
      const correlationScore = clamp(Number(features.correlation_score || 0), -1, 1)
      const validationAccuracy = Number(features.prediction_validation_accuracy_5m)
      const validationReturn = Number(features.prediction_validation_avg_return_5m)
      const validationEdge = clamp(
        (Number.isFinite(validationAccuracy) ? Math.max(0, validationAccuracy - 0.5) * 1.6 : 0) +
        (Number.isFinite(validationReturn) ? Math.max(0, validationReturn) / 3 : 0),
        0,
        1
      )
      const positiveCatalyst = Boolean(
        (articleCount > 0 && newsAvg > 0.05) ||
        (socialCount > 0 && Number(row.social_sentiment || 0) > 0.08) ||
        correlationScore > 0.12 ||
        validationEdge > 0.10 ||
        Number(features.is_news_catalyst || 0) === 1
      )
      const technicalConfirmation = positiveCatalyst
        ? clamp(
            (Number(features.rsi || 50) >= 38 && Number(features.rsi || 50) <= 68 ? 0.35 : 0) +
            (Number(features.rsi_oversold || 0) * 0.20) +
            (Number(row.change_pct || 0) >= -4 && Number(row.change_pct || 0) <= 12 ? 0.20 : 0) +
            (Number(row.rel_volume || 0) >= 1.25 ? 0.25 : 0),
            0,
            1
          )
        : 0
      const blended = clamp(
        tradeScore * 0.22 +
        newsScore * 0.18 +
        evidenceScore * 0.14 +
        socialDensity * 0.08 +
        predictionScore * 0.16 +
        quoteFreshness * 0.05 +
        ((correlationScore + 1) / 2) * 0.08 +
        validationEdge * 0.05 +
        technicalConfirmation * 0.04 +
        modelDirectionBoost
      )
      const aiRankScore = Number((blended * 100).toFixed(1))
      const direction = aiRankScore >= 68 && Number(row.change_pct || 0) >= 0
        ? 'bullish'
        : aiRankScore <= 38 || activeSignal?.direction === 'down'
          ? 'bearish'
          : 'watch'

      return {
        rank_seed: index + 1,
        ticker,
        company: row.company || '',
        exchange: row.exchange || '',
        sector: row.sector || '',
        price: row.price ?? null,
        change_pct: Number(row.change_pct || 0),
        rel_volume: Number(row.rel_volume || 0),
        volume: Number(row.volume || 0),
        ai_rank_score: aiRankScore,
        direction,
        confidence: Number(Math.abs(blended - 0.5).toFixed(3)),
        trade_watch_score: Number(tradeScore.toFixed(3)),
        prediction_signal: activeSignal || null,
        model_signal: modelSignal,
        baseline_signal: baselineSignal,
        model_ready: Boolean(modelSignal),
        evidence: {
          news_score: Number((newsAvg * 100).toFixed(1)),
          news_articles: articleCount,
          scored_news_articles: Number(news.n || 0),
          bullish_news: Number(news.pos || 0),
          bearish_news: Number(news.neg || 0),
          social_posts: socialCount,
          social_sentiment: Number(Number(row.social_sentiment || 0).toFixed(3)),
          structured_articles: Number(row.structured_article_count || 0),
          public_articles: Number(row.unstructured_article_count || 0),
          evidence_score: Number(evidenceScore.toFixed(3)),
          agreement: Number(row.trade_watch?.agreement || 0),
          positive_catalyst_gate: positiveCatalyst,
          technical_confirmation: Number(technicalConfirmation.toFixed(3)),
          correlation_score: Number(correlationScore.toFixed(3)),
          validation_edge: Number(validationEdge.toFixed(3)),
          quote_age_minutes: row.trade_watch?.quote_age_minutes ?? null,
          latest_signal_status: storedSignal?.label_status || null,
        },
        reasons: row.trade_watch?.reasons || [],
        risks: row.trade_watch?.risks || [],
      }
    })
      .filter(row => row.ticker && row.ai_rank_score >= minScore)
      .sort((a, b) => b.ai_rank_score - a.ai_rank_score || b.evidence.news_articles - a.evidence.news_articles)
      .slice(0, limit)
      .map((row, index) => ({ ...row, rank: index + 1 }))

    const summary = {
      rows: rows.length,
      source_rows: tradeRows.length,
      article_window_days: days,
      scored_articles: arts.length,
      social_window_minutes: socialWindow,
      bullish: rows.filter(row => row.direction === 'bullish').length,
      bearish: rows.filter(row => row.direction === 'bearish').length,
      watch: rows.filter(row => row.direction === 'watch').length,
      model_status: model?.status || 'baseline',
      model_samples: Number(model?.samples || 0),
      model_updated_at: model?.updated_at || null,
    }
    const modelValidation = modelValidationState(model)

    res.json({
      ok: true,
      generated_at: new Date().toISOString(),
      model: {
        name: model?.model_id || PREDICTION_MODEL_ID,
        status: model?.status || 'baseline',
        samples: Number(model?.samples || 0),
        min_samples: model?.min_samples || Number(process.env.PREDICTION_MIN_TRAINING_SAMPLES || 20),
        metrics: model?.metrics || null,
        validation_status: modelValidation.status,
        validation_edge: modelValidation.edge,
        live_classifier_enabled: modelValidation.allow_live_classifier,
        live_classifier_reason: modelValidation.reason,
        fallback: 'baseline_trade_watch_v1',
      },
      methodology: {
        ranking: 'blended Trade Watch, rolling news sentiment, social density, quote freshness, correlation, gated technical confirmation, and validated prediction signal',
        scaling: 'server-side capped and cached; no browser-side scan of Mongo collections',
        provider_dependency: 'none on read path; uses stored validated model when it beats baseline, otherwise shadows it and falls back to baseline/transparent evidence',
      },
      summary,
      rows,
    })
  } catch (err) {
    console.error('GET /api/ai/rankings failed:', err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get('/api/ai/ticker/:ticker', async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: 'MongoDB not connected' })

    const ticker = String(req.params.ticker || '').toUpperCase().replace(/[^A-Z0-9.-]/g, '')
    if (!ticker) return res.status(400).json({ ok: false, error: 'Ticker is required' })

    const days = Math.min(14, Math.max(1, Number(req.query.days) || 3))
    const socialWindow = Math.min(4320, Math.max(5, Number(req.query.window_minutes) || 1440))
    const sinceSocialSec = Math.floor(Date.now() / 1000) - socialWindow * 60
    const tickerRegex = `(^|,\\s*)${escapeRegExp(ticker)}(\\s*,|$)`
    const articleMatch = {
      ...recentArticleMatch(days),
      ...approvedNewsSourceMongoFilter('source'),
      $or: [
        { ticker: { $regex: tickerRegex, $options: 'i' } },
        { tickers: ticker },
        { tickers_mentioned: ticker },
      ],
    }

    const [movers, arts, model, articles, articleCount, socialRows, predictionRows] = await Promise.all([
      loadPositiveFinvizMoverRows(db, 200),
      aiRecentArticles(db, days),
      loadLatestPredictionModel(db),
      db.collection('articles').find(
        articleMatch,
        {
          projection: {
            title: 1,
            source: 1,
            category: 1,
            article_kind: 1,
            sentiment: 1,
            sentiment_score: 1,
            ml_confidence: 1,
            event_type: 1,
            event_score: 1,
            sentiment_reason: 1,
            publish_date: 1,
            fetched_date: 1,
            detected_at: 1,
            url: 1,
          },
        }
      ).sort({ publish_date: -1, fetched_date: -1, detected_at: -1 }).limit(20).toArray(),
      db.collection('articles').countDocuments(articleMatch),
      db.collection('socials').aggregate([
        ...socialTimeStages(),
        { $match: { _event_sec: { $gte: sinceSocialSec }, _ticker_candidates: ticker } },
        { $sort: { _event_sec: -1 } },
        { $limit: 20 },
        {
          $project: {
            _id: 0,
            platform: '$_norm_platform',
            author: 1,
            text: { $ifNull: ['$text', { $ifNull: ['$content', '$title'] }] },
            sentiment: 1,
            sentiment_score: 1,
            url: 1,
            event_sec: '$_event_sec',
          },
        },
      ]).toArray(),
      db.collection('prediction_signals').find(
        { ticker },
        {
          projection: {
            _id: 0,
            signal_id: 1,
            signal_sec: 1,
            decision: 1,
            trade_watch: 1,
            baseline_signal: 1,
            model_signal: 1,
            label_status: 1,
            labels: 1,
            features: 1,
            rank: 1,
          },
        }
      ).sort({ signal_sec: -1 }).limit(20).toArray(),
    ])

    const mover = movers.find(row => String(row.ticker || '').toUpperCase() === ticker)
    const [articleMap, socialMap] = await Promise.all([
      loadArticleStatsForTickers(db, [ticker], days),
      loadSocialStatsForTickers(db, [ticker], socialWindow),
    ])
    const enriched = mover
      ? addTradeWatchFields(mergeMoverContext(mover, articleMap.get(ticker), socialMap.get(ticker)))
      : null
    const news = aiScoreTickers(arts).get(ticker) || { sum: 0, n: 0, pos: 0, neg: 0 }
    const newsAvg = news.n ? news.sum / news.n : Number(enriched?.article_sentiment || 0)
    const features = enriched ? predictionFeaturesFromMover(enriched, socialWindow) : {}
    const modelSignal = enriched ? applyPredictionModel(features, model) : null
    const baselineSignal = enriched ? baselinePredictionFromMover(enriched) : null
    const storedModelSignal = predictionRows[0]?.model_signal
    const usableModelSignal = isLiveModelSignalEligible(modelSignal, model) ? modelSignal : null
    const usableStoredModelSignal = isLiveModelSignalEligible(storedModelSignal, model) ? storedModelSignal : null
    const activeSignal = usableModelSignal || usableStoredModelSignal || predictionRows[0]?.baseline_signal || baselineSignal
    const socialCount = Number(enriched?.message_count || 0)
    const articleTotal = Number(enriched?.article_count || 0)
    const evidenceScore = Number(enriched?.trade_watch?.evidence_score || 0)
    const tradeScore = Number(enriched?.trade_watch?.trade_watch_score || 0)
    const predictionScore = Number.isFinite(Number(activeSignal?.probability_up))
      ? clamp(Number(activeSignal.probability_up))
      : activeSignal?.direction === 'up'
        ? 0.62
        : activeSignal?.direction === 'down'
          ? 0.38
          : 0.5
    const newsScore = clamp((newsAvg + 1) / 2)
    const socialDensity = clamp(Math.log1p(socialCount) / Math.log1p(80))
    const quoteFreshness = Number(enriched?.trade_watch?.quote_freshness ?? 0.5)
    const correlationScore = clamp(Number(features.correlation_score || 0), -1, 1)
    const validationAccuracy = Number(features.prediction_validation_accuracy_5m)
    const validationReturn = Number(features.prediction_validation_avg_return_5m)
    const validationEdge = clamp(
      (Number.isFinite(validationAccuracy) ? Math.max(0, validationAccuracy - 0.5) * 1.6 : 0) +
      (Number.isFinite(validationReturn) ? Math.max(0, validationReturn) / 3 : 0),
      0,
      1
    )
    const positiveCatalyst = Boolean(
      (articleTotal > 0 && newsAvg > 0.05) ||
      (socialCount > 0 && Number(enriched?.social_sentiment || 0) > 0.08) ||
      correlationScore > 0.12 ||
      validationEdge > 0.10 ||
      Number(features.is_news_catalyst || 0) === 1
    )
    const technicalConfirmation = positiveCatalyst
      ? clamp(
          (Number(features.rsi || 50) >= 38 && Number(features.rsi || 50) <= 68 ? 0.35 : 0) +
          (Number(features.rsi_oversold || 0) * 0.20) +
          (Number(enriched?.change_pct || 0) >= -4 && Number(enriched?.change_pct || 0) <= 12 ? 0.20 : 0) +
          (Number(enriched?.rel_volume || 0) >= 1.25 ? 0.25 : 0),
          0,
          1
        )
      : 0
    const blended = enriched
      ? clamp(
          tradeScore * 0.22 +
          newsScore * 0.18 +
          evidenceScore * 0.14 +
          socialDensity * 0.08 +
          predictionScore * 0.16 +
          quoteFreshness * 0.05 +
          ((correlationScore + 1) / 2) * 0.08 +
          validationEdge * 0.05 +
          technicalConfirmation * 0.04 +
          (activeSignal?.direction === 'up' ? 0.08 : activeSignal?.direction === 'down' ? -0.08 : 0)
        )
      : 0
    const aiRankScore = Number((blended * 100).toFixed(1))
    const labeledSignals = predictionRows.filter(row => row.label_status && row.label_status !== 'pending')
    const completeSignals = predictionRows.filter(row => row.label_status === 'complete')
    const correct5 = predictionRows
      .map(row => row.labels?.return_5m?.direction_correct)
      .filter(value => value === true || value === false)
    const accuracy5m = correct5.length
      ? Number((correct5.filter(Boolean).length / correct5.length).toFixed(3))
      : null
    const modelActionableSamples = Number(model?.metrics?.actionable_samples || 0)
    const baselineValidationSamples = Number(model?.metrics?.baseline_actionable_samples || 0)
    const baselineValidationAccuracy = Number(model?.metrics?.baseline_directional_accuracy_5m)
    const modelValidation = modelValidationState(model)

    const checks = [
      {
        label: 'Ticker in Finviz mover universe',
        status: mover ? 'pass' : 'warn',
        detail: mover ? 'Ticker is present in the latest Finviz positive mover set.' : 'Ticker is not in the current Finviz positive mover set.',
      },
      {
        label: 'News evidence window',
        status: articleCount > 0 ? 'pass' : 'warn',
        detail: `${articleCount} approved articles found in the last ${days} day(s).`,
      },
      {
        label: 'Social evidence window',
        status: socialCount > 0 ? 'pass' : 'warn',
        detail: `${socialCount} social posts found in the selected ${socialWindow} minute window.`,
      },
      {
        label: 'Prediction validation',
        status: correct5.length >= 20 ? 'pass' : correct5.length ? 'warn' : 'info',
        detail: correct5.length
          ? `${correct5.length} labeled 5m outcomes for this ticker; accuracy ${Math.round((accuracy5m || 0) * 100)}%.`
          : 'No completed 5m labels for this ticker yet; ranking uses current model/baseline signal.',
      },
      {
        label: 'Model validation set',
        status: modelValidation.allow_live_classifier ? 'pass' : baselineValidationSamples > 0 ? 'warn' : 'info',
        detail: modelActionableSamples > 0
          ? `${modelActionableSamples} actionable validation samples; model ${Number.isFinite(Number(model?.metrics?.directional_accuracy_5m)) ? `${Math.round(Number(model.metrics.directional_accuracy_5m) * 100)}%` : 'accuracy pending'} vs baseline ${Number.isFinite(baselineValidationAccuracy) ? `${Math.round(baselineValidationAccuracy * 100)}%` : 'pending'}. Live classifier: ${modelValidation.allow_live_classifier ? 'enabled' : `shadowed (${modelValidation.reason})`}.`
          : baselineValidationSamples > 0
            ? `The trained model has no confident actionable validation yet; baseline has ${baselineValidationSamples} chart-backed samples${Number.isFinite(baselineValidationAccuracy) ? ` at ${Math.round(baselineValidationAccuracy * 100)}% directional accuracy` : ''}.`
            : model?.status === 'flat_labels'
            ? 'Recent labeled returns are flat/zero, so model weights are disabled and baseline evidence is used.'
            : 'Validation metrics have not accumulated actionable samples yet; baseline evidence is used where needed.',
      },
    ]

    res.json({
      ok: true,
      ticker,
      generated_at: new Date().toISOString(),
      days,
      social_window_minutes: socialWindow,
      score: {
        ai_rank_score: aiRankScore,
        direction: aiRankScore >= 68 && Number(enriched?.change_pct || 0) >= 0 ? 'bullish' : aiRankScore <= 38 ? 'bearish' : 'watch',
        trade_watch_score: Number(tradeScore.toFixed(3)),
        news_score: Number((newsAvg * 100).toFixed(1)),
        evidence_score: Number(evidenceScore.toFixed(3)),
        social_density_score: Number(socialDensity.toFixed(3)),
        prediction_score: Number(predictionScore.toFixed(3)),
        quote_freshness: Number(quoteFreshness.toFixed(3)),
        positive_catalyst_gate: positiveCatalyst,
        technical_confirmation: Number(technicalConfirmation.toFixed(3)),
        correlation_score: Number(correlationScore.toFixed(3)),
        validation_edge: Number(validationEdge.toFixed(3)),
      },
      mover: enriched ? {
        ticker,
        company: enriched.company || '',
        exchange: enriched.exchange || '',
        price: enriched.price ?? null,
        change_pct: Number(enriched.change_pct || 0),
        rel_volume: Number(enriched.rel_volume || 0),
        volume: Number(enriched.volume || 0),
        quote_age_minutes: enriched.trade_watch?.quote_age_minutes ?? null,
        reasons: enriched.trade_watch?.reasons || [],
        risks: enriched.trade_watch?.risks || [],
      } : null,
      evidence: {
        article_count: articleTotal,
        approved_article_count: articleCount,
        scored_news_articles: Number(news.n || 0),
        bullish_news: Number(news.pos || 0),
        bearish_news: Number(news.neg || 0),
        structured_articles: Number(enriched?.structured_article_count || 0),
        public_articles: Number(enriched?.unstructured_article_count || 0),
        social_posts: socialCount,
        social_sentiment: Number(Number(enriched?.social_sentiment || 0).toFixed(3)),
        technicals_used: positiveCatalyst,
      },
      prediction: {
        active_signal: activeSignal || null,
        model_signal: modelSignal,
        baseline_signal: baselineSignal,
        model: model ? {
          status: model.status,
          samples: Number(model.samples || 0),
          metrics: model.metrics || null,
          updated_at: model.updated_at || null,
        } : null,
        signals: predictionRows.map(row => ({
          signal_id: row.signal_id,
          signal_sec: row.signal_sec,
          time: timeLabel(row.signal_sec),
          decision: row.decision,
          rank: row.rank,
          label_status: row.label_status || 'pending',
          trade_watch_score: row.trade_watch?.trade_watch_score ?? null,
          model_signal: row.model_signal || null,
          baseline_signal: row.baseline_signal || null,
          labels: row.labels || {},
        })),
        summary: {
          total: predictionRows.length,
          labeled: labeledSignals.length,
          complete: completeSignals.length,
          accuracy_5m: accuracy5m,
        },
      },
      articles: articles.map(article => ({
        title: article.title || '',
        source: article.source || '',
        category: article.category || '',
        kind: article.article_kind || '',
        sentiment: article.sentiment || 'neutral',
        sentiment_score: Number(articleSentimentValue(article).toFixed(3)),
        confidence: Number(article.ml_confidence || Math.abs(articleSentimentValue(article)) || 0),
        event_type: article.event_type || 'general_news',
        event_score: Number(article.event_score || 0),
        reason: article.sentiment_reason || '',
        url: article.url || '',
        time: timeLabel(article.publish_date || article.fetched_date || article.detected_at),
      })),
      social_posts: socialRows.map(post => ({
        platform: post.platform || 'social',
        author: post.author || '',
        text: post.text || '',
        sentiment: typeof post.sentiment_score === 'number'
          ? Number(post.sentiment_score.toFixed(3))
          : sentimentDirectionValue(post.sentiment),
        url: post.url || '',
        time: timeLabel(post.event_sec),
      })),
      checks,
    })
  } catch (err) {
    console.error('GET /api/ai/ticker/:ticker failed:', err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

const SUPPORTED_TRANSLATION_LANGUAGES = new Set(["en", "es", "fr", "de", "pt", "ja"])
const UNSUPPORTED_TRANSLATION_SCRIPT_RE = /[\u3400-\u9FFF\uF900-\uFAFF\u3040-\u30FF\uAC00-\uD7AF]/

const FINANCE_GLOSSARY = {
  en: [
    ["informa que", "reports that"],
    ["sus activos totales", "its total assets"],
    ["ascienden a", "amount to"],
    ["millones de dolares", "million dollars"],
    ["millones de dólares", "million dollars"],
    ["acciones", "stocks"],
    ["accion", "stock"],
    ["acción", "stock"],
    ["mercado bursatil", "stock market"],
    ["mercado bursátil", "stock market"],
    ["mercado de acoes", "stock market"],
    ["mercado de ações", "stock market"],
    ["ingresos", "revenue"],
    ["receita", "revenue"],
    ["chiffre d'affaires", "revenue"],
    ["umsatz", "revenue"],
    ["resultados", "earnings"],
    ["resultats", "earnings"],
    ["résultats", "earnings"],
    ["gewinne", "earnings"],
    ["ganancia", "profit"],
    ["lucro", "profit"],
    ["benefice", "profit"],
    ["bénéfice", "profit"],
    ["gewinn", "profit"],
    ["perdida", "loss"],
    ["pérdida", "loss"],
    ["perte", "loss"],
    ["verlust", "loss"],
    ["fusion", "merger"],
    ["fusión", "merger"],
    ["fusao", "merger"],
    ["fusão", "merger"],
    ["gappei", "merger"],
    ["adquisicion", "acquisition"],
    ["adquisición", "acquisition"],
    ["aquisicao", "acquisition"],
    ["aquisição", "acquisition"],
    ["ubernahme", "acquisition"],
    ["übernahme", "acquisition"],
    ["prevision", "guidance"],
    ["previsión", "guidance"],
    ["previsions", "guidance"],
    ["prévisions", "guidance"],
    ["projecao", "guidance"],
    ["projeção", "guidance"],
    ["ausblick", "guidance"],
    ["dividendo", "dividend"],
    ["dividende", "dividend"],
    ["inflacion", "inflation"],
    ["inflación", "inflation"],
    ["inflacao", "inflation"],
    ["inflação", "inflation"],
    ["mercado", "market"],
    ["marche", "market"],
    ["marché", "market"],
    ["markt", "market"],
    ["preco", "price"],
    ["preço", "price"],
    ["precio", "price"],
    ["prix", "price"],
    ["preis", "price"],
    ["sube", "rises"],
    ["sobe", "rises"],
    ["steigt", "rises"],
    ["cae", "falls"],
    ["cai", "falls"],
    ["baisse", "falls"],
    ["fallt", "falls"],
    ["fällt", "falls"],
    ["supera", "beats"],
    ["depasse", "beats"],
    ["dépasse", "beats"],
    ["ubertrifft", "beats"],
    ["übertrifft", "beats"],
  ],
  es: [
    ["stock market", "mercado bursatil"],
    ["stocks", "acciones"],
    ["stock", "accion"],
    ["shares", "acciones"],
    ["earnings", "resultados"],
    ["revenue", "ingresos"],
    ["profit", "ganancia"],
    ["loss", "perdida"],
    ["merger", "fusion"],
    ["acquisition", "adquisicion"],
    ["upgrade", "mejora"],
    ["downgrade", "rebaja"],
    ["guidance", "prevision"],
    ["dividend", "dividendo"],
    ["inflation", "inflacion"],
    ["market", "mercado"],
    ["price", "precio"],
    ["rally", "repunte"],
    ["falls", "cae"],
    ["rises", "sube"],
    ["beats", "supera"],
    ["misses", "no alcanza"],
  ],
  fr: [
    ["stock market", "marche boursier"],
    ["stocks", "actions"],
    ["stock", "action"],
    ["shares", "actions"],
    ["earnings", "resultats"],
    ["revenue", "chiffre d'affaires"],
    ["profit", "benefice"],
    ["loss", "perte"],
    ["merger", "fusion"],
    ["acquisition", "acquisition"],
    ["upgrade", "relevement"],
    ["downgrade", "abaissement"],
    ["guidance", "previsions"],
    ["dividend", "dividende"],
    ["inflation", "inflation"],
    ["market", "marche"],
    ["price", "prix"],
    ["rally", "rebond"],
    ["falls", "baisse"],
    ["rises", "monte"],
    ["beats", "depasse"],
    ["misses", "rate"],
  ],
  de: [
    ["stock market", "aktienmarkt"],
    ["stocks", "aktien"],
    ["stock", "aktie"],
    ["shares", "anteile"],
    ["earnings", "gewinne"],
    ["revenue", "umsatz"],
    ["profit", "gewinn"],
    ["loss", "verlust"],
    ["merger", "fusion"],
    ["acquisition", "ubernahme"],
    ["upgrade", "heraufstufung"],
    ["downgrade", "herabstufung"],
    ["guidance", "ausblick"],
    ["dividend", "dividende"],
    ["inflation", "inflation"],
    ["market", "markt"],
    ["price", "preis"],
    ["rally", "rallye"],
    ["falls", "fallt"],
    ["rises", "steigt"],
    ["beats", "ubertrifft"],
    ["misses", "verfehlt"],
  ],
  pt: [
    ["stock market", "mercado de acoes"],
    ["stocks", "acoes"],
    ["stock", "acao"],
    ["shares", "acoes"],
    ["earnings", "resultados"],
    ["revenue", "receita"],
    ["profit", "lucro"],
    ["loss", "perda"],
    ["merger", "fusao"],
    ["acquisition", "aquisicao"],
    ["upgrade", "elevacao"],
    ["downgrade", "rebaixamento"],
    ["guidance", "projecao"],
    ["dividend", "dividendo"],
    ["inflation", "inflacao"],
    ["market", "mercado"],
    ["price", "preco"],
    ["rally", "alta"],
    ["falls", "cai"],
    ["rises", "sobe"],
    ["beats", "supera"],
    ["misses", "fica abaixo"],
  ],
  ja: [
    ["stock market", "kabushiki shijo"],
    ["stocks", "kabushiki"],
    ["stock", "kabushiki"],
    ["shares", "kabushiki"],
    ["earnings", "gyoseki"],
    ["revenue", "uriage"],
    ["profit", "rieki"],
    ["loss", "sonshitsu"],
    ["merger", "gappei"],
    ["acquisition", "baishu"],
    ["upgrade", "kakuzuke hikiage"],
    ["downgrade", "kakuzuke hikisage"],
    ["guidance", "gyoseki yosou"],
    ["dividend", "haito"],
    ["inflation", "infure"],
    ["market", "shijo"],
    ["price", "kakaku"],
    ["rally", "joraku"],
    ["falls", "geraku"],
    ["rises", "josho"],
    ["beats", "uwamawaru"],
    ["misses", "shitamawaru"],
  ],
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

function glossaryTranslate(text, targetLanguage) {
  const glossary = FINANCE_GLOSSARY[targetLanguage] || []
  let translated = String(text || "")

  if (targetLanguage === "en") {
    translated = englishFallbackTranslate(translated)
  }

  for (const [source, target] of glossary) {
    translated = translated.replace(new RegExp(`\\b${escapeRegExp(source)}\\b`, "gi"), target)
  }

  return translated
}

const ENGLISH_DIRECT_TRANSLATIONS = [
  [
    /AIFA\s+就涉及\s+HyalRoute Communication Group Limited\s+的股份收購交易正式作出澄清及反駁/i,
    "AIFA issues formal clarification and rebuttal regarding the share acquisition transaction involving HyalRoute Communication Group Limited",
  ],
  [
    /AIFA、ヒアルルート・コミュニケーション・グループに関連する株式取得取引について、正式な説明および反論を発表/i,
    "AIFA issues formal explanation and rebuttal regarding the share acquisition transaction involving HyalRoute Communication Group Limited",
  ],
  [
    /Penjelasan Rasmi dan Penafian oleh AIFA Berhubung Transaksi Pemerolehan Saham yang melibatkan HyalRoute Communication Group Limited/i,
    "Official clarification and denial by AIFA regarding the share acquisition transaction involving HyalRoute Communication Group Limited",
  ],
  [
    /Huasun belegt den 12\. Platz der TIME-Liste der weltweit führenden GreenTech-Unternehmen 2026 und verbessert sich dank seines Engagements für die HJT-Technologie um 22 Plätze/i,
    "Huasun ranks 12th on TIME's 2026 list of the world's leading GreenTech companies and rises 22 places thanks to its commitment to HJT technology",
  ],
]

const ENGLISH_PHRASE_FALLBACKS = [
  ["belegt den", "ranks"],
  ["Platz der", "place on the"],
  ["TIME-Liste", "TIME list"],
  ["weltweit führenden", "world's leading"],
  ["GreenTech-Unternehmen", "GreenTech companies"],
  ["verbessert sich", "rises"],
  ["dank seines Engagements", "thanks to its commitment"],
  ["für die", "to the"],
  ["Technologie", "technology"],
  ["Plätze", "places"],
  ["Juni", "June"],
  ["Unternehmen", "company"],
  ["weltweit", "worldwide"],
  ["führenden", "leading"],
  ["Umsatz", "revenue"],
  ["Gewinn", "profit"],
  ["Verlust", "loss"],
  ["Aktien", "shares"],
  ["Markt", "market"],
  ["Prix", "price"],
  ["marché", "market"],
  ["résultats", "earnings"],
  ["acciones", "stocks"],
  ["mercado", "market"],
  ["ingresos", "revenue"],
  ["receita", "revenue"],
  ["ações", "stocks"],
  ["就涉及", "regarding"],
  ["的股份收購交易", "the share acquisition transaction"],
  ["股份收購交易", "share acquisition transaction"],
  ["正式作出", "formally issues"],
  ["澄清及反駁", "clarification and rebuttal"],
  ["澄清", "clarification"],
  ["反駁", "rebuttal"],
  ["ヒアルルート・コミュニケーション・グループ", "HyalRoute Communication Group"],
  ["に関連する", "regarding"],
  ["株式取得取引", "share acquisition transaction"],
  ["について", "regarding"],
  ["正式な説明", "formal explanation"],
  ["および反論", "and rebuttal"],
  ["を発表", "announces"],
  ["Penjelasan Rasmi", "Official clarification"],
  ["Penafian", "denial"],
  ["Berhubung", "regarding"],
  ["Transaksi Pemerolehan Saham", "share acquisition transaction"],
  ["yang melibatkan", "involving"],
]

function likelyNeedsEnglishFallback(text) {
  return /[\u3400-\u9FFF\uF900-\uFAFF\u3040-\u30FF\uAC00-\uD7AFäöüßéèêàáíóúñçãõ]|(?:\b(?:der|die|das|und|für|mit|von|belegt|verbessert|weltweit|führenden|acciones|mercado|ingresos|résultats|marché|receita|ações|penjelasan|rasmi|penafian|berhubung|transaksi|pemerolehan|saham|melibatkan)\b)/i.test(text)
}

function englishFallbackTranslate(text) {
  const original = String(text || "")

  for (const [pattern, translation] of ENGLISH_DIRECT_TRANSLATIONS) {
    if (pattern.test(original)) return translation
  }

  if (!likelyNeedsEnglishFallback(original)) return original

  let translated = original
  for (const [source, target] of ENGLISH_PHRASE_FALLBACKS) {
    translated = translated.replace(new RegExp(escapeRegExp(source), "gi"), target)
  }

  translated = translated
    .replace(/\bden\b/gi, "the")
    .replace(/\bder\b/gi, "of the")
    .replace(/\bdie\b/gi, "the")
    .replace(/\bdas\b/gi, "the")
    .replace(/\bund\b/gi, "and")
    .replace(/\bum\b/gi, "by")
    .replace(/\bauf\b/gi, "on")
    .replace(/\bin\b/gi, "in")
    .replace(/\bmit\b/gi, "with")

  return translated === original ? `English translation pending: ${original}` : translated
}

async function translateWithProvider(text, targetLanguage) {
  const url = process.env.TRANSLATION_API_URL
  if (!url || typeof fetch !== "function") return null

  const body = {
    q: text,
    text,
    source: "auto",
    target: targetLanguage,
    target_language: targetLanguage,
    format: "text",
  }

  if (process.env.TRANSLATION_API_KEY) {
    body.api_key = process.env.TRANSLATION_API_KEY
    body.apiKey = process.env.TRANSLATION_API_KEY
  }

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })

  if (!response.ok) {
    throw new Error(`translation provider returned HTTP ${response.status}`)
  }

  const data = await response.json()
  return data.translatedText || data.translated_text || data.translation || data.text || null
}

function easternParts(date) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: MARKET_WINDOW_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date)

  return Object.fromEntries(
    parts
      .filter(part => part.type !== 'literal')
      .map(part => [part.type, Number(part.value)])
  )
}

function easternLocalToUtc(year, month, day, hour, minute = 0, second = 0) {
  const target = Date.UTC(year, month - 1, day, hour, minute, second)
  let guess = target

  for (let i = 0; i < 4; i += 1) {
    const parts = easternParts(new Date(guess))
    const actual = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second)
    const diff = target - actual
    if (diff === 0) break
    guess += diff
  }

  return new Date(guess)
}

function shiftLocalDate(year, month, day, deltaDays) {
  const shifted = new Date(Date.UTC(year, month - 1, day + deltaDays))
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
  }
}

function localWeekday(year, month, day) {
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay()
}

function latestMarketCloseCutoff(now = new Date()) {
  let { year, month, day, hour } = easternParts(now)
  let weekday = localWeekday(year, month, day)

  if (weekday === 0) {
    ;({ year, month, day } = shiftLocalDate(year, month, day, -2))
  } else if (weekday === 6) {
    ;({ year, month, day } = shiftLocalDate(year, month, day, -1))
  } else if (hour < MARKET_WINDOW_CLOSE_HOUR) {
    ;({ year, month, day } = shiftLocalDate(year, month, day, -1))
    while ([0, 6].includes(localWeekday(year, month, day))) {
      ;({ year, month, day } = shiftLocalDate(year, month, day, -1))
    }
  }

  return easternLocalToUtc(year, month, day, MARKET_WINDOW_CLOSE_HOUR)
}

function previousTradingDateParts(year, month, day) {
  let shifted = shiftLocalDate(year, month, day, -1)
  while ([0, 6].includes(localWeekday(shifted.year, shifted.month, shifted.day))) {
    shifted = shiftLocalDate(shifted.year, shifted.month, shifted.day, -1)
  }
  return shifted
}

function mostRecentFridayParts(year, month, day) {
  let shifted = { year, month, day }
  while (localWeekday(shifted.year, shifted.month, shifted.day) !== 5) {
    shifted = shiftLocalDate(shifted.year, shifted.month, shifted.day, -1)
  }
  return shifted
}

function marketPredictionContext(now = new Date()) {
  const parts = easternParts(now)
  const weekday = localWeekday(parts.year, parts.month, parts.day)
  const minutes = Number(parts.hour || 0) * 60 + Number(parts.minute || 0)
  const preStart = 4 * 60
  const regularStart = 9 * 60 + 30
  const regularEnd = 16 * 60
  const afterEnd = 20 * 60
  const isWeekday = weekday >= 1 && weekday <= 5
  let session = 'closed'
  let target = 'next_regular_session'
  let startParts
  let startHour = 16
  let startMinute = 0

  if (!isWeekday) {
    session = 'weekend'
    target = 'next_premarket_open'
    startParts = mostRecentFridayParts(parts.year, parts.month, parts.day)
  } else if (minutes >= preStart && minutes < regularStart) {
    session = 'premarket'
    target = 'regular_session_risers'
    startParts = previousTradingDateParts(parts.year, parts.month, parts.day)
  } else if (minutes >= regularStart && minutes < regularEnd) {
    session = 'regular'
    target = 'late_day_and_afterhours_continuation'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
    startHour = 4
  } else if (minutes >= regularEnd && minutes < afterEnd) {
    session = 'afterhours'
    target = 'afterhours_and_next_premarket_risers'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
    startHour = 9
    startMinute = 30
  } else if (minutes < preStart) {
    session = 'overnight'
    target = 'premarket_risers'
    startParts = previousTradingDateParts(parts.year, parts.month, parts.day)
  } else {
    session = 'closed_post_afterhours'
    target = 'next_premarket_open'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
  }

  const start = easternLocalToUtc(startParts.year, startParts.month, startParts.day, startHour, startMinute)
  const end = now
  const startSec = Math.floor(start.getTime() / 1000)
  const endSec = Math.floor(end.getTime() / 1000)
  const hours = Math.max(0, (endSec - startSec) / 3600)

  return {
    session,
    target,
    timezone: MARKET_WINDOW_TIME_ZONE,
    evidence_window_start: start.toISOString(),
    evidence_window_start_sec: startSec,
    evidence_window_end: end.toISOString(),
    evidence_window_end_sec: endSec,
    evidence_window_hours: Number(hours.toFixed(2)),
    includes_weekend_carry: ['weekend', 'premarket', 'overnight'].includes(session) && localWeekday(startParts.year, startParts.month, startParts.day) === 5,
    rule: session === 'premarket'
      ? 'previous trading day after close through current premarket'
      : session === 'regular'
        ? 'current premarket through now'
        : session === 'afterhours'
          ? 'regular session through afterhours'
          : session === 'weekend'
            ? 'Friday after close through weekend'
            : 'latest after-close window through now',
  }
}

function articleWindowMatch(cutoffMs) {
  const cutoffSec = Math.floor(cutoffMs / 1000)
  const cutoffDate = new Date(cutoffMs)
  const missingPublishDate = {
    $or: [
      { publish_date: { $exists: false } },
      { publish_date: null },
      { publish_date: "" },
    ],
  }

  return {
    $or: [
      { publish_date: { $type: "date", $gte: cutoffDate } },
      { publish_date: { $type: "int", $gte: cutoffSec } },
      { publish_date: { $type: "long", $gte: cutoffSec } },
      { publish_date: { $type: "double", $gte: cutoffSec } },
      {
        $and: [
          missingPublishDate,
          {
            $or: [
              { fetched_date: { $type: "date", $gte: cutoffDate } },
              { fetched_date: { $type: "int", $gte: cutoffSec } },
              { fetched_date: { $type: "long", $gte: cutoffSec } },
              { fetched_date: { $type: "double", $gte: cutoffSec } },
              { detected_at: { $type: "date", $gte: cutoffDate } },
              { detected_at: { $type: "int", $gte: cutoffSec } },
              { detected_at: { $type: "long", $gte: cutoffSec } },
              { detected_at: { $type: "double", $gte: cutoffSec } },
              { createdAt: { $gte: cutoffDate } },
            ],
          },
        ],
      },
    ],
  }
}

function recentArticleMatch(days = 0) {
  const n = Number(days || 0)
  const cutoffMs = Number.isFinite(n) && n > 0
    ? Date.now() - n * 86_400_000
    : latestMarketCloseCutoff().getTime()

  return articleWindowMatch(cutoffMs)
}

function sessionArticleMatch(context = marketPredictionContext()) {
  return articleWindowMatch(Number(context.evidence_window_start_sec || 0) * 1000)
}

function articleMatchStage(match) {
  return Object.keys(match).length ? [{ $match: match }] : []
}

function timestampSecondsExpression(valueExpr) {
  const numericSeconds = {
    $let: {
      vars: { raw: { $toLong: valueExpr } },
      in: {
        $cond: [
          { $gt: ["$$raw", 1_000_000_000_000] },
          { $floor: { $divide: ["$$raw", 1000] } },
          "$$raw",
        ],
      },
    },
  }
  return {
    $switch: {
      branches: [
        {
          case: { $eq: [{ $type: valueExpr }, "date"] },
          then: { $floor: { $divide: [{ $toLong: valueExpr }, 1000] } },
        },
        {
          case: { $in: [{ $type: valueExpr }, ["int", "long", "double", "decimal"]] },
          then: numericSeconds,
        },
        {
          case: { $eq: [{ $type: valueExpr }, "string"] },
          then: {
            $floor: {
              $divide: [
                { $toLong: { $dateFromString: { dateString: valueExpr, onError: new Date(0) } } },
                1000,
              ],
            },
          },
        },
      ],
      default: 0,
    },
  }
}

function articleActivityWindowMatch(days = 2) {
  const n = Number(days || 0)
  const cutoffMs = Number.isFinite(n) && n > 0
    ? Date.now() - n * 86_400_000
    : latestMarketCloseCutoff().getTime()
  const cutoffDate = new Date(cutoffMs)
  const cutoffSec = Math.floor(cutoffMs / 1000)
  const recentField = (field) => ({
    $or: [
      { [field]: { $type: "date", $gte: cutoffDate } },
      { [field]: { $type: "int", $gte: cutoffSec } },
      { [field]: { $type: "long", $gte: cutoffSec } },
      { [field]: { $type: "double", $gte: cutoffSec } },
    ],
  })
  return {
    $or: [
      recentField("publish_date"),
      recentField("fetched_date"),
      recentField("detected_at"),
      { createdAt: { $gte: cutoffDate } },
    ],
  }
}

function articleTickerCandidateStages() {
  const stringSplit = (field) => ({
    $cond: [
      { $eq: [{ $type: field }, "string"] },
      { $split: [field, ","] },
      [],
    ],
  })
  const arrayOrStringSplit = (field) => ({
    $cond: [
      { $isArray: field },
      field,
      stringSplit(field),
    ],
  })

  return [
    {
      $addFields: {
        _article_ticker_raw: {
          $concatArrays: [
            stringSplit("$ticker"),
            stringSplit("$symbol"),
            arrayOrStringSplit("$tickers"),
            arrayOrStringSplit("$tickers_mentioned"),
            arrayOrStringSplit("$matched_mover_tickers"),
          ],
        },
        _article_title_cashtags: {
          $map: {
            input: {
              $regexFindAll: {
                input: {
                  $concat: [
                    { $toString: { $ifNull: ["$title", ""] } },
                    " ",
                    { $toString: { $ifNull: ["$content", ""] } },
                  ],
                },
                regex: /\$[A-Za-z][A-Za-z0-9.-]{0,5}\b/,
              },
            },
            as: "tag",
            in: "$$tag.match",
          },
        },
      },
    },
    {
      $addFields: {
        _article_ticker_values: {
          $cond: [
            {
              $gt: [
                {
                  $size: {
                    $filter: {
                      input: { $ifNull: ["$_article_ticker_raw", []] },
                      as: "raw",
                      cond: { $ne: [{ $trim: { input: { $toString: "$$raw" } } }, ""] },
                    },
                  },
                },
                0,
              ],
            },
            "$_article_ticker_raw",
            "$_article_title_cashtags",
          ],
        },
      },
    },
    {
      $addFields: {
        _ticker_parts: {
          $setUnion: [
            {
              $filter: {
                input: {
                  $map: {
                    input: "$_article_ticker_values",
                    as: "raw",
                    in: {
                      $trim: {
                        input: {
                          $replaceAll: {
                            input: { $toUpper: { $toString: "$$raw" } },
                            find: { $literal: "$" },
                            replacement: "",
                          },
                        },
                        chars: " ,;#",
                      },
                    },
                  },
                },
                as: "candidate",
                cond: {
                  $and: [
                    { $regexMatch: { input: "$$candidate", regex: "^[A-Z][A-Z0-9.-]{0,5}$" } },
                    { $not: [{ $in: ["$$candidate", Array.from(NON_STOCK_TICKERS)] }] },
                  ],
                },
              },
            },
            [],
          ],
        },
      },
    },
  ]
}

function tickerArticlePipeline({ days = 2, limit = 150, ticker = "", tickers = [], articleMatch = null } = {}) {
  const wantedTickers = normalizeTickerList(
    [
      ...(Array.isArray(tickers) ? tickers : [tickers]),
      ticker,
    ].filter(Boolean),
    10000,
    { ensurePrivate: false }
  )
  const match = {
    ...(articleMatch || articleActivityWindowMatch(days)),
  }

  const pipeline = [
    { $match: match },
    ...articleTickerCandidateStages(),
    { $unwind: "$_ticker_parts" },
    { $match: { _ticker_parts: { $ne: "", $nin: Array.from(NON_STOCK_TICKERS) } } },
  ]

  if (wantedTickers.length) pipeline.push({ $match: { _ticker_parts: { $in: wantedTickers } } })

  pipeline.push(
    {
      $addFields: {
        _article_kind: {
          $cond: [
            {
              $or: [
                { $in: ["$category", ["unstructured_public_title", "public_news", "public_market_news"]] },
                { $eq: ["$collector", "unstructured_news_title_only_v1"] },
                {
                  $regexMatch: {
                    input: { $toLower: { $toString: { $ifNull: ["$source", ""] } } },
                    regex: "unstructured"
                  }
                },
              ],
            },
            "unstructured",
            "structured",
          ],
        },
        _sentiment_direction: {
          $switch: {
            branches: [
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    {
      $addFields: {
        _sentiment_numeric: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"] ] }, then: { $toDouble: "$sentiment_score" } },
              { case: { $in: [{ $type: "$ml_confidence" }, ["int", "long", "double", "decimal"] ] }, then: { $multiply: ["$_sentiment_direction", { $toDouble: "$ml_confidence" }] } },
            ],
            default: "$_sentiment_direction",
          },
        },
        _publish_sec: timestampSecondsExpression("$publish_date"),
        _fetch_sec: timestampSecondsExpression("$fetched_date"),
        _detected_sec: timestampSecondsExpression("$detected_at"),
        _created_sec: timestampSecondsExpression("$createdAt"),
      },
    },
    {
      $addFields: {
        _activity_sec: { $max: ["$_publish_sec", "$_fetch_sec", "$_detected_sec", "$_created_sec"] },
      },
    },
    {
      $addFields: {
        _source_weight: {
          $switch: {
            branches: [
              {
                case: {
                  $and: [
                    {
                      $or: [
                        { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$source", ""] } } }, regex: "sec|edgar" } },
                        { $eq: [{ $toLower: { $toString: { $ifNull: ["$event_type", ""] } } }, "sec_filing"] },
                      ],
                    },
                    { $lte: [{ $abs: "$_sentiment_numeric" }, 0.08] },
                  ],
                },
                then: 0.15,
              },
              {
                case: {
                  $in: [
                    { $toLower: { $toString: { $ifNull: ["$event_type", ""] } } },
                    ["earnings_beat", "earnings_miss", "guidance_raise", "guidance_cut", "fda_approval", "fda_rejection", "clinical_positive", "clinical_negative", "public_offering", "bankruptcy_default"],
                  ],
                },
                then: 1.35,
              },
            ],
            default: 1,
          },
        },
      },
    },
    {
      $group: {
        _id: "$_ticker_parts",
        count: { $sum: 1 },
        structured_count: { $sum: { $cond: [{ $eq: ["$_article_kind", "structured"] }, 1, 0] } },
        unstructured_count: { $sum: { $cond: [{ $eq: ["$_article_kind", "unstructured"] }, 1, 0] } },
        structured_weight_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "structured"] }, "$_source_weight", 0] } },
        unstructured_weight_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "unstructured"] }, "$_source_weight", 0] } },
        bullish: { $sum: { $cond: [{ $gt: ["$_sentiment_numeric", 0.08] }, 1, 0] } },
        bearish: { $sum: { $cond: [{ $lt: ["$_sentiment_numeric", -0.08] }, 1, 0] } },
        neutral: { $sum: { $cond: [{ $lte: [{ $abs: "$_sentiment_numeric" }, 0.08] }, 1, 0] } },
        score_sum: { $sum: "$_sentiment_numeric" },
        structured_bullish: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "structured"] }, { $gt: ["$_sentiment_numeric", 0.08] }] }, 1, 0] } },
        structured_bearish: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "structured"] }, { $lt: ["$_sentiment_numeric", -0.08] }] }, 1, 0] } },
        structured_neutral: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "structured"] }, { $lte: [{ $abs: "$_sentiment_numeric" }, 0.08] }] }, 1, 0] } },
        structured_score_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "structured"] }, "$_sentiment_numeric", 0] } },
        structured_weighted_score_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "structured"] }, { $multiply: ["$_sentiment_numeric", "$_source_weight"] }, 0] } },
        unstructured_bullish: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "unstructured"] }, { $gt: ["$_sentiment_numeric", 0.08] }] }, 1, 0] } },
        unstructured_bearish: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "unstructured"] }, { $lt: ["$_sentiment_numeric", -0.08] }] }, 1, 0] } },
        unstructured_neutral: { $sum: { $cond: [{ $and: [{ $eq: ["$_article_kind", "unstructured"] }, { $lte: [{ $abs: "$_sentiment_numeric" }, 0.08] }] }, 1, 0] } },
        unstructured_score_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "unstructured"] }, "$_sentiment_numeric", 0] } },
        unstructured_weighted_score_sum: { $sum: { $cond: [{ $eq: ["$_article_kind", "unstructured"] }, { $multiply: ["$_sentiment_numeric", "$_source_weight"] }, 0] } },
        sources: { $addToSet: "$source" },
        latest_publish: { $max: "$_publish_sec" },
        latest_fetch: { $max: "$_fetch_sec" },
        latest_detected: { $max: "$_detected_sec" },
        latest_activity: { $max: "$_activity_sec" }
      }
    },
    { $sort: { count: -1, latest_activity: -1 } },
    { $limit: Math.max(1, Math.min(300, Number(limit || 150))) },
    {
      $project: {
        _id: 0,
        ticker: "$_id",
        count: 1,
        structured_count: 1,
        unstructured_count: 1,
        structured_weight_sum: 1,
        unstructured_weight_sum: 1,
        bullish: 1,
        bearish: 1,
        neutral: 1,
        score_sum: 1,
        structured_bullish: 1,
        structured_bearish: 1,
        structured_neutral: 1,
        structured_score_sum: 1,
        structured_weighted_score_sum: 1,
        unstructured_bullish: 1,
        unstructured_bearish: 1,
        unstructured_neutral: 1,
        unstructured_score_sum: 1,
        unstructured_weighted_score_sum: 1,
        sources: 1,
        latest_publish: 1,
        latest_fetch: 1,
        latest_detected: 1,
        latest_activity: 1
      }
    }
  )

  return pipeline
}

function sentimentScore(row) {
  const hasArticleKinds = row.structured_count != null || row.unstructured_count != null
  if (hasArticleKinds) {
    const structuredWeight = 2
    const unstructuredWeight = 1
    const structuredCount = Number(row.structured_count || 0)
    const unstructuredCount = Number(row.unstructured_count || 0)
    if (row.structured_weighted_score_sum != null || row.unstructured_weighted_score_sum != null) {
      const structuredDenominator = row.structured_weight_sum != null ? Number(row.structured_weight_sum || 0) : structuredCount
      const unstructuredDenominator = row.unstructured_weight_sum != null ? Number(row.unstructured_weight_sum || 0) : unstructuredCount
      const numerator =
        structuredWeight * Number(row.structured_weighted_score_sum || 0) +
        unstructuredWeight * Number(row.unstructured_weighted_score_sum || 0)
      const denominator = structuredWeight * structuredDenominator + unstructuredWeight * unstructuredDenominator
      return denominator ? Number((numerator / (denominator + 1.5)).toFixed(3)) : 0
    }
    if (row.structured_score_sum != null || row.unstructured_score_sum != null) {
      const numerator =
        structuredWeight * Number(row.structured_score_sum || 0) +
        unstructuredWeight * Number(row.unstructured_score_sum || 0)
      const denominator = structuredWeight * structuredCount + unstructuredWeight * unstructuredCount
      return denominator ? Number((numerator / (denominator + 2)).toFixed(3)) : 0
    }
    const numerator =
      structuredWeight * (Number(row.structured_bullish || 0) - Number(row.structured_bearish || 0)) +
      unstructuredWeight * (Number(row.unstructured_bullish || 0) - Number(row.unstructured_bearish || 0))
    const denominator = structuredWeight * structuredCount + unstructuredWeight * unstructuredCount
    return denominator ? Number((numerator / (denominator + 2)).toFixed(3)) : 0
  }

  const total = Math.max(1, Number(row.count || 0))
  const priorNeutralWeight = 4
  return Number((((row.bullish || 0) - (row.bearish || 0)) / (total + priorNeutralWeight)).toFixed(3))
}

function kindSentimentScore(row, kind) {
  const prefix = kind === "unstructured" ? "unstructured" : "structured"
  const count = Number(row?.[`${prefix}_count`] || 0)
  if (!count) return 0
  if (row?.[`${prefix}_weighted_score_sum`] != null) {
    const denominator = Number(row?.[`${prefix}_weight_sum`] || count)
    return denominator ? Number((Number(row[`${prefix}_weighted_score_sum`] || 0) / (denominator + 0.75)).toFixed(3)) : 0
  }
  if (row?.[`${prefix}_score_sum`] != null) {
    return Number((Number(row[`${prefix}_score_sum`] || 0) / (count + 1)).toFixed(3))
  }
  return Number(((Number(row?.[`${prefix}_bullish`] || 0) - Number(row?.[`${prefix}_bearish`] || 0)) / (count + 2)).toFixed(3))
}

function sentimentDirectionValue(value) {
  const text = String(value || "").toLowerCase()
  if (/bull|positive/.test(text)) return 1
  if (/bear|negative/.test(text)) return -1
  return 0
}

function articleSentimentValue(row) {
  if (!row) return 0
  const direct = Number(row.sentiment_score)
  if (Number.isFinite(direct) && direct !== 0) return clamp(direct, -1, 1)
  const direction = sentimentDirectionValue(row.sentiment)
  const confidence = Number(row.ml_confidence)
  if (Number.isFinite(confidence) && confidence > 0) return clamp(direction * confidence, -1, 1)
  return direction
}

function stableHash(value) {
  let hash = 0
  const text = String(value || "")
  for (let i = 0; i < text.length; i += 1) hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0
  return Math.abs(hash)
}

function derivedNumber(ticker, min, max, decimals = 2, salt = "") {
  const span = max - min
  const pct = (stableHash(`${ticker}:${salt}`) % 10000) / 10000
  return Number((min + span * pct).toFixed(decimals))
}

function nullableNumber(value) {
  if (value == null || value === "") return null
  if (typeof value === "number") return Number.isFinite(value) ? value : null

  let raw = String(value).trim()
  if (!raw || raw === "-" || raw === "--" || raw.toLowerCase() === "nan" || raw.toUpperCase() === "N/A") return null

  raw = raw.replace(/,/g, "").replace(/\$/g, "")
  if (raw.endsWith("%")) raw = raw.slice(0, -1)

  const suffix = raw.match(/^([-+]?\d*\.?\d+)\s*([KMBT])$/i)
  if (suffix) {
    const base = Number(suffix[1])
    const mult = { K: 1e3, M: 1e6, B: 1e9, T: 1e12 }[suffix[2].toUpperCase()] || 1
    return Number.isFinite(base) ? base * mult : null
  }

  const n = Number(raw)
  return Number.isFinite(n) ? n : null
}

function nullableFixed(value, decimals = 2) {
  const n = nullableNumber(value)
  return n == null ? null : Number(n.toFixed(decimals))
}

function clamp(value, min = 0, max = 1) {
  const n = Number(value)
  if (!Number.isFinite(n)) return min
  return Math.max(min, Math.min(max, n))
}

function marketCapBucket(marketCap) {
  const cap = Number(marketCap || 0)
  if (cap >= 200e9) return "Mega"
  if (cap >= 10e9) return "Large"
  if (cap >= 2e9) return "Mid"
  if (cap >= 300e6) return "Small"
  if (cap > 0) return "Micro"
  return "Unknown"
}

function sourceTextForRow(row = {}) {
  return `${row.quote_source || ""} ${row.source || ""} ${row.screener_source || ""} ${row.finviz_filter || ""}`.toLowerCase()
}

function normalizeScreenerMarketCap(value, doc = {}) {
  const cap = nullableNumber(value)
  if (cap == null) return null

  // Finviz Elite export stores market cap as millions in the numeric CSV
  // (for example 679.2 means $679.2M). TradingView already stores dollars.
  const isFinviz = sourceTextForRow(doc).includes("finviz")
  if (isFinviz && cap > 0 && cap < 10_000_000) return Math.round(cap * 1_000_000)
  return cap
}

function isLikelyFundOrEtfRow(row = {}) {
  const text = `${row.industry || ""} ${row.sector || ""} ${row.company || ""}`.toLowerCase()
  return Boolean(
    text.includes("exchange traded fund") ||
    text.includes("exchange-traded fund") ||
    /\betf\b/.test(text) ||
    /\betn\b/.test(text) ||
    text.includes("closed-end fund")
  )
}

function normalizeExchange(value) {
  const raw = String(value || "").trim().toUpperCase()
  if (raw === "NYSEAMERICAN" || raw === "NYSE AMERICAN") return "AMEX"
  if (raw === "NAS") return "NASDAQ"
  return raw
}

function normalizeScreenerDoc(doc = {}) {
  const ticker = String(doc.ticker || "").toUpperCase()
  const hasStoredPrice = doc.price != null
  const price = nullableFixed(doc.price, 2)
  const change = doc.change_pct ?? doc.change_percent
  const changePct = nullableFixed(change, 2)
  const rawPreviousClose = nullableFixed(doc.previous_close, 4)
  const derivedPreviousClose = price != null && changePct != null && Math.abs(1 + changePct / 100) > 0.0001
    ? nullableFixed(price / (1 + changePct / 100), 4)
    : null
  const rawPreviousCloseImpliesChange = rawPreviousClose != null && price != null && rawPreviousClose > 0
    ? ((price - rawPreviousClose) / rawPreviousClose) * 100
    : null
  const previousCloseIsConsistent = rawPreviousClose != null &&
    (changePct == null || rawPreviousCloseImpliesChange == null || Math.abs(rawPreviousCloseImpliesChange - changePct) <= Math.max(2, Math.abs(changePct) * 0.1))
  const previousClose = previousCloseIsConsistent ? rawPreviousClose : derivedPreviousClose
  const volume = nullableNumber(doc.volume)
  const avgVolume = nullableNumber(doc.avg_volume)
  const storedRelVolume = nullableNumber(doc.rel_volume ?? doc.relative_volume ?? doc.relVol)
  const relVolume = storedRelVolume != null
    ? Number(storedRelVolume.toFixed(2))
    : (volume != null && avgVolume ? Number((volume / Math.max(1, avgVolume)).toFixed(2)) : null)
  const marketCap = normalizeScreenerMarketCap(doc.market_cap, doc)
  const avgSentiment = Number(doc.avg_sentiment ?? doc.news_sentiment ?? doc.structured_sentiment ?? 0)
  const premarketPrice = nullableFixed(doc.premarket_price ?? doc.pre_market_price, 4)
  const premarketChangePct = nullableFixed(doc.premarket_change_pct ?? doc.pre_market_change_pct, 4)
  const premarketVolume = nullableNumber(doc.premarket_volume ?? doc.pre_market_volume)
  const postmarketPrice = nullableFixed(doc.postmarket_price ?? doc.afterhours_price ?? doc.after_hours_price, 4)
  const postmarketChangePct = nullableFixed(doc.postmarket_change_pct ?? doc.afterhours_change_pct ?? doc.after_hours_change_pct, 4)
  const postmarketVolume = nullableNumber(doc.postmarket_volume ?? doc.afterhours_volume ?? doc.after_hours_volume)

  return {
    ticker,
    company: doc.company || "",
    price,
    regular_price: price,
    premarket_price: premarketPrice,
    postmarket_price: postmarketPrice,
    change_pct: changePct,
    regular_change_pct: changePct,
    premarket_change_pct: premarketChangePct,
    postmarket_change_pct: postmarketChangePct,
    volume,
    regular_volume: volume,
    premarket_volume: premarketVolume,
    postmarket_volume: postmarketVolume,
    avg_volume: avgVolume,
    rel_volume: relVolume,
    market_cap: marketCap,
    market_cap_bucket: marketCapBucket(marketCap),
    sector: doc.sector || "Unclassified",
    industry: doc.industry || "Unclassified",
    country: doc.country || "",
    exchange: normalizeExchange(doc.exchange),
    index: doc.index || "",
    avg_sentiment: avgSentiment,
    social_sentiment: Number(doc.social_sentiment ?? 0),
    structured_sentiment: Number(doc.structured_sentiment ?? doc.news_sentiment ?? avgSentiment),
    sentiment: avgSentiment,
    message_count: Number(doc.message_count ?? 0),
    news_article_count: Number(doc.news_article_count ?? 0),
    bullish_count: Number(doc.bullish_count ?? 0),
    bearish_count: Number(doc.bearish_count ?? 0),
    neutral_count: Number(doc.neutral_count ?? 0),
    sources: doc.sources || [],
    pe_ratio: nullableNumber(doc.pe_ratio ?? doc.pe),
    forward_pe: nullableNumber(doc.forward_pe),
    peg: nullableNumber(doc.peg),
    ps_ratio: nullableNumber(doc.ps_ratio),
    pb_ratio: nullableNumber(doc.pb_ratio),
    dividend_yield: nullableNumber(doc.dividend_yield),
    eps_growth_this_y: nullableNumber(doc.eps_growth_this_y),
    eps_growth_next_y: nullableNumber(doc.eps_growth_next_y),
    sales_growth: nullableNumber(doc.sales_growth),
    gross_margin: nullableNumber(doc.gross_margin),
    operating_margin: nullableNumber(doc.operating_margin),
    roe: nullableNumber(doc.roe),
    debt_equity: nullableNumber(doc.debt_equity),
    beta: nullableNumber(doc.beta),
    rsi: nullableNumber(doc.rsi),
    sma20: nullableNumber(doc.sma20),
    sma50: nullableNumber(doc.sma50),
    sma200: nullableNumber(doc.sma200),
    perf_week: nullableNumber(doc.perf_week),
    perf_month: nullableNumber(doc.perf_month),
    perf_quarter: nullableNumber(doc.perf_quarter),
    perf_half: nullableNumber(doc.perf_half),
    perf_year: nullableNumber(doc.perf_year),
    perf_ytd: nullableNumber(doc.perf_ytd),
    atr: nullableNumber(doc.atr),
    gap: nullableNumber(doc.gap),
    analyst: doc.analyst || null,
    target_price: nullableFixed(doc.target_price, 2),
    inst_own: nullableNumber(doc.inst_own),
    insider_own: nullableNumber(doc.insider_own),
    float_short: nullableNumber(doc.float_short),
    earnings_date: doc.earnings_date || null,
    previous_close: previousClose == null ? null : Number(previousClose.toFixed(4)),
    previous_close_status: previousCloseIsConsistent
      ? "reported"
      : (derivedPreviousClose != null ? "derived_from_price_change" : "missing"),
    change: nullableFixed(doc.change, 2),
    quote_source: doc.quote_source || null,
    quote_time: doc.quote_time || null,
    quote_updated_at: doc.quote_updated_at || null,
    quote_status: doc.quote_status || (hasStoredPrice ? "priced" : "missing"),
  }
}

function normalizeMoverSession(value = "regular") {
  const session = String(value || "regular").toLowerCase()
  if (["pre", "premarket", "pre_market"].includes(session)) return "premarket"
  if (["post", "afterhours", "after_hours", "after-hours", "ah", "postmarket", "post_market"].includes(session)) return "postmarket"
  if (["auto", "strongest"].includes(session)) return "auto"
  return "regular"
}

function applySessionMovement(row = {}, sessionValue = "regular") {
  const session = normalizeMoverSession(sessionValue)
  const candidates = [
    {
      session: "premarket",
      price: row.premarket_price ?? row.price ?? null,
      change_pct: row.premarket_change_pct,
      volume: row.premarket_volume ?? 0,
      available: row.premarket_change_pct != null,
    },
    {
      session: "regular",
      price: row.regular_price ?? row.price ?? null,
      change_pct: row.regular_change_pct ?? row.change_pct,
      volume: row.regular_volume ?? row.volume ?? 0,
      available: row.regular_change_pct != null || row.change_pct != null,
    },
    {
      session: "postmarket",
      price: row.postmarket_price ?? row.price ?? null,
      change_pct: row.postmarket_change_pct,
      volume: row.postmarket_volume ?? 0,
      available: row.postmarket_change_pct != null,
    },
  ]
  const selected = session === "auto"
    ? candidates.filter(row => row.available).reduce((best, item) => Math.abs(Number(item.change_pct || 0)) > Math.abs(Number(best.change_pct || 0)) ? item : best, candidates[1])
    : candidates.find(item => item.session === session) || candidates[1]
  return {
    ...row,
    active_session: selected.session,
    session_price: selected.price ?? row.price ?? null,
    session_change_pct: selected.change_pct ?? 0,
    session_volume: selected.volume ?? (selected.session === "regular" ? row.volume : 0),
    session_data_available: Boolean(selected.available),
    price: selected.price ?? row.price ?? null,
    change_pct: selected.change_pct ?? 0,
    volume: selected.volume || (selected.session === "regular" ? row.volume : 0),
  }
}

function isFinvizScreenerRow(row = {}) {
  return sourceTextForRow(row).includes("finviz")
}

function isCleanListedUsScreenerRow(row) {
  const ticker = String(row?.ticker || "").toUpperCase()
  const exchange = normalizeExchange(row?.exchange)
  const fromFinviz = isFinvizScreenerRow(row)

  return Boolean(
    ticker &&
    !ticker.includes(".") &&
    !ticker.includes("-") &&
    !NON_STOCK_TICKERS.has(ticker) &&
    !isLikelyFundOrEtfRow(row) &&
    (fromFinviz || US_EXCHANGES.has(exchange)) &&
    row.price != null &&
    Number(row.price) > 0 &&
    row.change_pct != null &&
    Number.isFinite(Number(row.change_pct)) &&
    Number(row.change_pct) > 0 &&
    Math.abs(Number(row.change_pct)) <= MAX_SIGNAL_CHANGE_PCT &&
    row.quote_status !== "missing"
  )
}

function isPredictionCandidateScreenerRow(row) {
  const ticker = String(row?.ticker || "").toUpperCase()
  const exchange = normalizeExchange(row?.exchange)
  const fromFinviz = isFinvizScreenerRow(row)
  const price = Number(row?.price || 0)
  const changePct = Number(row?.change_pct ?? row?.change_percent ?? 0)

  return Boolean(
    ticker &&
    !ticker.includes(".") &&
    !ticker.includes("-") &&
    !NON_STOCK_TICKERS.has(ticker) &&
    !isLikelyFundOrEtfRow(row) &&
    (fromFinviz || US_EXCHANGES.has(exchange)) &&
    Number.isFinite(price) &&
    price > 0 &&
    Number.isFinite(changePct) &&
    Math.abs(changePct) <= MAX_SIGNAL_CHANGE_PCT &&
    row.quote_status !== "missing"
  )
}

function tickerStatsToScreenerRow(row, quoteRow = {}) {
  const score = sentimentScore(row)
  const quote = normalizeScreenerDoc({ ...quoteRow, ticker: quoteRow.ticker || row.ticker })
  const price = quote.price
  const volume = quote.quote_status === "priced" ? quote.volume : null
  return normalizeScreenerDoc({
    ...quote,
    ticker: row.ticker,
    company: quote.company || "",
    price,
    change_pct: quote.change_pct,
    volume,
    avg_volume: quote.quote_status === "priced" ? quote.avg_volume : null,
    market_cap: quote.market_cap,
    sector: quote.quote_status === "priced" ? quote.sector : "News matched",
    industry: quote.quote_status === "priced" ? quote.industry : "Ticker mentions",
    avg_sentiment: score,
    social_sentiment: quote.social_sentiment || 0,
    structured_sentiment: score,
    message_count: row.count || 0,
    news_article_count: row.count || 0,
    bullish_count: row.bullish || 0,
    bearish_count: row.bearish || 0,
    neutral_count: row.neutral || 0,
    sources: (row.sources || []).filter(Boolean).slice(0, 6),
    latest_publish: row.latest_publish,
    latest_fetch: row.latest_fetch,
  })
}

function tickerStatsToMomentumRow(row, quoteRow = {}) {
  const score = sentimentScore(row)
  const base = tickerStatsToScreenerRow(row, quoteRow)
  const volume = base.volume
  const articleCount = row.count || 0
  return {
    ...base,
    ticker: row.ticker,
    volume,
    avg_volume: base.avg_volume,
    rel_volume: base.rel_volume,
    sentiment: score,
    article_count: articleCount,
    message_count: articleCount,
    bullish_count: row.bullish || 0,
    bearish_count: row.bearish || 0,
    neutral_count: row.neutral || 0,
    sources: (row.sources || []).filter(Boolean).slice(0, 6),
    latest_publish: row.latest_publish,
    latest_fetch: row.latest_fetch,
    momentum_score: Number(Math.abs(base.change_pct || 0).toFixed(2)),
  }
}

function timeLabel(value) {
  const raw = Number(value || 0)
  const ms = raw > 1000000000000 ? raw : raw > 1000000000 ? raw * 1000 : Date.parse(value)
  if (!Number.isFinite(ms) || ms <= 0) return ""
  const diff = Math.max(0, Date.now() - ms)
  if (diff < 60_000) return "now"
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h`
  return new Date(ms).toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

function normalizeTickerList(values = [], limit = TRACKED_TICKER_LIMIT, { ensurePrivate = true } = {}) {
  const max = Math.max(1, Number(limit || TRACKED_TICKER_LIMIT))
  const tickers = []
  const seen = new Set()

  const addTicker = (raw) => {
    const ticker = String(raw || "").trim().toUpperCase()
    if (!ticker || seen.has(ticker)) return
    if (!PRIVATE_TRACKED_TICKERS.has(ticker) && !/^[A-Z][A-Z0-9.-]{0,5}$/.test(ticker)) return
    tickers.push(ticker)
    seen.add(ticker)
  }

  for (const ticker of values) addTicker(ticker)
  if (ensurePrivate) {
    for (const ticker of PRIVATE_TRACKED_TICKERS) {
      if (!seen.has(ticker)) tickers.unshift(ticker)
    }
  }

  return tickers.slice(0, max)
}

function loadTrackedTickers(limit = TRACKED_TICKER_LIMIT) {
  const configured = process.env.TRACKED_TICKERS || ""
  if (configured.trim()) {
    return normalizeTickerList(configured.split(","), limit)
  }

  const configuredFile = process.env.TRACKED_TICKER_FILE || process.env.SOCIAL_TICKER_FILE || ""
  const candidates = configuredFile
    ? [path.isAbsolute(configuredFile) ? configuredFile : path.resolve(process.cwd(), configuredFile)]
    : TRACKED_TICKER_FILE_CANDIDATES

  for (const filePath of candidates) {
    try {
      const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/)
      const tickers = normalizeTickerList(lines, limit)
      if (tickers.length > 1) return tickers
    } catch {
      // Try the next known runtime layout.
    }
  }

  console.warn("Could not read tracked ticker file from known paths:", candidates.join(", "))
  return normalizeTickerList(["SPACEX"], limit)
}

async function loadArticleStats(db, days = 0) {
  const articles = db.collection("articles")
  const match = recentArticleMatch(days)
  const trackedTickers = loadTrackedTickers()
  const trackedMarketTickers = await loadTrackedMarketTickerSymbols(db, Number(process.env.TRACKED_MARKET_TICKER_LIMIT || 5000))

  const [sources, categories, sentimentRows, tickerRows, total, totalAll] = await Promise.all([
    articles.aggregate([
      ...articleMatchStage(match),
      { $group: { _id: "$source", count: { $sum: 1 } } },
      { $project: { _id: 0, source: "$_id", count: 1 } },
      { $sort: { count: -1 } }
    ]).toArray(),
    articles.aggregate([
      ...articleMatchStage(match),
      { $group: { _id: "$category", count: { $sum: 1 } } },
      { $project: { _id: 0, category: "$_id", count: 1 } },
      { $sort: { count: -1 } }
    ]).toArray(),
    articles.aggregate([
      ...articleMatchStage(match),
      {
        $group: {
          _id: { $toLower: { $ifNull: ["$sentiment", "neutral"] } },
          count: { $sum: 1 }
        }
      }
    ]).toArray(),
    articles.aggregate(tickerArticlePipeline({ days, limit: 500 })).toArray(),
    articles.countDocuments(match),
    articles.countDocuments({})
  ])

  const sentiment = { bullish: 0, bearish: 0, neutral: 0, unknown: 0 }
  for (const row of sentimentRows) {
    const key = sentiment[row._id] == null ? "unknown" : row._id
    sentiment[key] = (sentiment[key] || 0) + row.count
  }

  return {
    total,
    total_recent: total,
    total_all: totalAll,
    sources,
    categories,
    sentiment,
    ticker_mentions: tickerRows,
    tracked_market_count: TRACKED_MARKETS.length,
    tracked_markets: TRACKED_MARKETS,
    tracked_exchanges: Array.from(US_EXCHANGES),
    tracked_indices: TRACKED_MARKET_INDICES,
    market_universe_label: "NASDAQ / NYSE / AMEX equities plus major US index markets",
    tracked_ticker_count: trackedTickers.length,
    tracked_tickers: trackedTickers,
    tracked_market_ticker_count: trackedMarketTickers.length,
    tracked_market_tickers: trackedMarketTickers.slice(0, 500),
  }
}

async function loadScreenerQuoteMap(db, tickers = []) {
  const unique = Array.from(new Set(tickers.map(t => String(t || "").toUpperCase()).filter(Boolean)))
  if (!unique.length) return new Map()

  const docs = await db.collection("screeners").find({ ticker: { $in: unique } }).toArray()
  return new Map(docs.map(doc => [String(doc.ticker || "").toUpperCase(), normalizeScreenerDoc(doc)]))
}

async function loadAllScreenerRows(db) {
  const docs = await db.collection("screeners").find({}).toArray()
  return docs.map(normalizeScreenerDoc).filter(row => row.ticker)
}

async function loadPositiveFinvizMoverRows(db, limit = 100, options = {}) {
  const requestedLimit = Math.max(1, Math.min(300, Number(limit || 100)))
  const session = normalizeMoverSession(options.session || "regular")

  const docs = await db.collection("screeners").find({
    ticker: { $exists: true, $nin: ["", null] },
    finviz_status: { $ne: "dropped" },
    $or: [
      { quote_source: "finviz_elite_screener" },
      { source: /finviz/i },
      { screener_source: /finviz/i },
      { finviz_filter: { $exists: true } },
      { finviz_seen_at: { $exists: true } },
    ],
  }).toArray()

  return docs
    .map(normalizeScreenerDoc)
    .map(row => applySessionMovement(row, session))
    .filter(row => isFinvizScreenerRow(row) && isCleanListedUsScreenerRow(row))
    .filter(row => Number(row.change_pct || 0) > 0)
    .sort((a, b) => {
      const changeDiff = Number(b.change_pct || 0) - Number(a.change_pct || 0)
      if (changeDiff !== 0) return changeDiff

      const relDiff = Number(b.rel_volume || 0) - Number(a.rel_volume || 0)
      if (relDiff !== 0) return relDiff

      return Number(b.volume || 0) - Number(a.volume || 0)
    })
    .slice(0, requestedLimit)
    .map((row, index) => ({
      ...row,
      finviz_rank: index + 1,
      discovery_source: "finviz_top_mover",
      discovery_session: session,
      positive_mover: true,
      sentiment: row.avg_sentiment || 0,
      article_count: row.news_article_count || 0,
      momentum_score: Number((row.change_pct || 0).toFixed(2)),
    }))
}

async function loadArticleDrivenPredictionRows(db, { limit = 150, days = 3 } = {}) {
  const requestedLimit = Math.max(1, Math.min(600, Number(limit || 150)))
  const stats = await db.collection("articles")
    .aggregate(tickerArticlePipeline({ days, limit: requestedLimit }))
    .toArray()
  const tickers = stats.map(row => row.ticker).filter(Boolean)
  const quoteMap = await loadScreenerQuoteMap(db, tickers)

  return stats
    .map((stat) => {
      const ticker = String(stat.ticker || "").toUpperCase()
      const quote = quoteMap.get(ticker)
      if (!quote) return null
      const sentiment = sentimentScore(stat)
      const sourceDiversity = Array.isArray(stat.sources) ? stat.sources.filter(Boolean).length : 0
      const articleCount = Number(stat.count || 0)
      const structuredCount = Number(stat.structured_count || 0)
      const priority = clamp(
        Math.log1p(articleCount) / Math.log1p(40) * 0.36 +
        Math.max(0, sentiment) * 0.30 +
        Math.log1p(structuredCount) / Math.log1p(10) * 0.18 +
        Math.log1p(sourceDiversity) / Math.log1p(8) * 0.16,
        0,
        1
      )
      return {
        ...quote,
        discovery_source: structuredCount ? "news_catalyst" : "ai_news_evidence",
        positive_mover: Number(quote.change_pct || 0) > 0,
        sentiment,
        avg_sentiment: sentiment,
        article_count: articleCount,
        news_article_count: articleCount,
        structured_article_count: structuredCount,
        unstructured_article_count: Number(stat.unstructured_count || 0),
        bullish_count: Number(stat.bullish || 0),
        bearish_count: Number(stat.bearish || 0),
        neutral_count: Number(stat.neutral || 0),
        candidate_priority: Number(priority.toFixed(3)),
        candidate_reasons: [
          structuredCount ? `${structuredCount} structured catalysts` : "",
          articleCount ? `${articleCount} matched articles` : "",
          sentiment > 0.05 ? `news sentiment +${sentiment.toFixed(2)}` : "",
        ].filter(Boolean),
      }
    })
    .filter(row => row && isPredictionCandidateScreenerRow(row))
    .sort((a, b) => Number(b.candidate_priority || 0) - Number(a.candidate_priority || 0))
    .slice(0, requestedLimit)
}

async function loadCorrelationPredictionRows(db, { limit = 100 } = {}) {
  const requestedLimit = Math.max(1, Math.min(500, Number(limit || 100)))
  const docs = await db.collection("correlations").find({
    ticker: { $exists: true, $nin: ["", null] },
    $or: [
      { correlation_score: { $gt: 0 } },
      { signal_score: { $gt: 0 } },
      { prediction_validation_avg_return_5m: { $gt: 0 } },
      { prediction_validation_accuracy_5m: { $gte: 0.52 } },
    ],
  }).sort({
    prediction_validation_accuracy_5m: -1,
    prediction_validation_avg_return_5m: -1,
    correlation_score: -1,
    signal_score: -1,
    updated_at: -1,
    updatedAt: -1,
  }).limit(requestedLimit * 3).toArray()

  const tickers = docs.map(row => row.ticker).filter(Boolean)
  const quoteMap = await loadScreenerQuoteMap(db, tickers)
  return docs
    .map((doc) => {
      const ticker = String(doc.ticker || "").toUpperCase()
      const quote = quoteMap.get(ticker) || normalizeScreenerDoc(doc)
      const validationSamples = Number(doc.prediction_validation_samples || 0)
      const validationAccuracy = Number(doc.prediction_validation_accuracy_5m)
      const validationReturn = Number(doc.prediction_validation_avg_return_5m)
      const correlationScore = Number(doc.correlation_score ?? doc.signal_score ?? doc.correlation ?? 0)
      const priority = clamp(
        Math.max(0, correlationScore) * 0.35 +
        (Number.isFinite(validationAccuracy) ? Math.max(0, validationAccuracy - 0.5) * 1.4 : 0) +
        (Number.isFinite(validationReturn) ? Math.max(0, validationReturn) / 2 : 0) +
        Math.log1p(validationSamples) / Math.log1p(60) * 0.15,
        0,
        1
      )
      return {
        ...quote,
        ticker,
        discovery_source: "correlation_validation",
        correlation_score: Number(correlationScore.toFixed(3)),
        prediction_validation_accuracy_5m: Number.isFinite(validationAccuracy) ? Number(validationAccuracy.toFixed(3)) : null,
        prediction_validation_avg_return_5m: Number.isFinite(validationReturn) ? Number(validationReturn.toFixed(3)) : null,
        prediction_validation_samples: validationSamples,
        candidate_priority: Number(priority.toFixed(3)),
        candidate_reasons: [
          validationSamples ? `${validationSamples} validated samples` : "",
          Number.isFinite(validationAccuracy) ? `${Math.round(validationAccuracy * 100)}% validation accuracy` : "",
          Number.isFinite(validationReturn) && validationReturn > 0 ? `avg +${validationReturn.toFixed(2)}% validation return` : "",
        ].filter(Boolean),
      }
    })
    .filter(row => isPredictionCandidateScreenerRow(row))
    .sort((a, b) => Number(b.candidate_priority || 0) - Number(a.candidate_priority || 0))
    .slice(0, requestedLimit)
}

async function loadTechnicalSetupPredictionRows(db, { limit = 150 } = {}) {
  const requestedLimit = Math.max(1, Math.min(600, Number(limit || 150)))
  const docs = await db.collection("screeners").find({
    ticker: { $exists: true, $nin: ["", null], $not: /\./ },
    exchange: { $in: Array.from(US_EXCHANGES) },
    quote_status: { $ne: "missing" },
    price: { $gt: 0 },
    volume: { $gt: 100000 },
    $or: [
      { rel_volume: { $gte: 1.25 } },
      { rsi: { $gte: 35, $lte: 65 } },
      { change_pct: { $gte: -6, $lte: 10 } },
    ],
  }).sort({ rel_volume: -1, volume: -1, market_cap: -1 }).limit(requestedLimit * 3).toArray()

  return docs
    .map(normalizeScreenerDoc)
    .filter(row => isPredictionCandidateScreenerRow(row))
    .filter(row => Math.abs(Number(row.change_pct || 0)) <= 18)
    .map((row) => {
      const changePct = Number(row.change_pct || 0)
      const relVolume = Number(row.rel_volume || 0)
      const rsi = Number(row.rsi)
      const constructiveRsi = Number.isFinite(rsi) && rsi >= 38 && rsi <= 68 ? 1 : 0
      const preMove = changePct >= -4 && changePct <= 8 ? 1 : changePct > 8 ? 0.4 : 0.2
      const priority = clamp(
        Math.log1p(Math.max(0, relVolume)) / Math.log1p(6) * 0.38 +
        constructiveRsi * 0.25 +
        preMove * 0.24 +
        Math.log1p(Number(row.volume || 0)) / Math.log1p(50_000_000) * 0.13,
        0,
        1
      )
      return {
        ...row,
        discovery_source: "technical_setup",
        candidate_priority: Number(priority.toFixed(3)),
        candidate_reasons: [
          relVolume >= 1.25 ? `${relVolume.toFixed(1)}x rel vol` : "",
          Number.isFinite(rsi) ? `RSI ${rsi.toFixed(0)}` : "",
          changePct <= 8 ? "not already extended" : "",
        ].filter(Boolean),
      }
    })
    .sort((a, b) => Number(b.candidate_priority || 0) - Number(a.candidate_priority || 0))
    .slice(0, requestedLimit)
}

function mergeCandidateRowsByTicker(rows = []) {
  const byTicker = new Map()
  for (const row of rows) {
    const ticker = String(row?.ticker || "").toUpperCase()
    if (!ticker) continue
    const existing = byTicker.get(ticker)
    if (!existing || Number(row.candidate_priority || 0) > Number(existing.candidate_priority || 0)) {
      byTicker.set(ticker, {
        ...existing,
        ...row,
        discovery_sources: Array.from(new Set([
          ...(existing?.discovery_sources || [existing?.discovery_source].filter(Boolean)),
          ...(row.discovery_sources || [row.discovery_source].filter(Boolean)),
        ])),
      })
    } else {
      existing.discovery_sources = Array.from(new Set([
        ...(existing.discovery_sources || [existing.discovery_source].filter(Boolean)),
        ...(row.discovery_sources || [row.discovery_source].filter(Boolean)),
      ]))
    }
  }
  return Array.from(byTicker.values())
}

async function loadDiversifiedPredictionCandidateRows(db, { limit = 100, days = 3 } = {}) {
  const requestedLimit = Math.max(1, Math.min(1000, Number(limit || 100)))
  const poolLimit = Math.max(80, Math.min(600, requestedLimit * 3))
  const [movers, articleRows, correlationRows, technicalRows] = await Promise.all([
    loadPositiveFinvizMoverRows(db, Math.max(25, Math.ceil(poolLimit * 0.35))),
    loadArticleDrivenPredictionRows(db, { limit: Math.max(40, Math.ceil(poolLimit * 0.45)), days }),
    loadCorrelationPredictionRows(db, { limit: Math.max(25, Math.ceil(poolLimit * 0.25)) }),
    loadTechnicalSetupPredictionRows(db, { limit: Math.max(40, Math.ceil(poolLimit * 0.45)) }),
  ])

  const moverRows = movers.map((row, index) => {
    const changePct = Number(row.change_pct || 0)
    const extensionPenalty = changePct > 20 ? clamp((changePct - 20) / 60, 0, 0.45) : 0
    return {
      ...row,
      candidate_priority: Number(clamp(0.74 - extensionPenalty - index * 0.002, 0, 1).toFixed(3)),
      candidate_reasons: [`Finviz mover rank ${index + 1}`],
    }
  })

  const balanced = []
  const seen = new Set()
  const quotas = [
    { rows: articleRows, max: Math.ceil(requestedLimit * 0.35) },
    { rows: technicalRows, max: Math.ceil(requestedLimit * 0.25) },
    { rows: correlationRows, max: Math.ceil(requestedLimit * 0.25) },
    { rows: moverRows, max: Math.ceil(requestedLimit * 0.30) },
  ]
  for (const group of quotas) {
    let used = 0
    for (const row of group.rows) {
      const ticker = String(row.ticker || "").toUpperCase()
      if (!ticker || seen.has(ticker) || used >= group.max) continue
      balanced.push(row)
      seen.add(ticker)
      used += 1
    }
  }

  const remaining = mergeCandidateRowsByTicker([...articleRows, ...technicalRows, ...correlationRows, ...moverRows])
    .filter(row => !seen.has(String(row.ticker || "").toUpperCase()))
    .sort((a, b) => Number(b.candidate_priority || 0) - Number(a.candidate_priority || 0))

  return [...balanced, ...remaining]
    .filter(row => isPredictionCandidateScreenerRow(row))
    .slice(0, requestedLimit)
}

async function loadFinvizMomentumStatus(db) {
  const [sourceStatus, latest] = await Promise.all([
    db.collection("source_status").findOne({ source: "Finviz Elite Screener" }).catch(() => null),
    db.collection("screeners").find(
      {
        quote_source: "finviz_elite_screener",
        finviz_status: { $ne: "dropped" },
      },
      { projection: { ticker: 1, quote_updated_at: 1, finviz_seen_at: 1 } }
    ).sort({ quote_updated_at: -1, finviz_seen_at: -1 }).limit(1).next().catch(() => null),
  ])
  const quoteSec = timestampSeconds(latest?.quote_updated_at || latest?.finviz_seen_at)
  return {
    status: sourceStatus?.status || "unknown",
    detail: sourceStatus?.detail || "",
    last_checked_at: sourceStatus?.last_checked_at || null,
    last_success_at: sourceStatus?.last_success_at || null,
    last_count: Number(sourceStatus?.last_count || 0),
    latest_ticker: latest?.ticker || null,
    latest_quote_updated_at: latest?.quote_updated_at || null,
    latest_finviz_seen_at: latest?.finviz_seen_at || null,
    quote_age_seconds: quoteSec ? Math.max(0, Math.floor(Date.now() / 1000) - quoteSec) : null,
  }
}

async function persistFinvizMomentumSnapshot(db, { limit = 100, reason = "refresh", session = "regular" } = {}) {
  if (!db) return null
  const now = new Date()
  const bucketSec = Math.floor(now.getTime() / 60_000) * 60
  const normalizedSession = normalizeMoverSession(session)
  const rows = await loadPositiveFinvizMoverRows(db, limit, { session: normalizedSession })
  const doc = {
    _id: `finviz:${normalizedSession}:${bucketSec}`,
    source: "Finviz Elite top movers",
    reason,
    session: normalizedSession,
    snapshot_sec: bucketSec,
    snapshot_at: new Date(bucketSec * 1000),
    count: rows.length,
    top_tickers: rows.slice(0, 20).map(row => row.ticker),
    rows: rows.map((row, index) => ({
      rank: index + 1,
      ticker: row.ticker,
      company: row.company || "",
      exchange: row.exchange || "",
      price: row.price ?? null,
      change_pct: row.change_pct ?? null,
      active_session: row.active_session || normalizedSession,
      regular_change_pct: row.regular_change_pct ?? null,
      premarket_change_pct: row.premarket_change_pct ?? null,
      postmarket_change_pct: row.postmarket_change_pct ?? null,
      volume: row.volume ?? null,
      rel_volume: row.rel_volume ?? null,
      market_cap: row.market_cap ?? null,
      quote_updated_at: row.quote_updated_at || null,
      finviz_seen_at: row.finviz_seen_at || null,
    })),
    updated_at: now,
  }
  await db.collection("finviz_momentum_snapshots").updateOne(
    { _id: doc._id },
    { $set: doc, $setOnInsert: { created_at: now } },
    { upsert: true }
  )
  await db.collection("finviz_momentum_snapshots").deleteMany({
    snapshot_sec: { $lt: bucketSec - 31 * 86_400 },
  }).catch(() => {})
  return doc
}

async function loadMomentumSnapshots(db, limit = 12) {
  const requestedLimit = Math.max(1, Math.min(100, Number(limit || 12)))
  return db.collection("finviz_momentum_snapshots")
    .find({}, { projection: { rows: { $slice: 10 }, top_tickers: 1, count: 1, snapshot_sec: 1, snapshot_at: 1, source: 1, reason: 1 } })
    .sort({ snapshot_sec: -1 })
    .limit(requestedLimit)
    .toArray()
}

async function loadTrackedMarketTickerSymbols(db, limit = 5000) {
  const requestedLimit = Math.max(1, Math.min(10000, Number(limit || 5000)))
  const docs = await db.collection("screeners").find(
    {
      ticker: { $exists: true, $nin: ["", null], $not: /\./ },
      exchange: { $in: Array.from(US_EXCHANGES) },
      quote_status: { $ne: "missing" },
    },
    { projection: { ticker: 1, volume: 1, market_cap: 1, quote_source: 1 } }
  ).sort({ volume: -1, market_cap: -1 }).limit(requestedLimit).toArray()
  return normalizeTickerList(docs.map(row => row.ticker), requestedLimit, { ensurePrivate: false })
}

async function loadArticleStatsForTickers(db, tickers = [], days = 2, options = {}) {
  const wanted = new Set(tickers.map(t => String(t || "").toUpperCase()).filter(Boolean))
  if (!wanted.size) return new Map()
  const context = options.predictionContext || null
  const articleMatch = options.articleMatch || (context ? sessionArticleMatch(context) : null)

  const rows = await db.collection("articles")
    .aggregate(tickerArticlePipeline({ days, limit: Math.max(wanted.size * 4, 150), tickers: Array.from(wanted), articleMatch }))
    .toArray()

  return new Map(
    rows
      .filter(row => wanted.has(String(row.ticker || "").toUpperCase()))
      .map(row => [String(row.ticker || "").toUpperCase(), row])
  )
}

async function loadSocialStatsForTickers(db, tickers = [], windowMinutes = 1440) {
  const wanted = normalizeTickerList(tickers, 1500, { ensurePrivate: false })
  if (!wanted.length) return new Map()

  const sinceSec = Math.floor(Date.now() / 1000) - Math.max(1, Number(windowMinutes || 1440)) * 60
  const rows = await db.collection("socials").aggregate([
    ...socialTimeStages(),
    { $match: { _event_sec: { $gte: sinceSec } } },
    { $match: { _ticker_candidates: { $in: wanted } } },
    { $unwind: "$_ticker_candidates" },
    { $match: { _ticker_candidates: { $in: wanted } } },
    {
      $group: {
        _id: "$_ticker_candidates",
        count: { $sum: 1 },
        bullish: {
          $sum: {
            $cond: [
              { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } },
              1,
              0,
            ],
          },
        },
        bearish: {
          $sum: {
            $cond: [
              { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } },
              1,
              0,
            ],
          },
        },
        avg_sentiment_score: {
          $avg: {
            $switch: {
              branches: [
                {
                  case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"] ] },
                  then: { $toDouble: "$sentiment_score" },
                },
                {
                  case: { $in: [{ $type: "$sentiment" }, ["int", "long", "double", "decimal"] ] },
                  then: { $toDouble: "$sentiment" },
                },
                {
                  case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } },
                  then: 1,
                },
                {
                  case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } },
                  then: -1,
                },
              ],
              default: 0,
            },
          },
        },
        platforms: { $addToSet: "$_norm_platform" },
        stocktwits_count: {
          $sum: { $cond: [{ $eq: ["$_norm_platform", "StockTwits"] }, 1, 0] },
        },
        bluesky_count: {
          $sum: { $cond: [{ $eq: ["$_norm_platform", "Bluesky"] }, 1, 0] },
        },
        reddit_count: {
          $sum: { $cond: [{ $eq: ["$_norm_platform", "Reddit"] }, 1, 0] },
        },
        twitter_count: {
          $sum: { $cond: [{ $eq: ["$_norm_platform", "Twitter"] }, 1, 0] },
        },
        gossip_count: {
          $sum: {
            $cond: [
              {
                $or: [
                  {
                    $gt: [
                      {
                        $switch: {
                          branches: [
                            { case: { $in: [{ $type: "$gossip_score" }, ["int", "long", "double", "decimal"] ] }, then: { $toDouble: "$gossip_score" } },
                          ],
                          default: 0,
                        },
                      },
                      0,
                    ],
                  },
                  { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$text", { $ifNull: ["$content", "$title"] }] } } }, regex: "rumou?r|hearing|unconfirmed|leak|buyout|takeover|halt|news pending|squeeze" } },
                ],
              },
              1,
              0,
            ],
          },
        },
        latest_post: { $max: "$_event_sec" },
      },
    },
  ]).toArray()

  return new Map(rows.map(row => [String(row._id || "").toUpperCase(), row]))
}

async function loadPredictionAiEvidenceForTickers(db, tickers = [], days = 3) {
  const wanted = new Set(tickers.map(t => String(t || "").toUpperCase()).filter(Boolean))
  if (!wanted.size) return new Map()
  const articles = await aiRecentArticles(db, days).catch(() => [])
  const byTicker = new Map()
  for (const article of articles) {
    const score = aiSentiment(article)
    if (score == null) continue
    const source = String(article.source || "").trim()
    for (const ticker of aiTickers(article)) {
      const key = String(ticker || "").toUpperCase()
      if (!wanted.has(key)) continue
      const row = byTicker.get(key) || {
        sum: 0,
        n: 0,
        bullish: 0,
        bearish: 0,
        sources: new Set(),
        latest_ms: 0,
      }
      row.sum += Number(score || 0)
      row.n += 1
      if (score > 0.12) row.bullish += 1
      if (score < -0.12) row.bearish += 1
      if (source) row.sources.add(source)
      row.latest_ms = Math.max(row.latest_ms, aiArticleTimeMs(article))
      byTicker.set(key, row)
    }
  }

  const out = new Map()
  for (const [ticker, row] of byTicker.entries()) {
    const avg = row.n ? row.sum / row.n : 0
    const agreement = row.n ? Math.abs(row.bullish - row.bearish) / Math.max(1, row.n) : 0
    const sourceCount = row.sources.size
    const aiScore = Math.round(clamp(((avg + 1) / 2) * 70 + Math.min(18, row.n * 2) + Math.min(12, sourceCount * 2), 0, 100))
    out.set(ticker, {
      ai_score: aiScore,
      ai_sentiment_score: Number(clamp(avg, -1, 1).toFixed(3)),
      ai_confidence: Number(clamp(Math.min(1, row.n / 8) * 0.7 + agreement * 0.3, 0, 1).toFixed(3)),
      ai_article_count: row.n,
      ai_bullish_articles: row.bullish,
      ai_bearish_articles: row.bearish,
      ai_source_count: sourceCount,
      ai_latest_publish: row.latest_ms ? new Date(row.latest_ms) : null,
    })
  }
  return out
}

async function loadPredictionMomentumContextForTickers(db, tickers = []) {
  const wanted = new Set(tickers.map(t => String(t || "").toUpperCase()).filter(Boolean))
  if (!wanted.size) return new Map()
  const snapshots = await db.collection("finviz_momentum_snapshots")
    .find({}, { projection: { snapshot_sec: 1, rows: 1 } })
    .sort({ snapshot_sec: -1 })
    .limit(30)
    .toArray()
    .catch(() => [])
  const byTicker = new Map()
  for (const snapshot of snapshots) {
    for (const row of Array.isArray(snapshot.rows) ? snapshot.rows : []) {
      const ticker = String(row.ticker || "").toUpperCase()
      if (!wanted.has(ticker)) continue
      const current = byTicker.get(ticker) || {
        appearances: 0,
        latest_rank: null,
        previous_rank: null,
        best_rank: null,
        latest_change_pct: null,
        latest_rel_volume: null,
        latest_snapshot_sec: null,
      }
      current.appearances += 1
      const rank = Number(row.rank || 999)
      if (current.latest_snapshot_sec == null || Number(snapshot.snapshot_sec || 0) > current.latest_snapshot_sec) {
        current.previous_rank = current.latest_rank
        current.latest_rank = rank
        current.latest_change_pct = Number(row.change_pct || 0)
        current.latest_rel_volume = Number(row.rel_volume || 0)
        current.latest_snapshot_sec = Number(snapshot.snapshot_sec || 0)
      }
      current.best_rank = current.best_rank == null ? rank : Math.min(current.best_rank, rank)
      byTicker.set(ticker, current)
    }
  }
  for (const [ticker, ctx] of byTicker.entries()) {
    const rankStrength = ctx.latest_rank ? clamp((101 - ctx.latest_rank) / 100, 0, 1) : 0
    const persistence = clamp(ctx.appearances / Math.max(1, snapshots.length), 0, 1)
    const relVolStrength = clamp(Math.log1p(Math.max(0, ctx.latest_rel_volume || 0)) / Math.log1p(30), 0, 1)
    const changeStrength = clamp(Math.abs(Number(ctx.latest_change_pct || 0)) / 25, 0, 1)
    const rankTrend = ctx.previous_rank && ctx.latest_rank ? clamp((ctx.previous_rank - ctx.latest_rank) / 20, -1, 1) : 0
    ctx.momentum_context_score = Math.round(clamp(
      rankStrength * 38 +
      persistence * 18 +
      relVolStrength * 20 +
      changeStrength * 14 +
      Math.max(0, rankTrend) * 10,
      0,
      100
    ))
    ctx.momentum_rank_trend = Number(rankTrend.toFixed(3))
    ctx.momentum_snapshot_count = snapshots.length
    byTicker.set(ticker, ctx)
  }
  return byTicker
}

async function loadPredictionCorrelationContextForTickers(db, tickers = []) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || "").toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()
  const map = new Map()
  const stored = await db.collection("correlations").find(
    { $or: [{ ticker: { $in: wanted } }, { symbol: { $in: wanted } }] },
    { projection: { ticker: 1, symbol: 1, score: 1, correlation: 1, correlation_score: 1, sentiment_correlation: 1, news_correlation: 1, updated_at: 1, created_at: 1 } },
  ).toArray().catch(() => [])
  for (const row of stored) {
    const ticker = String(row.ticker || row.symbol || "").toUpperCase()
    const raw = Number(row.correlation_score ?? row.score ?? row.correlation ?? row.sentiment_correlation ?? row.news_correlation)
    if (!ticker || !Number.isFinite(raw)) continue
    map.set(ticker, {
      correlation_score: raw > 1 ? clamp(raw / 100, -1, 1) : clamp(raw, -1, 1),
      correlation_source: "correlations_collection",
      correlation_samples: null,
      correlation_updated_at: row.updated_at || row.created_at || null,
    })
  }
  const labelRows = await db.collection("prediction_signals").aggregate([
    {
      $match: {
        ticker: { $in: wanted },
        "labels.return_5m.labeled": true,
        "labels.return_5m.direction_correct": { $in: [true, false] },
      },
    },
    {
      $group: {
        _id: "$ticker",
        samples: { $sum: 1 },
        correct: { $sum: { $cond: ["$labels.return_5m.direction_correct", 1, 0] } },
        avg_return_5m: { $avg: "$labels.return_5m.return_pct" },
        latest_signal_sec: { $max: "$signal_sec" },
      },
    },
  ]).toArray().catch(() => [])
  for (const row of labelRows) {
    const ticker = String(row._id || "").toUpperCase()
    if (map.has(ticker)) continue
    const samples = Number(row.samples || 0)
    const accuracy = samples ? Number(row.correct || 0) / samples : 0.5
    map.set(ticker, {
      correlation_score: Number(clamp((accuracy - 0.5) * 2, -1, 1).toFixed(3)),
      correlation_source: "intraday_label_accuracy_proxy",
      correlation_samples: samples,
      correlation_accuracy: Number(accuracy.toFixed(3)),
      avg_return_5m: row.avg_return_5m == null ? null : Number(Number(row.avg_return_5m).toFixed(3)),
      correlation_updated_at: row.latest_signal_sec ? new Date(Number(row.latest_signal_sec) * 1000) : null,
    })
  }
  return map
}

function bracketOrderResearchSignal(row, { sentiment, totalArticleCount, socialCount }) {
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const price = Number(row.price || 0)
  const supportCount = Number(totalArticleCount || 0) + Number(socialCount || 0)
  const capBucket = String(row.market_cap_bucket || "").toLowerCase()

  const moveScore = clamp(changePct / 20)
  const volumeScore = clamp(relVolume / 5)
  const sentimentScoreNorm = clamp((Number(sentiment || 0) + 1) / 2)
  const catalystScore = clamp(Math.log1p(supportCount) / Math.log1p(50))
  const confidence = clamp(
    moveScore * 0.35 +
    volumeScore * 0.25 +
    sentimentScoreNorm * 0.25 +
    catalystScore * 0.15
  )

  const volatile = capBucket === "micro" || capBucket === "small" || price < 5 || Math.abs(changePct) >= 25
  const stopLossPct = volatile ? 6 : 3
  const takeProfitPct = volatile ? 12 : 6
  const candidate = confidence >= 0.7 && changePct > 0 && sentiment > 0.05 && supportCount >= 2

  return {
    candidate,
    confidence: Number(confidence.toFixed(3)),
    direction: candidate ? "long_watch" : "monitor",
    entry_reference: Number.isFinite(price) && price > 0 ? Number(price.toFixed(4)) : null,
    stop_loss_pct: stopLossPct,
    take_profit_pct: takeProfitPct,
    support_count: supportCount,
    rationale: [
      changePct > 0 ? "positive price move" : "",
      relVolume >= 2 ? "elevated relative volume" : "",
      sentiment > 0.05 ? "positive weighted sentiment" : "",
      supportCount ? "matched news/social support" : "",
    ].filter(Boolean),
    status: "research_only_not_connected_to_broker",
  }
}

function mergeMoverContext(row, articleRow, socialRow) {
  const newsSentiment = articleRow ? sentimentScore(articleRow) : 0
  const structuredArticleCount = Number(articleRow?.structured_count || 0)
  const unstructuredArticleCount = Number(articleRow?.unstructured_count || 0)
  const totalArticleCount = Number(articleRow?.count || row.news_article_count || 0)
  const structuredSentiment = articleRow ? kindSentimentScore(articleRow, "structured") : Number(row.structured_sentiment || 0)
  const unstructuredSentiment = articleRow ? kindSentimentScore(articleRow, "unstructured") : 0
  const socialCount = Number(socialRow?.count || 0)
  const socialPlatforms = Array.isArray(socialRow?.platforms) ? socialRow.platforms.filter(Boolean) : []
  const stocktwitsCount = Number(socialRow?.stocktwits_count || 0)
  const blueskyCount = Number(socialRow?.bluesky_count || 0)
  const redditCount = Number(socialRow?.reddit_count || 0)
  const twitterCount = Number(socialRow?.twitter_count || 0)
  const gossipCount = Number(socialRow?.gossip_count || 0)
  const socialSentiment = socialCount
    ? Number((Number.isFinite(Number(socialRow.avg_sentiment_score))
      ? Number(socialRow.avg_sentiment_score)
      : ((socialRow.bullish || 0) - (socialRow.bearish || 0)) / Math.max(1, socialCount)).toFixed(3))
    : 0
  const structuredWeight = 2
  const unstructuredWeight = 1
  const socialWeight = 0.75
  const sentimentDenominator =
    structuredArticleCount * structuredWeight +
    unstructuredArticleCount * unstructuredWeight +
    socialCount * socialWeight
  const sentiment = sentimentDenominator
    ? Number(((
      structuredSentiment * structuredArticleCount * structuredWeight +
      unstructuredSentiment * unstructuredArticleCount * unstructuredWeight +
      socialSentiment * socialCount * socialWeight
    ) / sentimentDenominator).toFixed(3))
    : Number(row.avg_sentiment || 0)
  const bracketOrder = bracketOrderResearchSignal(row, { sentiment, totalArticleCount, socialCount })

  return {
    ...row,
    sentiment,
    article_sentiment: newsSentiment,
    social_sentiment: socialSentiment,
    structured_sentiment: structuredSentiment,
    unstructured_sentiment: unstructuredSentiment,
    article_count: totalArticleCount,
    structured_article_count: structuredArticleCount,
    unstructured_article_count: unstructuredArticleCount,
    news_article_count: totalArticleCount,
    message_count: socialCount,
    stocktwits_count: stocktwitsCount,
    bluesky_count: blueskyCount,
    reddit_count: redditCount,
    twitter_count: twitterCount,
    gossip_count: gossipCount,
    social_platform_count: new Set(socialPlatforms).size,
    social_platforms: socialPlatforms,
    bullish_count: Number(articleRow?.bullish || 0) + Number(socialRow?.bullish || 0),
    bearish_count: Number(articleRow?.bearish || 0) + Number(socialRow?.bearish || 0),
    neutral_count: Number(articleRow?.neutral || 0),
    sources: [
      row.discovery_source === "finviz_top_mover" ? "Positive Movers" : row.discovery_source || "Prediction Candidate",
      ...(articleRow?.sources || []),
      ...socialPlatforms,
    ].filter(Boolean).slice(0, 8),
    latest_social: socialRow?.latest_post || null,
    latest_publish: articleRow?.latest_publish || articleRow?.latest_activity || row.latest_publish || null,
    latest_detected: articleRow?.latest_detected || null,
    latest_activity: articleRow?.latest_activity || null,
    momentum_score: Number((row.change_pct || 0).toFixed(2)),
    discovery_source: row.discovery_source || null,
    discovery_sources: row.discovery_sources || [row.discovery_source].filter(Boolean),
    candidate_priority: row.candidate_priority ?? null,
    candidate_reasons: row.candidate_reasons || [],
    correlation_score: row.correlation_score ?? null,
    prediction_validation_accuracy_5m: row.prediction_validation_accuracy_5m ?? null,
    prediction_validation_avg_return_5m: row.prediction_validation_avg_return_5m ?? null,
    prediction_validation_samples: row.prediction_validation_samples ?? null,
    ai_numeric_rank: bracketOrder.confidence,
    bracket_order: bracketOrder,
  }
}

function tradeWatchDecision(row) {
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const price = Number(row.price || 0)
  const sentiment = Number(row.sentiment || 0)
  const articleSentiment = Number(row.article_sentiment || 0)
  const socialSentiment = Number(row.social_sentiment || 0)
  const articleCount = Number(row.article_count || 0)
  const structuredCount = Number(row.structured_article_count || 0)
  const publicCount = Number(row.unstructured_article_count || 0)
  const socialCount = Number(row.message_count || 0)
  const supportCount = articleCount + socialCount
  const latestQuoteSec = timestampSeconds(row.quote_updated_at || row.quote_time)
  const quoteAgeMinutes = latestQuoteSec ? Math.max(0, (Date.now() / 1000 - latestQuoteSec) / 60) : null
  const quoteFreshness = quoteAgeMinutes == null ? 0.45 : clamp(1 - quoteAgeMinutes / 360, 0.2, 1)
  const capBucket = String(row.market_cap_bucket || "").toLowerCase()
  const microOrPenny = capBucket === "micro" || (Number.isFinite(price) && price > 0 && price < 1)

  const priceScore = clamp(changePct / 25)
  const volumeScore = clamp(relVolume / 8)
  const structuredScore = clamp(Math.log1p(structuredCount) / Math.log1p(8))
  const publicNewsScore = clamp(Math.log1p(publicCount) / Math.log1p(12))
  const socialDensityScore = clamp(Math.log1p(socialCount) / Math.log1p(60))
  const sentimentMagnitude = clamp((sentiment + 1) / 2)
  const socialMagnitude = clamp((socialSentiment + 1) / 2)
  const articleMagnitude = clamp((articleSentiment + 1) / 2)
  const evidenceScore = clamp(
    structuredScore * 0.3 +
    publicNewsScore * 0.2 +
    socialDensityScore * 0.25 +
    sentimentMagnitude * 0.15 +
    socialMagnitude * 0.1
  )
  const agreement = clamp(
    (changePct > 0 ? 0.25 : 0) +
    (sentiment > 0.05 ? 0.25 : sentiment < -0.05 ? -0.15 : 0.05) +
    (socialCount > 0 && socialSentiment > 0.05 ? 0.2 : socialCount > 0 && socialSentiment < -0.05 ? -0.1 : 0) +
    (articleCount > 0 && articleSentiment > 0.05 ? 0.2 : articleCount > 0 && articleSentiment < -0.05 ? -0.1 : 0) +
    (relVolume >= 2 ? 0.1 : 0),
    0,
    1
  )
  const thinSpikePenalty = supportCount === 0 ? 0.18 : supportCount === 1 ? 0.08 : 0
  const microPenalty = microOrPenny && supportCount < 3 ? 0.08 : 0
  const rawScore =
    priceScore * 0.25 +
    volumeScore * 0.2 +
    evidenceScore * 0.25 +
    agreement * 0.2 +
    quoteFreshness * 0.1 -
    thinSpikePenalty -
    microPenalty
  const score = clamp(rawScore)
  const scoreBreakdown = {
    price_action: Number(priceScore.toFixed(3)),
    relative_volume: Number(volumeScore.toFixed(3)),
    evidence: Number(evidenceScore.toFixed(3)),
    agreement: Number(agreement.toFixed(3)),
    freshness: Number(quoteFreshness.toFixed(3)),
    penalties: Number((thinSpikePenalty + microPenalty).toFixed(3)),
  }

  let decision = "Monitor"
  if (score >= 0.74 && agreement >= 0.65 && supportCount >= 2) decision = "High Watch"
  else if (score >= 0.58 && supportCount >= 1) decision = "Watch"
  else if (changePct >= 15 && supportCount === 0) decision = "Unsupported Spike"
  else if (sentiment < -0.15 || socialSentiment < -0.2) decision = "Divergent"

  const reasons = [
    changePct > 0 ? `price +${changePct.toFixed(2)}%` : "",
    relVolume >= 2 ? `${relVolume.toFixed(1)}x rel vol` : "",
    structuredCount ? `${structuredCount} structured news` : "",
    publicCount ? `${publicCount} public news` : "",
    socialCount ? `${socialCount} social posts` : "",
    sentiment > 0.05 ? `weighted sent +${sentiment.toFixed(2)}` : sentiment < -0.05 ? `weighted sent ${sentiment.toFixed(2)}` : "",
  ].filter(Boolean).slice(0, 5)
  const risks = [
    supportCount === 0 ? "no matched news/social evidence yet" : "",
    quoteAgeMinutes != null && quoteAgeMinutes > 180 ? `quote ${Math.round(quoteAgeMinutes)}m old` : "",
    microOrPenny ? "microcap/penny volatility" : "",
    socialCount > 0 && socialSentiment < -0.05 ? "negative social tone" : "",
    articleCount > 0 && articleSentiment < -0.05 ? "negative news tone" : "",
  ].filter(Boolean).slice(0, 4)

  return {
    trade_watch_score: Number(score.toFixed(3)),
    decision,
    confidence: Number((score * 100).toFixed(1)),
    agreement: Number(agreement.toFixed(3)),
    evidence_score: Number(evidenceScore.toFixed(3)),
    quote_freshness: Number(quoteFreshness.toFixed(3)),
    quote_age_minutes: quoteAgeMinutes == null ? null : Number(quoteAgeMinutes.toFixed(1)),
    support_count: supportCount,
    score_breakdown: scoreBreakdown,
    reasons,
    risks,
  }
}

function addTradeWatchFields(row) {
  return {
    ...row,
    trade_watch: tradeWatchDecision(row),
  }
}

const PREDICTION_HORIZONS_MINUTES = [5, 15, 60]
const PREDICTION_MODEL_ID = "trade_watch_linear_v1"
const NEXT_DAY_MODEL_ID = "next_day_multifactor_v1"
const NEXT_DAY_MODEL_VERSION = "2026-06-28.1"
const PREDICTION_FEATURE_KEYS = [
  "change_pct",
  "abs_change_pct",
  "extension_risk",
  "price_log",
  "rel_volume",
  "volume_log",
  "market_cap_log",
  "rsi",
  "rsi_centered",
  "rsi_overbought",
  "rsi_oversold",
  "article_count",
  "structured_article_count",
  "unstructured_article_count",
  "article_density",
  "source_diversity",
  "article_sentiment",
  "structured_sentiment",
  "unstructured_sentiment",
  "social_count",
  "social_density_per_minute",
  "social_sentiment",
  "social_news_agreement",
  "weighted_sentiment",
  "evidence_score",
  "trade_watch_score",
  "agreement",
  "quote_freshness",
  "ai_score",
  "ai_sentiment_score",
  "ai_confidence",
  "ai_article_count",
  "ai_source_count",
  "momentum_context_score",
  "momentum_rank_trend",
  "stocktwits_count",
  "bluesky_count",
  "reddit_count",
  "social_platform_count",
  "gossip_count",
  "correlation_score",
  "prediction_validation_accuracy_5m",
  "prediction_validation_avg_return_5m",
  "prediction_validation_samples",
  "candidate_priority",
  "evidence_window_hours",
  "is_premarket_signal",
  "is_regular_signal",
  "is_afterhours_signal",
  "is_weekend_carry_signal",
  "is_news_catalyst",
  "is_correlation_candidate",
  "is_technical_setup",
  "is_top_mover",
]

function probabilityFromDirectionHint(features = {}) {
  const validationAccuracy = Number(features.prediction_validation_accuracy_5m)
  const validationReturn = Number(features.prediction_validation_avg_return_5m)
  if (Number.isFinite(validationAccuracy) && Number.isFinite(validationReturn) && validationReturn > 0) {
    return clamp(0.5 + Math.max(0, validationAccuracy - 0.5), 0, 1)
  }
  if (Number(features.is_news_catalyst || 0) === 1 && Number(features.article_sentiment || 0) > 0.05) return 0.58
  if (Number(features.is_top_mover || 0) === 1 && Number(features.change_pct || 0) > 0) return 0.56
  return 0.5
}

function nextDayModelFeatureScore(row, features) {
  const changePct = Number(features.change_pct || 0)
  const relVolume = Number(features.rel_volume || 0)
  const rsi = Number(features.rsi)
  const price = Number(features.price || 0)
  const marketCap = Number(features.market_cap || 0)
  const articleCount = Number(features.article_count || 0)
  const socialCount = Number(features.social_count || 0)
  const articleSentiment = Number(features.article_sentiment || 0)
  const structuredSentiment = Number(features.structured_sentiment || 0)
  const socialSentiment = Number(features.social_sentiment || 0)
  const weightedSentiment = Number(features.weighted_sentiment || 0)
  const evidenceScore = Number(features.evidence_score || 0)
  const tradeWatchScore = Number(features.trade_watch_score || 0)
  const agreement = Number(features.agreement || 0)
  const aiScore = Number(features.ai_score ?? 50)
  const aiSentimentScore = Number(features.ai_sentiment_score || 0)
  const aiConfidence = Number(features.ai_confidence || 0)
  const aiArticleCount = Number(features.ai_article_count || 0)
  const aiSourceCount = Number(features.ai_source_count || 0)
  const momentumContextScore = Number(features.momentum_context_score ?? 50)
  const momentumRankTrend = Number(features.momentum_rank_trend || 0)
  const stocktwitsCount = Number(features.stocktwits_count || 0)
  const blueskyCount = Number(features.bluesky_count || 0)
  const redditCount = Number(features.reddit_count || 0)
  const socialPlatformCount = Number(features.social_platform_count || 0)
  const gossipCount = Number(features.gossip_count || 0)
  const correlationScore = Number(features.correlation_score || 0)
  const validationAccuracy = Number(features.prediction_validation_accuracy_5m)
  const validationReturn = Number(features.prediction_validation_avg_return_5m)
  const candidatePriority = Number(features.candidate_priority || 0)
  const evidenceWindowHours = Number(features.evidence_window_hours || 0)
  const isPremarketSignal = Number(features.is_premarket_signal || 0) === 1
  const isAfterhoursSignal = Number(features.is_afterhours_signal || 0) === 1
  const isWeekendCarrySignal = Number(features.is_weekend_carry_signal || 0) === 1
  const positiveCatalyst = Boolean(
    (articleCount > 0 && (articleSentiment > 0.05 || structuredSentiment > 0.05 || weightedSentiment > 0.05)) ||
    (socialCount > 0 && socialSentiment > 0.08) ||
    (aiArticleCount > 0 && aiSentimentScore > 0.06 && aiScore >= 58) ||
    correlationScore > 0.12 ||
    (Number.isFinite(validationAccuracy) && validationAccuracy >= 0.54 && Number.isFinite(validationReturn) && validationReturn > 0) ||
    Number(features.is_news_catalyst || 0) === 1
  )
  const technicalGate = positiveCatalyst ? 1 : 0

  const momentum = clamp(changePct / 12, -0.55, 0.7)
  const volume = clamp(Math.log1p(Math.max(0, relVolume)) / Math.log1p(8), 0, 1)
  const news = clamp((articleSentiment + structuredSentiment) / 2, -1, 1)
  const social = clamp(socialSentiment, -1, 1)
  const combined = clamp(weightedSentiment || evidenceScore, -1, 1)
  const evidenceDepth = clamp(Math.log1p(articleCount + socialCount) / Math.log1p(80), 0, 1)
  const tradeQuality = clamp(tradeWatchScore, 0, 1)
  const agreementScore = clamp(agreement, 0, 1)
  const correlation = clamp(correlationScore, -1, 1)
  const aiDirectional = clamp((aiScore - 50) / 50, -1, 1)
  const aiEvidence = clamp(
    aiDirectional * 0.55 +
    aiSentimentScore * 0.30 +
    clamp(aiConfidence, 0, 1) * 0.15,
    -1,
    1
  )
  const aiDepth = clamp(Math.log1p(aiArticleCount + aiSourceCount) / Math.log1p(20), 0, 1)
  const momentumPersistence = clamp((momentumContextScore - 50) / 50, -1, 1)
  const socialPlatformDepth = clamp(Math.log1p(stocktwitsCount + blueskyCount + redditCount + socialPlatformCount * 3) / Math.log1p(60), 0, 1)
  const gossipDirectional = gossipCount > 0 ? clamp(socialSentiment || aiSentimentScore || combined, -1, 1) * clamp(Math.log1p(gossipCount) / Math.log1p(8), 0, 1) : 0
  const validationEdge = clamp(
    (Number.isFinite(validationAccuracy) ? Math.max(0, validationAccuracy - 0.5) * 1.6 : 0) +
    (Number.isFinite(validationReturn) ? Math.max(0, validationReturn) / 3 : 0),
    0,
    1
  )
  const preMoveSetup = clamp(
    (changePct >= -4 && changePct <= 8 ? 0.45 : changePct > 8 && changePct <= 15 ? 0.18 : 0) +
    (relVolume >= 1.25 ? 0.22 : 0) +
    (candidatePriority ? candidatePriority * 0.22 : 0) +
    (articleCount + socialCount > 0 ? 0.11 : 0),
    0,
    1
  ) * technicalGate
  const rsiPenalty = Number.isFinite(rsi) && rsi > 78 && changePct > 10 ? clamp((rsi - 78) / 22, 0, 1) : 0
  const oversoldRebound = positiveCatalyst && Number.isFinite(rsi) && rsi < 35 && combined > 0 ? clamp((35 - rsi) / 20, 0, 1) : 0
  const thinEvidencePenalty = articleCount + socialCount === 0 ? 0.18 : articleCount + socialCount === 1 ? 0.08 : 0
  const aiDisagreementPenalty = aiArticleCount > 0 && aiEvidence < -0.12 && (news > 0.05 || combined > 0.05 || probabilityFromDirectionHint(features) > 0.55)
    ? clamp(Math.abs(aiEvidence) * aiConfidence, 0, 0.22)
    : 0
  const socialDisagreementPenalty = socialCount > 0 && socialSentiment < -0.12 && (news > 0.05 || aiEvidence > 0.05)
    ? clamp(Math.abs(socialSentiment) * 0.16, 0, 0.16)
    : 0
  const staleWindowPenalty = evidenceWindowHours > 72 ? 0.08 : evidenceWindowHours > 48 ? 0.04 : 0
  const sessionOpportunity = clamp(
    (isPremarketSignal ? 0.08 : 0) +
    (isAfterhoursSignal ? 0.05 : 0) +
    (isWeekendCarrySignal && articleCount > 0 ? 0.04 : 0),
    0,
    0.12
  )
  const microPenalty = (price > 0 && price < 1) || (marketCap > 0 && marketCap < 300e6)
    ? (articleCount + socialCount < 3 ? 0.1 : 0.04)
    : 0
  const extensionPenalty = changePct > 18 ? clamp((changePct - 18) / 52, 0, combined > 0.15 ? 0.28 : 0.42) : 0
  const reversalPenalty = changePct > 35 ? clamp((changePct - 35) / 65, 0, 0.35) : 0

  const raw =
    momentum * 0.09 +
    volume * 0.10 +
    news * 0.18 +
    social * 0.10 +
    combined * 0.15 +
    evidenceDepth * 0.10 +
    tradeQuality * 0.07 +
    agreementScore * 0.07 +
    correlation * 0.09 +
    aiEvidence * 0.12 +
    aiDepth * 0.04 +
    momentumPersistence * 0.08 +
    Math.max(0, momentumRankTrend) * 0.03 +
    socialPlatformDepth * 0.04 +
    gossipDirectional * 0.04 +
    validationEdge * 0.07 +
    preMoveSetup * 0.07 +
    oversoldRebound * 0.03 -
    staleWindowPenalty +
    sessionOpportunity -
    rsiPenalty * 0.10 -
    thinEvidencePenalty -
    aiDisagreementPenalty -
    socialDisagreementPenalty -
    microPenalty -
    extensionPenalty -
    reversalPenalty

  return {
    score: clamp(raw, -1, 1),
    components: {
      momentum: Number(momentum.toFixed(3)),
      relative_volume: Number(volume.toFixed(3)),
      news_sentiment: Number(news.toFixed(3)),
      social_sentiment: Number(social.toFixed(3)),
      combined_sentiment: Number(combined.toFixed(3)),
      evidence_depth: Number(evidenceDepth.toFixed(3)),
      trade_quality: Number(tradeQuality.toFixed(3)),
      agreement: Number(agreementScore.toFixed(3)),
      correlation: Number(correlation.toFixed(3)),
      ai_evidence: Number(aiEvidence.toFixed(3)),
      ai_depth: Number(aiDepth.toFixed(3)),
      momentum_persistence: Number(momentumPersistence.toFixed(3)),
      momentum_rank_trend: Number(momentumRankTrend.toFixed(3)),
      social_platform_depth: Number(socialPlatformDepth.toFixed(3)),
      gossip_directional: Number(gossipDirectional.toFixed(3)),
      validation_edge: Number(validationEdge.toFixed(3)),
      positive_catalyst_gate: positiveCatalyst ? 1 : 0,
      evidence_window_hours: Number(evidenceWindowHours.toFixed(2)),
      session_opportunity: Number(sessionOpportunity.toFixed(3)),
      pre_move_setup: Number(preMoveSetup.toFixed(3)),
      oversold_rebound: Number(oversoldRebound.toFixed(3)),
      rsi_penalty: Number(rsiPenalty.toFixed(3)),
      thin_evidence_penalty: Number(thinEvidencePenalty.toFixed(3)),
      ai_disagreement_penalty: Number(aiDisagreementPenalty.toFixed(3)),
      social_disagreement_penalty: Number(socialDisagreementPenalty.toFixed(3)),
      stale_window_penalty: Number(staleWindowPenalty.toFixed(3)),
      microcap_penalty: Number(microPenalty.toFixed(3)),
      extension_penalty: Number(extensionPenalty.toFixed(3)),
      reversal_penalty: Number(reversalPenalty.toFixed(3)),
    },
  }
}

function nextDayPredictionFromMover(row, features, { intradaySignal = null, trainedModel = null } = {}) {
  const { score, components } = nextDayModelFeatureScore(row, features)
  const probabilityUp = clamp(sigmoid(score * 2.4))
  const predictedReturn = clamp(score * 8, -12, 12)
  const confidence = clamp(Math.abs(probabilityUp - 0.5) * 2)
  const direction = probabilityUp >= 0.54 && predictedReturn > 0.15
    ? "up"
    : probabilityUp <= 0.46 && predictedReturn < -0.15
      ? "down"
      : "watch"
  const articleCount = Number(features.article_count || 0)
  const socialCount = Number(features.social_count || 0)
  const metrics = trainedModel?.metrics || {}
  const modelAccuracy = Number(metrics.directional_accuracy_5m)
  const baselineAccuracy = Number(metrics.baseline_directional_accuracy_5m)
  const modelValidatedEdge = Number.isFinite(modelAccuracy) &&
    (!Number.isFinite(baselineAccuracy) || modelAccuracy >= baselineAccuracy)
  const warnings = [
    "No completed chart-backed 1d labels yet; prediction uses transparent multifactor evidence weights and should be validated after the next trading day.",
    trainedModel?.status === "trained" ? "" : "Intraday validation model is not trained; confidence is evidence-only.",
    trainedModel?.status === "trained" && !modelValidatedEdge ? "Intraday validation model is below recent baseline; it is stored as reference only, not treated as a live edge." : "",
    articleCount + socialCount === 0 ? "No current matched news/social support." : "",
    row.ticker && String(row.ticker).length === 1 ? "Single-letter ticker evidence requires strict relevance checks." : "",
  ].filter(Boolean)

  return {
    model: NEXT_DAY_MODEL_ID,
    model_version: NEXT_DAY_MODEL_VERSION,
    algorithm: "transparent_multifactor_scoring_v1",
    horizon: "1d",
    prediction_session: features.prediction_session || null,
    prediction_target: features.prediction_target || null,
    evidence_window_start_sec: features.evidence_window_start_sec || null,
    evidence_window_end_sec: features.evidence_window_end_sec || null,
    evidence_window_hours: features.evidence_window_hours ?? null,
    direction,
    predicted_return_1d: Number(predictedReturn.toFixed(3)),
    predicted_return_next_day: Number(predictedReturn.toFixed(3)),
    probability_up: Number(probabilityUp.toFixed(3)),
    confidence: Number(confidence.toFixed(3)),
    feature_score: Number(score.toFixed(3)),
    feature_contributions: components,
    generated_at: new Date(),
    trained_intraday_model_status: trainedModel?.status || "missing",
    trained_intraday_model_validated_edge: Boolean(modelValidatedEdge),
    intraday_reference_signal: intradaySignal ? {
      model: intradaySignal.model || null,
      direction: intradaySignal.direction || null,
      predicted_return_5m: intradaySignal.predicted_return_5m ?? null,
      confidence: intradaySignal.confidence ?? null,
    } : null,
    caveats: warnings,
  }
}

function predictionFeaturesFromMover(row, socialWindowMinutes = 60, options = {}) {
  const predictionContext = options.predictionContext || row.prediction_session_context || marketPredictionContext()
  const socialCount = Number(row.message_count || 0)
  const articleCount = Number(row.article_count || 0)
  const structuredArticleCount = Number(row.structured_article_count || 0)
  const unstructuredArticleCount = Number(row.unstructured_article_count || 0)
  const relVolume = Number(row.rel_volume || 0)
  const changePct = Number(row.change_pct || 0)
  const sentiment = Number(row.sentiment || 0)
  const price = Number(row.price || 0)
  const volume = Number(row.volume || 0)
  const marketCap = Number(row.market_cap || 0)
  const rsi = Number(row.rsi)
  const sourceDiversity = Array.isArray(row.sources) ? new Set(row.sources.filter(Boolean)).size : 0
  const articleSentiment = Number(row.article_sentiment || 0)
  const socialSentiment = Number(row.social_sentiment || 0)
  const aiScore = row.ai_score == null ? 50 : Number(row.ai_score)
  const aiSentimentScore = Number(row.ai_sentiment_score || 0)
  const aiConfidence = Number(row.ai_confidence || 0)
  const aiArticleCount = Number(row.ai_article_count || 0)
  const aiSourceCount = Number(row.ai_source_count || 0)
  const momentumContextScore = row.momentum_context_score == null ? Number(row.momentum_score || 50) : Number(row.momentum_context_score)
  const momentumRankTrend = Number(row.momentum_rank_trend || 0)
  const stocktwitsCount = Number(row.stocktwits_count || 0)
  const blueskyCount = Number(row.bluesky_count || 0)
  const redditCount = Number(row.reddit_count || 0)
  const socialPlatformCount = Number(row.social_platform_count || 0)
  const gossipCount = Number(row.gossip_count || 0)
  const discoverySource = String(row.discovery_source || "")
  const evidenceScore =
    articleSentiment * Math.min(1, articleCount / 5) +
    socialSentiment * Math.min(1, socialCount / 20)
  const socialNewsAgreement = articleCount > 0 && socialCount > 0
    ? (Math.sign(articleSentiment) === Math.sign(socialSentiment) ? Math.min(Math.abs(articleSentiment), Math.abs(socialSentiment)) : -Math.min(Math.abs(articleSentiment), Math.abs(socialSentiment)))
    : 0

  return {
    price,
    price_log: Number(Math.log1p(Math.max(0, price)).toFixed(4)),
    change_pct: changePct,
    abs_change_pct: Number(Math.abs(changePct).toFixed(3)),
    extension_risk: Number(clamp((Math.abs(changePct) - 12) / 38, 0, 1).toFixed(3)),
    volume,
    volume_log: Number(Math.log1p(Math.max(0, volume)).toFixed(4)),
    rel_volume: Number(relVolume.toFixed(3)),
    market_cap: marketCap,
    market_cap_log: Number(Math.log1p(Math.max(0, marketCap)).toFixed(4)),
    market_cap_bucket: row.market_cap_bucket || "Unknown",
    rsi: Number.isFinite(rsi) ? Number(rsi.toFixed(3)) : null,
    rsi_centered: Number.isFinite(rsi) ? Number(((rsi - 50) / 50).toFixed(4)) : 0,
    rsi_overbought: Number.isFinite(rsi) ? Number(clamp((rsi - 70) / 20, 0, 1).toFixed(3)) : 0,
    rsi_oversold: Number.isFinite(rsi) ? Number(clamp((35 - rsi) / 25, 0, 1).toFixed(3)) : 0,
    gap: row.gap ?? null,
    perf_week: row.perf_week ?? null,
    perf_month: row.perf_month ?? null,
    article_count: articleCount,
    structured_article_count: structuredArticleCount,
    unstructured_article_count: unstructuredArticleCount,
    article_density: Number((articleCount / Math.max(1, Number(row.rolling_window_minutes || 1440) / 60)).toFixed(4)),
    source_diversity: sourceDiversity,
    article_sentiment: Number(articleSentiment.toFixed(3)),
    structured_sentiment: Number(Number(row.structured_sentiment || 0).toFixed(3)),
    unstructured_sentiment: Number(Number(row.unstructured_sentiment || 0).toFixed(3)),
    social_count: socialCount,
    social_density_per_minute: Number((socialCount / Math.max(1, socialWindowMinutes)).toFixed(3)),
    social_sentiment: Number(socialSentiment.toFixed(3)),
    social_news_agreement: Number(socialNewsAgreement.toFixed(3)),
    weighted_sentiment: Number(sentiment.toFixed(3)),
    evidence_score: Number(evidenceScore.toFixed(3)),
    trade_watch_score: Number(row.trade_watch?.trade_watch_score || 0),
    agreement: Number(row.trade_watch?.agreement || 0),
    quote_freshness: Number(row.trade_watch?.quote_freshness || 0),
    ai_score: Number(Number.isFinite(aiScore) ? aiScore.toFixed(3) : 50),
    ai_sentiment_score: Number(aiSentimentScore.toFixed(3)),
    ai_confidence: Number(clamp(aiConfidence, 0, 1).toFixed(3)),
    ai_article_count: aiArticleCount,
    ai_source_count: aiSourceCount,
    momentum_context_score: Number(Number.isFinite(momentumContextScore) ? momentumContextScore.toFixed(3) : 50),
    momentum_rank_trend: Number(momentumRankTrend.toFixed(3)),
    stocktwits_count: stocktwitsCount,
    bluesky_count: blueskyCount,
    reddit_count: redditCount,
    social_platform_count: socialPlatformCount,
    gossip_count: gossipCount,
    discovery_source: row.discovery_source || null,
    discovery_sources: row.discovery_sources || [],
    candidate_priority: Number(row.candidate_priority || 0),
    candidate_reasons: row.candidate_reasons || [],
    prediction_session: predictionContext.session || null,
    prediction_target: predictionContext.target || null,
    evidence_window_start_sec: Number(predictionContext.evidence_window_start_sec || 0) || null,
    evidence_window_end_sec: Number(predictionContext.evidence_window_end_sec || 0) || null,
    evidence_window_hours: Number(predictionContext.evidence_window_hours || 0),
    is_premarket_signal: predictionContext.session === "premarket" || predictionContext.session === "overnight" ? 1 : 0,
    is_regular_signal: predictionContext.session === "regular" ? 1 : 0,
    is_afterhours_signal: predictionContext.session === "afterhours" || predictionContext.session === "closed_post_afterhours" ? 1 : 0,
    is_weekend_carry_signal: predictionContext.includes_weekend_carry ? 1 : 0,
    correlation_score: Number(row.correlation_score || 0),
    prediction_validation_accuracy_5m: row.prediction_validation_accuracy_5m == null ? null : Number(row.prediction_validation_accuracy_5m),
    prediction_validation_avg_return_5m: row.prediction_validation_avg_return_5m == null ? null : Number(row.prediction_validation_avg_return_5m),
    prediction_validation_samples: Number(row.prediction_validation_samples || 0),
    is_news_catalyst: discoverySource === "news_catalyst" || discoverySource === "ai_news_evidence" ? 1 : 0,
    is_correlation_candidate: discoverySource === "correlation_validation" ? 1 : 0,
    is_technical_setup: discoverySource === "technical_setup" ? 1 : 0,
    is_top_mover: discoverySource === "finviz_top_mover" ? 1 : 0,
  }
}

function baselinePredictionFromMover(row) {
  const features = predictionFeaturesFromMover(row)
  const tradeScore = Number(row.trade_watch?.trade_watch_score || 0)
  const evidence = Number(features.evidence_score || 0)
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const direction = evidence >= 0.12 && changePct > 0
    ? "up"
    : evidence <= -0.12 && changePct < 0
      ? "down"
      : "watch"
  const confidence = clamp(
    tradeScore * 0.45 +
    Math.min(1, Math.abs(evidence)) * 0.25 +
    Math.min(1, relVolume / 6) * 0.15 +
    Math.min(1, Math.abs(changePct) / 25) * 0.15
  )
  return {
    direction,
    confidence: Number(confidence.toFixed(3)),
    model: "baseline_trade_watch_v1",
    model_ready: Boolean(row.price && (row.article_count || row.message_count) && Number.isFinite(changePct)),
  }
}

function sigmoid(value) {
  return 1 / (1 + Math.exp(-value))
}

function normalizedFeatureVector(features = {}, featureStats = {}, keys = PREDICTION_FEATURE_KEYS) {
  return keys.map(key => {
    const stat = featureStats[key] || { mean: 0, std: 1 }
    const std = Number(stat.std || 1) || 1
    const raw = Number(features[key])
    const normalized = Number.isFinite(raw) ? (raw - Number(stat.mean || 0)) / std : 0
    return Number(Math.max(-8, Math.min(8, normalized)).toFixed(4))
  })
}

function vectorDistance(a = [], b = []) {
  const length = Math.min(a.length, b.length)
  if (!length) return Infinity
  let sum = 0
  for (let i = 0; i < length; i += 1) {
    const diff = Number(a[i] || 0) - Number(b[i] || 0)
    sum += diff * diff
  }
  return Math.sqrt(sum / length)
}

function meanVector(vectors = []) {
  if (!vectors.length) return []
  const width = vectors[0].length
  const sums = Array.from({ length: width }, () => 0)
  for (const vector of vectors) {
    for (let i = 0; i < width; i += 1) sums[i] += Number(vector[i] || 0)
  }
  return sums.map(value => Number((value / vectors.length).toFixed(4)))
}

function buildRegularizedLogisticClassifier(samples = [], featureStats = {}, keys = PREDICTION_FEATURE_KEYS) {
  const minMove = Number(process.env.PREDICTION_DIRECTION_MIN_MOVE_PCT || 0.05)
  const rows = samples
    .map(row => {
      const target = Number(row.target)
      if (!Number.isFinite(target) || Math.abs(target) < minMove) return null
      return {
        y: target > 0 ? 1 : 0,
        target,
        vector: normalizedFeatureVector(row.features, featureStats, keys),
      }
    })
    .filter(Boolean)

  const upCount = rows.filter(row => row.y === 1).length
  const downCount = rows.length - upCount
  if (upCount < 20 || downCount < 20) return null

  const epochs = Math.max(80, Math.min(800, Number(process.env.PREDICTION_LOGISTIC_EPOCHS || 260)))
  const learningRate = Math.max(0.001, Math.min(0.2, Number(process.env.PREDICTION_LOGISTIC_LR || 0.035)))
  const l2 = Math.max(0, Math.min(1, Number(process.env.PREDICTION_LOGISTIC_L2 || 0.025)))
  const actionThreshold = Math.max(0.5, Math.min(0.95, Number(process.env.PREDICTION_LOGISTIC_ACTION_THRESHOLD || 0.535)))
  const width = keys.length
  const weights = Array.from({ length: width }, () => 0)
  let intercept = Math.log(upCount / Math.max(1, downCount))
  const upWeight = rows.length / Math.max(1, 2 * upCount)
  const downWeight = rows.length / Math.max(1, 2 * downCount)

  for (let epoch = 0; epoch < epochs; epoch += 1) {
    const grad = Array.from({ length: width }, () => 0)
    let interceptGrad = 0
    let totalWeight = 0
    for (const row of rows) {
      let z = intercept
      for (let i = 0; i < width; i += 1) z += weights[i] * Number(row.vector[i] || 0)
      z = clamp(z, -12, 12)
      const p = sigmoid(z)
      const sampleWeight = row.y ? upWeight : downWeight
      const error = (p - row.y) * sampleWeight
      totalWeight += sampleWeight
      interceptGrad += error
      for (let i = 0; i < width; i += 1) grad[i] += error * Number(row.vector[i] || 0)
    }
    const denom = Math.max(1, totalWeight)
    intercept -= learningRate * (interceptGrad / denom)
    for (let i = 0; i < width; i += 1) {
      const regularized = grad[i] / denom + l2 * weights[i]
      weights[i] -= learningRate * regularized
      weights[i] = clamp(weights[i], -4, 4)
    }
  }

  const upTargets = rows.filter(row => row.y === 1).map(row => row.target)
  const downTargets = rows.filter(row => row.y === 0).map(row => row.target)
  const avg = list => list.reduce((sum, value) => sum + value, 0) / Math.max(1, list.length)
  const absMean = list => list.reduce((sum, value) => sum + Math.abs(value), 0) / Math.max(1, list.length)
  const sortedWeights = weights
    .map((value, index) => ({ key: keys[index], weight: Number(value.toFixed(5)), abs: Math.abs(value) }))
    .sort((a, b) => b.abs - a.abs)
    .slice(0, 12)
    .map(({ key, weight }) => ({ key, weight }))

  return {
    type: "regularized_logistic_direction_v2",
    min_move_pct: minMove,
    action_threshold: Number(actionThreshold.toFixed(3)),
    epochs,
    learning_rate: learningRate,
    l2,
    class_counts: { up: upCount, down: downCount },
    intercept: Number(intercept.toFixed(6)),
    weights: weights.map(value => Number(value.toFixed(6))),
    avg_up_return: Number(avg(upTargets).toFixed(4)),
    avg_down_return: Number(avg(downTargets).toFixed(4)),
    avg_abs_up_return: Number(absMean(upTargets).toFixed(4)),
    avg_abs_down_return: Number(absMean(downTargets).toFixed(4)),
    top_features: sortedWeights,
  }
}

function buildDirectionalClassifier(samples = [], featureStats = {}, keys = PREDICTION_FEATURE_KEYS) {
  const logisticClassifier = buildRegularizedLogisticClassifier(samples, featureStats, keys)
  if (logisticClassifier) return logisticClassifier

  const minMove = Number(process.env.PREDICTION_DIRECTION_MIN_MOVE_PCT || 0.05)
  const maxPerClass = Math.max(25, Math.min(500, Number(process.env.PREDICTION_CLASSIFIER_PROTOTYPES_PER_CLASS || 250)))
  const rows = samples
    .map(row => {
      const target = Number(row.target)
      if (!Number.isFinite(target) || Math.abs(target) < minMove) return null
      return {
        direction: target > 0 ? "up" : "down",
        target: Number(target.toFixed(3)),
        vector: normalizedFeatureVector(row.features, featureStats, keys),
      }
    })
    .filter(Boolean)

  const upRows = rows.filter(row => row.direction === "up")
  const downRows = rows.filter(row => row.direction === "down")
  if (upRows.length < 10 || downRows.length < 10) return null

  const choose = list => list.slice(0, maxPerClass)

  const upPrototypes = choose(upRows)
  const downPrototypes = choose(downRows)
  return {
    type: "knn_centroid_direction_v1",
    min_move_pct: minMove,
    k: Math.max(5, Math.min(35, Number(process.env.PREDICTION_CLASSIFIER_K || 21))),
    class_counts: { up: upRows.length, down: downRows.length },
    centroids: {
      up: meanVector(upRows.map(row => row.vector)),
      down: meanVector(downRows.map(row => row.vector)),
    },
    prototypes: {
      up: upPrototypes.map(row => ({ v: row.vector, target: row.target })),
      down: downPrototypes.map(row => ({ v: row.vector, target: row.target })),
    },
  }
}

function applyDirectionalClassifier(features = {}, model = null) {
  const classifier = model?.direction_classifier
  const keys = model.feature_keys || PREDICTION_FEATURE_KEYS
  const vector = normalizedFeatureVector(features, model.feature_stats, keys)
  if (classifier?.type === "regularized_logistic_direction_v2" && Array.isArray(classifier.weights)) {
    let z = Number(classifier.intercept || 0)
    for (let i = 0; i < keys.length; i += 1) z += Number(classifier.weights[i] || 0) * Number(vector[i] || 0)
    const probabilityUp = clamp(sigmoid(clamp(z, -12, 12)))
    const avgUp = Number(classifier.avg_up_return || 0.25)
    const avgDown = Number(classifier.avg_down_return || -0.25)
    const predictedReturn = probabilityUp * avgUp + (1 - probabilityUp) * avgDown
    const confidence = Math.abs(probabilityUp - 0.5) * 2
    const actionThreshold = Math.max(0.5, Math.min(0.95, Number(classifier.action_threshold || 0.535)))
    const direction = probabilityUp >= actionThreshold && predictedReturn > 0
      ? "up"
      : probabilityUp <= 1 - actionThreshold && predictedReturn < 0
        ? "down"
        : "watch"
    const contributions = keys
      .map((key, index) => ({
        key,
        value: Number(features[key] || 0),
        contribution: Number((Number(classifier.weights[index] || 0) * Number(vector[index] || 0)).toFixed(5)),
      }))
      .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
      .slice(0, 8)

    return {
      model: model.model_id || PREDICTION_MODEL_ID,
      model_version: model.version || 1,
      algorithm: classifier.type,
      direction,
      predicted_return_5m: Number(predictedReturn.toFixed(3)),
      probability_up: Number(probabilityUp.toFixed(3)),
      confidence: Number(confidence.toFixed(3)),
      trained_samples: Number(model.samples || 0),
      class_counts: classifier.class_counts || null,
      top_feature_contributions: contributions,
    }
  }

  if (!classifier?.prototypes?.up?.length || !classifier?.prototypes?.down?.length || !model?.feature_stats) return null
  const neighbors = [
    ...classifier.prototypes.up.map(row => ({ direction: "up", target: Number(row.target || 0), distance: vectorDistance(vector, row.v) })),
    ...classifier.prototypes.down.map(row => ({ direction: "down", target: Number(row.target || 0), distance: vectorDistance(vector, row.v) })),
  ]
    .filter(row => Number.isFinite(row.distance))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, Number(classifier.k || 21))

  if (!neighbors.length) return null

  let upWeight = 0
  let totalWeight = 0
  let weightedReturn = 0
  for (const row of neighbors) {
    const weight = 1 / Math.max(0.08, row.distance + 0.08)
    totalWeight += weight
    if (row.direction === "up") upWeight += weight
    weightedReturn += weight * row.target
  }
  if (!totalWeight) return null

  const knnProbability = upWeight / totalWeight
  const upDistance = vectorDistance(vector, classifier.centroids?.up || [])
  const downDistance = vectorDistance(vector, classifier.centroids?.down || [])
  const centroidProbability = Number.isFinite(upDistance) && Number.isFinite(downDistance)
    ? sigmoid((downDistance - upDistance) * 1.4)
    : knnProbability
  const probabilityUp = clamp(knnProbability * 0.7 + centroidProbability * 0.3)
  const predictedReturn = weightedReturn / totalWeight
  const confidence = Math.abs(probabilityUp - 0.5)
  const direction = probabilityUp >= 0.56 && predictedReturn > 0
    ? "up"
    : probabilityUp <= 0.44 && predictedReturn < 0
      ? "down"
      : "watch"

  return {
    model: model.model_id || PREDICTION_MODEL_ID,
    model_version: model.version || 1,
    algorithm: classifier.type,
    direction,
    predicted_return_5m: Number(predictedReturn.toFixed(3)),
    probability_up: Number(probabilityUp.toFixed(3)),
    confidence: Number(confidence.toFixed(3)),
    nearest_samples: neighbors.length,
    trained_samples: Number(model.samples || 0),
  }
}

function applyPredictionModel(features = {}, model = null) {
  if (!model?.weights || !model?.feature_stats || model.status !== "trained") return null
  const classifierSignal = applyDirectionalClassifier(features, model)
  const validation = modelValidationState(model)
  if (classifierSignal && validation.allow_live_classifier) {
    return {
      ...classifierSignal,
      validation_status: validation.status,
      validation_edge: validation.edge,
    }
  }

  let score = Number(model.intercept || 0)
  for (const key of model.feature_keys || PREDICTION_FEATURE_KEYS) {
    const stat = model.feature_stats[key] || { mean: 0, std: 1 }
    const std = Number(stat.std || 1) || 1
    const raw = Number(features[key])
    const normalized = Number.isFinite(raw) ? (raw - Number(stat.mean || 0)) / std : 0
    score += Number(model.weights[key] || 0) * normalized
  }
  const predictedReturn = Number(score.toFixed(3))
  const probabilityUp = Number(sigmoid(score / Math.max(0.25, Number(model.target_std || 1))).toFixed(3))
  return {
    model: model.model_id || PREDICTION_MODEL_ID,
    model_version: model.version || 1,
    algorithm: classifierSignal ? "linear_return_v1_classifier_shadowed" : "linear_return_v1",
    direction: predictedReturn > 0.05 ? "up" : predictedReturn < -0.05 ? "down" : "watch",
    predicted_return_5m: predictedReturn,
    probability_up: probabilityUp,
    confidence: Number(Math.abs(probabilityUp - 0.5).toFixed(3)),
    trained_samples: Number(model.samples || 0),
    validation_status: validation.status,
    validation_edge: validation.edge,
    shadowed_classifier_signal: classifierSignal ? {
      direction: classifierSignal.direction,
      probability_up: classifierSignal.probability_up,
      confidence: classifierSignal.confidence,
      reason: validation.reason,
    } : null,
  }
}

function evaluateModelDirections(samples = [], model = null, { thresholds = [null] } = {}) {
  return thresholds.map((threshold) => {
    const classifier = threshold == null
      ? model?.direction_classifier
      : { ...(model?.direction_classifier || {}), action_threshold: threshold }
    const candidateModel = { ...(model || {}), direction_classifier: classifier }
    const rows = samples.map(row => {
      const signal = applyPredictionModel(row.features, candidateModel)
      const direction = signal?.direction || "watch"
      const target = Number(row.target)
      const correct = direction !== "watch"
        ? (direction === "up" ? target > 0 : target < 0)
        : null
      return {
        direction,
        target,
        probability_up: signal?.probability_up ?? null,
        confidence: signal?.confidence ?? null,
        correct,
      }
    })
    const actionable = rows.filter(row => row.correct != null)
    const accuracy = actionable.length
      ? actionable.reduce((sum, row) => sum + (row.correct ? 1 : 0), 0) / actionable.length
      : null
    const avgAbsReturn = actionable.length
      ? actionable.reduce((sum, row) => sum + Math.abs(Number(row.target || 0)), 0) / actionable.length
      : 0
    return {
      threshold,
      actionable_samples: actionable.length,
      accuracy,
      avg_abs_return: avgAbsReturn,
      coverage: samples.length ? actionable.length / samples.length : 0,
      rows,
    }
  })
}

function optimizeLogisticActionThreshold(samples = [], model = null, baselineAccuracy = null) {
  if (model?.direction_classifier?.type !== "regularized_logistic_direction_v2") return null
  const thresholds = []
  for (let value = 0.52; value <= 0.95; value += 0.01) thresholds.push(Number(value.toFixed(3)))
  const minActionable = Math.max(20, Math.min(120, Number(process.env.PREDICTION_MIN_ACTIONABLE_HOLDOUT || 50)))
  const minAccuracy = Math.max(0.5, Math.min(0.9, Number(process.env.MIN_LIVE_MODEL_ACCURACY || 0.60)))
  const minEdge = Math.max(0, Math.min(0.25, Number(process.env.MIN_LIVE_MODEL_EDGE || 0)))
  const evaluated = evaluateModelDirections(samples, model, { thresholds })
    .map(row => {
      const accuracy = Number(row.accuracy)
      const edge = Number.isFinite(accuracy) && Number.isFinite(Number(baselineAccuracy))
        ? accuracy - Number(baselineAccuracy)
        : Number.isFinite(accuracy) ? accuracy - 0.5 : -1
      const accuracyShortfall = Number.isFinite(accuracy) ? Math.max(0, minAccuracy - accuracy) : 1
      const edgeShortfall = Number.isFinite(edge) ? Math.max(0, minEdge - edge) : minEdge
      const coverageBonus = Math.min(0.04, row.coverage * 0.08)
      const samplePenalty = row.actionable_samples < minActionable
        ? (minActionable - row.actionable_samples) / minActionable * 0.15
        : 0
      const returnBonus = Math.min(0.04, Number(row.avg_abs_return || 0) / 20)
      return {
        threshold: row.threshold,
        actionable_samples: row.actionable_samples,
        accuracy: row.accuracy == null ? null : Number(row.accuracy.toFixed(3)),
        coverage: Number(row.coverage.toFixed(3)),
        avg_abs_return: Number(row.avg_abs_return.toFixed(3)),
        edge: Number(edge.toFixed(3)),
        meets_accuracy_floor: Boolean(Number.isFinite(accuracy) && accuracy >= minAccuracy),
        meets_edge_floor: Boolean(Number.isFinite(edge) && edge >= minEdge),
        objective: Number((
          (Number.isFinite(accuracy) ? accuracy : 0) * 1.35 +
          (Number.isFinite(edge) ? edge : -0.2) * 0.45 +
          coverageBonus +
          returnBonus -
          accuracyShortfall * 1.20 -
          edgeShortfall * 0.45 -
          samplePenalty
        ).toFixed(5)),
      }
    })
  const validated = evaluated.filter(row =>
    row.actionable_samples >= minActionable &&
    row.accuracy != null &&
    row.meets_accuracy_floor &&
    row.meets_edge_floor
  )
  const highPrecisionFallback = evaluated.filter(row =>
    row.actionable_samples >= Math.max(20, Math.floor(minActionable * 0.6)) &&
    row.accuracy != null &&
    row.meets_accuracy_floor &&
    row.meets_edge_floor
  )
  const bestSupportedFallback = evaluated.filter(row => row.actionable_samples >= minActionable && row.accuracy != null)
  const candidates = validated.length ? validated : highPrecisionFallback.length ? highPrecisionFallback : bestSupportedFallback.length ? bestSupportedFallback : evaluated
  const best = candidates
    .filter(row => row.accuracy != null)
    .sort((a, b) => Number(b.objective || 0) - Number(a.objective || 0))[0]
  if (!best) return null
  return {
    selected_threshold: best.threshold,
    min_actionable_samples: minActionable,
    required_accuracy: minAccuracy,
    required_edge: minEdge,
    selected_status: validated.includes(best)
      ? "validated"
      : highPrecisionFallback.includes(best)
        ? "high_precision_low_sample"
        : "best_available_shadow",
    selected: best,
    candidates: evaluated,
  }
}

function modelValidationState(model = null) {
  if (model?.status !== "trained") {
    return {
      status: model?.status || "missing",
      allow_live_classifier: false,
      edge: null,
      reason: "model_not_trained",
    }
  }
  if (!model.metrics) {
    return {
      status: "training_evaluation",
      allow_live_classifier: true,
      edge: null,
      reason: "temporary_model_without_persisted_metrics",
    }
  }
  const metrics = model?.metrics || {}
  const actionable = Number(metrics.actionable_samples || 0)
  const accuracy = Number(metrics.directional_accuracy_5m)
  const baselineAccuracy = Number(metrics.baseline_directional_accuracy_5m)
  const minSamples = Number(process.env.MIN_LIVE_MODEL_VALIDATION_SAMPLES || 50)
  const minEdge = Number(process.env.MIN_LIVE_MODEL_EDGE || 0)
  const minAccuracy = Number(process.env.MIN_LIVE_MODEL_ACCURACY || 0.60)
  const edge = Number.isFinite(accuracy) && Number.isFinite(baselineAccuracy)
    ? Number((accuracy - baselineAccuracy).toFixed(3))
    : null
  if (model?.direction_classifier?.type === "knn_centroid_direction_v1" && process.env.ALLOW_KNN_LIVE_MODEL !== "1") {
    return {
      status: "shadow_knn_disabled",
      allow_live_classifier: false,
      edge,
      reason: "knn_live_use_disabled",
    }
  }
  if (actionable < minSamples) {
    return {
      status: "shadow_insufficient_validation",
      allow_live_classifier: false,
      edge,
      reason: `needs_at_least_${minSamples}_actionable_holdout_samples`,
    }
  }
  if (!Number.isFinite(accuracy)) {
    return {
      status: "shadow_no_validation_accuracy",
      allow_live_classifier: false,
      edge,
      reason: "missing_validation_accuracy",
    }
  }
  if (accuracy < minAccuracy) {
    return {
      status: "shadow_below_required_accuracy",
      allow_live_classifier: false,
      edge,
      reason: `model_accuracy_${accuracy.toFixed(3)}_below_required_${minAccuracy.toFixed(3)}`,
    }
  }
  if (Number.isFinite(baselineAccuracy) && accuracy < baselineAccuracy + minEdge) {
    return {
      status: "shadow_under_baseline",
      allow_live_classifier: false,
      edge,
      reason: `model_accuracy_${accuracy.toFixed(3)}_below_required_baseline_${(baselineAccuracy + minEdge).toFixed(3)}`,
    }
  }
  return {
    status: "live_validated_edge",
    allow_live_classifier: true,
    edge,
    reason: "model_beats_recent_baseline",
  }
}

function isLiveModelSignalEligible(signal = null, model = null) {
  if (!signal || model?.status !== "trained") return false
  if (Number(signal.confidence || 0) < MIN_LIVE_MODEL_CONFIDENCE) return false
  return modelValidationState(model).allow_live_classifier
}

async function loadLatestPredictionModel(db) {
  return db.collection("prediction_models").findOne({ _id: PREDICTION_MODEL_ID })
}

async function loadLatestNextSessionPredictionModel(db) {
  return db.collection("next_session_prediction_models").findOne({ _id: "next_session_outcome_calibrator_v1" })
}

function publicPredictionModel(model = null) {
  if (!model) return null
  const validation = modelValidationState(model)
  const classifier = model.direction_classifier
    ? model.direction_classifier.type === "regularized_logistic_direction_v2"
      ? {
        type: model.direction_classifier.type,
        min_move_pct: model.direction_classifier.min_move_pct,
        action_threshold: model.direction_classifier.action_threshold,
        class_counts: model.direction_classifier.class_counts,
        top_features: model.direction_classifier.top_features || [],
      }
      : {
        type: model.direction_classifier.type,
        min_move_pct: model.direction_classifier.min_move_pct,
        k: model.direction_classifier.k,
        class_counts: model.direction_classifier.class_counts,
        prototype_counts: {
          up: Number(model.direction_classifier.prototypes?.up?.length || 0),
          down: Number(model.direction_classifier.prototypes?.down?.length || 0),
        },
      }
    : null
  return {
    _id: model._id,
    model_id: model.model_id,
    status: model.status,
    algorithm: model.algorithm || null,
    version: model.version || null,
    samples: model.samples || 0,
    min_samples: model.min_samples,
    feature_keys: model.feature_keys || PREDICTION_FEATURE_KEYS,
    metrics: model.metrics || null,
    validation_status: validation.status,
    validation_edge: validation.edge,
    live_classifier_enabled: validation.allow_live_classifier,
    live_classifier_reason: validation.reason,
    direction_classifier: classifier,
    updated_at: model.updated_at || null,
    note: model.note || null,
  }
}

function publicNextSessionPredictionModel(model = null) {
  if (!model) return null
  return {
    _id: model._id,
    model_id: model.model_id,
    status: model.status,
    algorithm: model.algorithm || null,
    samples: Number(model.samples || 0),
    min_samples: Number(model.min_samples || 0),
    training_samples: Number(model.training_samples || 0),
    holdout_samples: Number(model.holdout_samples || 0),
    target: model.target || "close",
    selected_threshold: model.selected_threshold ?? null,
    live_enabled: Boolean(model.live_enabled),
    required_accuracy: model.required_accuracy ?? null,
    required_holdout: model.required_holdout ?? null,
    validation_status: model.validation_status || model.status || "missing",
    validation_reason: model.validation_reason || model.reason || null,
    metrics: model.metrics || null,
    feature_keys: model.feature_keys || [],
    top_features: model.top_features || [],
    updated_at: model.updated_at || null,
    note: model.note || null,
  }
}

async function loadScreenerRowsForTickers(db, tickers = []) {
  const wanted = normalizeTickerList(tickers, 1000, { ensurePrivate: false })
  if (!wanted.length) return []
  const rows = await db.collection("screeners").find(
    {
      ticker: { $in: wanted },
      exchange: { $in: Array.from(US_EXCHANGES) },
      price: { $gt: 0 },
    }
  ).toArray()
  return rows
    .map(row => ({
      ...row,
      ticker: String(row.ticker || "").toUpperCase(),
      change_pct: Number(row.change_pct ?? row.change_percent ?? 0),
      rel_volume: Number(row.rel_volume ?? row.relative_volume ?? 0),
      price: Number(row.price || 0),
      volume: Number(row.volume || 0),
    }))
    .filter(row => row.ticker && !row.ticker.includes(".") && Number(row.price || 0) > 0 && Math.abs(Number(row.change_pct || 0)) <= MAX_SIGNAL_CHANGE_PCT)
}

async function loadPredictionCandidateRows(db, { limit = 10, tickers = [], days = 3 } = {}) {
  const explicit = normalizeTickerList(tickers, 1000, { ensurePrivate: false })
  if (explicit.length) return loadScreenerRowsForTickers(db, explicit)
  return loadDiversifiedPredictionCandidateRows(db, {
    limit: Math.max(1, Math.min(5000, Number(limit || 10))),
    days,
  })
}

async function loadEnrichedTradeWatchRows(db, { limit = 10, days = 2, socialWindow = 60, tickers = [], predictionContext = null } = {}) {
  const requestedLimit = Math.max(1, Math.min(5000, Number(limit || 10)))
  const explicit = normalizeTickerList(tickers, 1000, { ensurePrivate: false })
  const movers = await loadPredictionCandidateRows(db, {
    limit: explicit.length ? Math.max(requestedLimit, explicit.length) : Math.max(requestedLimit * 4, 100),
    tickers: explicit,
    days,
  })
  const moverTickers = movers.map(row => row.ticker)
  const [articleMap, socialMap, aiMap, momentumMap, correlationMap] = await Promise.all([
    loadArticleStatsForTickers(db, moverTickers, days, { predictionContext }),
    loadSocialStatsForTickers(db, moverTickers, socialWindow),
    loadPredictionAiEvidenceForTickers(db, moverTickers, days),
    loadPredictionMomentumContextForTickers(db, moverTickers),
    loadPredictionCorrelationContextForTickers(db, moverTickers),
  ])
  return movers
    .map(row => {
      const ticker = row.ticker
      const ai = aiMap.get(ticker) || null
      const momentum = momentumMap.get(ticker) || null
      const correlation = correlationMap.get(ticker) || null
      return addTradeWatchFields({
        ...mergeMoverContext(row, articleMap.get(ticker), socialMap.get(ticker)),
        ai_score: ai?.ai_score ?? null,
        ai_sentiment_score: ai?.ai_sentiment_score ?? 0,
        ai_confidence: ai?.ai_confidence ?? 0,
        ai_article_count: ai?.ai_article_count ?? 0,
        ai_bullish_articles: ai?.ai_bullish_articles ?? 0,
        ai_bearish_articles: ai?.ai_bearish_articles ?? 0,
        ai_source_count: ai?.ai_source_count ?? 0,
        ai_latest_publish: ai?.ai_latest_publish || null,
        momentum_context_score: momentum?.momentum_context_score ?? null,
        momentum_rank_trend: momentum?.momentum_rank_trend ?? 0,
        momentum_snapshot_count: momentum?.momentum_snapshot_count ?? 0,
        momentum_context: momentum || null,
        correlation_score: correlation?.correlation_score ?? row.correlation_score ?? null,
        correlation_context: correlation || null,
      })
    })
    .sort((a, b) => {
      const scoreDiff = Number(b.trade_watch?.trade_watch_score || 0) - Number(a.trade_watch?.trade_watch_score || 0)
      if (scoreDiff !== 0) return scoreDiff
      const evidenceDiff = Number(b.trade_watch?.evidence_score || 0) - Number(a.trade_watch?.evidence_score || 0)
      if (evidenceDiff !== 0) return evidenceDiff
      return Number(b.change_pct || 0) - Number(a.change_pct || 0)
    })
    .slice(0, explicit.length ? Math.max(requestedLimit, explicit.length) : requestedLimit)
}

function alertSeverityRank(value) {
  return { critical: 4, warning: 3, info: 2, watch: 1 }[String(value || "").toLowerCase()] || 0
}

async function buildMomentumAlerts(db, { limit = 20, socialWindow = 1440 } = {}) {
  const requestedLimit = Math.max(1, Math.min(100, Number(limit || 20)))
  const now = new Date()
  const [finvizStatus, tradeRows, latestSnapshot] = await Promise.all([
    loadFinvizMomentumStatus(db),
    loadEnrichedTradeWatchRows(db, { limit: Math.max(requestedLimit, 20), days: 2, socialWindow }),
    db.collection("finviz_momentum_snapshots").findOne({}, { sort: { snapshot_sec: -1 } }).catch(() => null),
  ])
  const alerts = []
  const finvizState = String(finvizStatus.status || "unknown").toLowerCase()
  const quoteAge = Number(finvizStatus.quote_age_seconds)

  if (!["working", "working_public"].includes(finvizState)) {
    alerts.push({
      id: `finviz-status:${finvizState}`,
      scope: "momentum",
      type: "source",
      severity: "critical",
      title: "Finviz Elite needs attention",
      detail: finvizStatus.detail || `Status is ${finvizStatus.status || "unknown"}. Refresh may be using stored movers.`,
      created_at: now,
      source: "Finviz Elite Screener",
    })
  } else if (Number.isFinite(quoteAge) && quoteAge > 30 * 60) {
    alerts.push({
      id: "finviz-stale",
      scope: "momentum",
      type: "freshness",
      severity: "warning",
      title: "Finviz movers are stale",
      detail: `Latest Finviz quote is ${Math.floor(quoteAge / 60)} minutes old.`,
      created_at: now,
      source: "Finviz Elite Screener",
    })
  }

  if (!latestSnapshot) {
    alerts.push({
      id: "finviz-no-snapshot",
      scope: "momentum",
      type: "snapshot",
      severity: "info",
      title: "No Finviz snapshot saved yet",
      detail: "Run a refresh cycle to start storing minute-bucket top mover history.",
      created_at: now,
      source: "Finviz Elite Screener",
    })
  }

  for (const row of tradeRows) {
    const ticker = row.ticker
    const watch = row.trade_watch || {}
    const score = Number(watch.trade_watch_score || 0)
    const changePct = Number(row.change_pct || 0)
    const relVolume = Number(row.rel_volume || 0)
    const supportCount = Number(watch.support_count ?? (Number(row.article_count || 0) + Number(row.message_count || 0)))
    const socialCount = Number(row.message_count || 0)
    const socialSentiment = Number(row.social_sentiment || 0)
    const floatShort = Number(row.float_short || 0)

    if (score >= 0.8) {
      alerts.push({
        id: `high-watch:${ticker}`,
        scope: "momentum",
        type: "trade_watch",
        severity: "watch",
        ticker,
        title: `${ticker} high watch`,
        detail: `${watch.confidence || Math.round(score * 100)} score; ${changePct.toFixed(2)}% move; ${supportCount} evidence items.`,
        created_at: now,
        score,
        reasons: watch.reasons || [],
        risks: watch.risks || [],
      })
    }

    if (changePct >= 25 && supportCount === 0) {
      alerts.push({
        id: `unsupported-spike:${ticker}`,
        scope: "momentum",
        type: "unsupported_spike",
        severity: "warning",
        ticker,
        title: `${ticker} unsupported spike`,
        detail: `${changePct.toFixed(2)}% move with no matched news/social evidence yet.`,
        created_at: now,
        score,
      })
    }

    if (socialCount >= 100 && Math.abs(socialSentiment) >= 0.15) {
      alerts.push({
        id: `social-density:${ticker}`,
        scope: "momentum",
        type: "social_density",
        severity: socialSentiment > 0 ? "watch" : "warning",
        ticker,
        title: `${ticker} social density spike`,
        detail: `${socialCount} posts in the selected window; sentiment ${socialSentiment >= 0 ? "+" : ""}${socialSentiment.toFixed(2)}.`,
        created_at: now,
        score,
      })
    }

    if (floatShort >= 10 && relVolume >= 5 && changePct >= 10) {
      alerts.push({
        id: `short-squeeze:${ticker}`,
        scope: "momentum",
        type: "short_squeeze",
        severity: "warning",
        ticker,
        title: `${ticker} short squeeze watch`,
        detail: `${floatShort.toFixed(1)}% float short, ${relVolume.toFixed(1)}x relative volume, ${changePct.toFixed(2)}% move.`,
        created_at: now,
        score,
      })
    }
  }

  return alerts
    .sort((a, b) => alertSeverityRank(b.severity) - alertSeverityRank(a.severity) || Number(b.score || 0) - Number(a.score || 0))
    .slice(0, requestedLimit)
}

async function captureTradeWatchPredictionSignals(db, { limit = 10, days = 2, socialWindow = 60, tickers = [] } = {}) {
  const nowSec = Math.floor(Date.now() / 1000)
  const minuteBucket = Math.floor(nowSec / 60) * 60
  const explicitTickers = normalizeTickerList(tickers, 1000, { ensurePrivate: false })
  const predictionContext = marketPredictionContext(new Date(minuteBucket * 1000))
  const [rows, model] = await Promise.all([
    loadEnrichedTradeWatchRows(db, { limit, days, socialWindow, tickers: explicitTickers, predictionContext }),
    loadLatestPredictionModel(db),
  ])
  const docs = rows
    .filter(row => Number(row.price || 0) > 0)
    .map((row, index) => {
      const signalId = `${row.ticker}:${minuteBucket}`
      const features = predictionFeaturesFromMover(row, socialWindow, { predictionContext })
      const baseline = baselinePredictionFromMover(row)
      const intradayModelSignal = applyPredictionModel(features, model)
      const nextDaySignal = nextDayPredictionFromMover(row, features, {
        intradaySignal: intradayModelSignal,
        trainedModel: model,
      })
      return {
        _id: signalId,
        signal_id: signalId,
        ticker: row.ticker,
        company: row.company || "",
        exchange: row.exchange || "",
        sector: row.sector || "",
        source: "trade_watch",
        discovery_source: row.discovery_source || null,
        discovery_sources: row.discovery_sources || [],
        candidate_priority: row.candidate_priority ?? null,
        candidate_reasons: row.candidate_reasons || [],
        signal_sec: minuteBucket,
        signal_at: new Date(minuteBucket * 1000),
        prediction_session_context: predictionContext,
        prediction_session: predictionContext.session,
        prediction_target: predictionContext.target,
        evidence_window_start_sec: predictionContext.evidence_window_start_sec,
        evidence_window_end_sec: predictionContext.evidence_window_end_sec,
        entry_price: Number(row.price || 0),
        entry_quote_source: row.quote_source || null,
        entry_quote_updated_at: row.quote_updated_at || null,
        rank: index + 1,
        decision: row.trade_watch?.decision || "Monitor",
        trade_watch: row.trade_watch || {},
        features,
        baseline_signal: baseline,
        model_signal: nextDaySignal,
        intraday_model_signal: intradayModelSignal,
        labels: {},
        label_status: "pending",
        horizons_minutes: PREDICTION_HORIZONS_MINUTES,
        prediction_horizons: ["1d", "5m", "15m", "60m"],
        created_at: new Date(),
        updated_at: new Date(),
      }
    })

  if (!docs.length) return { saved: 0, rows: [], prediction_session_context: predictionContext }
  const result = await db.collection("prediction_signals").bulkWrite(
    docs.map(doc => ({
      updateOne: {
        filter: { _id: doc._id },
        update: {
          $setOnInsert: {
            _id: doc._id,
            signal_id: doc.signal_id,
            ticker: doc.ticker,
            source: doc.source,
            signal_sec: doc.signal_sec,
            signal_at: doc.signal_at,
            labels: doc.labels,
            label_status: doc.label_status,
            horizons_minutes: doc.horizons_minutes,
            created_at: doc.created_at,
          },
          $set: {
            last_seen_at: new Date(),
            last_rank: doc.rank,
            company: doc.company,
            exchange: doc.exchange,
            sector: doc.sector,
            discovery_source: doc.discovery_source,
            discovery_sources: doc.discovery_sources,
            candidate_priority: doc.candidate_priority,
            candidate_reasons: doc.candidate_reasons,
            prediction_session_context: doc.prediction_session_context,
            prediction_session: doc.prediction_session,
            prediction_target: doc.prediction_target,
            evidence_window_start_sec: doc.evidence_window_start_sec,
            evidence_window_end_sec: doc.evidence_window_end_sec,
            entry_price: doc.entry_price,
            entry_quote_source: doc.entry_quote_source,
            entry_quote_updated_at: doc.entry_quote_updated_at,
            rank: doc.rank,
            decision: doc.decision,
            trade_watch: doc.trade_watch,
            features: doc.features,
            baseline_signal: doc.baseline_signal,
            model_signal: doc.model_signal,
            intraday_model_signal: doc.intraday_model_signal,
            prediction_horizons: doc.prediction_horizons,
            updated_at: new Date(),
          },
        },
        upsert: true,
      },
    })),
    { ordered: false }
  )
  return { saved: Number(result.upsertedCount || 0), rows: docs, prediction_session_context: predictionContext }
}

const PREDICTION_LABEL_SOURCE = "chart_1m_v2"

function candleAtOrAfterWithin(candles = [], targetSec, maxDelaySec = 600) {
  if (!Array.isArray(candles) || !candles.length || !Number.isFinite(Number(targetSec))) return null
  const target = Number(targetSec)
  for (const candle of candles) {
    const time = Number(candle.time || 0)
    if (time >= target) {
      if (time - target <= maxDelaySec) return candle
      return null
    }
  }
  return null
}

function chartReturnLabel(candles = [], signalSec, horizonMinutes) {
  const horizonSec = Number(horizonMinutes || 0) * 60
  const entry = candleAtOrAfterWithin(candles, Number(signalSec), 10 * 60)
  if (!entry) return { ok: false, reason: "no_entry_candle_near_signal" }
  const futureMaxDelay = Number(horizonMinutes || 0) >= 60 ? 30 * 60 : 10 * 60
  const future = candleAtOrAfterWithin(candles, Number(signalSec) + horizonSec, futureMaxDelay)
  if (!future) return { ok: false, reason: "no_future_candle_near_horizon", entry }
  const entryClose = Number(entry.close || 0)
  const futureClose = Number(future.close || 0)
  if (!entryClose || !futureClose) return { ok: false, reason: "missing_candle_close", entry, future }
  return {
    ok: true,
    entry,
    future,
    returnPct: ((futureClose - entryClose) / entryClose) * 100,
  }
}

async function labelMaturePredictionSignals(db, { limit = 500 } = {}) {
  const nowSec = Math.floor(Date.now() / 1000)
  const oldestDueSec = nowSec - Math.min(...PREDICTION_HORIZONS_MINUTES) * 60
  const docs = await db.collection("prediction_signals").find({
    signal_sec: { $lte: oldestDueSec },
    entry_price: { $gt: 0 },
    $or: PREDICTION_HORIZONS_MINUTES.map(horizon => ({
      signal_sec: { $lte: nowSec - horizon * 60 },
      [`labels.return_${horizon}m.checked_source`]: { $ne: PREDICTION_LABEL_SOURCE },
    })),
  }).sort({ signal_sec: -1 }).limit(Math.max(1, Math.min(2000, Number(limit || 500)))).toArray()
  if (!docs.length) return { checked: 0, labeled: 0 }

  const tickers = Array.from(new Set(docs.map(doc => String(doc.ticker || "").toUpperCase()).filter(Boolean)))
  const candleEntries = await Promise.all(tickers.map(async ticker => {
    try {
      const result = await fetchYahooCandles(ticker, "5d", "1m", { raw: true })
      return [ticker, result.candles || []]
    } catch (err) {
      return [ticker, []]
    }
  }))
  const candleMap = new Map(candleEntries)
  const updates = []
  let labeled = 0

  for (const doc of docs) {
    const ticker = String(doc.ticker || "").toUpperCase()
    const candles = candleMap.get(ticker) || []
    const entryPrice = Number(doc.entry_price || 0)
    if (!entryPrice) continue

    const setFields = { updated_at: new Date() }
    let wroteLabel = false
    let wroteUnavailable = false
    for (const horizon of PREDICTION_HORIZONS_MINUTES) {
      const key = `return_${horizon}m`
      if (doc.labels?.[key]?.checked_source === PREDICTION_LABEL_SOURCE) continue
      const due = nowSec - Number(doc.signal_sec || 0) >= horizon * 60
      if (!due) continue

      const label = chartReturnLabel(candles, Number(doc.signal_sec || 0), horizon)
      if (!label.ok) {
        setFields[`labels.${key}.labeled`] = false
        setFields[`labels.${key}.checked_source`] = PREDICTION_LABEL_SOURCE
        setFields[`labels.${key}.unavailable`] = true
        setFields[`labels.${key}.unavailable_reason`] = label.reason
        setFields[`labels.${key}.horizon_minutes`] = horizon
        setFields[`labels.${key}.checked_at`] = new Date()
        setFields[`labels.${key}.checked_sec`] = nowSec
        if (label.entry?.time) {
          setFields[`labels.${key}.entry_candle_sec`] = Number(label.entry.time)
          setFields[`labels.${key}.entry_candle_close`] = Number(Number(label.entry.close || 0).toFixed(4))
        }
        wroteUnavailable = true
        continue
      }

      const returnPct = label.returnPct
      const direction = doc.baseline_signal?.direction || "watch"
      setFields[`labels.${key}`] = {
        labeled: true,
        checked_source: PREDICTION_LABEL_SOURCE,
        label_source: "chart_1m",
        horizon_minutes: horizon,
        return_pct: Number(returnPct.toFixed(3)),
        entry_price: Number(Number(label.entry.close || entryPrice).toFixed(4)),
        original_entry_price: Number(entryPrice.toFixed(4)),
        label_price: Number(Number(label.future.close || 0).toFixed(4)),
        entry_candle_sec: Number(label.entry.time),
        label_candle_sec: Number(label.future.time),
        labeled_at: new Date(),
        label_sec: nowSec,
        label_delay_seconds: nowSec - Number(doc.signal_sec || 0) - horizon * 60,
        quote_source: "chart_1m",
        direction_correct: direction === "up" ? returnPct > 0 : direction === "down" ? returnPct < 0 : null,
      }
      labeled += 1
      wroteLabel = true
    }

    if (Object.keys(setFields).length > 1) {
      const mergedLabels = { ...(doc.labels || {}) }
      for (const horizon of PREDICTION_HORIZONS_MINUTES) {
        const key = `return_${horizon}m`
        if (setFields[`labels.${key}`]) mergedLabels[key] = setFields[`labels.${key}`]
        else if (setFields[`labels.${key}.checked_source`]) {
          mergedLabels[key] = {
            ...(mergedLabels[key] || {}),
            checked_source: PREDICTION_LABEL_SOURCE,
            labeled: false,
            unavailable: true,
          }
        }
      }
      const allChecked = PREDICTION_HORIZONS_MINUTES.every(h => mergedLabels[`return_${h}m`]?.checked_source === PREDICTION_LABEL_SOURCE)
      const allLabeled = PREDICTION_HORIZONS_MINUTES.every(h => mergedLabels[`return_${h}m`]?.labeled === true)
      setFields.label_status = wroteLabel ? "partially_labeled" : wroteUnavailable ? "label_unavailable" : (doc.label_status || "pending")
      if (allLabeled) {
        setFields.label_status = "complete"
      } else if (allChecked && !wroteLabel) {
        setFields.label_status = "label_unavailable"
      }
      updates.push({ updateOne: { filter: { _id: doc._id }, update: { $set: setFields } } })
    }
  }

  if (updates.length) await db.collection("prediction_signals").bulkWrite(updates, { ordered: false })
  return { checked: docs.length, labeled }
}

function fitPredictionModelParts(samples = []) {
  const targetMean = samples.reduce((sum, row) => sum + row.target, 0) / Math.max(1, samples.length)
  const targetVar = samples.reduce((sum, row) => sum + (row.target - targetMean) ** 2, 0) / Math.max(1, samples.length - 1)
  const targetStd = Math.sqrt(targetVar) || 1
  const featureStats = {}
  const weights = {}

  for (const key of PREDICTION_FEATURE_KEYS) {
    const vals = samples.map(row => Number(row.features?.[key])).map(value => Number.isFinite(value) ? value : 0)
    const mean = vals.reduce((sum, value) => sum + value, 0) / Math.max(1, vals.length)
    const variance = vals.reduce((sum, value) => sum + (value - mean) ** 2, 0) / Math.max(1, vals.length - 1)
    const std = Math.sqrt(variance) || 1
    const covariance = vals.reduce((sum, value, index) => sum + ((value - mean) / std) * (samples[index].target - targetMean), 0) / Math.max(1, vals.length - 1)
    const weight = clamp(covariance / targetStd, -0.8, 0.8)
    featureStats[key] = { mean: Number(mean.toFixed(5)), std: Number(std.toFixed(5)) }
    weights[key] = Number((weight * 0.35).toFixed(5))
  }

  return {
    targetMean,
    targetStd,
    featureStats,
    weights,
    directionClassifier: buildDirectionalClassifier(samples, featureStats, PREDICTION_FEATURE_KEYS),
  }
}

async function trainPredictionModel(db, { limit = 5000, minSamples = 20 } = {}) {
  const docs = await db.collection("prediction_signals").find({
    "labels.return_5m.labeled": true,
    "labels.return_5m.label_source": "chart_1m",
    "labels.return_5m.return_pct": { $type: "number" },
    features: { $exists: true },
  }).sort({ signal_sec: -1 }).limit(Math.max(50, Math.min(10000, Number(limit || 2000)))).toArray()

  const samples = docs
    .map(doc => ({
      target: Number(doc.labels?.return_5m?.return_pct),
      features: doc.features || {},
      baseline_direction: doc.baseline_signal?.direction || "watch",
    }))
    .filter(row => Number.isFinite(row.target))

  if (samples.length < minSamples) {
    const model = {
      _id: PREDICTION_MODEL_ID,
      model_id: PREDICTION_MODEL_ID,
      status: "insufficient_samples",
      samples: samples.length,
      min_samples: minSamples,
      feature_keys: PREDICTION_FEATURE_KEYS,
      updated_at: new Date(),
      note: "Collect more labeled prediction_signals before training the statistical model.",
    }
    await db.collection("prediction_models").updateOne({ _id: PREDICTION_MODEL_ID }, { $set: model }, { upsert: true })
    return model
  }

  const targetMean = samples.reduce((sum, row) => sum + row.target, 0) / samples.length
  const targetVar = samples.reduce((sum, row) => sum + (row.target - targetMean) ** 2, 0) / Math.max(1, samples.length - 1)
  const targetStd = Math.sqrt(targetVar) || 1
  const nonZeroTargets = samples.filter(row => Math.abs(Number(row.target || 0)) >= 0.01).length
  if (nonZeroTargets < Math.min(minSamples, 20) || targetStd < 0.005) {
    const model = {
      _id: PREDICTION_MODEL_ID,
      model_id: PREDICTION_MODEL_ID,
      status: "flat_labels",
      samples: samples.length,
      nonzero_samples: nonZeroTargets,
      min_samples: minSamples,
      feature_keys: PREDICTION_FEATURE_KEYS,
      metrics: {
        mae_5m: 0,
        directional_accuracy_5m: null,
        actionable_samples: 0,
        avg_target_return_5m: Number(targetMean.toFixed(3)),
      },
      updated_at: new Date(),
      note: "Recent labeled 5m returns are flat/zero, so model weights are intentionally disabled until labels contain measurable movement.",
    }
    await db.collection("prediction_models").updateOne({ _id: PREDICTION_MODEL_ID }, { $set: model }, { upsert: true })
    return model
  }

  const holdoutSize = samples.length >= 250 ? Math.max(50, Math.min(500, Math.floor(samples.length * 0.2))) : 0
  const holdoutSamples = holdoutSize ? samples.slice(0, holdoutSize) : samples
  const trainingSamples = holdoutSize ? samples.slice(holdoutSize) : samples
  const validationFit = fitPredictionModelParts(trainingSamples.length >= minSamples ? trainingSamples : samples)
  const finalFit = fitPredictionModelParts(samples)
  const validationModel = {
    model_id: PREDICTION_MODEL_ID,
    status: "trained",
    version: Date.now(),
    intercept: validationFit.targetMean,
    target_std: validationFit.targetStd,
    weights: validationFit.weights,
    feature_stats: validationFit.featureStats,
    feature_keys: PREDICTION_FEATURE_KEYS,
    direction_classifier: validationFit.directionClassifier,
    samples: trainingSamples.length,
  }

  const baselineHoldout = holdoutSamples.map(row => {
    const direction = row.baseline_direction || "watch"
    const correct = direction === "up" ? row.target > 0 : direction === "down" ? row.target < 0 : null
    return { direction, correct }
  })
  const baselineActionablePreview = baselineHoldout.filter(row => row.correct != null)
  const baselineAccuracyPreview = baselineActionablePreview.length
    ? baselineActionablePreview.reduce((sum, row) => sum + (row.correct ? 1 : 0), 0) / baselineActionablePreview.length
    : null
  const thresholdOptimization = optimizeLogisticActionThreshold(holdoutSamples, validationModel, baselineAccuracyPreview)
  if (thresholdOptimization?.selected_threshold && validationModel.direction_classifier?.type === "regularized_logistic_direction_v2") {
    validationModel.direction_classifier.action_threshold = thresholdOptimization.selected_threshold
    if (finalFit.directionClassifier?.type === "regularized_logistic_direction_v2") {
      finalFit.directionClassifier.action_threshold = thresholdOptimization.selected_threshold
      finalFit.directionClassifier.threshold_optimization = {
        selected: thresholdOptimization.selected,
        min_actionable_samples: thresholdOptimization.min_actionable_samples,
        required_accuracy: thresholdOptimization.required_accuracy,
        required_edge: thresholdOptimization.required_edge,
        selected_status: thresholdOptimization.selected_status,
      }
    }
  }

  const predictions = holdoutSamples.map(row => {
    const signal = applyPredictionModel(row.features, {
      ...validationModel,
    })
    const predicted = Number(signal?.predicted_return_5m || 0)
    const predictedDirection = signal?.direction || (predicted > 0 ? "up" : predicted < 0 ? "down" : "watch")
    return {
      target: row.target,
      predicted,
      confidence: Number(signal?.confidence || 0),
      correct: predictedDirection !== "watch"
        ? (predictedDirection === "up" ? row.target > 0 : row.target < 0)
        : null,
      baseline_correct: row.baseline_direction === "up" ? row.target > 0 : row.baseline_direction === "down" ? row.target < 0 : null,
    }
  })
  const actionable = predictions.filter(row => row.correct != null)
  const baselineActionable = predictions.filter(row => row.baseline_correct != null)
  const mae = predictions.reduce((sum, row) => sum + Math.abs(row.predicted - row.target), 0) / predictions.length
  const directionalAccuracy = actionable.length
    ? actionable.reduce((sum, row) => sum + (row.correct ? 1 : 0), 0) / actionable.length
    : null
  const baselineDirectionalAccuracy = baselineActionable.length
    ? baselineActionable.reduce((sum, row) => sum + (row.baseline_correct ? 1 : 0), 0) / baselineActionable.length
    : null
  const linearOnlyEval = evaluateModelDirections(holdoutSamples, {
    ...validationModel,
    direction_classifier: null,
  }, { thresholds: [null] })[0]

  const model = {
    _id: PREDICTION_MODEL_ID,
    model_id: PREDICTION_MODEL_ID,
    status: "trained",
    version: Date.now(),
    samples: samples.length,
    feature_keys: PREDICTION_FEATURE_KEYS,
    feature_stats: finalFit.featureStats,
    weights: finalFit.weights,
    direction_classifier: finalFit.directionClassifier,
    algorithm: finalFit.directionClassifier ? `${finalFit.directionClassifier.type}+linear_return_v1` : "linear_return_v1",
    intercept: Number(finalFit.targetMean.toFixed(5)),
    target_std: Number(finalFit.targetStd.toFixed(5)),
    metrics: {
      mae_5m: Number(mae.toFixed(3)),
      directional_accuracy_5m: directionalAccuracy == null ? null : Number(directionalAccuracy.toFixed(3)),
      actionable_samples: actionable.length,
      validation_rows: predictions.length,
      validation_mode: holdoutSize ? "recent_holdout" : "in_sample_small_set",
      classifier_type: finalFit.directionClassifier?.type || null,
      action_threshold: finalFit.directionClassifier?.action_threshold ?? null,
      classifier_up_samples: Number(finalFit.directionClassifier?.class_counts?.up || 0),
      classifier_down_samples: Number(finalFit.directionClassifier?.class_counts?.down || 0),
      baseline_directional_accuracy_5m: baselineDirectionalAccuracy == null ? null : Number(baselineDirectionalAccuracy.toFixed(3)),
      baseline_actionable_samples: baselineActionable.length,
      avg_target_return_5m: Number(targetMean.toFixed(3)),
      live_edge_vs_baseline: directionalAccuracy != null && baselineDirectionalAccuracy != null
        ? Number((directionalAccuracy - baselineDirectionalAccuracy).toFixed(3))
        : null,
      model_comparison: {
        baseline: {
          accuracy: baselineDirectionalAccuracy == null ? null : Number(baselineDirectionalAccuracy.toFixed(3)),
          actionable_samples: baselineActionable.length,
        },
        linear_return: {
          accuracy: linearOnlyEval?.accuracy == null ? null : Number(linearOnlyEval.accuracy.toFixed(3)),
          actionable_samples: Number(linearOnlyEval?.actionable_samples || 0),
        },
        regularized_logistic: {
          accuracy: directionalAccuracy == null ? null : Number(directionalAccuracy.toFixed(3)),
          actionable_samples: actionable.length,
          action_threshold: finalFit.directionClassifier?.action_threshold ?? null,
        },
      },
      threshold_optimization: thresholdOptimization
        ? {
          selected: thresholdOptimization.selected,
          selected_status: thresholdOptimization.selected_status,
          required_accuracy: thresholdOptimization.required_accuracy,
          required_edge: thresholdOptimization.required_edge,
          candidates: thresholdOptimization.candidates,
        }
        : null,
    },
    updated_at: new Date(),
    note: finalFit.directionClassifier
      ? `${finalFit.directionClassifier.type} trained on chart-backed 5m labels and validated against a recent holdout window.`
      : "Linear return model trained on chart-backed 5m labels; classifier disabled until enough up/down samples are available.",
  }
  await db.collection("prediction_models").updateOne({ _id: PREDICTION_MODEL_ID }, { $set: model }, { upsert: true })
  return model
}

async function loadTopMomentumTickerSymbols(db, limit = 10) {
  const requestedLimit = Math.max(1, Math.min(50, Number(limit || 10)))
  const movers = await loadPositiveFinvizMoverRows(db, requestedLimit)
  return normalizeTickerList(movers.map(row => row.ticker), requestedLimit, { ensurePrivate: false })
}

function withPrivateSocialTickers(tickers = []) {
  return normalizeTickerList([...tickers, ...Array.from(PRIVATE_TRACKED_TICKERS)], Math.max(tickers.length + PRIVATE_TRACKED_TICKERS.size, 1), { ensurePrivate: false })
}

// ── Routes ────────────────────────────────────────────────
app.post("/api/translate", async (req, res) => {
  try {
    const text = String(req.body.text || "").trim().slice(0, 1200)
    const targetLanguage = String(req.body.target_language || req.body.target || "en").toLowerCase()

    if (!text) return res.status(400).json({ ok: false, error: "text is required" })
    if (!SUPPORTED_TRANSLATION_LANGUAGES.has(targetLanguage)) {
      return res.status(400).json({ ok: false, error: "unsupported target language" })
    }

    try {
      const providerTranslation = await translateWithProvider(text, targetLanguage)
      if (providerTranslation) {
        return res.json({
          ok: true,
          translated_text: providerTranslation,
          target_language: targetLanguage,
          provider: "external",
        })
      }
    } catch (err) {
      console.warn("Translation provider failed, using glossary fallback:", err.message)
    }

    return res.json({
      ok: true,
      translated_text: glossaryTranslate(text, targetLanguage),
      target_language: targetLanguage,
      provider: UNSUPPORTED_TRANSLATION_SCRIPT_RE.test(text) ? "glossary_cjk_fallback" : "glossary",
    })
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.use('/api/articles',    articlesRouter)
app.use('/api/screener',    screenerRouter)
app.use('/api/decision-map', decisionMapRouter)

app.get("/api/momentum/trending", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, tickers: [], error: "MongoDB is not connected" })

    const days = Number(req.query.days || 3)
    const limit = Number(req.query.limit || 30)
    const movers = await loadPositiveFinvizMoverRows(db, Math.max(1, Math.min(100, limit)))
    const articleMap = await loadArticleStatsForTickers(db, movers.map(row => row.ticker), days)
    const socialWindow = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const socialMap = await loadSocialStatsForTickers(db, movers.map(row => row.ticker), socialWindow)
    const tickers = movers.map(row => mergeMoverContext(
      row,
      articleMap.get(row.ticker),
      socialMap.get(row.ticker)
    ))

    res.json({ ok: true, tickers, days, order: "positive_price_change", source: "Finviz Elite top movers", social_window_minutes: socialWindow })
  } catch (err) {
    console.error("GET /api/momentum/trending failed:", err)
    res.status(500).json({ ok: false, tickers: [], error: String(err.message || err) })
  }
})

app.get("/api/social/targets", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, tickers: [], error: "MongoDB is not connected" })
    const limit = Math.max(1, Math.min(50, Number(req.query.limit || 10)))
    const tickers = await loadTopMomentumTickerSymbols(db, limit)
    const rows = await loadPositiveFinvizMoverRows(db, limit)
    res.json({
      ok: true,
      tickers,
      rows: rows.slice(0, limit).map(row => ({
        ticker: row.ticker,
        change_pct: row.change_pct,
        price: row.price,
        volume: row.volume,
        exchange: row.exchange,
        quote_source: row.quote_source,
        finviz_rank: row.finviz_rank,
      })),
      source: "Finviz Elite top positive momentum movers, falling back to stored U.S. screener rows only if Finviz has no rows",
      social_refresh_seconds: 60,
    })
  } catch (err) {
    console.error("GET /api/social/targets failed:", err)
    res.status(500).json({ ok: false, tickers: [], error: String(err.message || err) })
  }
})

app.get("/api/momentum/snapshots", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, snapshots: [], error: "MongoDB is not connected" })
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 12)))
    let snapshots = await loadMomentumSnapshots(db, limit)
    if (!snapshots.length) {
      await persistFinvizMomentumSnapshot(db, { limit: 100, reason: "on_demand" }).catch(() => null)
      snapshots = await loadMomentumSnapshots(db, limit)
    }
    res.json({
      ok: true,
      count: snapshots.length,
      retention_days: 31,
      snapshots,
    })
  } catch (err) {
    console.error("GET /api/momentum/snapshots failed:", err)
    res.status(500).json({ ok: false, snapshots: [], error: String(err.message || err) })
  }
})

app.get("/api/alerts", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, alerts: [], error: "MongoDB is not connected" })
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 20)))
    const socialWindow = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const scope = String(req.query.scope || "momentum").toLowerCase()
    const alerts = scope === "momentum"
      ? await buildMomentumAlerts(db, { limit, socialWindow })
      : []
    res.json({ ok: true, scope, count: alerts.length, alerts, generated_at: new Date().toISOString() })
  } catch (err) {
    console.error("GET /api/alerts failed:", err)
    res.status(500).json({ ok: false, alerts: [], error: String(err.message || err) })
  }
})

app.get("/api/trade-watch", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, tickers: [], error: "MongoDB is not connected" })

    const days = Math.max(0, Math.min(7, Number(req.query.days || 3)))
    const limit = Math.max(1, Math.min(50, Number(req.query.limit || 10)))
    const socialWindow = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const minScore = Math.max(0, Math.min(1, Number(req.query.min_score || 0)))
    const [rawTradeRows, model] = await Promise.all([
      loadEnrichedTradeWatchRows(db, { limit: Math.max(limit, 10), days, socialWindow }),
      loadLatestPredictionModel(db),
    ])
    const tickers = rawTradeRows
      .map(row => ({
        ...row,
        prediction_signal: applyPredictionModel(predictionFeaturesFromMover(row, socialWindow), model),
      }))
      .filter(row => row.trade_watch.trade_watch_score >= minScore)
      .slice(0, limit)

    res.json({
      ok: true,
      count: tickers.length,
      tickers,
      days,
      social_window_minutes: socialWindow,
      source: "Finviz momentum movers ranked by quote action, relative volume, structured/public news, and social evidence",
      methodology: {
        price_action: "positive Finviz Elite mover list, limited to clean NASDAQ/NYSE/AMEX rows",
        evidence: "structured news is weighted higher than public news; social counts and rolling sentiment are support signals",
        caution: "research-only scoring; broker execution is not connected",
      },
      model: model ? {
        status: model.status,
        samples: model.samples || 0,
        updated_at: model.updated_at || null,
        metrics: model.metrics || null,
      } : null,
    })
  } catch (err) {
    console.error("GET /api/trade-watch failed:", err)
    res.status(500).json({ ok: false, tickers: [], error: String(err.message || err) })
  }
})

const PROFESSOR_REGULAR_MOVER_SAMPLE = [
  "DSC", "RGC", "FRHC", "MAAS", "RDDT", "GH", "DLO", "OSCR", "BULL", "KRMN", "UTI", "APP", "VNET", "ARX", "MMYT", "GRND", "VERX", "COIN", "CELH", "META", "GIS", "HIMS", "HOOD",
]
const PROFESSOR_AFTERHOURS_MOVER_SAMPLE = ["USDE", "DSY", "SDEV", "SURG", "JEM", "IZM", "CAST", "WHLR", "AVAT", "FWDI"]

function missedMoverTickerList(req) {
  const explicit = normalizeTickerList(String(req.query.tickers || "").split(","), 200, { ensurePrivate: false })
  if (explicit.length) return explicit
  const sample = String(req.query.sample || "").toLowerCase()
  if (sample === "regular") return PROFESSOR_REGULAR_MOVER_SAMPLE
  if (sample === "afterhours" || sample === "postmarket") return PROFESSOR_AFTERHOURS_MOVER_SAMPLE
  if (sample === "professor" || sample === "all") return [...PROFESSOR_REGULAR_MOVER_SAMPLE, ...PROFESSOR_AFTERHOURS_MOVER_SAMPLE]
  return PROFESSOR_REGULAR_MOVER_SAMPLE
}

function screenerAuditReasons(row = null, { session = "regular", minRelVolume = 0, minAbsChange = 0 } = {}) {
  const reasons = []
  if (!row) return ["not found in screeners collection"]
  if (!row.ticker) reasons.push("missing ticker")
  if (String(row.ticker || "").includes(".")) reasons.push("ticker has dot/class suffix")
  if (!["NASDAQ", "NYSE", "AMEX"].includes(String(row.exchange || "").toUpperCase())) reasons.push(`exchange not in US screener set: ${row.exchange || "missing"}`)
  if (!(Number(row.price || 0) > 0)) reasons.push("missing/nonpositive session price")
  if (!(Number(row.volume || row.regular_volume || 0) > 0)) reasons.push("missing/nonpositive volume")
  if (Number(row.rel_volume || 0) < minRelVolume) reasons.push(`relative volume ${Number(row.rel_volume || 0).toFixed(2)} below filter ${minRelVolume}`)
  if (Math.abs(Number(row.change_pct || 0)) < minAbsChange) reasons.push(`${session} change ${Number(row.change_pct || 0).toFixed(2)}% below abs filter ${minAbsChange}%`)
  if (String(row.finviz_status || "").toLowerCase() === "dropped") reasons.push("FinViz row marked dropped")
  if (row.session_data_available === false) reasons.push(`${session} session field missing; row may be regular-only`)
  return reasons
}

app.get("/api/momentum/missed-movers", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: "MongoDB is not connected" })

    const session = normalizeMoverSession(req.query.session || (String(req.query.sample || "").toLowerCase() === "afterhours" ? "postmarket" : "regular"))
    const days = Math.max(1, Math.min(14, Number(req.query.days || 3)))
    const socialWindow = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const minRelVolume = Math.max(0, Number(req.query.min_rel_volume || 0))
    const minAbsChange = Math.max(0, Number(req.query.min_abs_change || 0))
    const tickers = missedMoverTickerList(req)
    const [rawDocs, momentumRows, articleMap, socialMap, latestSignals, finvizStatus] = await Promise.all([
      db.collection("screeners").find({ ticker: { $in: tickers } }).sort({ quote_updated_at: -1, finviz_seen_at: -1, tradingview_seen_at: -1 }).toArray(),
      loadPositiveFinvizMoverRows(db, 300, { session }),
      loadArticleStatsForTickers(db, tickers, days),
      loadSocialStatsForTickers(db, tickers, socialWindow),
      db.collection("prediction_signals").aggregate([
        { $match: { ticker: { $in: tickers } } },
        { $sort: { signal_sec: -1 } },
        { $group: { _id: "$ticker", doc: { $first: "$$ROOT" } } },
        { $replaceRoot: { newRoot: "$doc" } },
        { $project: { ticker: 1, signal_sec: 1, signal_at: 1, prediction_session: 1, prediction_target: 1, model_signal: 1, baseline_signal: 1, label_status: 1 } },
      ]).toArray().catch(() => []),
      loadFinvizMomentumStatus(db),
    ])

    const rawByTicker = new Map()
    for (const doc of rawDocs) {
      const ticker = String(doc.ticker || "").toUpperCase()
      if (!rawByTicker.has(ticker)) rawByTicker.set(ticker, doc)
    }
    const momentumByTicker = new Map(momentumRows.map(row => [String(row.ticker || "").toUpperCase(), row]))
    const signalByTicker = new Map(latestSignals.map(row => [String(row.ticker || "").toUpperCase(), row]))

    const rows = tickers.map(ticker => {
      const raw = rawByTicker.get(ticker) || null
      const normalized = raw ? applySessionMovement(normalizeScreenerDoc(raw), session) : null
      const momentum = momentumByTicker.get(ticker) || null
      const article = articleMap.get(ticker) || null
      const social = socialMap.get(ticker) || null
      const signal = signalByTicker.get(ticker) || null
      const decisionMapReasons = screenerAuditReasons(normalized, { session, minRelVolume, minAbsChange })
      const momentumReasons = screenerAuditReasons(normalized, { session, minRelVolume: 0, minAbsChange: 0 })
      if (normalized && Number(normalized.change_pct || 0) <= 0) momentumReasons.push(`${session} change is not positive, so top-gainers Momentum excludes it`)
      if (normalized && !isFinvizScreenerRow(normalized)) momentumReasons.push("not a FinViz screener row; Momentum uses FinViz top movers")
      if (normalized && !isCleanListedUsScreenerRow(normalized)) momentumReasons.push("failed clean listed US equity filter")
      if (normalized && !momentum && momentumReasons.length === 0) momentumReasons.push("passed basic filters but ranked outside the current Momentum result window")
      const structured = Number(article?.structured_count || 0)
      const unstructured = Number(article?.unstructured_count || 0)
      const socialCount = Number(social?.count || 0)
      const catalystState = structured > 0 && socialCount > 0
        ? "movement with structured and social support"
        : structured > 0
          ? "movement with structured catalyst"
          : unstructured > 0 || socialCount > 0
            ? "movement with unstructured/social support"
            : normalized
              ? "movement with no clear matched catalyst"
              : "not enough local screener data to evaluate catalyst"
      return {
        ticker,
        requested_session: session,
        in_screener: Boolean(raw),
        in_momentum: Boolean(momentum),
        in_decision_map_universe: Boolean(normalized && decisionMapReasons.length === 0),
        in_prediction_signals: Boolean(signal),
        excluded_from_momentum_reasons: momentum ? [] : momentumReasons,
        excluded_from_decision_map_reasons: normalized && decisionMapReasons.length === 0 ? [] : decisionMapReasons,
        screener: normalized ? {
          company: normalized.company || "",
          exchange: normalized.exchange || "",
          quote_source: normalized.quote_source || normalized.source || raw?.quote_source || raw?.source || "",
          finviz_status: raw?.finviz_status || null,
          quote_updated_at: normalized.quote_updated_at || null,
          finviz_seen_at: raw?.finviz_seen_at || null,
          quote_age_seconds: timestampSeconds(normalized.quote_updated_at || raw?.finviz_seen_at) ? Math.max(0, Math.floor(Date.now() / 1000) - timestampSeconds(normalized.quote_updated_at || raw?.finviz_seen_at)) : null,
          market_cap: normalized.market_cap ?? null,
          market_cap_bucket: normalized.market_cap_bucket || "",
          price: normalized.price ?? null,
          change_pct: normalized.change_pct ?? null,
          volume: normalized.volume ?? null,
          rel_volume: normalized.rel_volume ?? null,
          active_session: normalized.active_session,
          session_data_available: normalized.session_data_available,
          regular_change_pct: normalized.regular_change_pct ?? null,
          premarket_change_pct: normalized.premarket_change_pct ?? null,
          postmarket_change_pct: normalized.postmarket_change_pct ?? null,
        } : null,
        evidence: {
          structured_news_count: structured,
          unstructured_news_count: unstructured,
          social_count: socialCount,
          sources: article?.sources || [],
          social_platforms: social?.platforms || [],
          catalyst_state: catalystState,
          latest_article_sec: article?.latest_publish || article?.latest_activity || null,
          latest_social_sec: social?.latest_post || null,
        },
        prediction: signal ? {
          signal_sec: signal.signal_sec || null,
          signal_at: signal.signal_at || null,
          prediction_session: signal.prediction_session || null,
          prediction_target: signal.prediction_target || null,
          model_signal: signal.model_signal || null,
          baseline_signal: signal.baseline_signal || null,
          label_status: signal.label_status || null,
        } : null,
      }
    })

    res.json({
      ok: true,
      generated_at: new Date().toISOString(),
      endpoint: "/api/momentum/missed-movers",
      session,
      sample: req.query.sample || null,
      tickers,
      count: rows.length,
      finviz_status: finvizStatus,
      summary: {
        in_screener: rows.filter(row => row.in_screener).length,
        in_momentum: rows.filter(row => row.in_momentum).length,
        in_decision_map_universe: rows.filter(row => row.in_decision_map_universe).length,
        with_structured_news: rows.filter(row => Number(row.evidence.structured_news_count || 0) > 0).length,
        with_social: rows.filter(row => Number(row.evidence.social_count || 0) > 0).length,
        with_prediction_signal: rows.filter(row => row.in_prediction_signals).length,
      },
      methodology: "Compares requested tickers against screener ingestion, selected-session Momentum, Decision Map eligibility, matched news/social evidence, and latest prediction_signals. This is an audit/debug endpoint only; it does not create fake rows or hardcode predictions.",
      rows,
    })
  } catch (err) {
    console.error("GET /api/momentum/missed-movers failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get("/api/momentum", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, tickers: [], error: "MongoDB is not connected" })

    const days = Number(req.query.days || 3)
    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 30)))
    const minNews = Math.max(0, Number(req.query.min_volume || req.query.min_news || 0))
    const minRelVolume = Math.max(0, Number(req.query.min_rel_vol || 0))
    const maxPrice = req.query.max_price ? Number(req.query.max_price) : null
    const sentiment = String(req.query.sentiment || "").toLowerCase()
    const order = String(req.query.order || "absolute_momentum").toLowerCase()
    const session = normalizeMoverSession(req.query.session || "regular")

    const [movers, finvizStatus] = await Promise.all([
      loadPositiveFinvizMoverRows(db, Math.max(limit * 4, 100), { session }),
      loadFinvizMomentumStatus(db),
    ])
    const articleMap = await loadArticleStatsForTickers(db, movers.map(row => row.ticker), days)
    const socialWindow = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const socialMap = await loadSocialStatsForTickers(db, movers.map(row => row.ticker), socialWindow)
    let tickers = movers.map(row => mergeMoverContext(
      row,
      articleMap.get(row.ticker),
      socialMap.get(row.ticker)
    ))

    if (minNews > 0) tickers = tickers.filter(row => (row.article_count || row.message_count || 0) >= minNews)
    if (minRelVolume > 0) tickers = tickers.filter(row => (row.rel_volume || 0) >= minRelVolume)
    if (maxPrice != null && Number.isFinite(maxPrice)) {
      tickers = tickers.filter(row => row.price == null || row.price <= maxPrice)
    }
    if (sentiment === "bullish") tickers = tickers.filter(row => (row.sentiment || 0) > 0)
    if (sentiment === "bearish") tickers = tickers.filter(row => (row.sentiment || 0) < 0)

    tickers.sort((a, b) => {
      if (order === "news") {
        const scoreA = (a.article_count || a.message_count || 0) * (1 + Math.abs(a.sentiment || 0))
        const scoreB = (b.article_count || b.message_count || 0) * (1 + Math.abs(b.sentiment || 0))
        return scoreB - scoreA
      }
      const scoreA = Number(a.change_pct || 0)
      const scoreB = Number(b.change_pct || 0)
      if (scoreB !== scoreA) return scoreB - scoreA
      const relA = Number(a.rel_volume || 0)
      const relB = Number(b.rel_volume || 0)
      if (relB !== relA) return relB - relA
      return (b.volume || 0) - (a.volume || 0)
    })

    res.json({
      ok: true,
      tickers: tickers.slice(0, limit),
      count: Math.min(tickers.length, limit),
      days,
      order,
      session,
      session_note: session === "postmarket"
        ? "After-hours/post-market movers sorted by post-market change percentage."
        : session === "premarket"
          ? "Premarket movers sorted by premarket change percentage."
          : session === "auto"
            ? "Auto selects the strongest available session move per ticker."
            : "Regular-market movers sorted by regular-session change percentage.",
      source: "Finviz Elite top movers",
      social_window_minutes: socialWindow,
      finviz_status: finvizStatus,
    })
  } catch (err) {
    console.error("GET /api/momentum failed:", err)
    res.status(500).json({ ok: false, tickers: [], error: String(err.message || err) })
  }
})

app.get("/api/momentum/:ticker/details", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, headlines: [], posts: [], error: "MongoDB is not connected" })

    const ticker = String(req.params.ticker || "").toUpperCase().replace(/[^A-Z0-9.-]/g, "")
    const days = Number(req.query.days || 3)

    const articles = await db.collection("articles").aggregate([
      { $match: articleActivityWindowMatch(days) },
      ...articleTickerCandidateStages(),
      { $match: { _ticker_parts: ticker } },
      {
        $addFields: {
          _publish_sec: timestampSecondsExpression("$publish_date"),
          _fetch_sec: timestampSecondsExpression("$fetched_date"),
          _detected_sec: timestampSecondsExpression("$detected_at"),
          _created_sec: timestampSecondsExpression("$createdAt"),
        },
      },
      { $addFields: { _activity_sec: { $max: ["$_publish_sec", "$_fetch_sec", "$_detected_sec", "$_created_sec"] } } },
      { $sort: { _activity_sec: -1, _publish_sec: -1 } },
      {
        $project: {
          title: 1,
          source: 1,
          sentiment: 1,
          publish_date: "$_publish_sec",
          fetched_date: "$_fetch_sec",
          detected_at: "$_detected_sec",
          url: 1,
          category: 1,
          event_type: 1,
        },
      },
      { $limit: 12 },
    ]).toArray()

    const headlines = articles.map(article => ({
      title: article.title || "Untitled headline",
      source: article.source || "News",
      sentiment: article.sentiment || "neutral",
      time: timeLabel(article.publish_date || article.fetched_date),
      catalyst: article.event_type || article.category || undefined,
      url: article.url,
    }))

    const socialRows = await db.collection("socials").aggregate([
      ...socialTimeStages(),
      { $match: { _ticker_candidates: ticker } },
      { $sort: { _event_sec: -1 } },
      { $limit: 12 },
      {
        $project: {
          _id: 0,
          platform: "$_norm_platform",
          author: 1,
          content: { $ifNull: ["$text", { $ifNull: ["$content", "$title"] }] },
          sentiment: 1,
          sentiment_score: 1,
          url: 1,
          fetched_at: "$_event_sec",
        },
      },
    ]).toArray()

    const posts = socialRows.map(post => ({
      platform: post.platform || "Social",
      author: post.author || "",
      content: post.content || "",
      sentiment: typeof post.sentiment_score === "number"
        ? post.sentiment_score
        : /bull|positive/i.test(String(post.sentiment || "")) ? 1
        : /bear|negative/i.test(String(post.sentiment || "")) ? -1
        : 0,
      url: post.url,
      time: timeLabel(post.fetched_at),
    }))

    res.json({ ok: true, ticker, headlines, posts })
  } catch (err) {
    console.error("GET /api/momentum/:ticker/details failed:", err)
    res.status(500).json({ ok: false, headlines: [], posts: [], error: String(err.message || err) })
  }
})

app.get("/api/prices/:ticker", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: "MongoDB is not connected" })

    const ticker = String(req.params.ticker || "").toUpperCase().replace(/[^A-Z0-9.-]/g, "")
    const doc = await db.collection("screeners").findOne({ ticker })
    const row = normalizeScreenerDoc(doc || { ticker })
    res.json({
      ok: true,
      ticker,
      price: row.price,
      change_pct: row.change_pct,
      volume: row.volume,
      rel_volume: row.rel_volume,
      previous_close: row.previous_close,
      previous_close_status: row.previous_close_status,
      quote_source: row.quote_source,
      quote_time: row.quote_time,
      quote_status: row.quote_status,
      updated_at: doc?.quote_updated_at || doc?.updated_at || doc?.updatedAt || null,
    })
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

// SOCIAL_ROLLING_API_V2_START
// Rolling social feed using existing Mongoose connection.
// Supports numeric Unix-second timestamps, JS Date timestamps, and fallback fields.
function socialTimeStages() {
  return [
    {
      $addFields: {
        _time_raw: {
          $ifNull: [
            "$fetched_at",
            { $ifNull: [
              "$detected_at",
              { $ifNull: [
                "$timestamp",
                { $ifNull: ["$created_at", "$publish_date"] }
              ] }
            ] }
          ]
        }
      }
    },
    {
      $addFields: {
        _event_sec: {
          $switch: {
            branches: [
              {
                case: { $eq: [{ $type: "$_time_raw" }, "date"] },
                then: { $floor: { $divide: [{ $toLong: "$_time_raw" }, 1000] } }
              },
              {
                case: { $in: [{ $type: "$_time_raw" }, ["int", "long", "double", "decimal"] ] },
                then: { $toLong: "$_time_raw" }
              },
              {
                case: { $eq: [{ $type: "$_time_raw" }, "string"] },
                then: {
                  $floor: {
                    $divide: [
                      { $toLong: { $dateFromString: { dateString: "$_time_raw", onError: new Date(0) } } },
                      1000
                    ]
                  }
                }
              }
            ],
            default: 0
          }
        }
      }
    },
    {
      $addFields: {
        _norm_platform: {
          $switch: {
            branches: [
              {
                case: {
                  $regexMatch: {
                    input: { $toLower: { $ifNull: ["$platform", ""] } },
                    regex: "stocktwits"
                  }
                },
                then: "StockTwits"
              },
              {
                case: {
                  $regexMatch: {
                    input: { $toLower: { $ifNull: ["$platform", ""] } },
                    regex: "bluesky|bsky"
                  }
                },
                then: "Bluesky"
              },
              {
                case: {
                  $or: [
                    {
                      $regexMatch: {
                        input: { $toLower: { $ifNull: ["$platform", ""] } },
                        regex: "reddit"
                      }
                    },
                    {
                      $regexMatch: {
                        input: { $toLower: { $ifNull: ["$collector", ""] } },
                        regex: "reddit"
                      }
                    }
                  ]
                },
                then: "Reddit"
              },
              {
                case: {
                  $or: [
                    {
                      $regexMatch: {
                        input: { $toLower: { $ifNull: ["$platform", ""] } },
                        regex: "twitter|x"
                      }
                    },
                    {
                      $regexMatch: {
                        input: { $toLower: { $ifNull: ["$collector", ""] } },
                        regex: "twitter|x_"
                      }
                    }
                  ]
                },
                then: "Twitter"
              }
            ],
            default: { $ifNull: ["$platform", "Unknown"] }
          }
        }
      }
    },
    ...socialTickerCandidateStages(),
  ]
}

function socialTickerCandidateStages() {
  const stringSplit = (field) => ({
    $cond: [
      { $eq: [{ $type: field }, "string"] },
      { $split: [field, ","] },
      [],
    ],
  })
  const arrayOrStringSplit = (field) => ({
    $cond: [
      { $isArray: field },
      field,
      stringSplit(field),
    ],
  })

  return [
    {
      $addFields: {
        _ticker_primary_values_raw: {
          $concatArrays: [
            stringSplit("$ticker"),
            stringSplit("$symbol"),
            stringSplit("$cashtag"),
            arrayOrStringSplit("$tickers_mentioned"),
          ],
        },
        _ticker_text_cashtags: {
          $map: {
            input: {
              $regexFindAll: {
                input: {
                  $concat: [
                    { $toString: { $ifNull: ["$text", ""] } },
                    " ",
                    { $toString: { $ifNull: ["$content", ""] } },
                    " ",
                    { $toString: { $ifNull: ["$title", ""] } },
                  ],
                },
                regex: /\$[A-Za-z][A-Za-z0-9.-]{0,5}\b/,
              },
            },
            as: "tag",
            in: "$$tag.match",
          },
        },
      },
    },
    {
      $addFields: {
        _ticker_values_raw: {
          $cond: [
            {
              $gt: [
                {
                  $size: {
                    $filter: {
                      input: { $ifNull: ["$_ticker_primary_values_raw", []] },
                      as: "raw",
                      cond: { $ne: [{ $trim: { input: { $toString: "$$raw" } } }, ""] },
                    },
                  },
                },
                0,
              ],
            },
            "$_ticker_primary_values_raw",
            "$_ticker_text_cashtags",
          ],
        },
      },
    },
    {
      $addFields: {
        _ticker_candidates: {
          $setUnion: [
            {
              $filter: {
                input: {
                  $map: {
                    input: "$_ticker_values_raw",
                    as: "raw",
                    in: {
                      $trim: {
                        input: {
                          $replaceAll: {
                            input: { $toUpper: { $toString: "$$raw" } },
                            find: { $literal: "$" },
                            replacement: "",
                          },
                        },
                        chars: " ,;#",
                      },
                    },
                  },
                },
                as: "candidate",
                cond: {
                  $regexMatch: {
                    input: "$$candidate",
                    regex: "^[A-Z][A-Z0-9.-]{0,5}$",
                  },
                },
              },
            },
            [],
          ],
        },
      },
    }
  ]
}

function marketSessionForSec(sec) {
  const date = new Date(Number(sec || 0) * 1000)
  if (!Number.isFinite(date.getTime())) return "unknown"
  const ny = new Date(date.toLocaleString("en-US", { timeZone: "America/New_York" }))
  const day = ny.getDay()
  const minutes = ny.getHours() * 60 + ny.getMinutes()
  if (day < 1 || day > 5) return "closed"
  if (minutes >= 4 * 60 && minutes < 9 * 60 + 30) return "pre"
  if (minutes >= 9 * 60 + 30 && minutes < 16 * 60) return "regular"
  if (minutes >= 16 * 60 && minutes < 20 * 60) return "after"
  return "closed"
}

function addSessionScaledSocialFields(rows, bucketMinutes) {
  const maxima = new Map()
  for (const row of rows) {
    const session = row.session || "unknown"
    const current = maxima.get(session) || { count: 0, density: 0 }
    current.count = Math.max(current.count, Number(row.message_count || 0))
    current.density = Math.max(current.density, Number(row.message_density || 0))
    maxima.set(session, current)
  }

  return rows.map(row => {
    const max = maxima.get(row.session || "unknown") || { count: 0, density: 0 }
    const count = Number(row.message_count || 0)
    const density = Number(row.message_density || 0)
    const sentiment = Number(row.sentiment || 0)
    return {
      ...row,
      bucket_minutes: bucketMinutes,
      message_count_scaled: max.count ? Number((count / max.count).toFixed(3)) : 0,
      message_density_scaled: max.density ? Number((density / max.density).toFixed(3)) : 0,
      sentiment_scaled: Number(((sentiment + 1) / 2).toFixed(3)),
    }
  })
}

app.get("/api/finviz/movers", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, tickers: [], error: "MongoDB is not connected" })

    const limit = Math.max(1, Math.min(100, Number(req.query.limit || 30)))
    const [movers, finvizStatus] = await Promise.all([
      loadPositiveFinvizMoverRows(db, limit),
      loadFinvizMomentumStatus(db),
    ])
    const articleMap = await loadArticleStatsForTickers(db, movers.map(row => row.ticker), Number(req.query.days || 3))
    const socialMap = await loadSocialStatsForTickers(db, movers.map(row => row.ticker), Number(req.query.window_minutes || 1440))
    const tickers = movers.map(row => mergeMoverContext(row, articleMap.get(row.ticker), socialMap.get(row.ticker)))

    res.json({ ok: true, source: "Finviz Elite top movers", tickers, count: tickers.length, finviz_status: finvizStatus })
  } catch (err) {
    res.status(500).json({ ok: false, tickers: [], error: String(err.message || err) })
  }
})

app.get("/api/social/rolling", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) {
      return res.status(503).json({ ok: false, error: "MongoDB is not connected", rows: [] })
    }

    const windowMinutes = Math.max(1, Math.min(4320, Number(req.query.window_minutes || 5)))
    const limit = Math.max(1, Math.min(1000, Number(req.query.limit || 500)))
    const platform = String(req.query.platform || "all").toLowerCase()
    const ticker = normalizeTickerList([req.query.ticker || req.query.symbol], 1, { ensurePrivate: false })[0] || ""
    const ranked = ["1", "true", "yes"].includes(String(req.query.ranked || "").toLowerCase())
    const sinceSec = Math.floor(Date.now() / 1000) - windowMinutes * 60
    const platformMap = {
      reddit: "Reddit",
      bluesky: "Bluesky",
      bsky: "Bluesky",
      twitter: "Twitter",
      x: "Twitter",
      stocktwits: "StockTwits",
    }
    const normalizedPlatform = platformMap[platform] || platform

    const statusPipeline = [
      ...socialTimeStages(),
      { $match: { _event_sec: { $gte: sinceSec } } },
      { $match: { _norm_platform: { $ne: "Unstructured" } } },
    ]
    if (ticker) statusPipeline.push({ $match: { _ticker_candidates: ticker } })
    statusPipeline.push(
      {
        $group: {
          _id: "$_norm_platform",
          total: { $sum: 1 },
          ticker_matched: {
            $sum: {
              $cond: [
                { $gt: [{ $size: { $ifNull: ["$_ticker_candidates", []] } }, 0] },
                1,
                0,
              ],
            },
          },
          latest_sec: { $max: "$_event_sec" },
        },
      },
      {
        $project: {
          _id: 0,
          platform: "$_id",
          total: 1,
          ticker_matched: 1,
          latest_sec: 1,
          status: {
            $cond: [
              { $gt: ["$ticker_matched", 0] },
              "working",
              { $cond: [{ $gt: ["$total", 0] }, "unmatched", "empty"] },
            ],
          },
        },
      },
      { $sort: { platform: 1 } }
    )

    const pipeline = [
      ...socialTimeStages(),
      { $match: { _event_sec: { $gte: sinceSec } } },
      {
        $match: {
          _norm_platform: { $ne: "Unstructured" },
          _ticker_candidates: { $ne: [] },
        },
      },
    ]

    if (platform !== "all") {
      pipeline.push({ $match: { _norm_platform: normalizedPlatform } })
    }

    if (ticker) {
      pipeline.push({
        $match: { _ticker_candidates: ticker },
      })
    }

    pipeline.push(
      {
        $addFields: {
          _display_sentiment_score: {
            $switch: {
              branches: [
                { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"] ] }, then: { $toDouble: "$sentiment_score" } },
                { case: { $in: [{ $type: "$sentiment" }, ["int", "long", "double", "decimal"] ] }, then: { $toDouble: "$sentiment" } },
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
              ],
              default: 0,
            },
          },
          _platform_rank: {
            $switch: {
              branches: [
                { case: { $eq: ["$_norm_platform", "StockTwits"] }, then: 4 },
                { case: { $eq: ["$_norm_platform", "Twitter"] }, then: 3 },
                { case: { $eq: ["$_norm_platform", "Reddit"] }, then: 2 },
                { case: { $eq: ["$_norm_platform", "Bluesky"] }, then: 1 },
              ],
              default: 0,
            },
          },
          _sentiment_abs: { $abs: "$_display_sentiment_score" },
        },
      },
      { $sort: ranked ? { _sentiment_abs: -1, _platform_rank: -1, _event_sec: -1 } : { _event_sec: -1 } },
      { $limit: limit },
      {
        $project: {
          _id: 1,
          platform: "$_norm_platform",
          source: 1,
          collector: 1,
          ticker: { $ifNull: ["$ticker", { $arrayElemAt: ["$_ticker_candidates", 0] }] },
          symbol: { $ifNull: ["$symbol", { $arrayElemAt: ["$_ticker_candidates", 0] }] },
          title: 1,
          text: 1,
          content: 1,
          url: 1,
          author: 1,
          sentiment: 1,
          sentiment_score: "$_display_sentiment_score",
          raw_sentiment_score: "$sentiment_score",
          ticker_candidates: "$_ticker_candidates",
          cashtag: 1,
          finance_keywords: 1,
          keywords: 1,
          gossip_keywords: 1,
          gossip_score: 1,
          fetched_at: "$_event_sec",
          detected_at: 1,
          created_at: 1,
          timestamp: 1
        }
      }
    )

    const [rows, platformStatusRows] = await Promise.all([
      db.collection("socials").aggregate(pipeline).toArray(),
      db.collection("socials").aggregate(statusPipeline).toArray(),
    ])
    const expectedPlatforms = ["Reddit", "Bluesky", "Twitter", "StockTwits"]
    const statusByPlatform = new Map(platformStatusRows.map(row => [String(row.platform || ""), row]))
    const platformStatus = expectedPlatforms.map(name => statusByPlatform.get(name) || {
      platform: name,
      total: 0,
      ticker_matched: 0,
      latest_sec: null,
      status: "empty",
    })
    if (ranked) {
      const platformRank = { StockTwits: 4, Twitter: 3, Reddit: 2, Bluesky: 1 }
      rows.sort((a, b) => {
        const sentimentDiff = Math.abs(Number(b.sentiment_score || 0)) - Math.abs(Number(a.sentiment_score || 0))
        if (sentimentDiff) return sentimentDiff
        const platformDiff = (platformRank[b.platform] || 0) - (platformRank[a.platform] || 0)
        if (platformDiff) return platformDiff
        return Number(b.fetched_at || b.timestamp || 0) - Number(a.fetched_at || a.timestamp || 0)
      })
    }

    return res.json({
      ok: true,
      rows,
      count: rows.length,
      platform_status: platformStatus,
      window_minutes: windowMinutes,
      platform,
      ticker,
      since_sec: sinceSec,
      now_sec: Math.floor(Date.now() / 1000),
    })
  } catch (err) {
    console.error("GET /api/social/rolling failed:", err)
    return res.status(500).json({ ok: false, error: String(err?.message || err), rows: [] })
  }
})

app.get("/api/social/series/:ticker", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, ticker: "", rows: [], error: "MongoDB is not connected" })

    const ticker = normalizeTickerList([req.params.ticker], 1, { ensurePrivate: false })[0] || ""
    if (!ticker) return res.status(400).json({ ok: false, ticker: "", rows: [], error: "ticker is required" })

    const windowMinutes = Math.max(5, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const bucketMinutes = Math.max(1, Math.min(60, Number(req.query.bucket_minutes || 5)))
    const sinceSec = Math.floor(Date.now() / 1000) - windowMinutes * 60
    const bucketSec = bucketMinutes * 60

    const rows = await db.collection("socials").aggregate([
      ...socialTimeStages(),
      { $match: { _event_sec: { $gte: sinceSec } } },
      { $match: { _ticker_candidates: ticker } },
      {
        $addFields: {
          _bucket_sec: {
            $multiply: [
              { $floor: { $divide: ["$_event_sec", bucketSec] } },
              bucketSec,
            ],
          },
        },
      },
      {
        $group: {
          _id: "$_bucket_sec",
          message_count: { $sum: 1 },
          bullish: {
            $sum: {
              $cond: [
                { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } },
                1,
                0,
              ],
            },
          },
          bearish: {
            $sum: {
              $cond: [
                { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } },
                1,
                0,
              ],
            },
          },
          platforms: { $addToSet: "$_norm_platform" },
        },
      },
      { $sort: { _id: 1 } },
    ]).toArray()

    const normalized = addSessionScaledSocialFields(rows.map(row => {
      const count = Number(row.message_count || 0)
      return {
        time: new Date(Number(row._id || 0) * 1000).toISOString(),
        bucket_sec: Number(row._id || 0),
        session: marketSessionForSec(row._id),
        message_count: count,
        message_density: Number((count / bucketMinutes).toFixed(3)),
        sentiment: count ? Number((((row.bullish || 0) - (row.bearish || 0)) / count).toFixed(3)) : 0,
        bullish: Number(row.bullish || 0),
        bearish: Number(row.bearish || 0),
        platforms: row.platforms || [],
      }
    }), bucketMinutes)

    res.json({
      ok: true,
      ticker,
      rows: normalized,
      window_minutes: windowMinutes,
      bucket_minutes: bucketMinutes,
      scaling: "per_ticker_per_market_session",
    })
  } catch (err) {
    console.error("GET /api/social/series/:ticker failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

function yahooRangeFor(range, interval) {
  const r = String(range || "3mo").toLowerCase()
  const i = String(interval || "1d").toLowerCase()
  if (i === "1m") return "1d"
  if (["5m", "15m", "30m"].includes(i)) return r === "1d" ? "1d" : "5d"
  if (i === "1h") return ["1d", "5d"].includes(r) ? "5d" : "1mo"
  if (["1mo", "3mo", "6mo", "1y", "2y", "5y"].includes(r)) return r
  return "3mo"
}

function yahooIntervalFor(interval) {
  const i = String(interval || "1d").toLowerCase()
  if (["1m", "5m", "15m", "30m", "1h", "1d", "1wk"].includes(i)) return i
  return "1d"
}

async function fetchYahooCandles(ticker, range, interval, opts = {}) {
  // raw:true passes the given range straight through (used by the multi-timeframe
  // tf= selector, which needs longer history than the default range caps allow).
  const yahooRange = opts.raw ? String(range || "1mo") : yahooRangeFor(range, interval)
  const yahooInterval = yahooIntervalFor(interval)
  const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}`)
  url.searchParams.set("range", yahooRange)
  url.searchParams.set("interval", yahooInterval)
  url.searchParams.set("includePrePost", "true")
  url.searchParams.set("events", "history")

  const resp = await fetch(url, {
    headers: {
      "User-Agent": "FeedFlashStockDashboard/0.1",
      "Accept": "application/json",
    },
  })
  if (!resp.ok) throw new Error(`chart provider HTTP ${resp.status}`)
  const payload = await resp.json()
  const result = payload?.chart?.result?.[0]
  const timestamps = result?.timestamp || []
  const quote = result?.indicators?.quote?.[0] || {}
  const candles = []

  for (let i = 0; i < timestamps.length; i += 1) {
    const open = Number(quote.open?.[i])
    const high = Number(quote.high?.[i])
    const low = Number(quote.low?.[i])
    const close = Number(quote.close?.[i])
    if (![open, high, low, close].every(Number.isFinite)) continue
    if (open <= 0 || high <= 0 || low <= 0 || close <= 0) continue
    if (high < Math.max(open, close, low) || low > Math.min(open, close, high)) continue
    candles.push({
      time: Number(timestamps[i]),
      open: Number(open.toFixed(4)),
      high: Number(high.toFixed(4)),
      low: Number(low.toFixed(4)),
      close: Number(close.toFixed(4)),
      volume: Number.isFinite(Number(quote.volume?.[i])) ? Number(quote.volume[i]) : 0,
    })
  }
  return { candles, provider_range: yahooRange, provider_interval: yahooInterval }
}

function sma(values, period) {
  return values.map((_, index) => {
    if (index < period - 1) return null
    const slice = values.slice(index - period + 1, index + 1)
    return slice.reduce((sum, value) => sum + value, 0) / period
  })
}

function bollinger(candles, period = 20, multiplier = 2) {
  const closes = candles.map(c => Number(c.close))
  const middle = sma(closes, period)
  const upper = []
  const lower = []
  for (let i = 0; i < candles.length; i += 1) {
    if (middle[i] == null) continue
    const slice = closes.slice(i - period + 1, i + 1)
    const variance = slice.reduce((sum, value) => sum + Math.pow(value - middle[i], 2), 0) / period
    const std = Math.sqrt(variance)
    upper.push({ time: candles[i].time, value: Number((middle[i] + multiplier * std).toFixed(4)) })
    lower.push({ time: candles[i].time, value: Number((middle[i] - multiplier * std).toFixed(4)) })
  }
  return { upper, lower }
}

function rsi(candles, period = 14) {
  const closes = candles.map(c => Number(c.close))
  const rows = []
  for (let i = period; i < closes.length; i += 1) {
    let gains = 0
    let losses = 0
    for (let j = i - period + 1; j <= i; j += 1) {
      const diff = closes[j] - closes[j - 1]
      if (diff >= 0) gains += diff
      else losses += Math.abs(diff)
    }
    const rs = losses ? gains / losses : 100
    const value = 100 - (100 / (1 + rs))
    rows.push({ time: candles[i].time, value: Number(value.toFixed(2)) })
  }
  return rows
}

function ema(values, period) {
  const k = 2 / (period + 1)
  let current = values[0]
  return values.map((value, index) => {
    current = index === 0 ? value : value * k + current * (1 - k)
    return current
  })
}

function macd(candles) {
  const closes = candles.map(c => Number(c.close))
  if (closes.length < 35) return { macd: [], signal: [], histogram: [] }
  const ema12 = ema(closes, 12)
  const ema26 = ema(closes, 26)
  const macdValues = closes.map((_, index) => ema12[index] - ema26[index])
  const signalValues = ema(macdValues, 9)
  const macdRows = []
  const signalRows = []
  const histogram = []
  for (let i = 26; i < candles.length; i += 1) {
    macdRows.push({ time: candles[i].time, value: Number(macdValues[i].toFixed(4)) })
    signalRows.push({ time: candles[i].time, value: Number(signalValues[i].toFixed(4)) })
    histogram.push({ time: candles[i].time, value: Number((macdValues[i] - signalValues[i]).toFixed(4)) })
  }
  return { macd: macdRows, signal: signalRows, histogram }
}

function predictedPriceSeries(candles, points = 12) {
  const lookback = candles.slice(-30)
  if (lookback.length < 6) return []

  const n = lookback.length
  const meanX = (n - 1) / 2
  const meanY = lookback.reduce((sum, candle) => sum + Number(candle.close), 0) / n
  let numerator = 0
  let denominator = 0
  for (let i = 0; i < n; i += 1) {
    const dx = i - meanX
    numerator += dx * (Number(lookback[i].close) - meanY)
    denominator += dx * dx
  }
  const slope = denominator ? numerator / denominator : 0
  const last = lookback[lookback.length - 1]
  const prev = lookback[lookback.length - 2]
  const step = Math.max(60, Number(last.time || 0) - Number(prev.time || 0) || 60)
  const start = Number(last.close)
  const rows = [{ time: last.time, value: Number(start.toFixed(4)) }]
  for (let i = 1; i <= points; i += 1) {
    rows.push({
      time: Number(last.time || 0) + step * i,
      value: Number(Math.max(0.0001, start + slope * i).toFixed(4)),
    })
  }
  return rows
}

function timestampSeconds(value) {
  if (!value) return 0
  if (value instanceof Date) return Math.floor(value.getTime() / 1000)
  const n = Number(value)
  if (Number.isFinite(n) && n > 0) {
    return n > 1_000_000_000_000 ? Math.floor(n / 1000) : Math.floor(n)
  }
  const ms = Date.parse(value)
  return Number.isFinite(ms) ? Math.floor(ms / 1000) : 0
}

async function chartNewsEvents(db, ticker, windowMinutes = 1440) {
  const days = Math.max(2, Math.ceil(Number(windowMinutes || 1440) / 1440))
  const docs = await db.collection("articles").aggregate([
    { $match: articleActivityWindowMatch(days) },
    ...articleTickerCandidateStages(),
    { $match: { _ticker_parts: ticker } },
    {
      $addFields: {
        _publish_sec: timestampSecondsExpression("$publish_date"),
        _fetch_sec: timestampSecondsExpression("$fetched_date"),
        _detected_sec: timestampSecondsExpression("$detected_at"),
        _created_sec: timestampSecondsExpression("$createdAt"),
      },
    },
    { $addFields: { _activity_sec: { $max: ["$_publish_sec", "$_fetch_sec", "$_detected_sec", "$_created_sec"] } } },
    { $sort: { _activity_sec: -1, _publish_sec: -1 } },
    {
      $project: {
        title: 1,
        source: 1,
        sentiment: 1,
        sentiment_score: 1,
        ml_confidence: 1,
        event_type: 1,
        sentiment_reason: 1,
        publish_date: "$_publish_sec",
        fetched_date: "$_fetch_sec",
        detected_at: "$_detected_sec",
        createdAt: "$_created_sec",
        url: 1,
      },
    },
    { $limit: 25 },
  ]).toArray()

  return docs
    .map(article => {
      const time = timestampSeconds(article.publish_date || article.fetched_date || article.detected_at || article.createdAt)
      const sentiment = String(article.sentiment || "neutral").toLowerCase()
      const bullish = /bull|positive/.test(sentiment)
      const bearish = /bear|negative/.test(sentiment)
      return {
        time,
        position: bearish ? "aboveBar" : "belowBar",
        color: bullish ? "#10b981" : bearish ? "#ef4444" : "#f59e0b",
        shape: bullish ? "arrowUp" : bearish ? "arrowDown" : "circle",
        text: article.event_type && article.event_type !== "general_news" ? String(article.event_type).replaceAll("_", " ").slice(0, 14).toUpperCase() : "NEWS",
        title: article.title || "Matched news",
        source: article.source || "News",
        sentiment,
        sentiment_score: Number(article.sentiment_score ?? article.ml_confidence ?? 0) || 0,
        event_type: article.event_type || "general_news",
        reason: article.sentiment_reason || "",
        url: article.url || "",
      }
    })
    .filter(event => event.time > 0)
    .sort((a, b) => a.time - b.time)
}

function chartSocialEvents(socialRows = []) {
  if (!Array.isArray(socialRows) || !socialRows.length) return []
  const maxCount = Math.max(1, ...socialRows.map(row => Number(row.message_count || 0)))
  return socialRows
    .filter(row => Number(row.message_count || 0) >= Math.max(2, Math.ceil(maxCount * 0.45)) || Math.abs(Number(row.sentiment || 0)) >= 0.45)
    .slice(-14)
    .map(row => {
      const sentiment = Number(row.sentiment || 0)
      return {
        time: Number(row.time || row.bucket_sec || 0),
        position: sentiment < -0.15 ? "aboveBar" : "belowBar",
        color: sentiment > 0.15 ? "#38bdf8" : sentiment < -0.15 ? "#fb7185" : "#a78bfa",
        shape: sentiment < -0.15 ? "arrowDown" : sentiment > 0.15 ? "arrowUp" : "circle",
        text: `SOC ${Number(row.message_count || 0)}`,
        title: `${Number(row.message_count || 0)} social messages; sentiment ${sentiment.toFixed(2)}`,
        source: Array.isArray(row.platforms) && row.platforms.length ? row.platforms.join(", ") : "Social",
        sentiment: sentiment > 0.15 ? "bullish" : sentiment < -0.15 ? "bearish" : "neutral",
        sentiment_score: sentiment,
        event_type: "social_spike",
      }
    })
    .filter(event => event.time > 0)
}

function densityCorrelationStrategyMarkers(candles = [], socialRows = [], opts = {}) {
  const threshold = Number.isFinite(Number(opts.threshold)) ? Number(opts.threshold) : 0.1
  const stopPct = Number.isFinite(Number(opts.stopPct)) ? Number(opts.stopPct) : 30
  const requestedWindow = Math.max(60, Math.min(360, Math.floor(Number(opts.windowSize || 360))))
  const rows = Array.isArray(candles)
    ? candles
        .map(candle => ({
          time: Math.floor(Number(candle.time || 0)),
          close: Number(candle.close),
        }))
        .filter(row => row.time > 0 && Number.isFinite(row.close) && row.close > 0)
        .sort((a, b) => a.time - b.time)
    : []
  const windowSize = Math.max(60, Math.min(requestedWindow, Math.floor(rows.length * 0.75)))
  if (rows.length < windowSize + 2) {
    return { markers: [], stats: { trades: 0, corr_defined: 0, messages: 0, window: windowSize, insufficient_history: true } }
  }

  const densityByMinute = new Map()
  let messages = 0
  for (const row of socialRows || []) {
    const sec = Math.floor(Number(row.bucket_sec || timestampSeconds(row.time) || row.time || 0) / 60) * 60
    if (!sec) continue
    const count = Number(row.message_count ?? row.count ?? row.message_density ?? 0) || 0
    densityByMinute.set(sec, (densityByMinute.get(sec) || 0) + count)
    messages += count
  }

  const densities = rows.map(row => densityByMinute.get(Math.floor(row.time / 60) * 60) || 0)
  const correlations = Array(rows.length).fill(null)
  for (let i = windowSize - 1; i < rows.length; i += 1) {
    const priceWindow = rows.slice(i - windowSize + 1, i + 1).map(row => row.close)
    const densityWindow = densities.slice(i - windowSize + 1, i + 1)
    const meanPrice = priceWindow.reduce((sum, value) => sum + value, 0) / windowSize
    const meanDensity = densityWindow.reduce((sum, value) => sum + value, 0) / windowSize
    let covariance = 0
    let priceVariance = 0
    let densityVariance = 0
    for (let j = 0; j < windowSize; j += 1) {
      const dp = priceWindow[j] - meanPrice
      const dd = densityWindow[j] - meanDensity
      covariance += dp * dd
      priceVariance += dp * dp
      densityVariance += dd * dd
    }
    if (priceVariance > 0 && densityVariance > 0) {
      correlations[i] = covariance / Math.sqrt(priceVariance * densityVariance)
    }
  }

  const stopFraction = Math.max(1, Math.min(80, stopPct)) / 100
  const markers = []
  let trades = 0
  let i = 1
  while (i < rows.length) {
    const prev = correlations[i - 1]
    const current = correlations[i]
    if (!(prev != null && current != null && prev < threshold && current >= threshold)) {
      i += 1
      continue
    }
    const entry = rows[i]
    let peak = entry.close
    let exitIndex = rows.length - 1
    let reason = "session_end"
    for (let j = i + 1; j < rows.length; j += 1) {
      peak = Math.max(peak, rows[j].close)
      if (rows[j].close <= peak * (1 - stopFraction)) {
        exitIndex = j
        reason = "price_trailing_stop"
        break
      }
    }
    markers.push({
      time: entry.time,
      type: "entry",
      price: Number(entry.close.toFixed(4)),
      corr: Number(current.toFixed(4)),
      strategy: "density_correlation",
      source: "chart_social_series_proxy",
    })
    markers.push({
      time: rows[exitIndex].time,
      type: "exit",
      price: Number(rows[exitIndex].close.toFixed(4)),
      reason,
      strategy: "density_correlation",
      source: "chart_social_series_proxy",
    })
    trades += 1
    i = exitIndex + 1
  }

  return {
    markers,
    stats: {
      trades,
      corr_defined: correlations.filter(value => value != null).length,
      messages: Number(messages.toFixed(3)),
      threshold,
      stop_pct: stopPct,
      window: windowSize,
      proxy_based: true,
      note: "Density-correlation strategy uses FlashFeed chart social/news density; sentiment-scout used StockTwits-only density.",
    },
  }
}

function snapMarkersToCandles(markers = [], candles = []) {
  if (!Array.isArray(markers) || !markers.length || !Array.isArray(candles) || !candles.length) return []
  const times = candles.map(candle => Number(candle.time || 0)).filter(time => time > 0).sort((a, b) => a - b)
  if (!times.length) return []
  const minTime = times[0]
  const maxTime = times[times.length - 1]
  const findNearest = (time) => {
    if (time <= minTime) return minTime
    if (time >= maxTime) return maxTime
    let lo = 0
    let hi = times.length - 1
    while (lo < hi) {
      const mid = Math.floor((lo + hi) / 2)
      if (times[mid] < time) lo = mid + 1
      else hi = mid
    }
    const after = times[lo]
    const before = times[Math.max(0, lo - 1)]
    return Math.abs(after - time) < Math.abs(time - before) ? after : before
  }
  return markers
    .filter(marker => Number(marker.time || 0) >= minTime && Number(marker.time || 0) <= maxTime)
    .map(marker => ({ ...marker, raw_time: Number(marker.time), time: findNearest(Number(marker.time)) }))
}

async function chartPredictionEvents(db, ticker, windowMinutes = 1440) {
  const sinceSec = Math.floor(Date.now() / 1000) - Math.max(60, Number(windowMinutes || 1440)) * 60
  const docs = await db.collection("prediction_signals").find(
    {
      ticker,
      signal_sec: { $gte: sinceSec },
    },
    {
      projection: {
        ticker: 1,
        signal_sec: 1,
        entry_price: 1,
        decision: 1,
        rank: 1,
        trade_watch: 1,
        baseline_signal: 1,
        model_signal: 1,
        labels: 1,
      },
    }
  ).sort({ signal_sec: 1 }).limit(40).toArray()

  return docs.map(doc => {
    const modelDirection = doc.model_signal?.direction
    const baselineDirection = doc.baseline_signal?.direction || "watch"
    const direction = modelDirection || baselineDirection
    const label5m = doc.labels?.return_5m
    const correct = label5m?.direction_correct
    const color = correct === true
      ? "#22c55e"
      : correct === false
        ? "#f97316"
        : direction === "down"
          ? "#fb7185"
          : "#f59e0b"
    const predictedReturn = doc.model_signal?.predicted_return_5m
    return {
      time: Number(doc.signal_sec || 0),
      position: direction === "down" ? "aboveBar" : "belowBar",
      color,
      shape: direction === "down" ? "arrowDown" : "arrowUp",
      text: direction === "watch" ? "PRED" : `PRED ${String(direction).toUpperCase()}`,
      title: [
        `Trade Watch ${doc.decision || "signal"}`,
        predictedReturn != null ? `model 5m ${Number(predictedReturn).toFixed(2)}%` : "",
        label5m?.return_pct != null ? `actual 5m ${Number(label5m.return_pct).toFixed(2)}%` : "",
      ].filter(Boolean).join("; "),
      source: "Prediction",
      sentiment: direction === "down" ? "bearish" : direction === "up" ? "bullish" : "neutral",
      sentiment_score: Number(doc.trade_watch?.trade_watch_score || 0),
      event_type: "prediction_signal",
      entry_price: doc.entry_price || null,
      model_signal: doc.model_signal || null,
      baseline_signal: doc.baseline_signal || null,
      label_5m: label5m || null,
    }
  }).filter(event => event.time > 0)
}

async function chartSocialSeries(db, ticker, windowMinutes, bucketMinutes, options = {}) {
  const fallbackUntil = Math.floor(Date.now() / 1000)
  const requestedStart = Number(options.startSec || options.start_sec || 0)
  const requestedEnd = Number(options.endSec || options.end_sec || 0)
  const sinceSec = Number.isFinite(requestedStart) && requestedStart > 0
    ? Math.floor(requestedStart)
    : fallbackUntil - windowMinutes * 60
  const untilSec = Number.isFinite(requestedEnd) && requestedEnd > sinceSec
    ? Math.floor(requestedEnd)
    : fallbackUntil
  const bucketSec = bucketMinutes * 60
  const [socialRows, articleRows] = await Promise.all([
    db.collection("socials").aggregate([
    ...socialTimeStages(),
    { $match: { _event_sec: { $gte: sinceSec, $lte: untilSec } } },
    { $match: { _ticker_candidates: ticker } },
    {
      $addFields: {
        _bucket_sec: { $multiply: [{ $floor: { $divide: ["$_event_sec", bucketSec] } }, bucketSec] },
        _score: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    {
      $group: {
        _id: "$_bucket_sec",
        message_count: { $sum: 1 },
        sentiment: { $avg: "$_score" },
        platforms: { $addToSet: "$_norm_platform" },
      },
    },
    { $sort: { _id: 1 } },
  ]).toArray(),
    db.collection("articles").aggregate([
      ...articleTickerCandidateStages(),
      { $unwind: "$_ticker_parts" },
      { $match: { _ticker_parts: ticker } },
      {
        $addFields: {
          _publish_sec: timestampSecondsExpression("$publish_date"),
          _fetch_sec: timestampSecondsExpression("$fetched_date"),
          _detected_sec: timestampSecondsExpression("$detected_at"),
          _created_sec: timestampSecondsExpression("$createdAt"),
        },
      },
      {
        $addFields: {
          _activity_sec: { $max: ["$_publish_sec", "$_fetch_sec", "$_detected_sec", "$_created_sec"] },
          _event_sec: {
            $cond: [
              { $gt: ["$_publish_sec", 0] },
              "$_publish_sec",
              { $max: ["$_fetch_sec", "$_detected_sec", "$_created_sec"] },
            ],
          },
        },
      },
      { $match: { _event_sec: { $gte: sinceSec, $lte: untilSec } } },
      {
        $addFields: {
          _bucket_sec: { $multiply: [{ $floor: { $divide: ["$_event_sec", bucketSec] } }, bucketSec] },
          _sentiment_direction: {
            $switch: {
              branches: [
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
              ],
              default: 0,
            },
          },
        },
      },
      {
        $addFields: {
          _score: {
            $switch: {
              branches: [
                { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
                { case: { $in: [{ $type: "$ml_confidence" }, ["int", "long", "double", "decimal"]] }, then: { $multiply: ["$_sentiment_direction", { $toDouble: "$ml_confidence" }] } },
              ],
              default: "$_sentiment_direction",
            },
          },
        },
      },
      {
        $group: {
          _id: "$_bucket_sec",
          article_count: { $sum: 1 },
          sentiment: { $avg: "$_score" },
          sources: { $addToSet: "$source" },
        },
      },
      { $sort: { _id: 1 } },
    ]).toArray(),
  ])

  const byBucket = new Map()
  for (const row of socialRows) {
    const key = Number(row._id || 0)
    if (!key) continue
    const count = Number(row.message_count || 0)
    const sentiment = Number(row.sentiment || 0)
    byBucket.set(key, {
      time: key,
      bucket_sec: key,
      social_count: count,
      article_count: 0,
      sentiment_sum: sentiment * count,
      evidence_count: count,
      platforms: row.platforms || [],
      sources: [],
    })
  }
  for (const row of articleRows) {
    const key = Number(row._id || 0)
    if (!key) continue
    const count = Number(row.article_count || 0)
    const sentiment = Number(row.sentiment || 0)
    const current = byBucket.get(key) || {
      time: key,
      bucket_sec: key,
      social_count: 0,
      article_count: 0,
      sentiment_sum: 0,
      evidence_count: 0,
      platforms: [],
      sources: [],
    }
    current.article_count += count
    current.sentiment_sum += sentiment * count
    current.evidence_count += count
    current.sources = Array.from(new Set([...(current.sources || []), ...(row.sources || [])].filter(Boolean))).slice(0, 8)
    byBucket.set(key, current)
  }

  const rows = Array.from(byBucket.values()).sort((a, b) => Number(a.time || 0) - Number(b.time || 0))
  return addSessionScaledSocialFields(rows.map(row => {
    const count = Number(row.evidence_count || 0)
    return {
      time: Number(row.time || 0),
      bucket_sec: Number(row.bucket_sec || 0),
      session: marketSessionForSec(row.bucket_sec),
      message_count: count,
      message_density: Number((count / bucketMinutes).toFixed(3)),
      sentiment: count ? Number((Number(row.sentiment_sum || 0) / count).toFixed(3)) : 0,
      social_count: Number(row.social_count || 0),
      article_count: Number(row.article_count || 0),
      platforms: row.platforms || [],
      sources: row.sources || [],
    }
  }), bucketMinutes)
}

// Full multi-timeframe selector → (Yahoo fetch range, base interval, resample-to
// minutes). Odd buckets (3m/10m/2h/5h/12h/2d) are resampled from a finer base on
// the server so the candlestick + RSI + MACD all line up. raw fetch is used so the
// longer histories aren't clipped by the default range caps.
const CHART_TF_MAP = {
  "1m":  { range: "1d",  interval: "1m",  resample: 0 },
  "3m":  { range: "5d",  interval: "1m",  resample: 3 },
  "5m":  { range: "5d",  interval: "5m",  resample: 0 },
  "10m": { range: "1mo", interval: "5m",  resample: 10 },
  "15m": { range: "1mo", interval: "15m", resample: 0 },
  "30m": { range: "1mo", interval: "30m", resample: 0 },
  "1h":  { range: "6mo", interval: "1h",  resample: 0 },
  "2h":  { range: "1y",  interval: "1h",  resample: 120 },
  "5h":  { range: "1y",  interval: "1h",  resample: 300 },
  "12h": { range: "1y",  interval: "1h",  resample: 720 },
  "1d":  { range: "2y",  interval: "1d",  resample: 0 },
  "2d":  { range: "5y",  interval: "1d",  resample: 2880 },
  "1w":  { range: "5y",  interval: "1wk", resample: 0 },
}
function resampleCandlesByMinutes(candles, minutes) {
  if (!minutes || minutes <= 0 || !candles.length) return candles
  const sizeSec = minutes * 60
  const buckets = new Map()
  for (const c of candles) {
    const t = Number(c.time)
    if (!Number.isFinite(t)) continue
    const bStart = Math.floor(t / sizeSec) * sizeSec
    const b = buckets.get(bStart)
    if (!b) buckets.set(bStart, { time: bStart, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 })
    else { b.high = Math.max(b.high, c.high); b.low = Math.min(b.low, c.low); b.close = c.close; b.volume += c.volume || 0 }
  }
  return [...buckets.values()].sort((a, b) => a.time - b.time)
}

app.get("/api/charts/:ticker", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, candles: [], error: "MongoDB is not connected" })

    const ticker = normalizeTickerList([req.params.ticker], 1, { ensurePrivate: false })[0] || ""
    if (!ticker) return res.status(400).json({ ok: false, candles: [], error: "ticker is required" })

    // Three ways to ask for candles, in priority order:
    //   1. tf= (1m,3m,5m,10m,15m,30m,1h,2h,5h,12h,1d,2d,1w) — the full multi-timeframe
    //      selector; server fetches the right history and resamples odd buckets.
    //   2. window= (full/2h/1h) — Aman's intraday 1-min views + density/sentiment overlays.
    //   3. range=&interval= — the original FlashFeed contract (back-compat).
    const tfParam = String(req.query.tf || "").toLowerCase()
    const tfDef = CHART_TF_MAP[tfParam]
    const windowParam = String(req.query.window || "").toLowerCase()
    const intradayWindow = !tfDef && ["full", "2h", "1h"].includes(windowParam)
    let range, interval, resampleMin = 0, rawFetch = false
    if (tfDef) {
      range = tfDef.range; interval = tfDef.interval; resampleMin = tfDef.resample; rawFetch = true
    } else if (intradayWindow) {
      range = "1d"; interval = "1m"
    } else {
      range = String(req.query.range || "3mo"); interval = yahooIntervalFor(req.query.interval || "1d")
    }
    const isMinute = interval.endsWith("m")
    const socialWindow = Math.max(60, Math.min(4320, Number(req.query.window_minutes || (isMinute ? 1440 : 4320))))
    const socialBucket = Math.max(1, Math.min(60, Number(req.query.bucket_minutes || (interval === "1m" ? 1 : 5))))

    let candleResult = { candles: [], provider_range: null, provider_interval: null }
    let priceStatus = "unavailable"
    let priceDetail = ""
    try {
      candleResult = await fetchYahooCandles(ticker, range, interval, { raw: rawFetch })
      priceStatus = candleResult.candles.length ? "working" : "no_bars_returned"
    } catch (err) {
      priceDetail = String(err.message || err)
    }

    // The multi-timeframe (tf=) path usually only needs OHLC + indicators — the
    // chart grid polls this route frequently and fetches social separately. The
    // single chart can opt into DB-backed event overlays with events=1.
    let socialRows = [], newsEvents = [], predictionEvents = []
    const includeChartEvents = !tfDef || String(req.query.events || req.query.include_events || "") === "1"
    if (includeChartEvents) {
      ;[socialRows, newsEvents, predictionEvents] = await Promise.all([
        chartSocialSeries(db, ticker, socialWindow, socialBucket),
        chartNewsEvents(db, ticker, socialWindow),
        chartPredictionEvents(db, ticker, socialWindow),
      ])
    }
    let candles = candleResult.candles
    if (resampleMin > 0) candles = resampleCandlesByMinutes(candles, resampleMin)
    // Optional intraday window slice (Aman's Last-2h / Last-1h controls).
    let viewCandles = candles
    if (intradayWindow && (windowParam === "2h" || windowParam === "1h") && candles.length) {
      const lastTime = Number(candles[candles.length - 1].time || 0)
      const spanSec = (windowParam === "2h" ? 2 : 1) * 3600
      viewCandles = candles.filter(c => Number(c.time || 0) >= lastTime - spanSec)
    }
    const strategyResult = includeChartEvents
      ? densityCorrelationStrategyMarkers(candleResult.candles, socialRows)
      : { markers: [], stats: null }
    const strategyMarkers = snapMarkersToCandles(strategyResult.markers, viewCandles)
    // Session date (YYYY-MM-DD, ET) used by Aman's charts header + research views.
    let sessionDate = ""
    try {
      const lastSec = Number((viewCandles[viewCandles.length - 1] || candles[candles.length - 1] || {}).time || 0)
      const d = lastSec ? new Date(lastSec * 1000) : new Date()
      sessionDate = new Intl.DateTimeFormat("en-CA", { timeZone: MARKET_WINDOW_TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit" }).format(d)
    } catch (_) { sessionDate = new Date().toISOString().slice(0, 10) }

    const quoteDoc = await db.collection("screeners").findOne({ ticker }).catch(() => null)
    const quoteRow = normalizeScreenerDoc(quoteDoc || { ticker })
    const quoteUpdatedSec = timestampSeconds(quoteDoc?.quote_updated_at || quoteDoc?.updated_at || quoteDoc?.updatedAt || quoteRow.quote_time)
    const currentQuote = quoteDoc ? {
      price: quoteRow.price,
      change_pct: quoteRow.change_pct,
      volume: quoteRow.volume,
      rel_volume: quoteRow.rel_volume,
      previous_close: quoteRow.previous_close,
      previous_close_status: quoteRow.previous_close_status,
      quote_source: quoteRow.quote_source,
      quote_time: quoteRow.quote_time,
      quote_status: quoteRow.quote_status,
      updated_at: quoteDoc?.quote_updated_at || quoteDoc?.updated_at || quoteDoc?.updatedAt || null,
      updated_sec: quoteUpdatedSec || null,
      age_seconds: quoteUpdatedSec ? Math.max(0, Math.floor(Date.now() / 1000) - quoteUpdatedSec) : null,
    } : null

    let candleChangePct = null
    if (viewCandles.length >= 2) {
      const lastClose = Number(viewCandles[viewCandles.length - 1]?.close)
      const prevClose = Number(viewCandles[viewCandles.length - 2]?.close)
      if (Number.isFinite(lastClose) && Number.isFinite(prevClose) && prevClose > 0) {
        candleChangePct = Number((((lastClose - prevClose) / prevClose) * 100).toFixed(2))
      }
    }
    const quoteChangePct = Number(currentQuote?.change_pct)
    const quoteDisagreesWithCandles = Number.isFinite(candleChangePct) &&
      Number.isFinite(quoteChangePct) &&
      Math.abs(candleChangePct) > 100 &&
      Math.abs(candleChangePct - quoteChangePct) > 50
    const chartEvents = [...newsEvents, ...chartSocialEvents(socialRows), ...predictionEvents].sort((a, b) => Number(a.time || 0) - Number(b.time || 0))
    res.json({
      ok: true,
      ticker,
      range,
      interval,
      tf: tfParam || undefined,
      window: windowParam || undefined,
      date: sessionDate,
      n: viewCandles.length,
      candles: viewCandles,
      bollinger: viewCandles.length >= 20 ? bollinger(viewCandles) : { upper: [], lower: [] },
      rsi: viewCandles.length >= 15 ? rsi(viewCandles) : [],
      macd: macd(viewCandles),
      predicted: predictedPriceSeries(viewCandles),
      current_quote: currentQuote,
      news_events: chartEvents,
      structured_news_events: newsEvents,
      social_events: chartEvents.filter(event => event.event_type === "social_spike"),
      prediction_events: predictionEvents,
      strategy_markers: strategyMarkers,
      strategy_signal_stats: strategyResult.stats,
      sentiment: socialRows.map(row => ({ time: row.time, value: row.sentiment })),
      social_density: socialRows.map(row => ({ time: row.time, value: row.message_density, scaled: row.message_density_scaled, count: row.message_count, session: row.session })),
      social_series: socialRows,
      source_status: {
        price: priceStatus,
        price_source: priceStatus === "working" ? "market_chart_provider" : "unavailable",
        price_detail: quoteDisagreesWithCandles
          ? `chart candles imply ${candleChangePct}% while screener quote says ${quoteChangePct}%; header should prefer screener quote for current-session change`
          : priceDetail,
        candle_change_pct: candleChangePct,
        quote_change_pct: Number.isFinite(quoteChangePct) ? quoteChangePct : null,
        quote_disagrees_with_candles: quoteDisagreesWithCandles,
        screener_source: "Listed momentum screener universe",
        social: socialRows.length ? "working" : "no_social_posts",
        news: newsEvents.length ? "working" : "no_matched_news",
        predictions: predictionEvents.length ? "working" : "no_prediction_signals",
        markers: chartEvents.length ? "working" : "no_events",
      },
      provider_range: candleResult.provider_range,
      provider_interval: candleResult.provider_interval,
    })
  } catch (err) {
    console.error("GET /api/charts/:ticker failed:", err)
    res.status(500).json({ ok: false, candles: [], error: String(err.message || err) })
  }
})

// ─────────────────────────────────────────────────────────────────────────────
//  Chart-support endpoints for the swapped-in Aman charts
//  (candlestick + research views + per-ticker enrich panel + grid sparklines).
//  All are additive and reuse FlashFeed's existing chart/social helpers.
// ─────────────────────────────────────────────────────────────────────────────
function etHHMM(sec) {
  const n = Number(sec || 0)
  if (!n) return ""
  try {
    return new Intl.DateTimeFormat("en-GB", { timeZone: MARKET_WINDOW_TIME_ZONE, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(n * 1000))
  } catch (_) { return "" }
}
function etDate(sec) {
  const d = sec ? new Date(Number(sec) * 1000) : new Date()
  try { return new Intl.DateTimeFormat("en-CA", { timeZone: MARKET_WINDOW_TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit" }).format(d) }
  catch (_) { return new Date().toISOString().slice(0, 10) }
}

// GET /api/chart — intraday price series for the research views (ResearchChart).
app.get("/api/chart", async (req, res) => {
  try {
    const ticker = normalizeTickerList([req.query.ticker], 1, { ensurePrivate: false })[0] || ""
    if (!ticker) return res.status(400).json({ error: "ticker is required" })
    const windowParam = String(req.query.window || "full").toLowerCase()
    let cr = { candles: [] }
    try { cr = await fetchYahooCandles(ticker, "1d", "1m") } catch (_) {}
    let candles = cr.candles || []
    if ((windowParam === "2h" || windowParam === "1h") && candles.length) {
      const lastTime = Number(candles[candles.length - 1].time || 0)
      const spanSec = (windowParam === "2h" ? 2 : 1) * 3600
      candles = candles.filter(c => Number(c.time || 0) >= lastTime - spanSec)
    }
    const date = etDate(Number((candles[candles.length - 1] || {}).time || 0))
    res.json({
      ticker, date,
      labels: candles.map(c => etHHMM(c.time)),
      prices: candles.map(c => Number(c.close ?? 0)),
      volumes: candles.map(c => Number(c.volume ?? 0)),
    })
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) })
  }
})

// GET /api/chart/social — per-minute density + sentiment series for both the
// candlestick overlays and the research views. Derived from FlashFeed's social
// rolling series; returns a graceful empty payload when there is no social data.
app.get("/api/chart/social", async (req, res) => {
  try {
    const db = mongoose.connection.db
    const ticker = normalizeTickerList([req.query.ticker], 1, { ensurePrivate: false })[0] || ""
    if (!ticker) return res.status(400).json({ error: "ticker is required" })
    const windowMinutes = Math.max(60, Math.min(10080, Number(req.query.window_minutes || 1440)))
    const bucketMinutes = Math.max(1, Math.min(60, Number(req.query.bucket_minutes || 1)))
    const startSec = Number(req.query.start_sec || req.query.start || 0)
    const endSec = Number(req.query.end_sec || req.query.end || 0)
    let rows = []
    try { rows = db ? await chartSocialSeries(db, ticker, windowMinutes, bucketMinutes, { startSec, endSec }) : [] } catch (_) { rows = [] }
    if (!rows.length) {
      return res.json({
        status: "ok", source: "none", messages: 0, bullish: 0, bearish: 0, complete: true,
        labels: [], times: [], density: [], density_smooth: [], sent_labels: [], sent_times: [], scores: [], scores_smooth: [],
        win_density: [], win_density_smooth: [], window_minutes: windowMinutes, bucket_minutes: bucketMinutes,
      })
    }
    const times = rows.map(r => Number(r.time || 0))
    const labels = rows.map(r => etHHMM(r.time))
    const density = rows.map(r => Number(r.message_density ?? 0))
    const scores = rows.map(r => Number(r.sentiment ?? 0))
    const messages = rows.reduce((a, r) => a + Number(r.message_count ?? 0), 0)
    const bullish = rows.reduce((a, r) => a + (Number(r.sentiment ?? 0) > 0.1 ? Number(r.message_count ?? 0) : 0), 0)
    const bearish = rows.reduce((a, r) => a + (Number(r.sentiment ?? 0) < -0.1 ? Number(r.message_count ?? 0) : 0), 0)
    const articleMessages = rows.reduce((a, r) => a + Number(r.article_count ?? 0), 0)
    const socialMessages = rows.reduce((a, r) => a + Number(r.social_count ?? 0), 0)
    res.json({
      status: "ok", source: "feedflash-news-social", messages, social_messages: socialMessages, article_messages: articleMessages, bullish, bearish, complete: true,
      labels, times, density, density_smooth: density,
      sent_labels: labels, sent_times: times, scores, scores_smooth: scores,
      win_density: density, win_density_smooth: density, window_minutes: windowMinutes, bucket_minutes: bucketMinutes,
    })
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) })
  }
})

// GET /api/ticker/:ticker/enrich — the per-ticker enrichment panel below the
// chart: the last-3-day news feed + a social/gossip summary. Pure DB reads.
app.get("/api/ticker/:ticker/enrich", async (req, res) => {
  const ticker = normalizeTickerList([req.params.ticker], 1, { ensurePrivate: false })[0] || ""
  const ENRICH_DAYS = 3
  const empty = {
    ticker, news_alert: false, news_alert_count: 0,
    news: { days: ENRICH_DAYS, articles: [], ai: null, sources: [], source_filter_active: false, note: "Last 3 days · FlashFeed structured news" },
    social: { stocktwits: null, bluesky: { configured: false, metrics: null }, reddit: { configured: false, metrics: null }, rumor: null, future_sources: ["X"] },
  }
  try {
    const db = mongoose.connection.db
    if (!db || !ticker) return res.json(empty)
    const tickerRe = new RegExp(`(^|,)\\s*${escapeRegExp(ticker)}\\s*(,|$)`, "i")
    let docs = []
    try {
      docs = await db.collection("articles").find(
        {
          $and: [
            recentArticleMatch(ENRICH_DAYS),
            { $or: [{ ticker }, { ticker: tickerRe }, { tickers: ticker }, { symbol: ticker }] },
          ],
        },
        { projection: { title: 1, source: 1, url: 1, publish_date: 1, fetched_date: 1, detected_at: 1, createdAt: 1, sentiment: 1, sentiment_score: 1, finbert_score: 1, vader_score: 1, ml_confidence: 1 } },
      ).sort({ publish_date: -1, fetched_date: -1, detected_at: -1, _id: -1 }).limit(40).toArray()
    } catch (_) { docs = [] }
    const articles = docs.map((d, i) => {
      const when = d.publish_date || d.fetched_date || d.detected_at || d.createdAt
      const sec = timestampSeconds(when) || null
      const explicitScore = Number(d.sentiment_score ?? d.finbert_score ?? d.vader_score)
      const score = Number.isFinite(explicitScore)
        ? explicitScore
        : (d.sentiment === "bullish" ? (d.ml_confidence ?? 0.5) : d.sentiment === "bearish" ? -(d.ml_confidence ?? 0.5) : 0)
      return {
        id: String(d._id || `a-${i}`),
        headline: d.title || "(untitled)",
        source: d.source || "unknown",
        url: d.url && d.url !== "#" ? d.url : null,
        published_at: sec,
        sentiment: d.sentiment || "neutral",
        sentiment_score: Number(score.toFixed(2)),
      }
    })
    const sources = [...new Set(articles.map(a => a.source))].slice(0, 12)

    // Platform-specific social summary for the chart enrichment panel.
    const socialWindowHours = 72
    const socialSinceSec = Math.floor(Date.now() / 1000) - socialWindowHours * 3600
    const scoreSocialPost = (post) => {
      const explicit = Number(post.sentiment_score)
      if (Number.isFinite(explicit)) return explicit
      const sentiment = String(post.sentiment || "").toLowerCase()
      if (/bull|positive/.test(sentiment)) return 1
      if (/bear|negative/.test(sentiment)) return -1
      return 0
    }
    const summarizeSocialPosts = (posts) => {
      const rows = Array.isArray(posts) ? posts : []
      if (!rows.length) return null
      const scores = rows.map(scoreSocialPost)
      const avg = scores.reduce((sum, value) => sum + value, 0) / Math.max(1, scores.length)
      return {
        sentiment: Number(avg.toFixed(2)),
        density: rows.length,
        bull: scores.filter(value => value > 0.1).length,
        bear: scores.filter(value => value < -0.1).length,
        window_hours: socialWindowHours,
        latest_sec: Math.max(...rows.map(row => Number(row.fetched_at || row.timestamp || row.created_at || 0)).filter(Number.isFinite), 0) || null,
      }
    }
    let socialRows = []
    let platformAvailability = []
    try {
      ;[socialRows, platformAvailability] = await Promise.all([
        db.collection("socials").aggregate([
          ...socialTimeStages(),
          { $match: { _event_sec: { $gte: socialSinceSec }, _ticker_candidates: ticker } },
          { $match: { _norm_platform: { $in: ["StockTwits", "Bluesky", "Reddit", "Twitter"] } } },
          { $sort: { _event_sec: -1 } },
          { $limit: 400 },
          {
            $project: {
              _id: 0,
              platform: "$_norm_platform",
              author: 1,
              text: { $ifNull: ["$text", { $ifNull: ["$content", "$title"] }] },
              sentiment: 1,
              sentiment_score: 1,
              gossip_keywords: 1,
              gossip_score: 1,
              url: 1,
              fetched_at: "$_event_sec",
              timestamp: 1,
              created_at: 1,
            },
          },
        ]).toArray(),
        db.collection("socials").aggregate([
          ...socialTimeStages(),
          { $match: { _norm_platform: { $in: ["StockTwits", "Bluesky", "Reddit", "Twitter"] } } },
          {
            $group: {
              _id: "$_norm_platform",
              total: { $sum: 1 },
              latest_sec: { $max: "$_event_sec" },
            },
          },
        ]).toArray(),
      ])
    } catch (_) {
      socialRows = []
      platformAvailability = []
    }

    const platformRows = (platform) => socialRows.filter(row => row.platform === platform)
    const availability = new Map(platformAvailability.map(row => [String(row._id || ""), row]))
    const stocktwits = summarizeSocialPosts(platformRows("StockTwits"))
    const blueskyMetrics = summarizeSocialPosts(platformRows("Bluesky"))
    const redditMetrics = summarizeSocialPosts(platformRows("Reddit"))
    const twitterMetrics = summarizeSocialPosts(platformRows("Twitter"))
    const blueskyConfigured = Boolean(blueskyMetrics || availability.get("Bluesky"))
    const redditConfigured = Boolean(
      redditMetrics ||
      availability.get("Reddit") ||
      process.env.REDDIT_ACCESS_TOKEN ||
      (process.env.REDDIT_CLIENT_ID && process.env.REDDIT_CLIENT_SECRET)
    )
    const twitterConfigured = Boolean(twitterMetrics || process.env.X_BEARER_TOKEN || process.env.TWITTER_BEARER_TOKEN)
    const rumorWords = /\brumou?r|hearing|unconfirmed|leak(?:ed)?|buyout|takeover|halt|news pending|squeeze|short squeeze\b/i
    const rumorPost = socialRows.find(row =>
      Number(row.gossip_score || 0) > 0 ||
      (Array.isArray(row.gossip_keywords) && row.gossip_keywords.length > 0) ||
      rumorWords.test(String(row.text || ""))
    )
    const rumor = rumorPost ? {
      text: String(rumorPost.text || "").slice(0, 500),
      direction: scoreSocialPost(rumorPost) >= 0.1 ? "Bullish rumor" : scoreSocialPost(rumorPost) <= -0.1 ? "Bearish rumor" : "Rumor",
      time: Number(rumorPost.fetched_at || 0) || null,
      author: rumorPost.author || null,
    } : null

    res.json({
      ticker,
      news_alert: articles.length > 0,
      news_alert_count: articles.length,
      news: { days: ENRICH_DAYS, articles, ai: null, sources, source_filter_active: false, note: "Last 3 days · FlashFeed structured news" },
      social: {
        stocktwits,
        bluesky: { configured: blueskyConfigured, metrics: blueskyMetrics },
        reddit: { configured: redditConfigured, metrics: redditMetrics },
        rumor,
        future_sources: twitterConfigured ? ["X/Twitter"] : ["X/Twitter · credentials needed"],
      },
    })
  } catch (err) {
    console.error("GET /api/ticker/:ticker/enrich failed:", err.message)
    res.json(empty)
  }
})

// GET /api/charts/grid-image/:ticker — server-rendered SVG sparkline for the
// Charts Grid (Aman's grid used Python PNGs; this is a pure-Node SVG so it needs
// no native canvas). Green/red by net change, white background to match the grid.
const GRID_TF_MAP = {
  "1m": ["1d", "1m"], "3m": ["5d", "5m"], "5m": ["5d", "5m"], "15m": ["1mo", "15m"],
  "1h": ["1mo", "1h"], "d": ["6mo", "1d"], "w": ["1y", "1wk"],
}
app.get("/api/charts/grid-image/:ticker", async (req, res) => {
  const W = 320, H = 132, PAD = 6
  const placeholder = (msg) =>
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">` +
    `<rect width="${W}" height="${H}" fill="#ffffff"/>` +
    `<text x="${W / 2}" y="${H / 2}" fill="#94a3b8" font-family="monospace" font-size="12" text-anchor="middle">${msg}</text></svg>`
  res.set("Content-Type", "image/svg+xml")
  res.set("Cache-Control", "public, max-age=45")
  try {
    const ticker = normalizeTickerList([req.params.ticker], 1, { ensurePrivate: false })[0] || ""
    if (!ticker) return res.send(placeholder("no ticker"))
    const tf = String(req.query.tf || "5m").toLowerCase()
    const [range, interval] = GRID_TF_MAP[tf] || GRID_TF_MAP["5m"]
    let cr = { candles: [] }
    try { cr = await fetchYahooCandles(ticker, range, interval) } catch (_) {}
    const closes = (cr.candles || []).map(c => Number(c.close ?? 0)).filter(Number.isFinite)
    if (closes.length < 2) return res.send(placeholder(`${ticker} · no data`))
    const lo = Math.min(...closes), hi = Math.max(...closes), span = (hi - lo) || 1
    const up = closes[closes.length - 1] >= closes[0]
    const stroke = up ? "#10b981" : "#ef4444"
    const fill = up ? "rgba(16,185,129,0.12)" : "rgba(239,68,68,0.12)"
    const x = (i) => PAD + (i / (closes.length - 1)) * (W - 2 * PAD)
    const y = (v) => PAD + (1 - (v - lo) / span) * (H - 2 * PAD - 14)
    const pts = closes.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ")
    const area = `${PAD},${(H - PAD - 14).toFixed(1)} ${pts} ${(W - PAD).toFixed(1)},${(H - PAD - 14).toFixed(1)}`
    const last = closes[closes.length - 1]
    const pct = (((last - closes[0]) / (closes[0] || 1)) * 100)
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">` +
      `<rect width="${W}" height="${H}" fill="#ffffff"/>` +
      `<polygon points="${area}" fill="${fill}" stroke="none"/>` +
      `<polyline points="${pts}" fill="none" stroke="${stroke}" stroke-width="1.6"/>` +
      `<text x="${PAD}" y="${H - 4}" fill="#475569" font-family="monospace" font-size="11">${ticker} ${tf}</text>` +
      `<text x="${W - PAD}" y="${H - 4}" fill="${stroke}" font-family="monospace" font-size="11" text-anchor="end">$${last.toFixed(2)} ${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%</text>` +
      `</svg>`
    return res.send(svg)
  } catch (err) {
    return res.send(placeholder("chart error"))
  }
})

function articlePrimaryTicker(article) {
  return normalizeTickerList(String(article?.ticker || "").split(","), 1, { ensurePrivate: false })[0] || ""
}

function nearestCandleAtOrAfter(candles, targetSec) {
  if (!Array.isArray(candles) || !candles.length || !Number.isFinite(targetSec)) return null
  let best = null
  for (const candle of candles) {
    const time = Number(candle.time || 0)
    if (time >= targetSec) {
      best = candle
      break
    }
  }
  return best || candles[candles.length - 1]
}

function postEventReturns(candles, eventSec) {
  const base = nearestCandleAtOrAfter(candles, eventSec)
  const baseClose = Number(base?.close || 0)
  if (!base || !baseClose) return null
  const horizons = [
    ["return_1m", 60],
    ["return_5m", 300],
    ["return_15m", 900],
    ["return_1h", 3600],
  ]
  const out = {
    base_time: Number(base.time),
    base_close: Number(baseClose.toFixed(4)),
  }
  for (const [key, seconds] of horizons) {
    const future = nearestCandleAtOrAfter(candles, eventSec + seconds)
    const futureClose = Number(future?.close || 0)
    out[key] = futureClose ? Number((((futureClose - baseClose) / baseClose) * 100).toFixed(3)) : null
  }
  return out
}

app.get("/api/correlation/post-news", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: "MongoDB is not connected" })

    const limit = Math.max(1, Math.min(120, Number(req.query.limit || 50)))
    const days = Math.max(1, Math.min(5, Number(req.query.days || 3)))
    const requestedTicker = normalizeTickerList([req.query.ticker], 1, { ensurePrivate: false })[0] || ""
    const match = { ...recentArticleMatch(days), ticker: { $exists: true, $nin: ["", null] } }
    if (requestedTicker) match.ticker = { $regex: `(^|,\\s*)${escapeRegExp(requestedTicker)}(\\s*,|$)`, $options: "i" }

    const articles = await db.collection("articles").find(
      match,
      { projection: { title: 1, source: 1, url: 1, ticker: 1, sentiment: 1, sentiment_score: 1, ml_confidence: 1, event_type: 1, sentiment_reason: 1, publish_date: 1, fetched_date: 1, detected_at: 1, createdAt: 1 } }
    ).sort({ publish_date: -1, fetched_date: -1, detected_at: -1 }).limit(limit).toArray()

    const tickers = Array.from(new Set(articles.map(articlePrimaryTicker).filter(Boolean))).slice(0, 20)
    const candleMap = new Map()
    await Promise.all(tickers.map(async ticker => {
      try {
        const result = await fetchYahooCandles(ticker, "5d", "1m")
        candleMap.set(ticker, result.candles || [])
      } catch {
        candleMap.set(ticker, [])
      }
    }))

    const rows = articles.map(article => {
      const ticker = articlePrimaryTicker(article)
      const eventSec = timestampSeconds(article.publish_date || article.fetched_date || article.detected_at || article.createdAt)
      const score = Number(article.sentiment_score ?? article.ml_confidence ?? 0) || 0
      const returns = postEventReturns(candleMap.get(ticker), eventSec)
      return {
        id: String(article._id),
        ticker,
        title: article.title || "",
        source: article.source || "",
        url: article.url || "",
        sentiment: article.sentiment || "neutral",
        sentiment_score: score,
        event_type: article.event_type || "general_news",
        reason: article.sentiment_reason || "",
        event_time: eventSec,
        ...(returns || { base_time: null, base_close: null, return_1m: null, return_5m: null, return_15m: null, return_1h: null }),
      }
    }).filter(row => row.ticker)

    const withReturns = rows.filter(row => row.return_5m != null)
    const average = key => {
      const vals = withReturns.map(row => Number(row[key])).filter(Number.isFinite)
      return vals.length ? Number((vals.reduce((sum, value) => sum + value, 0) / vals.length).toFixed(3)) : null
    }

    res.json({
      ok: true,
      rows,
      summary: {
        articles: rows.length,
        priced_articles: withReturns.length,
        avg_return_1m: average("return_1m"),
        avg_return_5m: average("return_5m"),
        avg_return_15m: average("return_15m"),
        avg_return_1h: average("return_1h"),
      },
      horizons: ["1m", "5m", "15m", "1h"],
      note: "Returns use nearest available 1-minute market candle at or after the article timestamp.",
    })
  } catch (err) {
    console.error("GET /api/correlation/post-news failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get(["/api/sentiment/audit", "/api/sentiment/snapshot"], async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: "MongoDB is not connected" })
    const days = Math.max(1, Math.min(7, Number(req.query.days || 3)))
    const limit = Math.max(1, Math.min(200, Number(req.query.limit || 60)))
    const label = String(req.query.label || "").toLowerCase()
    const recentMatch = recentArticleMatch(days)
    const tickerMatch = { ...recentMatch, ticker: { $exists: true, $nin: ["", null] } }
    const actionableMatch = {
      ...tickerMatch,
      $or: [
        { sentiment: { $nin: ["neutral", null, ""] } },
        { event_type: { $exists: true, $nin: ["general_news", "unknown", null, ""] } },
      ],
    }
    const match = { ...tickerMatch }
    if (["bullish", "positive"].includes(label)) match.sentiment = { $regex: "bull|positive", $options: "i" }
    if (["bearish", "negative"].includes(label)) match.sentiment = { $regex: "bear|negative", $options: "i" }
    if (label === "neutral") match.sentiment = { $regex: "neutral", $options: "i" }

    const scoredProjection = {
      title: 1,
      source: 1,
      url: 1,
      ticker: 1,
      sentiment: 1,
      sentiment_score: 1,
      ml_confidence: 1,
      sentiment_method: 1,
      event_type: 1,
      event_score: 1,
      sentiment_reason: 1,
      publish_date: 1,
      fetched_date: 1,
      detected_at: 1,
    }
    const scoreStages = [
      {
        $addFields: {
          _sentiment_direction: {
            $switch: {
              branches: [
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
              ],
              default: 0,
            },
          },
        },
      },
      {
        $addFields: {
          _score: {
            $switch: {
              branches: [
                { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
                { case: { $in: [{ $type: "$ml_confidence" }, ["int", "long", "double", "decimal"]] }, then: { $multiply: ["$_sentiment_direction", { $toDouble: "$ml_confidence" }] } },
              ],
              default: "$_sentiment_direction",
            },
          },
        },
      },
    ]

    const socialWindowMinutes = Math.max(5, Math.min(4320, Number(req.query.window_minutes || 1440)))
    const socialSinceSec = Math.floor(Date.now() / 1000) - socialWindowMinutes * 60

    const [rows, total, tickerMatched, nonNeutral, eventful, actionable, sentimentSummary, topPositive, topNegative, sourceSummary, eventSummary, tickerSummary, socialSummary] = await Promise.all([
      db.collection("articles").find(
        match,
        { projection: scoredProjection }
      ).sort({ detected_at: -1, fetched_date: -1, publish_date: -1 }).limit(limit).toArray(),
      db.collection("articles").countDocuments(recentMatch),
      db.collection("articles").countDocuments(tickerMatch),
      db.collection("articles").countDocuments({ ...tickerMatch, sentiment: { $nin: ["neutral", null, ""] } }),
      db.collection("articles").countDocuments({ ...tickerMatch, event_type: { $exists: true, $nin: ["general_news", "unknown", null, ""] } }),
      db.collection("articles").countDocuments(actionableMatch),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        {
          $group: {
            _id: null,
            avg_sentiment: { $avg: "$_score" },
            avg_abs_sentiment: { $avg: { $abs: "$_score" } },
            scored: { $sum: { $cond: [{ $gt: [{ $abs: "$_score" }, 0.005] }, 1, 0] } },
          },
        },
      ]).toArray(),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        { $match: { _score: { $gt: 0.005 } } },
        { $sort: { _score: -1, detected_at: -1, fetched_date: -1, publish_date: -1 } },
        { $limit: 5 },
        { $project: { ...scoredProjection, sentiment_score: "$_score" } },
      ]).toArray(),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        { $match: { _score: { $lt: -0.005 } } },
        { $sort: { _score: 1, detected_at: -1, fetched_date: -1, publish_date: -1 } },
        { $limit: 5 },
        { $project: { ...scoredProjection, sentiment_score: "$_score" } },
      ]).toArray(),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        {
          $group: {
            _id: { $ifNull: ["$source", "Unknown"] },
            count: { $sum: 1 },
            avg_sentiment: { $avg: "$_score" },
            scored: { $sum: { $cond: [{ $gt: [{ $abs: "$_score" }, 0.005] }, 1, 0] } },
          },
        },
        { $sort: { count: -1 } },
        { $limit: 8 },
        { $project: { _id: 0, source: "$_id", count: 1, avg_sentiment: { $round: ["$avg_sentiment", 3] }, scored: 1 } },
      ]).toArray(),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        {
          $group: {
            _id: { $ifNull: ["$event_type", "general_news"] },
            count: { $sum: 1 },
            avg_sentiment: { $avg: "$_score" },
          },
        },
        { $sort: { count: -1 } },
        { $limit: 8 },
        { $project: { _id: 0, event_type: "$_id", count: 1, avg_sentiment: { $round: ["$avg_sentiment", 3] } } },
      ]).toArray(),
      db.collection("articles").aggregate([
        { $match: tickerMatch },
        ...scoreStages,
        {
          $group: {
            _id: "$ticker",
            count: { $sum: 1 },
            avg_sentiment: { $avg: "$_score" },
            latest: { $max: { $ifNull: ["$detected_at", { $ifNull: ["$fetched_date", "$publish_date"] }] } },
          },
        },
        { $sort: { count: -1, latest: -1 } },
        { $limit: 8 },
        { $project: { _id: 0, ticker: "$_id", count: 1, avg_sentiment: { $round: ["$avg_sentiment", 3] }, latest: 1 } },
      ]).toArray(),
      db.collection("socials").aggregate([
        ...socialTimeStages(),
        { $match: { _event_sec: { $gte: socialSinceSec }, _ticker_candidates: { $ne: [] } } },
        {
          $addFields: {
            _social_score: {
              $switch: {
                branches: [
                  { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
                  { case: { $in: [{ $type: "$sentiment" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment" } },
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
                ],
                default: 0,
              },
            },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            avg_sentiment: { $avg: "$_social_score" },
            bullish: { $sum: { $cond: [{ $gt: ["$_social_score", 0.05] }, 1, 0] } },
            bearish: { $sum: { $cond: [{ $lt: ["$_social_score", -0.05] }, 1, 0] } },
            neutral: { $sum: { $cond: [{ $lte: [{ $abs: "$_social_score" }, 0.05] }, 1, 0] } },
            platforms: { $addToSet: "$_norm_platform" },
          },
        },
      ]).toArray(),
    ])

    const mapAuditRow = row => ({
      id: String(row._id),
      ticker: row.ticker || "",
      title: row.title || "",
      source: row.source || "",
      url: row.url || "",
      sentiment: row.sentiment || "neutral",
      sentiment_score: Number(articleSentimentValue(row).toFixed(3)),
      confidence: Number(row.ml_confidence ?? Math.abs(articleSentimentValue(row))) || 0,
      method: row.sentiment_method || "unknown",
      event_type: row.event_type || "general_news",
      event_score: Number(row.event_score || 0),
      reason: row.sentiment_reason || "No high-impact phrase matched",
      publish_date: row.publish_date || row.fetched_date || row.detected_at || null,
    })

    const social = socialSummary[0] || {}
    const newsAvg = Number(sentimentSummary[0]?.avg_sentiment || 0)
    const socialAvg = Number(social.avg_sentiment || 0)
    const combinedWeight = Number(tickerMatched || 0) + Number(social.total || 0) * 0.75
    const combinedAvg = combinedWeight
      ? (newsAvg * Number(tickerMatched || 0) + socialAvg * Number(social.total || 0) * 0.75) / combinedWeight
      : 0

    res.json({
      ok: true,
      generated_at: new Date().toISOString(),
      rows: rows.map(mapAuditRow),
      top_positive: topPositive.map(mapAuditRow),
      top_negative: topNegative.map(mapAuditRow),
      sources: sourceSummary,
      event_types: eventSummary,
      ticker_breakdown: tickerSummary,
      days,
      social_window_minutes: socialWindowMinutes,
      summary: {
        total,
        ticker_matched: tickerMatched,
        non_neutral: nonNeutral,
        eventful,
        actionable,
        avg_sentiment: Number((sentimentSummary[0]?.avg_sentiment || 0).toFixed(3)),
        avg_abs_sentiment: Number((sentimentSummary[0]?.avg_abs_sentiment || 0).toFixed(3)),
        scored: Number(sentimentSummary[0]?.scored || 0),
        social_total: Number(social.total || 0),
        social_avg_sentiment: Number((social.avg_sentiment || 0).toFixed(3)),
        social_bullish: Number(social.bullish || 0),
        social_bearish: Number(social.bearish || 0),
        social_neutral: Number(social.neutral || 0),
        social_platforms: social.platforms || [],
        combined_avg_sentiment: Number(combinedAvg.toFixed(3)),
      },
      snapshot_mode: "news_and_social_signed_sentiment_snapshot",
      audit_mode: "deterministic_financial_phrase_with_event_taxonomy",
    })
  } catch (err) {
    console.error("GET /api/sentiment snapshot failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get("/api/sentiment/batch-candidates", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, items: [], error: "MongoDB is not connected" })
    const days = Math.max(1, Math.min(7, Number(req.query.days || 3)))
    const limit = Math.max(1, Math.min(150, Number(req.query.limit || 100)))
    const rows = await db.collection("articles").find(
      {
        ...recentArticleMatch(days),
        ticker: { $exists: true, $nin: ["", null] },
        $or: [
          { sentiment: { $regex: "neutral", $options: "i" } },
          { sentiment_score: { $gte: -0.12, $lte: 0.12 } },
          { sentiment_score: { $exists: false } },
        ],
      },
      { projection: { title: 1, content: 1, source: 1, ticker: 1, url: 1 } }
    ).sort({ detected_at: -1, fetched_date: -1, publish_date: -1 }).limit(limit).toArray()

    const items = rows.map((row, index) => ({
      id: String(row._id),
      batch_id: index + 1,
      ticker: row.ticker || "",
      source: row.source || "",
      headline: row.title || "",
      excerpt: String(row.content || "").slice(0, 500),
      url: row.url || "",
    }))

    res.json({
      ok: true,
      items,
      prompt: "Classify each item sentiment for the listed stock ticker. Echo id. Return label as positive, negative, neutral, or mixed; score from -1 to 1; event_type; short reason.",
      response_schema: {
        type: "array",
        items: {
          type: "object",
          required: ["id", "label", "score", "event_type", "reason"],
          properties: {
            id: { type: "string" },
            label: { enum: ["positive", "negative", "neutral", "mixed"] },
            score: { type: "number" },
            event_type: { type: "string" },
            reason: { type: "string" },
          },
        },
      },
      note: "This is the low-volume LLM batch queue for borderline/neutral articles; deterministic scoring remains live.",
    })
  } catch (err) {
    console.error("GET /api/sentiment/batch-candidates failed:", err)
    res.status(500).json({ ok: false, items: [], error: String(err.message || err) })
  }
})

app.get("/api/prediction/features", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: "MongoDB is not connected" })

    const limit = Math.max(10, Math.min(500, Number(req.query.limit || 150)))
    const days = Math.max(1, Math.min(14, Number(req.query.days || 3)))
    const socialWindow = Math.max(5, Math.min(1440, Number(req.query.window_minutes || 60)))
    const sinceSec = Math.floor(Date.now() / 1000) - socialWindow * 60

    const screenerRows = await db.collection("screeners").find(
      {
        ticker: { $exists: true, $nin: ["", null], $not: /\./ },
        exchange: { $in: ["NASDAQ", "NYSE", "AMEX"] },
        price: { $gt: 0 },
        change_pct: { $exists: true },
      },
      {
        projection: {
          ticker: 1,
          company: 1,
          exchange: 1,
          sector: 1,
          industry: 1,
          price: 1,
          change_pct: 1,
          volume: 1,
          avg_volume: 1,
          market_cap: 1,
          rel_volume: 1,
          rsi: 1,
          gap: 1,
          perf_week: 1,
          perf_month: 1,
          quote_updated_at: 1,
        },
      }
    ).sort({ volume: -1 }).limit(limit).toArray()

    const tickers = screenerRows.map(row => String(row.ticker || "").toUpperCase()).filter(Boolean)
    const [articleRows, socialRows] = await Promise.all([
      db.collection("articles").aggregate([
        { $match: { ...recentArticleMatch(days), ticker: { $exists: true, $nin: ["", null] } } },
        {
          $addFields: {
            _ticker_parts: {
              $map: {
                input: { $split: [{ $toUpper: { $toString: "$ticker" } }, ","] },
                as: "ticker_part",
                in: { $trim: { input: "$$ticker_part" } },
              },
            },
            _sentiment_direction: {
              $switch: {
                branches: [
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
                ],
                default: 0,
              },
            },
          },
        },
        { $unwind: "$_ticker_parts" },
        { $match: { _ticker_parts: { $in: tickers } } },
        {
          $addFields: {
            _score: {
              $switch: {
                branches: [
                  { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
                  { case: { $in: [{ $type: "$ml_confidence" }, ["int", "long", "double", "decimal"]] }, then: { $multiply: ["$_sentiment_direction", { $toDouble: "$ml_confidence" }] } },
                ],
                default: "$_sentiment_direction",
              },
            },
          },
        },
        {
          $group: {
            _id: "$_ticker_parts",
            article_count: { $sum: 1 },
            article_sentiment: { $avg: "$_score" },
            article_sentiment_abs: { $avg: { $abs: "$_score" } },
            event_count: {
              $sum: {
                $cond: [
                  { $not: { $in: ["$event_type", ["general_news", "unknown", null, ""]] } },
                  1,
                  0,
                ],
              },
            },
            latest_article_ts: { $max: "$detected_at" },
          },
        },
      ]).toArray(),
      db.collection("socials").aggregate([
        ...socialTimeStages(),
        ...socialTickerCandidateStages(),
        { $match: { _event_sec: { $gte: sinceSec }, _ticker_candidates: { $in: tickers } } },
        { $unwind: "$_ticker_candidates" },
        { $match: { _ticker_candidates: { $in: tickers } } },
        {
          $addFields: {
            _score: {
              $switch: {
                branches: [
                  { case: { $in: [{ $type: "$sentiment_score" }, ["int", "long", "double", "decimal"]] }, then: { $toDouble: "$sentiment_score" } },
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bull|positive" } }, then: 1 },
                  { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ["$sentiment", ""] } } }, regex: "bear|negative" } }, then: -1 },
                ],
                default: 0,
              },
            },
          },
        },
        {
          $group: {
            _id: "$_ticker_candidates",
            social_count: { $sum: 1 },
            social_sentiment: { $avg: "$_score" },
            social_sentiment_abs: { $avg: { $abs: "$_score" } },
            latest_social_ts: { $max: "$_event_sec" },
          },
        },
      ]).toArray(),
    ])

    const articleMap = new Map(articleRows.map(row => [String(row._id || "").toUpperCase(), row]))
    const socialMap = new Map(socialRows.map(row => [String(row._id || "").toUpperCase(), row]))

    const rows = screenerRows.map(raw => {
      const row = normalizeScreenerDoc(raw)
      const articles = articleMap.get(row.ticker) || {}
      const social = socialMap.get(row.ticker) || {}
      const volume = Number(row.volume || 0)
      const avgVolume = Number(row.avg_volume || 0)
      const relVolume = Number(row.rel_volume || (avgVolume ? volume / Math.max(1, avgVolume) : 0)) || 0
      const articleSentiment = Number(articles.article_sentiment || 0)
      const socialSentiment = Number(social.social_sentiment || 0)
      const socialCount = Number(social.social_count || 0)
      const articleCount = Number(articles.article_count || 0)
      const eventCount = Number(articles.event_count || 0)
      const momentumScore = Number(row.change_pct || 0)
      const evidenceScore = articleSentiment * Math.min(1, articleCount / 5) + socialSentiment * Math.min(1, socialCount / 20)
      const modelReady = Boolean(row.price && volume && (articleCount || socialCount) && Number.isFinite(momentumScore))

      return {
        ticker: row.ticker,
        company: row.company,
        exchange: row.exchange,
        sector: row.sector,
        generated_at: new Date().toISOString(),
        features: {
          price: row.price,
          change_pct: row.change_pct,
          volume,
          rel_volume: Number(relVolume.toFixed(3)),
          market_cap: row.market_cap,
          rsi: row.rsi,
          gap: row.gap,
          perf_week: row.perf_week,
          perf_month: row.perf_month,
          article_count: articleCount,
          article_sentiment: Number(articleSentiment.toFixed(3)),
          event_count: eventCount,
          social_count: socialCount,
          social_density_per_minute: Number((socialCount / socialWindow).toFixed(3)),
          social_sentiment: Number(socialSentiment.toFixed(3)),
          evidence_score: Number(evidenceScore.toFixed(3)),
        },
        labels: {
          target_return_5m: null,
          target_return_15m: null,
          target_return_60m: null,
        },
        baseline_signal: {
          direction: evidenceScore >= 0.15 && momentumScore > 0 ? "up" : evidenceScore <= -0.15 && momentumScore < 0 ? "down" : "watch",
          confidence: Number(Math.min(0.95, Math.abs(evidenceScore) * 0.35 + Math.min(1, relVolume / 5) * 0.25 + Math.min(1, Math.abs(momentumScore) / 20) * 0.25).toFixed(3)),
          model_ready: modelReady,
        },
      }
    })

    res.json({
      ok: true,
      rows,
      count: rows.length,
      feature_version: "price_social_news_v1",
      social_window_minutes: socialWindow,
      label_status: "pending_intraday_return_join",
      note: "This endpoint is the stock-price-prediction feature matrix. The next step is joining 1-minute candles after each signal timestamp to fill target_return labels.",
    })
  } catch (err) {
    console.error("GET /api/prediction/features failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get("/api/prediction/signals", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: "MongoDB is not connected" })

    const limit = Math.max(1, Math.min(500, Number(req.query.limit || 100)))
    const ticker = String(req.query.ticker || "").toUpperCase().replace(/[^A-Z0-9.-]/g, "")
    const status = String(req.query.status || "").toLowerCase()
    const filter = {}
    if (ticker) filter.ticker = ticker
    if (status) filter.label_status = status

    const [rows, summaryRows, model] = await Promise.all([
      db.collection("prediction_signals").find(filter).sort({ signal_sec: -1, rank: 1 }).limit(limit).toArray(),
      db.collection("prediction_signals").aggregate([
        { $match: filter },
        {
          $group: {
            _id: "$label_status",
            count: { $sum: 1 },
            avg_score: { $avg: "$trade_watch.trade_watch_score" },
            avg_5m: { $avg: "$labels.return_5m.return_pct" },
            avg_15m: { $avg: "$labels.return_15m.return_pct" },
            avg_60m: { $avg: "$labels.return_60m.return_pct" },
            correct_5m: {
              $avg: {
                $cond: [
                  { $eq: ["$labels.return_5m.direction_correct", true] },
                  1,
                  { $cond: [{ $eq: ["$labels.return_5m.direction_correct", false] }, 0, null] },
                ],
              },
            },
          },
        },
      ]).toArray(),
      loadLatestPredictionModel(db),
    ])

    res.json({
      ok: true,
      rows: rows.map(row => ({
        ...row,
        id: String(row._id),
        _id: undefined,
      })),
      count: rows.length,
      summary: summaryRows.map(row => ({
        status: row._id || "unknown",
        count: row.count,
        avg_score: Number((row.avg_score || 0).toFixed(3)),
        avg_return_5m: row.avg_5m == null ? null : Number(row.avg_5m.toFixed(3)),
        avg_return_15m: row.avg_15m == null ? null : Number(row.avg_15m.toFixed(3)),
        avg_return_60m: row.avg_60m == null ? null : Number(row.avg_60m.toFixed(3)),
        directional_accuracy_5m: row.correct_5m == null ? null : Number(row.correct_5m.toFixed(3)),
      })),
      horizons_minutes: PREDICTION_HORIZONS_MINUTES,
      feature_version: "trade_watch_prediction_v1",
      model: model ? {
        status: model.status,
        samples: model.samples || 0,
        min_samples: model.min_samples,
        metrics: model.metrics || null,
        updated_at: model.updated_at || null,
      } : null,
    })
  } catch (err) {
    console.error("GET /api/prediction/signals failed:", err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

app.get("/api/prediction/model", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: "MongoDB is not connected" })
    const model = await loadLatestPredictionModel(db)
    const nextSessionModel = await loadLatestNextSessionPredictionModel(db)
    res.json({
      ok: true,
      model: publicPredictionModel(model),
      next_session_model: publicNextSessionPredictionModel(nextSessionModel),
    })
  } catch (err) {
    console.error("GET /api/prediction/model failed:", err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.get("/api/prediction/session-model", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: "MongoDB is not connected" })
    const model = await loadLatestNextSessionPredictionModel(db)
    const labeledOutcomes = await db.collection("prediction_outcomes").countDocuments({ "outcome.outcome_status": "labeled" })
    const pendingOutcomes = await db.collection("prediction_outcomes").countDocuments({ "outcome.outcome_status": "pending" })
    res.json({
      ok: true,
      model: publicNextSessionPredictionModel(model),
      outcome_counts: {
        labeled: labeledOutcomes,
        pending: pendingOutcomes,
      },
      note: model?.live_enabled
        ? "Next-session model is validated for live use."
        : "Next-session model is not live yet; continue saving snapshots and labeling mature outcomes before treating top picks as statistically validated.",
    })
  } catch (err) {
    console.error("GET /api/prediction/session-model failed:", err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.post("/api/prediction/train", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: "MongoDB is not connected" })
    const model = await trainPredictionModel(db, {
      minSamples: Number(req.query.min_samples || req.body?.min_samples || 20),
      limit: Number(req.query.limit || req.body?.limit || process.env.PREDICTION_TRAINING_LIMIT || 5000),
    })
    res.json({ ok: true, model: publicPredictionModel(model) })
  } catch (err) {
    console.error("POST /api/prediction/train failed:", err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.post("/api/prediction/session-train", async (req, res) => {
  try {
    const { execFile } = await import("node:child_process")
    const scriptPathCandidates = [
      path.join(PROJECT_ROOT, "scripts", "train_next_session_prediction_model.js"),
      path.join(SERVER_DIR, "scripts", "train_next_session_prediction_model.js"),
    ]
    const scriptPath = scriptPathCandidates.find(candidate => fs.existsSync(candidate))
    if (!scriptPath) {
      return res.status(500).json({ ok: false, error: `Trainer script missing. Checked: ${scriptPathCandidates.join(", ")}` })
    }
    const args = []
    for (const name of ["minSamples", "target", "minMovePct", "requiredAccuracy", "requiredHoldout", "limit"]) {
      const value = req.query[name] ?? req.body?.[name]
      if (value != null && value !== "") args.push(`--${name}`, String(value))
    }
    execFile(process.execPath, [scriptPath, ...args], {
      cwd: fs.existsSync(path.join(PROJECT_ROOT, "scripts")) ? PROJECT_ROOT : SERVER_DIR,
      env: process.env,
      timeout: 180000,
      maxBuffer: 8 * 1024 * 1024,
    }, (err, stdout, stderr) => {
      if (err) {
        console.error("POST /api/prediction/session-train failed:", stderr || err)
        return res.status(500).json({ ok: false, error: String(err.message || err), stderr: String(stderr || "").slice(-2000) })
      }
      try {
        const parsed = JSON.parse(stdout)
        return res.json(parsed)
      } catch (_) {
        return res.json({ ok: true, stdout, stderr })
      }
    })
  } catch (err) {
    console.error("POST /api/prediction/session-train failed:", err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.post("/api/prediction/snapshot", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: "MongoDB is not connected" })
    const tickers = String(req.query.tickers || req.body?.tickers || "")
      .split(",")
      .map(t => t.trim().toUpperCase())
      .filter(Boolean)
    const labels = await labelMaturePredictionSignals(db)
    const snapshot = await captureTradeWatchPredictionSignals(db, {
      limit: Number(req.query.limit || req.body?.limit || process.env.NEXT_DAY_SIGNAL_LIMIT || process.env.PREDICTION_SIGNAL_LIMIT || 250),
      socialWindow: Number(req.query.window_minutes || req.body?.window_minutes || process.env.PREDICTION_SOCIAL_WINDOW || 60),
      tickers,
    })
    const model = await trainPredictionModel(db, {
      minSamples: Number(process.env.PREDICTION_MIN_TRAINING_SAMPLES || 20),
      limit: Number(process.env.PREDICTION_TRAINING_LIMIT || 5000),
    })
    res.json({ ok: true, labels, snapshot, model: publicPredictionModel(model) })
  } catch (err) {
    console.error("POST /api/prediction/snapshot failed:", err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

async function runPythonScriptForRoute(scriptPath, {
  timeout = 180000,
  extraEnv = {},
} = {}) {
  const { execFile } = await import("node:child_process")
  const { existsSync } = await import("node:fs")
  const pythonPath = existsSync("/opt/rssvenv/bin/python") ? "/opt/rssvenv/bin/python" : "python3"

  if (!existsSync(scriptPath)) {
    return {
      ok: false,
      skipped: true,
      stdout: "",
      stderr: "",
      error: `Script not found at ${scriptPath}`,
    }
  }

  const mongoUri = process.env.MONGODB_URI || process.env.MONGO_URI || "mongodb://mongo:27017/feedflash"
  try {
    return await new Promise((resolve) => {
      execFile(
        pythonPath,
        [scriptPath],
        {
          cwd: process.cwd(),
          timeout,
          maxBuffer: 1024 * 1024 * 20,
          env: {
            ...process.env,
            MONGODB_URI: mongoUri,
            MONGO_URI: mongoUri,
            MONGO_DB: "feedflash",
            MONGODB_DB: "feedflash",
            ...extraEnv,
          },
        },
        (error, stdout, stderr) => {
          resolve({
            ok: !error,
            stdout: String(stdout || ""),
            stderr: String(stderr || ""),
            error: error ? String(error.message || error) : "",
          })
        }
      )
    })
  } catch (err) {
    return { ok: false, stdout: "", stderr: "", error: String(err?.message || err) }
  }
}

function parseSocialFetchForRoute(stdout = "") {
  const text = String(stdout || "")
  const savedMatch = text.match(/saved=(\d+)/i)
  const matchedMatch = text.match(/matched=(\d+)/i)
  const insertedMatch = text.match(/inserted=(\d+)/i)
  const modifiedMatch = text.match(/modified=(\d+)/i)
  return {
    saved: savedMatch ? Number(savedMatch[1]) : undefined,
    matched: matchedMatch ? Number(matchedMatch[1]) : undefined,
    inserted: insertedMatch ? Number(insertedMatch[1]) : undefined,
    modified: modifiedMatch ? Number(modifiedMatch[1]) : undefined,
  }
}

app.post("/api/social/fetch", async (req, res) => {
  const started = Date.now()
  const ticker = normalizeTickerList([req.query.ticker || req.body?.ticker], 1, { ensurePrivate: false })[0] || ""

  if (!ticker) {
    return res.status(400).json({ ok: false, error: "ticker is required", ms: Date.now() - started })
  }

  try {
    const result = await runPythonScriptForRoute("1_News/pipeline/fetch_social_to_mongo.py", {
      timeout: 45000,
      extraEnv: {
        SOCIAL_TICKERS: ticker,
        SOCIAL_MAX_TICKERS: "1",
        SOCIAL_MAX_WORKERS: "1",
      },
    })
    const counts = parseSocialFetchForRoute(result.stdout || "")

    return res.status(result.ok ? 200 : 500).json({
      ok: result.ok,
      ticker,
      ...counts,
      stdout: result.stdout,
      stderr: result.stderr,
      error: result.error,
      ms: Date.now() - started,
    })
  } catch (err) {
    return res.status(500).json({
      ok: false,
      ticker,
      error: String(err?.message || err),
      ms: Date.now() - started,
    })
  }
})

app.get("/api/social/rolling/stats", async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) {
      return res.status(503).json({ ok: false, error: "MongoDB is not connected", counts: {} })
    }

    const windowMinutes = Math.max(1, Math.min(1440, Number(req.query.window_minutes || 5)))
    const sinceSec = Math.floor(Date.now() / 1000) - windowMinutes * 60

    const rows = await db.collection("socials").aggregate([
      ...socialTimeStages(),
      { $match: { _event_sec: { $gte: sinceSec } } },
      {
        $match: {
          _norm_platform: { $ne: "Unstructured" },
          _ticker_candidates: { $ne: [] },
        },
      },
      { $group: { _id: "$_norm_platform", count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]).toArray()

    const counts = {}
    for (const row of rows) counts[row._id || "Unknown"] = row.count

    return res.json({
      ok: true,
      counts,
      rows,
      total: rows.reduce((sum, row) => sum + row.count, 0),
      window_minutes: windowMinutes,
      since_sec: sinceSec,
      now_sec: Math.floor(Date.now() / 1000),
    })
  } catch (err) {
    console.error("GET /api/social/rolling/stats failed:", err)
    return res.status(500).json({ ok: false, error: String(err?.message || err), counts: {} })
  }
})
// SOCIAL_ROLLING_API_V2_END


app.use('/api/social',      socialRouter)
app.use('/api/correlation', correlationRouter)
app.use('/api/settings',    settingsRouter)

// ── Health check ──────────────────────────────────────────
app.get('/api/health', (req, res) => {
  const { readyState } = mongoose.connection
  const states = { 0:'disconnected', 1:'connected', 2:'connecting', 3:'disconnecting' }
  res.json({
    status:  'ok',
    db:      states[readyState] || 'unknown',
    time:    new Date().toISOString(),
  })
})

// ── Start ─────────────────────────────────────────────────
async function ensureRuntimeIndexes() {
  const db = mongoose.connection.db
  if (!db) return

  await Promise.allSettled([
    db.collection("articles").createIndex({ ticker: 1, detected_at: -1 }),
    db.collection("articles").createIndex({ ticker: 1, fetched_date: -1 }),
    db.collection("articles").createIndex({ source: 1, fetched_date: -1 }),
    db.collection("articles").createIndex({ sentiment: 1, event_type: 1 }),
    db.collection("socials").createIndex({ ticker: 1, fetched_at: -1 }),
    db.collection("socials").createIndex({ symbol: 1, fetched_at: -1 }),
    db.collection("socials").createIndex({ platform: 1, fetched_at: -1 }),
    db.collection("screeners").createIndex({ exchange: 1, change_pct: -1 }),
    db.collection("screeners").createIndex({ exchange: 1, volume: -1 }),
    db.collection("screeners").createIndex({ quote_source: 1, change_pct: -1 }),
    db.collection("prediction_signals").createIndex({ ticker: 1, signal_sec: -1 }),
    db.collection("prediction_signals").createIndex({ label_status: 1, signal_sec: -1 }),
    db.collection("prediction_signals").createIndex({ source: 1, signal_sec: -1 }),
    db.collection("prediction_models").createIndex({ model_id: 1, updated_at: -1 }),
  ])
}

async function start() {
  await connectDB()
  await ensureRuntimeIndexes()

  // Shared guard so the heavy data-refresh cycle never runs twice at once
  // (double Run Now clicks, or Run Now firing while the auto-grabber is mid-cycle).
  let refreshCycleInFlight = false
  
// Ryan frontend compatibility endpoints
app.get("/api/status", async (req, res) => {
  try {
    const db = mongoose.connection.db;
    const articles = db.collection("articles");
    const articleWindow = recentArticleMatch();
    const [totalArticles, recentArticles] = await Promise.all([
      articles.countDocuments({}),
      articles.countDocuments(articleWindow),
    ])

    const latest = await articles.find(
      {},
      { projection: { title: 1, source: 1, publish_date: 1, fetched_date: 1 } }
    ).sort({ fetched_date: -1, publish_date: -1 }).limit(1).toArray();

    res.json({
      ok: true,
      status: "ok",
      connected: true,
      articles: totalArticles,
      total: totalArticles,
      total_all: totalArticles,
      recent_articles: recentArticles,
      article_count: totalArticles,
      database: {
        connected: mongoose.connection.readyState === 1,
        articles: totalArticles,
        total: totalArticles,
        total_all: totalArticles,
        recent_articles: recentArticles,
        article_count: totalArticles
      },
      latest_article: latest[0] || null,
      market_window_start: latestMarketCloseCutoff().toISOString(),
      time: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      status: "error",
      connected: false,
      articles: 0,
      total: 0,
      article_count: 0,
      database: {
        connected: false,
        articles: 0,
        total: 0,
        article_count: 0
      },
      error: "Failed to load status"
    });
  }
});

app.get("/api/market/status", async (req, res) => {
  try {
    const now = new Date();
    const ny = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const day = ny.getDay(); // 0 = Sun .. 6 = Sat
    const hour = ny.getHours();
    const minute = ny.getMinutes();
    const minutes = hour * 60 + minute;

    const preStart = 4 * 60; // 04:00 ET
    const regularStart = 9 * 60 + 30; // 09:30 ET
    const regularEnd = 16 * 60; // 16:00 ET
    const afterEnd = 20 * 60; // 20:00 ET

    const isWeekday = day >= 1 && day <= 5
    const inPreMarket = isWeekday && minutes >= preStart && minutes < regularStart
    const inRegular = isWeekday && minutes >= regularStart && minutes < regularEnd
    const inAfterHours = isWeekday && minutes >= regularEnd && minutes < afterEnd

    const nextOpen = (() => {
      if (inRegular || inPreMarket || inAfterHours) {
        if (inRegular || inPreMarket) return `${String(9).padStart(2, '0')}:30 ET`
        return `${String(9).padStart(2, '0')}:30 ET`
      }

      const isFriday = day === 5
      const nextWeekday = isFriday ? 1 : day === 6 ? 1 : day === 0 ? 1 : day + 1
      return `${String(9).padStart(2, '0')}:30 ET on ${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][nextWeekday]}`
    })()

    const nextClose = inRegular ? `${String(16).padStart(2, '0')}:00 ET` : undefined

    let status = 'closed'
    let label = 'Market Closed'
    if (inRegular) {
      status = 'open'
      label = 'Market Open'
    } else if (inPreMarket) {
      status = 'pre'
      label = 'Pre-market'
    } else if (inAfterHours) {
      status = 'after'
      label = 'After-hours'
    }

    res.json({
      open: status === 'open',
      status,
      label,
      timezone: 'America/New_York',
      next_open: nextOpen,
      next_close: nextClose,
      tracked_exchanges: Array.from(US_EXCHANGES),
      tracked_indices: TRACKED_MARKET_INDICES,
      tracked_markets: TRACKED_MARKETS,
      updated_at: ny.toISOString()
    })
  } catch (err) {
    res.json({ open: false, status: 'unknown', label: 'Market Unknown', updated_at: new Date().toISOString() })
  }
});

app.get("/api/stats", async (req, res) => {
  try {
    const db = mongoose.connection.db;
    res.json(await loadArticleStats(db, Number(req.query.days || req.query.recent_days || 0)));
  } catch (err) {
    const trackedTickers = loadTrackedTickers()
    res.status(500).json({
      total: 0,
      total_recent: 0,
      total_all: 0,
      sources: [],
      categories: [],
      sentiment: { bullish: 0, bearish: 0, neutral: 0, unknown: 0 },
      ticker_mentions: [],
      tracked_market_count: TRACKED_MARKETS.length,
      tracked_markets: TRACKED_MARKETS,
      tracked_exchanges: Array.from(US_EXCHANGES),
      tracked_indices: TRACKED_MARKET_INDICES,
      market_universe_label: "NASDAQ / NYSE / AMEX equities plus major US index markets",
      tracked_ticker_count: trackedTickers.length,
      tracked_tickers: trackedTickers,
      error: "Failed to load stats"
    });
  }
});

app.get("/api/keywords", async (req, res) => {
  res.json({
    keywords: [
      "earnings",
      "guidance",
      "upgrade",
      "downgrade",
      "merger",
      "acquisition",
      "lawsuit",
      "sec",
      "fda",
      "short squeeze",
      "bankruptcy",
      "dividend",
      "offering",
      "partnership"
    ]
  });
});


// Duplicate /api/keywords removed - see settings routes for the authoritative implementation

// Frontend compatibility endpoints
app.get("/api/status", async (req, res) => {
  try {
    const db = mongoose.connection.db;
    const articles = db.collection("articles");
    const [totalArticles, recentArticles] = await Promise.all([
      articles.countDocuments({}),
      articles.countDocuments(recentArticleMatch()),
    ]);

    res.json({
      ok: true,
      status: "ok",
      database: {
        connected: mongoose.connection.readyState === 1,
        articles: totalArticles,
        total_all: totalArticles,
        recent_articles: recentArticles,
        market_window_start: latestMarketCloseCutoff().toISOString()
      },
      time: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({
      ok: false,
      status: "error",
      database: {
        connected: false,
        articles: 0
      },
      error: "Failed to load status"
    });
  }
});

// Duplicate /api/market/status removed - see line 323 for the authoritative implementation

app.get("/api/stats", async (req, res) => {
  try {
    const db = mongoose.connection.db;
    res.json(await loadArticleStats(db, Number(req.query.days || req.query.recent_days || 0)));
  } catch (err) {
    const trackedTickers = loadTrackedTickers()
    res.status(500).json({
      total: 0,
      total_recent: 0,
      total_all: 0,
      sources: [],
      categories: [],
      sentiment: { bullish: 0, bearish: 0, neutral: 0, unknown: 0 },
      ticker_mentions: [],
      tracked_market_count: TRACKED_MARKETS.length,
      tracked_markets: TRACKED_MARKETS,
      tracked_exchanges: Array.from(US_EXCHANGES),
      tracked_indices: TRACKED_MARKET_INDICES,
      market_universe_label: "NASDAQ / NYSE / AMEX equities plus major US index markets",
      tracked_ticker_count: trackedTickers.length,
      tracked_tickers: trackedTickers,
      error: "Failed to load stats"
    });
  }
});

// Duplicate /api/keywords removed - see settings routes for the authoritative implementation

async function runPythonScript(scriptPath, {
  timeout = 180000,
  extraEnv = {},
  allowNonZeroPattern = null,
} = {}) {
  const { execFile } = await import("node:child_process")
  const { existsSync } = await import("node:fs")

  const pythonPath = existsSync("/opt/rssvenv/bin/python")
    ? "/opt/rssvenv/bin/python"
    : "python3"

  if (!existsSync(scriptPath)) {
    return {
      ok: false,
      skipped: true,
      stdout: "",
      stderr: "",
      error: `Script not found at ${scriptPath}`,
    }
  }

  const mongoUri = process.env.MONGODB_URI || process.env.MONGO_URI || "mongodb://mongo:27017/feedflash"
  const started = Date.now()

  try {
    const result = await new Promise((resolve, reject) => {
      execFile(
        pythonPath,
        [scriptPath],
        {
          cwd: process.cwd(),
          timeout,
          maxBuffer: 1024 * 1024 * 20,
          env: {
            ...process.env,
            MONGODB_URI: mongoUri,
            MONGO_URI: mongoUri,
            MONGO_DB: "feedflash",
            MONGODB_DB: "feedflash",
            RSS_COOLDOWN_SECONDS: "0",
            RSS_STATE_FILE: "/tmp/feedflash_rss_fetch_state.json",
            ...extraEnv,
          },
        },
        (error, stdout, stderr) => {
          if (error) {
            error.stdout = stdout
            error.stderr = stderr
            reject(error)
            return
          }
          resolve({ stdout, stderr })
        }
      )
    })

    return {
      ok: true,
      stdout: String(result.stdout || ""),
      stderr: String(result.stderr || ""),
      ms: Date.now() - started,
    }
  } catch (err) {
    const stdout = String(err?.stdout || "")
    const stderr = String(err?.stderr || "")
    const combined = `${stdout}\n${stderr}`
    if (allowNonZeroPattern && allowNonZeroPattern.test(combined)) {
      return {
        ok: true,
        soft_error: true,
        stdout,
        stderr,
        error: String(err?.message || err),
        ms: Date.now() - started,
      }
    }
    return {
      ok: false,
      stdout,
      stderr,
      error: String(err?.message || err),
      ms: Date.now() - started,
    }
  }
}

function skippedPythonResult(name, reason = "skipped in fast mode") {
  return {
    ok: true,
    skipped: true,
    stdout: `${name} skipped — ${reason}`,
    stderr: "",
    error: "",
    ms: 0,
  }
}

function parseStructuredFetch(stdout, before, after) {
  const match =
    stdout.match(/RSS Mongo import complete\s+—\s+(\d+)\s+new,\s+(\d+)\s+updated,\s+(\d+)\s+unchanged/i) ||
    stdout.match(/RSS Mongo import complete.*?(\d+)\s+new.*?(\d+)\s+updated.*?(\d+)\s+unchanged/is)

  return {
    new_articles: match ? Number(match[1]) : Math.max(0, after - before),
    updated_articles: match ? Number(match[2]) : 0,
    unchanged_articles: match ? Number(match[3]) : 0,
  }
}

function parseUnstructuredFetch(stdout) {
  const found = stdout.match(/['"]found['"]:\s*(\d+)/)
  const upserted = stdout.match(/['"]upserted['"]:\s*(\d+)/)
  const modified = stdout.match(/['"]modified['"]:\s*(\d+)/)
  return {
    unstructured_found: found ? Number(found[1]) : 0,
    unstructured_new: upserted ? Number(upserted[1]) : 0,
    unstructured_updated: modified ? Number(modified[1]) : 0,
  }
}

function parseSocialFetch(stdout) {
  const match = stdout.match(/Social import complete\s+—\s+(\d+)\s+found,\s+(\d+)\s+new,\s+(\d+)\s+updated/i)
  return {
    social_found: match ? Number(match[1]) : 0,
    social_new: match ? Number(match[2]) : 0,
    social_updated: match ? Number(match[3]) : 0,
  }
}

function parseSecFetch(stdout) {
  const match = stdout.match(/SEC EDGAR import complete\s+—\s+(\d+)\s+tickers fetched,\s+(\d+)\s+cooldown,\s+(\d+)\s+filings found,\s+(\d+)\s+new,\s+(\d+)\s+updated,\s+(\d+)\s+failed/i)
  return {
    sec_tickers_fetched: match ? Number(match[1]) : 0,
    sec_tickers_cooldown: match ? Number(match[2]) : 0,
    sec_filings_found: match ? Number(match[3]) : 0,
    sec_filings_new: match ? Number(match[4]) : 0,
    sec_filings_updated: match ? Number(match[5]) : 0,
    sec_filings_failed: match ? Number(match[6]) : 0,
  }
}

function parseQuoteFetch(stdout) {
  const match = stdout.match(/Quote import complete\s+—\s+(\d+)\s+quotes,\s+(\d+)\s+updated/i)
  return {
    quotes_found: match ? Number(match[1]) : 0,
    quotes_updated: match ? Number(match[2]) : 0,
  }
}

function parseFinvizEliteFetch(stdout) {
  const match = stdout.match(/Finviz Elite import complete\s+—\s+(\d+)\s+rows,\s+(\d+)\s+updated,\s+(\d+)\s+dropped/i)
  const warningLines = String(stdout || "")
    .split(/\r?\n/)
    .filter(line => /Finviz warning:/i.test(line))
    .map(line => line.replace(/^.*?Finviz warning:\s*/i, "").trim())
    .filter(Boolean)
  const authError = warningLines.find(line => /http\s*401|invalid token|unauthorized/i.test(line))
  return {
    finviz_rows: match ? Number(match[1]) : 0,
    finviz_updated: match ? Number(match[2]) : 0,
    finviz_dropped: match ? Number(match[3]) : 0,
    finviz_error: authError || (warningLines.length ? warningLines.slice(0, 3).join("; ") : null),
  }
}

function parseTradingViewFetch(stdout) {
  const match = stdout.match(/TradingView import complete\s+—\s+(\d+)\s+found,\s+(\d+)\s+new,\s+(\d+)\s+updated/i)
  return {
    tradingview_found: match ? Number(match[1]) : 0,
    tradingview_new: match ? Number(match[2]) : 0,
    tradingview_updated: match ? Number(match[3]) : 0,
  }
}

function parseTradingViewScreenerFetch(stdout) {
  const match = stdout.match(/TradingView screener import complete\s+—\s+(\d+)\s+rows,\s+(\d+)\s+updated/i)
  return {
    tradingview_screener_rows: match ? Number(match[1]) : 0,
    tradingview_screener_updated: match ? Number(match[2]) : 0,
  }
}

function parseBenzingaFetch(stdout) {
  const match = stdout.match(/Benzinga import complete\s+—\s+(\d+)\s+found,\s+(\d+)\s+new,\s+(\d+)\s+updated/i)
  return {
    benzinga_found: match ? Number(match[1]) : 0,
    benzinga_new: match ? Number(match[2]) : 0,
    benzinga_updated: match ? Number(match[3]) : 0,
  }
}

async function runDataRefreshCycle(db, { socialMode = "top_momentum", mode = "fast" } = {}) {
  const cycleStarted = Date.now()
  const requestedMode = String(mode || process.env.DEFAULT_FETCH_MODE || "fast").toLowerCase()
  const refreshMode = requestedMode === "full" ? "full" : requestedMode === "optimized" ? "optimized" : "fast"
  const fastMode = refreshMode !== "full"
  const beforeArticles = await db.collection("articles").countDocuments()
  const beforeSocial = await db.collection("socials").countDocuments()
  const socialExtraEnv = {
    SOCIAL_TICKER_SOURCE: "momentum",
    SOCIAL_MOMENTUM_LIMIT: process.env.SOCIAL_MOMENTUM_LIMIT || "10",
    SOCIAL_MAX_TICKERS: process.env.SOCIAL_MAX_TICKERS || "10",
    SOCIAL_MAX_WORKERS: process.env.SOCIAL_MAX_WORKERS || "8",
    SOCIAL_REDDIT_TIMEOUT: process.env.SOCIAL_REDDIT_TIMEOUT || "4",
    SOCIAL_REDDIT_PUBLIC_FALLBACK: process.env.SOCIAL_REDDIT_PUBLIC_FALLBACK || "false",
  }

  // Pre-load ticker lists first (fast DB queries), then fire ALL scripts in one parallel batch.
  const [trackedMarketTickers, publicSocialTickersRaw] = await Promise.all([
    fastMode ? Promise.resolve([]) : loadTrackedMarketTickerSymbols(db, Number(process.env.TRACKED_MARKET_TICKER_LIMIT || 5000)),
    socialMode === "top_momentum"
      ? loadTopMomentumTickerSymbols(db, Number(process.env.SOCIAL_MOMENTUM_LIMIT || (fastMode ? 12 : 10)))
      : Promise.resolve([]),
  ])
  const tradingViewScreenerRefreshSeconds = Math.max(60, Number(process.env.TRADINGVIEW_SCREENER_FAST_REFRESH_SECONDS || 300))
  const latestTradingViewScreener = await db.collection("screeners").findOne(
    { quote_source: "tradingview_numeric_screener" },
    { projection: { quote_updated_at: 1, tradingview_seen_at: 1 }, sort: { quote_updated_at: -1, tradingview_seen_at: -1 } }
  ).catch(() => null)
  const latestTradingViewScreenerSec = timestampSeconds(latestTradingViewScreener?.quote_updated_at || latestTradingViewScreener?.tradingview_seen_at)
  const tradingViewScreenerAge = latestTradingViewScreenerSec ? Math.max(0, Math.floor(Date.now() / 1000) - latestTradingViewScreenerSec) : null
  const shouldRefreshTradingViewScreener = !fastMode || tradingViewScreenerAge == null || tradingViewScreenerAge > tradingViewScreenerRefreshSeconds

  let publicSocialTickers = publicSocialTickersRaw
  let socialTickers = []
  if (socialMode === "top_momentum" && publicSocialTickers.length) {
    socialTickers = withPrivateSocialTickers(publicSocialTickers)
    socialExtraEnv.SOCIAL_TICKERS = socialTickers.join(",")
    socialExtraEnv.SOCIAL_MAX_TICKERS = String(socialTickers.length)
    socialExtraEnv.SOCIAL_PRIVATE_TICKERS = Array.from(PRIVATE_TRACKED_TICKERS).join(",")
    socialExtraEnv.SOCIAL_TICKER_SOURCE = "configured"
  } else if (socialMode !== "top_momentum") {
    socialExtraEnv.SOCIAL_TICKER_SOURCE = "configured"
    socialExtraEnv.SOCIAL_MAX_TICKERS = process.env.SOCIAL_MAX_TICKERS || "250"
  } else {
    socialExtraEnv.SOCIAL_MAX_TICKERS = "10"
  }

  const tradingViewExtraEnv = publicSocialTickers.length
    ? { TRADINGVIEW_TICKERS: publicSocialTickers.join(","), TRADINGVIEW_MAX_TICKERS: String(publicSocialTickers.length) }
    : {}
  const quoteTickers = fastMode ? publicSocialTickers : trackedMarketTickers
  const quoteExtraEnv = quoteTickers.length
    ? { QUOTE_TICKERS: quoteTickers.join(","), QUOTE_MAX_TICKERS: String(quoteTickers.length) }
    : { QUOTE_MAX_TICKERS: fastMode ? "25" : (process.env.QUOTE_MAX_TICKERS || "5000") }
  const unstructuredExtraEnv = {
    UNSTRUCTURED_MAX_PER_SOURCE: process.env.UNSTRUCTURED_MAX_PER_SOURCE || "0",
    UNSTRUCTURED_MAX_WORKERS: process.env.UNSTRUCTURED_MAX_WORKERS || (fastMode ? "4" : "6"),
    ...(fastMode
      ? { UNSTRUCTURED_SOURCE_FILTER: process.env.FAST_UNSTRUCTURED_SOURCE_FILTER || "Finviz News Flow,TradingView News" }
      : {}),
    ...(trackedMarketTickers.length ? { TRACKED_TICKERS: trackedMarketTickers.join(",") } : {}),
  }
  const secUniverseTickers = Array.from(new Set([
    ...publicSocialTickers,
    ...(fastMode ? [] : trackedMarketTickers.slice(0, Number(process.env.SEC_FULL_TRACKED_TICKER_LIMIT || 250))),
  ].filter(Boolean))).slice(0, fastMode
    ? Number(process.env.SEC_FAST_TICKER_LIMIT || 35)
    : Number(process.env.SEC_ACTIVE_TICKER_LIMIT || 250)
  )
  const secExtraEnv = {
    SEC_ACTIVE_TICKER_LIMIT: process.env.SEC_ACTIVE_TICKER_LIMIT || (fastMode ? "35" : "250"),
    SEC_RECENT_DAYS: process.env.SEC_RECENT_DAYS || "7",
    SEC_MAX_FILINGS_PER_TICKER: process.env.SEC_MAX_FILINGS_PER_TICKER || (fastMode ? "3" : "6"),
    SEC_MAX_WORKERS: process.env.SEC_MAX_WORKERS || (fastMode ? "3" : "4"),
    SEC_REQUEST_TIMEOUT: process.env.SEC_REQUEST_TIMEOUT || (fastMode ? "8" : "12"),
    SEC_TICKER_COOLDOWN_SECONDS: process.env.SEC_TICKER_COOLDOWN_SECONDS || (fastMode ? "300" : "120"),
    ...(secUniverseTickers.length ? { SEC_TICKERS: secUniverseTickers.join(",") } : {}),
  }

  // All scripts run in one parallel batch.
  const fetchBatchStarted = Date.now()
  const [finvizElite, tradingViewScreener, quotes, structured, tradingView, benzinga, ibkrNews, schwabSignals, unstructured, social, secFilings] = await Promise.all([
    runPythonScript("2_Screener/pipeline/fetch_finviz_elite_to_mongo.py", {
      timeout: fastMode ? 25000 : 90000,
      extraEnv: { FINVIZ_MAX_WORKERS: process.env.FINVIZ_MAX_WORKERS || (fastMode ? "12" : "6") },
    }),
    shouldRefreshTradingViewScreener
      ? runPythonScript("2_Screener/pipeline/fetch_tradingview_screener_to_mongo.py", { timeout: fastMode ? 30000 : 90000 })
      : Promise.resolve(skippedPythonResult(
          "TradingView numeric screener",
          `fresh; last updated ${tradingViewScreenerAge}s ago`
        )),
    runPythonScript("1_News/pipeline/fetch_quotes_to_mongo.py", {
      timeout: fastMode ? 20000 : 90000,
      extraEnv: quoteExtraEnv,
    }),
    runPythonScript("1_News/pipeline/fetch_rss_to_mongo.py", {
      timeout: fastMode ? 22000 : 180000,
      allowNonZeroPattern: /no RSS\/Atom entries parsed|RSS Mongo import complete|Article cache/i,
      extraEnv: fastMode
        ? {
            RSS_FAST_MODE: "1",
            RSS_MAX_WORKERS: process.env.RSS_MAX_WORKERS || "32",
            RSS_HTTP_TIMEOUT: process.env.RSS_HTTP_TIMEOUT || "5",
            NEWSWIRE_HTTP_TIMEOUT: process.env.NEWSWIRE_HTTP_TIMEOUT || "6",
            NEWSWIRE_MAX_PAGES: process.env.NEWSWIRE_MAX_PAGES || "1",
          }
        : {
            RSS_MAX_WORKERS: process.env.RSS_MAX_WORKERS || "16",
            NEWSWIRE_HTTP_TIMEOUT: process.env.NEWSWIRE_HTTP_TIMEOUT || "20",
            NEWSWIRE_MAX_PAGES: process.env.NEWSWIRE_MAX_PAGES || "0",
          },
    }),
    runPythonScript("1_News/pipeline/fetch_tradingview_to_mongo.py", {
      timeout: fastMode ? 20000 : 90000,
      extraEnv: tradingViewExtraEnv,
    }),
    fastMode && !process.env.BENZINGA_API_KEY
      ? Promise.resolve(skippedPythonResult("Benzinga", "no API key and fast mode"))
      : runPythonScript("1_News/pipeline/fetch_benzinga_to_mongo.py", { timeout: fastMode ? 25000 : 90000 }),
    fastMode
      ? Promise.resolve(skippedPythonResult("IBKR News"))
      : runPythonScript("1_News/pipeline/fetch_ibkr_news_to_mongo.py", { timeout: 30000 }),
    fastMode
      ? Promise.resolve(skippedPythonResult("Schwab signals"))
      : runPythonScript("2_Screener/pipeline/fetch_schwab_signals_to_mongo.py", { timeout: 30000 }),
    runPythonScript("1_News/pipeline/fetch_unstructured_news_titles_to_mongo.py", {
      timeout: fastMode ? 30000 : 90000,
      extraEnv: unstructuredExtraEnv,
    }),
    runPythonScript("1_News/pipeline/fetch_social_to_mongo.py", {
      timeout: fastMode ? 20000 : 90000,
      extraEnv: socialExtraEnv,
    }),
    runPythonScript("1_News/pipeline/fetch_sec_filings_to_mongo.py", {
      timeout: fastMode ? 22000 : 120000,
      extraEnv: secExtraEnv,
    }),
  ])
  const fetchParallelMs = Date.now() - fetchBatchStarted

  const afterStructuredArticles = await db.collection("articles").countDocuments()
  const structuredCounts = parseStructuredFetch(structured.stdout || "", beforeArticles, afterStructuredArticles)
  const afterArticles = await db.collection("articles").countDocuments()
  const afterSocial = await db.collection("socials").countDocuments()
  const unstructuredCounts = parseUnstructuredFetch(unstructured.stdout || "")
  const socialCounts = parseSocialFetch(social.stdout || "")
  const secCounts = parseSecFetch(secFilings.stdout || "")
  const quoteCounts = parseQuoteFetch(quotes.stdout || "")
  const finvizCounts = parseFinvizEliteFetch(finvizElite.stdout || "")
  const tradingViewCounts = parseTradingViewFetch(tradingView.stdout || "")
  const tradingViewScreenerCounts = parseTradingViewScreenerFetch(tradingViewScreener.stdout || "")
  const benzingaCounts = parseBenzingaFetch(benzinga.stdout || "")
  const finvizSnapshot = finvizCounts.finviz_rows
    ? await persistFinvizMomentumSnapshot(db, { limit: 100, reason: refreshMode }).catch(() => null)
    : null
  const predictionStarted = Date.now()
  const predictionLabels = await labelMaturePredictionSignals(db, {
    limit: fastMode
      ? Number(process.env.PREDICTION_FAST_LABEL_LIMIT || 150)
      : Number(process.env.PREDICTION_LABEL_LIMIT || 500),
  })
  const existingPredictionModel = await loadLatestPredictionModel(db).catch(() => null)
  const modelAgeMs = existingPredictionModel?.updated_at ? Date.now() - new Date(existingPredictionModel.updated_at).getTime() : Infinity
  const trainIntervalMs = fastMode
    ? Number(process.env.PREDICTION_FAST_TRAIN_INTERVAL_MS || 5 * 60 * 1000)
    : Number(process.env.PREDICTION_FULL_TRAIN_INTERVAL_MS || 60 * 1000)
  const predictionModel = modelAgeMs < trainIntervalMs && existingPredictionModel
    ? {
        ...existingPredictionModel,
        status: existingPredictionModel.status || "trained",
        skipped_training: true,
        skip_reason: `model refreshed ${Math.round(modelAgeMs / 1000)}s ago`,
      }
    : await trainPredictionModel(db, {
        minSamples: Number(process.env.PREDICTION_MIN_TRAINING_SAMPLES || 20),
        limit: fastMode
          ? Number(process.env.PREDICTION_FAST_TRAINING_LIMIT || 1500)
          : Number(process.env.PREDICTION_TRAINING_LIMIT || 5000),
      })
  const predictionSnapshot = await captureTradeWatchPredictionSignals(db, {
    limit: fastMode
      ? Number(process.env.NEXT_DAY_FAST_SIGNAL_LIMIT || process.env.NEXT_DAY_SIGNAL_LIMIT || process.env.PREDICTION_SIGNAL_LIMIT || 150)
      : Number(process.env.NEXT_DAY_SIGNAL_LIMIT || process.env.PREDICTION_SIGNAL_LIMIT || 250),
    socialWindow: Number(process.env.PREDICTION_SOCIAL_WINDOW || 60),
  })
  const predictionPostMs = Date.now() - predictionStarted

  return {
    ok: finvizElite.ok && !finvizCounts.finviz_error && tradingViewScreener.ok && quotes.ok && structured.ok && tradingView.ok && benzinga.ok && ibkrNews.ok && schwabSignals.ok && unstructured.ok && social.ok && secFilings.ok,
    ...finvizCounts,
    ...tradingViewScreenerCounts,
    ...quoteCounts,
    ...structuredCounts,
    ...tradingViewCounts,
    ...benzingaCounts,
    ...unstructuredCounts,
    ...socialCounts,
    ...secCounts,
    total_articles: afterArticles,
    total_social: afterSocial,
    tracked_market_ticker_count: trackedMarketTickers.length,
    quote_ticker_count: quoteTickers.length,
    fetch_mode: refreshMode,
    social_delta: Math.max(0, afterSocial - beforeSocial),
    prediction_labels_checked: predictionLabels.checked,
    prediction_labels_added: predictionLabels.labeled,
    prediction_signals_saved: predictionSnapshot.saved,
    prediction_model_status: predictionModel.status,
    prediction_model_samples: predictionModel.samples || 0,
    prediction_model_training_skipped: Boolean(predictionModel.skipped_training),
    finviz_snapshot_saved: Boolean(finvizSnapshot),
    finviz_snapshot_count: Number(finvizSnapshot?.count || 0),
    social_mode: socialMode,
    social_target_source: socialMode === "top_momentum" ? "top positive momentum movers" : "configured watchlist",
    social_tickers: socialTickers,
    sec_ticker_count: secUniverseTickers.length,
    finviz_ms: Number(finvizElite.ms || 0),
    tradingview_screener_ms: Number(tradingViewScreener.ms || 0),
    quotes_ms: Number(quotes.ms || 0),
    structured_ms: Number(structured.ms || 0),
    tradingview_news_ms: Number(tradingView.ms || 0),
    benzinga_ms: Number(benzinga.ms || 0),
    ibkr_ms: Number(ibkrNews.ms || 0),
    schwab_ms: Number(schwabSignals.ms || 0),
    unstructured_ms: Number(unstructured.ms || 0),
    social_ms: Number(social.ms || 0),
    sec_ms: Number(secFilings.ms || 0),
    fetch_parallel_ms: Number(fetchParallelMs || 0),
    prediction_post_ms: Number(predictionPostMs || 0),
    total_cycle_ms: Number(Date.now() - cycleStarted),
    refresh_timing_ms: {
      finviz: Number(finvizElite.ms || 0),
      tradingview_screener: Number(tradingViewScreener.ms || 0),
      quotes: Number(quotes.ms || 0),
      structured: Number(structured.ms || 0),
      tradingview_news: Number(tradingView.ms || 0),
      benzinga: Number(benzinga.ms || 0),
      ibkr: Number(ibkrNews.ms || 0),
      schwab: Number(schwabSignals.ms || 0),
      unstructured: Number(unstructured.ms || 0),
      social: Number(social.ms || 0),
      sec: Number(secFilings.ms || 0),
      fetch_parallel: Number(fetchParallelMs || 0),
      prediction_post: Number(predictionPostMs || 0),
      total_cycle: Number(Date.now() - cycleStarted),
    },
    timings: {
      finviz_ms: finvizElite.ms || 0,
      tradingview_screener_ms: tradingViewScreener.ms || 0,
      quotes_ms: quotes.ms || 0,
      structured_ms: structured.ms || 0,
      tradingview_news_ms: tradingView.ms || 0,
      benzinga_ms: benzinga.ms || 0,
      ibkr_ms: ibkrNews.ms || 0,
      schwab_ms: schwabSignals.ms || 0,
      unstructured_ms: unstructured.ms || 0,
      social_ms: social.ms || 0,
      sec_ms: secFilings.ms || 0,
      fetch_parallel_ms: fetchParallelMs,
      prediction_post_ms: predictionPostMs,
      total_cycle_ms: Date.now() - cycleStarted,
    },
    output: [
      structured.stdout,
      finvizElite.stdout,
      tradingViewScreener.stdout,
      tradingView.stdout,
      benzinga.stdout,
      ibkrNews.stdout,
      schwabSignals.stdout,
      unstructured.stdout,
      social.stdout,
      secFilings.stdout,
      quotes.stdout,
    ].filter(Boolean).join("\n").slice(-6000),
    stderr: [
      structured.stderr,
      finvizElite.stderr,
      tradingViewScreener.stderr,
      tradingView.stderr,
      benzinga.stderr,
      ibkrNews.stderr,
      schwabSignals.stderr,
      unstructured.stderr,
      social.stderr,
      secFilings.stderr,
      quotes.stderr,
    ].filter(Boolean).join("\n").slice(-3000),
    errors: [
      finvizElite.ok ? null : finvizElite.error,
      tradingViewScreener.ok ? null : tradingViewScreener.error,
      quotes.ok ? null : quotes.error,
      structured.ok ? null : structured.error,
      tradingView.ok ? null : tradingView.error,
      benzinga.ok ? null : benzinga.error,
      ibkrNews.ok ? null : ibkrNews.error,
      schwabSignals.ok ? null : schwabSignals.error,
      unstructured.ok ? null : unstructured.error,
      social.ok ? null : social.error,
      finvizCounts.finviz_error ? `Finviz Elite: ${finvizCounts.finviz_error}` : null,
    ].filter(Boolean),
  }
}

app.post("/api/fetch", async (req, res) => {
  const started = Date.now()

  // Skip duplicate/overlapping cycles instead of stacking expensive work.
  if (refreshCycleInFlight) {
    return res.json({ ok: true, skipped: true, already_running: true, new_articles: 0, updated_articles: 0,
      ms: Date.now() - started, message: "A refresh is already in progress — skipped the duplicate." })
  }

  try {
    const db = mongoose.connection.db
    if (!db) {
      return res.status(503).json({
        ok: false,
        error: "MongoDB is not connected",
        new_articles: 0,
        ms: Date.now() - started,
      })
    }

    refreshCycleInFlight = true
    const result = await runDataRefreshCycle(db, {
      mode: req.query.mode || req.body?.mode || process.env.DEFAULT_FETCH_MODE || "fast",
    })
    persistFetchNewsToDisk(db).catch(() => {})   // Redis+Kafka fetch → hard disk (3d)
    return res.json({
      ...result,
      ms: Date.now() - started,
      message: result.fetch_mode === "full"
        ? "Ran full structured, unstructured, and social importers"
        : "Ran fast trader refresh",
    })
  } catch (err) {
    console.error("Real /api/fetch failed:", err)
    return res.status(500).json({
      ok: false,
      error: String(err?.message || err),
      new_articles: 0,
      ms: Date.now() - started,
      stdout: String(err?.stdout || "").slice(-3000),
      stderr: String(err?.stderr || "").slice(-3000),
    })
  } finally {
    refreshCycleInFlight = false
  }
})
// NEWS_RSS_FETCH_API_V3_END

app.get("/api/watch", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const interval = Math.max(20, Math.min(600, Number(req.query.interval || 30)));
  const mode = String(req.query.mode || "fast") === "full" ? "full" : "fast";
  const sendEvent = (event, payload = {}) => {
    try {
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    } catch (_) {}
  };

  sendEvent("start", {
    message: `Auto-watch started. Interval: ${interval}s. Social auto-fetch targets the top 10 positive momentum movers.`,
    interval,
    mode,
    next_run_at: Date.now(),
  });

  let isRunning = false;

  const runFetchCycle = async () => {
    if (isRunning || refreshCycleInFlight) {
      sendEvent("heartbeat", {
        message: "Auto-watch waiting: another refresh cycle is still running.",
        skipped: true,
        running: false,
        interval,
        mode,
        next_run_at: Date.now() + interval * 1000,
      });
      return; // don't overlap with Run Now or another cycle
    }
    isRunning = true;
    refreshCycleInFlight = true;
    
    const cycleStarted = Date.now();
    try {
      sendEvent("heartbeat", {
        message: "Auto-watch refresh started.",
        running: true,
        skipped: false,
        interval,
        mode,
        started_at: cycleStarted,
      });
      const db = mongoose.connection.db;
      const result = await runDataRefreshCycle(db, {
        socialMode: "top_momentum",
        mode,
      })
      persistFetchNewsToDisk(db).catch(() => {})   // auto-watch fetch → hard disk (3d)
      const newCount = Number(result.new_articles || 0) + Number(result.unstructured_new || 0)
      const updatedCount = Number(result.updated_articles || 0) + Number(result.unstructured_updated || 0)
      const tradingViewNew = Number(result.tradingview_new || 0)
      const tradingViewUpdated = Number(result.tradingview_updated || 0)
      const socialNew = Number(result.social_new || 0)
      const socialUpdated = Number(result.social_updated || 0)
      const quotesUpdated = Number(result.quotes_updated || 0)
      const trackedMarketTickerCount = Number(result.tracked_market_ticker_count || 0)
      const finvizRows = Number(result.finviz_rows || 0)
      const tradingViewScreenerRows = Number(result.tradingview_screener_rows || 0)
      const ms = Date.now() - cycleStarted;

      sendEvent("line", { 
        text: `${finvizRows} Finviz movers; ${tradingViewScreenerRows} TV scanner rows; ${trackedMarketTickerCount || 'all'} tracked market tickers; ${quotesUpdated} quotes; +${newCount} articles${updatedCount > 0 ? `, ${updatedCount} refreshed` : ''}; +${tradingViewNew} TradingView news${tradingViewUpdated > 0 ? `, ${tradingViewUpdated} refreshed` : ''}; +${socialNew} social${socialUpdated > 0 ? `, ${socialUpdated} refreshed` : ''}${result.social_tickers?.length ? ` [${result.social_tickers.join(', ')}]` : ''} (${(ms / 1000).toFixed(1)}s)`,
        new: newCount + tradingViewNew,
        updated: updatedCount + tradingViewUpdated,
        tradingview_new: tradingViewNew,
        tradingview_updated: tradingViewUpdated,
        social_new: socialNew,
        social_updated: socialUpdated,
        social_tickers: result.social_tickers || [],
        finviz_rows: finvizRows,
        tradingview_screener_rows: tradingViewScreenerRows,
        tracked_market_ticker_count: trackedMarketTickerCount,
        quotes_updated: quotesUpdated,
        ms: ms,
        interval,
        mode,
        completed_at: Date.now(),
        next_run_at: Date.now() + interval * 1000,
      });
    } catch (err) {
      console.error("Auto-watch cycle failed:", err);
      sendEvent("error", { message: `Auto-watch cycle failed: ${err.message}` });
    } finally {
      isRunning = false;
      refreshCycleInFlight = false;
    }
  };

  // Run first cycle immediately, then schedule for every interval
  await runFetchCycle();
  
  const timer = setInterval(runFetchCycle, interval * 1000);

  req.on("close", () => {
    clearInterval(timer);
  });
});
// End Ryan frontend compatibility endpoints



app.get("/api/sources/health", async (req, res) => {
  try {
    const db = mongoose.connection.db;
    const registryPath = [
      path.join(PROJECT_ROOT, "config", "professor_source_registry.json"),
      path.join(process.cwd(), "config", "professor_source_registry.json"),
      path.join(SERVER_DIR, "config", "professor_source_registry.json"),
    ].find((candidate) => fs.existsSync(candidate))
    if (!registryPath) throw new Error("professor_source_registry.json not found")
    const registry = JSON.parse(fs.readFileSync(registryPath, "utf8"))
    const statuses = await db.collection("source_status").find({}).toArray()
    const statusBySource = new Map(statuses.map((row) => [row.source, row]))
    const apiTime = (value) => {
      if (!value) return null
      if (value instanceof Date) return value.toISOString()
      if (typeof value?.toISOString === "function") return value.toISOString()
      if (typeof value?.toNumber === "function") return value.toNumber()
      if (typeof value === "number" || typeof value === "string") return value
      return null
    }

    const sourceAliases = {
      "Finviz News Flow": ["Finviz News Flow"],
      "Finviz News": ["Finviz News"],
      "TradingView News Flow": ["TradingView News Flow"],
      "TradingView News": ["TradingView News"],
      "GlobeNewswire Public Companies": ["GlobeNewswire Public Companies", "GlobeNewswire"],
      "ACCESS Newswire": ["ACCESS Newswire", "AccessWire"],
      "BusinessWire": ["BusinessWire", "Business Wire"],
      "Schwab News": ["Schwab News", "Charles Schwab", "TD Ameritrade"],
      "X/Twitter": ["X/Twitter", "Twitter", "X"],
      "FDA": ["FDA Press Releases", "FDA Recalls", "FDA Drug Approvals", "FDA MedWatch Safety Alerts", "FDA"],
    }
    const screenerSources = {
      "Finviz Elite Screener": { quote_source: "finviz_elite_screener" },
      "TradingView Numeric Screener": { quote_source: "tradingview_numeric_screener" },
      "Schwab Movers": { source: "Schwab Movers" },
    }
    const statusPreserveSet = new Set([
      "api_key_required",
      "api_key_recommended",
      "broker_api_pending",
      "gateway_required",
      "licensed_feed_required",
      "no_rows",
      "rate_limited_public",
      "requires_official_api_access",
      "ready_no_rows_yet",
      "error",
    ])
    const staleSecondsFor = (entry) => {
      if (entry.collection === "screeners") return entry.source === "Finviz Elite Screener" ? 45 * 60 : 90 * 60
      if (entry.collection === "socials") return 6 * 60 * 60
      if (entry.source === "SEC EDGAR") return 24 * 60 * 60
      return 12 * 60 * 60
    }
    const liveStatusFor = (entry) => {
      const aliases = [entry.source, ...(sourceAliases[entry.source] || [])]
      for (const alias of aliases) {
        const status = statusBySource.get(alias)
        if (status) return status
      }
      return null
    }

    async function countSource(entry) {
      const aliases = sourceAliases[entry.source] || [entry.source]
      if (entry.collection === "articles") {
        const query = {
          $or: aliases.map((source) => ({
            source: { $regex: `^${escapeRegExp(source)}$`, $options: "i" },
          })),
        }
        const [count, latest] = await Promise.all([
          db.collection("articles").countDocuments(query),
          db.collection("articles").find(query).sort({ fetched_date: -1, detected_at: -1, publish_date: -1 }).limit(1).project({ fetched_date: 1, detected_at: 1, publish_date: 1 }).next(),
        ])
        return {
          count,
          latest_fetch: apiTime(latest?.fetched_date || latest?.detected_at),
          latest_publish: apiTime(latest?.publish_date),
        }
      }
      if (entry.collection === "screeners") {
        const query = screenerSources[entry.source] || { source: entry.source }
        const [count, latest] = await Promise.all([
          db.collection("screeners").countDocuments(query),
          db.collection("screeners").find(query).sort({ quote_updated_at: -1, finviz_seen_at: -1, tradingview_seen_at: -1 }).limit(1).project({ quote_updated_at: 1, finviz_seen_at: 1, tradingview_seen_at: 1 }).next(),
        ])
        return {
          count,
          latest_fetch: apiTime(latest?.quote_updated_at || latest?.finviz_seen_at || latest?.tradingview_seen_at),
          latest_publish: null,
        }
      }
      if (entry.collection === "socials") {
        const aliasesLower = aliases.map((s) => s.toLowerCase())
        const query = {
          $or: [
            { platform: { $in: aliasesLower } },
            { platform: { $in: aliases } },
            { source: { $in: aliases } },
          ],
        }
        const [count, latest] = await Promise.all([
          db.collection("socials").countDocuments(query),
          db.collection("socials").find(query).sort({ fetched_at: -1, fetched_date: -1, detected_at: -1, created_at: -1, createdAt: -1 }).limit(1).project({ fetched_at: 1, fetched_date: 1, detected_at: 1, created_at: 1, createdAt: 1 }).next(),
        ])
        return {
          count,
          latest_fetch: apiTime(latest?.fetched_at || latest?.fetched_date || latest?.detected_at || latest?.created_at || latest?.createdAt),
          latest_publish: null,
        }
      }
      return { count: 0, latest_fetch: null, latest_publish: null }
    }

    const sources = []
    for (const entry of registry) {
      const counted = await countSource(entry)
      const liveStatus = liveStatusFor(entry)
      const envValue = entry.env_var ? String(process.env[entry.env_var] || "").trim() : ""
      const hasRequiredEnv = !entry.env_var || (Boolean(envValue) && !["0", "false", "no"].includes(envValue.toLowerCase()))
      const requiresMissingCredential = Boolean(entry.auth_required && entry.env_var && !hasRequiredEnv)
      let status = liveStatus?.status || entry.status || "unknown"
      const storedLatestSec = timestampSeconds(counted.latest_fetch)
      const storedAgeSeconds = storedLatestSec ? Math.max(0, Math.floor(Date.now() / 1000) - storedLatestSec) : null
      const liveCheckedSec = timestampSeconds(liveStatus?.last_checked_at)
      const liveCheckAgeSeconds = liveCheckedSec ? Math.max(0, Math.floor(Date.now() / 1000) - liveCheckedSec) : null
      const staleAfterSeconds = staleSecondsFor(entry)
      if (requiresMissingCredential && counted.count === 0 && !["broker_api_pending", "licensed_feed_required", "planned"].includes(entry.status)) {
        status = "api_key_required"
      } else if (!liveStatus && counted.count === 0 && String(status).startsWith("working")) {
        status = "ready_no_rows_yet"
      } else if (
        counted.count > 0 &&
        !["planned", "licensed_feed_required", "broker_api_pending"].includes(status) &&
        !statusPreserveSet.has(status)
      ) {
        status = status.startsWith("working") ? status : "working"
      }
      if (counted.count > 0 && ["ready_no_rows_yet", "no_rows"].includes(status)) {
        status = "working"
      }
      if (
        counted.count > 0 &&
        storedAgeSeconds != null &&
        storedAgeSeconds > staleAfterSeconds &&
        String(status).startsWith("working") &&
        !(entry.collection === "articles" && liveCheckAgeSeconds != null && liveCheckAgeSeconds <= staleAfterSeconds)
      ) {
        status = "stale"
      }

      sources.push({
        ...entry,
        status,
        configured: hasRequiredEnv,
        count: counted.count,
        latest_fetch: counted.latest_fetch,
        latest_publish: counted.latest_publish,
        age_seconds: storedAgeSeconds,
        stale_after_seconds: staleAfterSeconds,
        last_check_age_seconds: liveCheckAgeSeconds,
        last_checked_at: apiTime(liveStatus?.last_checked_at),
        detail: liveStatus?.detail || "",
      })
    }

    const working = sources.filter((row) => String(row.status).startsWith("working") && (row.count > 0 || row.last_checked_at))
    const ready = sources.filter((row) => row.status === "ready_no_rows_yet")
    const stale = sources.filter((row) => row.status === "stale")
    const blocked = sources.filter((row) => row.count === 0 && !String(row.status).startsWith("working") && row.status !== "planned" && row.status !== "ready_no_rows_yet" && row.status !== "stale")

    res.json({
      working_count: working.length,
      ready_count: ready.length,
      stale_count: stale.length,
      blocked_count: blocked.length,
      planned_count: sources.filter((row) => row.status === "planned").length,
      sources,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to load source health", detail: err.message });
  }
});


// FEEDFLASH_SETTINGS_KEYWORDS_SOURCES_PATCH_V1

function settingsDb() {
  const d = mongoose.connection.db
  if (!d) throw new Error('MongoDB connection is not ready')
  return d
}

const DEFAULT_SIGNAL_KEYWORDS = [
  ["earnings", "fundamental"],
  ["ipo", "fundamental"],
  ["listing", "fundamental"],
  ["delisting", "fundamental"],
  ["dividend", "fundamental"],
  ["merger", "fundamental"],
  ["acquisition", "fundamental"],
  ["buyout", "fundamental"],
  ["contract", "fundamental"],
  ["partnership", "fundamental"],
  ["fda approval", "regulatory"],
  ["fda rejection", "regulatory"],
  ["clinical trial", "regulatory"],
  ["sec filing", "regulatory"],
  ["short squeeze", "momentum"],
  ["price target", "analyst"],
  ["downgrade", "analyst"],
  ["upgrade", "analyst"],
  ["beat estimates", "fundamental"],
  ["miss estimates", "fundamental"],
  ["guidance", "fundamental"],
  ["recall", "regulatory"],
  ["bankruptcy", "fundamental"],
  ["layoffs", "fundamental"],
  ["restructuring", "fundamental"]
];

async function seedDefaultKeywordsIfEmpty() {
  const keywords = settingsDb().collection("keywords");
  const count = await keywords.countDocuments();
  if (count > 0) return;

  await keywords.insertMany(DEFAULT_SIGNAL_KEYWORDS.map(([keyword, category]) => ({
    keyword,
    word: keyword,
    category,
    enabled: true,
    active: true,
    hits: 0,
    created_at: Math.floor(Date.now() / 1000),
    updated_at: Math.floor(Date.now() / 1000)
  })));
}

function cleanSettingText(v) {
  return String(v || "").trim();
}

function cleanKeyword(v) {
  return cleanSettingText(v).toLowerCase();
}

const DEFAULT_CONNECTION_SETTINGS = {
  finviz: {
    label: "Finviz Elite",
    url: process.env.FINVIZ_URL || "https://elite.finviz.com/screener",
    token: process.env.FINVIZ_TOKEN || "",
    login: "",
  },
  tradingview: {
    label: "TradingView",
    url: process.env.TRADINGVIEW_URL || "https://www.tradingview.com",
    token: process.env.TRADINGVIEW_TOKEN || "",
    login: process.env.TRADINGVIEW_LOGIN || "",
  },
  td_ameritrade: {
    label: "TD Ameritrade / Schwab",
    url: process.env.TD_URL || process.env.SCHWAB_URL || "",
    token: process.env.TD_TOKEN || process.env.SCHWAB_TOKEN || "",
    login: process.env.TD_LOGIN || process.env.SCHWAB_LOGIN || "",
  },
  interactive_brokers: {
    label: "Interactive Brokers",
    url: process.env.IB_URL || "",
    token: process.env.IB_TOKEN || "",
    login: process.env.IB_LOGIN || "",
  },
};

function cleanConnectionPayload(value = {}) {
  const out = {};
  for (const [key, defaults] of Object.entries(DEFAULT_CONNECTION_SETTINGS)) {
    const row = value[key] || {};
    out[key] = {
      label: defaults.label,
      url: cleanSettingText(row.url ?? defaults.url),
      token: cleanSettingText(row.token ?? defaults.token),
      login: cleanSettingText(row.login ?? defaults.login),
    };
  }
  return out;
}

app.get("/api/settings/connections", async (req, res) => {
  try {
    const row = await settingsDb().collection("app_settings").findOne({ key: "connections" });
    res.json({
      ok: true,
      connections: cleanConnectionPayload(row?.value || {}),
    });
  } catch (err) {
    console.error("GET /api/settings/connections failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.patch("/api/settings/connections", async (req, res) => {
  try {
    const connections = cleanConnectionPayload(req.body.connections || req.body || {});
    await settingsDb().collection("app_settings").updateOne(
      { key: "connections" },
      {
        $set: {
          key: "connections",
          value: connections,
          updated_at: Math.floor(Date.now() / 1000),
        },
        $setOnInsert: { created_at: Math.floor(Date.now() / 1000) },
      },
      { upsert: true }
    );
    res.json({ ok: true, connections });
  } catch (err) {
    console.error("PATCH /api/settings/connections failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.get("/api/keywords", async (req, res) => {
  try {
    await seedDefaultKeywordsIfEmpty();
    const rows = await settingsDb().collection("keywords")
      .find({})
      .sort({ enabled: -1, category: 1, keyword: 1, word: 1 })
      .toArray();

    res.json({
      ok: true,
      keywords: rows.map(r => ({
        id: String(r._id),
        keyword: r.keyword || r.word,
        word: r.word || r.keyword,
        category: r.category || "custom",
        enabled: r.enabled !== false && r.active !== false,
        active: r.enabled !== false && r.active !== false,
        hits: r.hits || 0
      }))
    });
  } catch (err) {
    console.error("GET /api/keywords failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.post("/api/keywords", async (req, res) => {
  try {
    const keyword = cleanKeyword(req.body.keyword || req.body.word);
    const category = cleanSettingText(req.body.category || "custom").toLowerCase();

    if (!keyword) return res.status(400).json({ ok: false, error: "keyword is required" });

    const now = Math.floor(Date.now() / 1000);
    await settingsDb().collection("keywords").updateOne(
      { keyword },
      {
        $set: { keyword, word: keyword, category, enabled: true, active: true, updated_at: now },
        $setOnInsert: { hits: 0, created_at: now }
      },
      { upsert: true }
    );

    res.json({ ok: true, keyword, category });
  } catch (err) {
    console.error("POST /api/keywords failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.patch("/api/keywords/:keyword", async (req, res) => {
  try {
    const keyword = cleanKeyword(decodeURIComponent(req.params.keyword));
    const enabled = req.body.enabled !== false && req.body.active !== false;
    const result = await settingsDb().collection("keywords").updateOne(
      { $or: [{ keyword }, { word: keyword }] },
      { $set: { enabled, active: enabled, updated_at: Math.floor(Date.now() / 1000) } }
    );
    res.json({ ok: true, matched: result.matchedCount, modified: result.modifiedCount });
  } catch (err) {
    console.error("PATCH /api/keywords/:keyword failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.delete("/api/keywords/:keyword", async (req, res) => {
  try {
    const keyword = cleanKeyword(decodeURIComponent(req.params.keyword));
    const result = await settingsDb().collection("keywords").deleteOne({ $or: [{ keyword }, { word: keyword }] });
    res.json({ ok: true, deleted: result.deletedCount });
  } catch (err) {
    console.error("DELETE /api/keywords/:keyword failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

const PROFESSOR_STRUCTURED_SOURCES = [
  { source: "Finviz News Flow", status: "working_elite_cookie", method: "platform_news_flow", editable: false },
  { source: "Finviz News", status: "working_public", method: "platform_news_screener", editable: false },
  { source: "TradingView News", status: "working_public", method: "platform_news_flow", editable: false },
  { source: "PR Newswire", status: "public_feed", method: "rss", editable: false },
  { source: "GlobeNewswire", status: "public_feed", method: "rss", editable: false },
  { source: "FDA", status: "public_feed", method: "official_fda_rss", editable: false },
  { source: "Business Wire", status: "valid_rss_channel_required", method: "official_businesswire_rss_or_media_partner_feed", editable: false },
  { source: "ACCESS Newswire / AccessWire", status: "public_endpoint", method: "accessnewswire_newsroom_json", editable: false },
  { source: "Benzinga", status: "api_key_required", method: "official_benzinga_stock_news_api", editable: false },
  { source: "Dow Jones Newswires", status: "contract_required", method: "licensed_api", editable: false },
  { source: "TradingView News Flow", status: "public_endpoint", method: "news_mediator_symbol_endpoint", editable: false },
  { source: "Interactive Brokers News", status: "broker_api_required", method: "broker_api", editable: false },
  { source: "Charles Schwab / TD Ameritrade News", status: "broker_api_required", method: "broker_api", editable: false }
];

async function countArticlesForSourceLabel(label) {
  const parts = label.split("/").map(s => s.trim()).filter(Boolean);
  const pattern = parts.length ? parts.join("|") : label;
  return settingsDb().collection("articles").countDocuments({ source: new RegExp(pattern, "i") });
}

app.get("/api/settings/sources", async (req, res) => {
  try {
    const db = settingsDb()
    const [custom, favDocs] = await Promise.all([
      db.collection("rss_sources").find({}).sort({ enabled: -1, name: 1 }).toArray(),
      db.collection("source_favorites").find({}).toArray(),
    ])
    const favSet = new Set(favDocs.map(f => f.name))

    const structured = [];
    for (const s of PROFESSOR_STRUCTURED_SOURCES) {
      structured.push({
        ...s,
        is_favorite: favSet.has(s.source),
        count: await countArticlesForSourceLabel(s.source)
      });
    }

    res.json({
      ok: true,
      structured,
      favorites: Array.from(favSet),
      custom_rss_sources: [],
      blocked_custom_rss_source_count: custom.length,
      custom_rss_policy: "disabled_professor_sources_only"
    });
  } catch (err) {
    console.error("GET /api/settings/sources failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.post("/api/settings/sources/:name/favorite", async (req, res) => {
  try {
    const name = cleanSettingText(decodeURIComponent(req.params.name))
    await settingsDb().collection("source_favorites").updateOne(
      { name },
      { $set: { name, favorited_at: Math.floor(Date.now() / 1000) } },
      { upsert: true }
    )
    res.json({ ok: true, name, favorited: true })
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.delete("/api/settings/sources/:name/favorite", async (req, res) => {
  try {
    const name = cleanSettingText(decodeURIComponent(req.params.name))
    await settingsDb().collection("source_favorites").deleteOne({ name })
    res.json({ ok: true, name, favorited: false })
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.get("/api/settings/sources/favorites", async (req, res) => {
  try {
    const docs = await settingsDb().collection("source_favorites").find({}).sort({ favorited_at: -1 }).toArray()
    res.json({ ok: true, favorites: docs.map(d => d.name) })
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.post("/api/settings/sources", async (req, res) => {
  try {
    const name = cleanSettingText(req.body.name || req.body.source);
    const url = cleanSettingText(req.body.url);
    const category = cleanSettingText(req.body.category || "custom").toLowerCase();

    if (!name || !url) return res.status(400).json({ ok: false, error: "name and url are required" });
    if (!/^https?:\/\//i.test(url)) return res.status(400).json({ ok: false, error: "url must start with http:// or https://" });
    return res.status(403).json({
      ok: false,
      error: "custom RSS sources are disabled; FlashFeed is locked to professor-approved sources only",
      allowed_sources: PROFESSOR_STRUCTURED_SOURCES.map(s => s.source)
    });
  } catch (err) {
    console.error("POST /api/settings/sources failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.patch("/api/settings/sources/:name", async (req, res) => {
  try {
    const name = cleanSettingText(decodeURIComponent(req.params.name));
    const enabled = req.body.enabled !== false;
    const result = await settingsDb().collection("rss_sources").updateOne(
      { name },
      { $set: { enabled, updated_at: Math.floor(Date.now() / 1000) } }
    );
    res.json({ ok: true, matched: result.matchedCount, modified: result.modifiedCount });
  } catch (err) {
    console.error("PATCH /api/settings/sources/:name failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.delete("/api/settings/sources/:name", async (req, res) => {
  try {
    const name = cleanSettingText(decodeURIComponent(req.params.name));
    const result = await settingsDb().collection("rss_sources").deleteOne({ name });
    res.json({ ok: true, deleted: result.deletedCount });
  } catch (err) {
    console.error("DELETE /api/settings/sources/:name failed:", err);
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});


// FEEDFLASH_SETTINGS_KEYWORDS_ALIAS_PATCH_V1
app.get('/api/settings/keywords', async (req, res) => {
  try {
    await seedDefaultKeywordsIfEmpty()

    const rows = await settingsDb().collection('keywords')
      .find({})
      .sort({ enabled: -1, category: 1, keyword: 1, word: 1 })
      .toArray()

    res.json({
      ok: true,
      keywords: rows.map(r => ({
        id: String(r._id),
        keyword: r.keyword || r.word,
        word: r.word || r.keyword,
        category: r.category || 'custom',
        enabled: r.enabled !== false && r.active !== false,
        active: r.enabled !== false && r.active !== false,
        hits: r.hits || 0
      }))
    })
  } catch (err) {
    console.error('GET /api/settings/keywords failed:', err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.post('/api/settings/keywords', async (req, res) => {
  try {
    const keyword = cleanKeyword(req.body?.keyword || req.body?.word)
    const category = cleanSettingText(req.body?.category || 'custom').toLowerCase()

    if (!keyword) return res.status(400).json({ ok: false, error: 'keyword is required' })

    const now = Math.floor(Date.now() / 1000)
    await settingsDb().collection('keywords').updateOne(
      { keyword },
      {
        $set: { keyword, word: keyword, category, enabled: true, active: true, updated_at: now },
        $setOnInsert: { hits: 0, created_at: now }
      },
      { upsert: true }
    )

    res.json({ ok: true, keyword, category })
  } catch (err) {
    console.error('POST /api/settings/keywords failed:', err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.patch('/api/settings/keywords/:keyword', async (req, res) => {
  try {
    const keyword = cleanKeyword(decodeURIComponent(req.params.keyword))
    const enabled = req.body?.enabled !== false && req.body?.active !== false

    const result = await settingsDb().collection('keywords').updateOne(
      { $or: [{ keyword }, { word: keyword }] },
      { $set: { enabled, active: enabled, updated_at: Math.floor(Date.now() / 1000) } }
    )

    res.json({ ok: true, matched: result.matchedCount, modified: result.modifiedCount })
  } catch (err) {
    console.error('PATCH /api/settings/keywords failed:', err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

app.delete('/api/settings/keywords/:keyword', async (req, res) => {
  try {
    const keyword = cleanKeyword(decodeURIComponent(req.params.keyword))

    const result = await settingsDb().collection('keywords').deleteOne({
      $or: [{ keyword }, { word: keyword }]
    })

    res.json({ ok: true, deleted: result.deletedCount })
  } catch (err) {
    console.error('DELETE /api/settings/keywords failed:', err)
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

  // ═══════════════════════════════════════════════════════════════════════════
  //  HARD-DISK DATABASE — on-disk persistence + retention + auto-grab
  //  Companion to the RAM layer (Redis). See diskdb.js. Buckets:
  //    manual (3d) · auto (2d, away-mode) · fetch (3d, Redis+Kafka path)
  // ═══════════════════════════════════════════════════════════════════════════
  await diskdb.init()
  const diskRetention = diskdb.stats().retention_days
  const diskFetchDays = diskRetention.fetch
  const diskAutoDays  = diskRetention.auto
  const diskDailyDays = diskRetention.daily || 31

  // Shape the latest Mongo news for the disk store.
  async function collectRecentNewsFromMongo(db, days = 3, limit = 5000) {
    if (!db) return []
    // publish_date is stored as Unix seconds (integer) — compare as number, not Date
    const cutoffSec = Math.floor((Date.now() - Math.max(1, days) * 86_400_000) / 1000)
    const projection = { title: 1, source: 1, url: 1, publish_date: 1, fetched_date: 1, detected_at: 1, sentiment: 1, sentiment_score: 1, ml_confidence: 1, ticker: 1, tickers: 1, event_type: 1, event_score: 1, content: 1 }
    let docs = []
    try {
      docs = await db.collection('articles').find({
        $or: [
          { publish_date: { $gte: cutoffSec } },
          { fetched_date: { $gte: cutoffSec } },
        ]
      }, { projection })
        .sort({ publish_date: -1 }).limit(Math.max(1, Math.min(20000, limit))).toArray()
    } catch (_) {
      try { docs = await db.collection('articles').find({}, { projection }).sort({ _id: -1 }).limit(2000).toArray() }
      catch (__) { docs = [] }
    }
    return docs.map(d => {
      const sec = timestampSeconds(d.publish_date || d.fetched_date || d.detected_at) || null
      const score = d.sentiment === 'bullish' ? (d.ml_confidence ?? 0.5) : d.sentiment === 'bearish' ? -(d.ml_confidence ?? 0.5) : 0
      return {
        ticker: articlePrimaryTicker(d) || String(d.ticker || '').split(',')[0] || '',
        tickers: Array.isArray(d.tickers) ? d.tickers : String(d.ticker || '').split(',').map(s => s.trim()).filter(Boolean),
        title: d.title || '',
        source: d.source || '',
        url: d.url && d.url !== '#' ? d.url : '',
        summary: String(d.content || '').slice(0, 400),
        sentiment: d.sentiment || 'neutral',
        sentiment_score: Number(Number(d.sentiment_score ?? score).toFixed(3)),
        ml_confidence: Number(d.ml_confidence || 0),
        event_type: d.event_type || 'general_news',
        event_score: Number(d.event_score || 0),
        published_at: sec,
        detected_at: timestampSeconds(d.detected_at || d.fetched_date) || null,
      }
    })
  }

  // Redis+Kafka fetch path → hard disk (bucket 'fetch', 3-day retention).
  async function persistFetchNewsToDisk(db) {
    if (!diskdb.isEnabled()) return { stored: 0 }
    try { return diskdb.storeNews(await collectRecentNewsFromMongo(db, diskFetchDays, 5000), 'fetch') }
    catch (e) { console.warn('persistFetchNewsToDisk error:', e.message); return { stored: 0 } }
  }

  async function persistDailyArchiveToDisk(db) {
    if (!diskdb.isEnabled()) return { stored: 0 }
    try {
      const news = await collectRecentNewsFromMongo(db, 1, Number(process.env.DISK_DAILY_ARCHIVE_LIMIT || 10000))
      return diskdb.storeDailyArchive(news, { maxDays: diskDailyDays })
    } catch (e) {
      console.warn('persistDailyArchiveToDisk error:', e.message)
      return { stored: 0 }
    }
  }

  // ── Presence: the frontend pings while open; absence ⇒ auto-grabber archives.
  let lastPresenceAt = 0
  const PRESENCE_TIMEOUT_MS = Number(process.env.PRESENCE_TIMEOUT_MS || 90_000)
  const siteOpen = () => (Date.now() - lastPresenceAt) < PRESENCE_TIMEOUT_MS
  // Reassigned below once the on-site auto-fetch is set up; the ping triggers a check.
  let triggerOnSiteAutoFetch = () => {}
  app.post('/api/presence/ping', (req, res) => {
    lastPresenceAt = Date.now()
    res.json({ ok: true, last_presence_at: lastPresenceAt, site_open: true })
    // While someone is on the site, grab fresh news on arrival and then every interval.
    try { triggerOnSiteAutoFetch() } catch (_) {}
  })

  // ── Disk DB REST API ───────────────────────────────────────────────────────
  // Save the last N days of news to disk (manual button + on-exit beacon).
  app.post('/api/disk/save-news', async (req, res) => {
    const db = mongoose.connection.db
    const days = Math.max(1, Math.min(30, Number(req.query.days || req.body?.days || 3)))
    if (!diskdb.isEnabled()) return res.status(503).json({ ok: false, error: 'Hard-disk database is not available', saved: 0 })
    try {
      const r = diskdb.storeNews(await collectRecentNewsFromMongo(db, days, 5000), 'manual')
      res.json({ ok: true, saved: r.stored, bucket: 'manual', days, retention_days: diskdb.stats().retention_days.manual })
    } catch (e) { res.status(500).json({ ok: false, error: String(e.message || e), saved: 0 }) }
  })

  app.post('/api/disk/save-daily', async (req, res) => {
    const db = mongoose.connection.db
    if (!diskdb.isEnabled()) return res.status(503).json({ ok: false, error: 'Hard-disk database is not available', saved: 0 })
    try {
      const r = await persistDailyArchiveToDisk(db)
      lastDailyArchiveAt = Date.now()
      lastDailyArchiveDate = todayInArchiveZone()
      res.json({ ok: true, saved: r.unique ?? r.stored ?? 0, date: r.date, total_days: r.total_days, retention_days: diskDailyDays })
    } catch (e) { res.status(500).json({ ok: false, error: String(e.message || e), saved: 0 }) }
  })

  app.get('/api/disk/news', (req, res) => {
    const news = diskdb.listNews({ bucket: req.query.bucket, ticker: req.query.ticker, limit: req.query.limit })
    res.json({ ok: true, count: news.length, news })
  })

  app.get('/api/disk/stats', (req, res) => {
    const diskStats = diskdb.stats()
    res.json({
      ...diskStats,
      presence: { site_open: siteOpen(), last_presence_at: lastPresenceAt || null },
      auto_fetch: {
        onsite_enabled: ONSITE_FETCH_ENABLED,
        onsite_interval_min: Math.round(ONSITE_FETCH_INTERVAL_MS / 60000),
        onsite_last_at: lastOnSiteFetchAt,
        onsite_retention_days: diskFetchDays,
        away_enabled: AUTO_GRAB_ENABLED,
        away_interval_min: Math.round(AUTO_GRAB_INTERVAL_MS / 60000),
        away_retention_days: diskAutoDays,
      },
      daily_archive: {
        ...(diskStats.daily_archive || {}),
        enabled: DAILY_ARCHIVE_ENABLED,
        schedule_time: DAILY_ARCHIVE_TIME,
        timezone: DAILY_ARCHIVE_TIMEZONE,
        last_archive_at: lastDailyArchiveAt,
        last_archive_date: lastDailyArchiveDate,
        retention_days: diskDailyDays,
      },
    })
  })

  // ── Redis (RAM) stats ─────────────────────────────────────────────────────
  app.get('/api/redis/stats', async (req, res) => {
    if (!redisReady()) {
      return res.json({ available: false, error: 'Redis not connected' })
    }
    try {
      const raw = await redis.info()
      const parse = (key) => {
        const m = raw.match(new RegExp(`^${key}:(.+)$`, 'm'))
        return m ? m[1].trim() : null
      }
      const usedMem   = Number(parse('used_memory') || 0)
      const peakMem   = Number(parse('used_memory_peak') || 0)
      const maxMem    = Number(parse('maxmemory') || 0)
      const keyspaceHits   = Number(parse('keyspace_hits') || 0)
      const keyspaceMisses = Number(parse('keyspace_misses') || 0)
      const totalCmds = Number(parse('total_commands_processed') || 0)
      const hitRate   = (keyspaceHits + keyspaceMisses) > 0
        ? Math.round(keyspaceHits / (keyspaceHits + keyspaceMisses) * 100)
        : null
      // Count total keys across all DBs
      const dbSection = raw.match(/^db\d+:keys=(\d+)/mg) || []
      const totalKeys = dbSection.reduce((s, l) => s + Number(l.match(/keys=(\d+)/)[1]), 0)
      const uptimeSecs = Number(parse('uptime_in_seconds') || 0)
      res.json({
        available: true,
        mode: 'RAM-only (no disk persistence)',
        policy: parse('maxmemory_policy') || 'allkeys-lru',
        used_memory_bytes: usedMem,
        peak_memory_bytes: peakMem,
        max_memory_bytes: maxMem,
        used_pct: maxMem > 0 ? Math.round(usedMem / maxMem * 100) : null,
        total_keys: totalKeys,
        keyspace_hits: keyspaceHits,
        keyspace_misses: keyspaceMisses,
        hit_rate_pct: hitRate,
        total_commands: totalCmds,
        uptime_seconds: uptimeSecs,
        version: parse('redis_version'),
        connected_clients: Number(parse('connected_clients') || 0),
      })
    } catch (e) {
      res.json({ available: false, error: e.message })
    }
  })

  // Download saved news as a real local JSON file ("locally save").
  app.get('/api/disk/export', (req, res) => {
    const days = Math.max(1, Math.min(30, Number(req.query.days || 3)))
    const bucket = req.query.bucket || null
    const rows = diskdb.recentForExport(days, bucket)
    const stamp = new Date().toISOString().slice(0, 10)
    res.set('Content-Type', 'application/json')
    res.set('Content-Disposition', `attachment; filename="flashfeed-news-${stamp}.json"`)
    res.send(JSON.stringify({ exported_at: new Date().toISOString(), days, bucket: bucket || 'all', count: rows.length, news: rows }, null, 2))
  })

  app.post('/api/disk/sweep', (req, res) => {
    res.json({ ok: true, deleted: diskdb.sweep(), stats: diskdb.stats() })
  })

  const DAILY_ARCHIVE_ENABLED = process.env.DISK_DAILY_ARCHIVE_ENABLED !== 'false'
  const DAILY_ARCHIVE_TIME = process.env.DISK_DAILY_ARCHIVE_TIME || '23:55'
  const DAILY_ARCHIVE_TIMEZONE = process.env.DISK_DAILY_ARCHIVE_TIMEZONE || MARKET_WINDOW_TIME_ZONE
  const DAILY_ARCHIVE_CHECK_MS = Math.max(30_000, Number(process.env.DISK_DAILY_ARCHIVE_CHECK_MS || 60_000))
  const initialDailyStats = diskdb.stats().daily_archive || {}
  let lastDailyArchiveAt = null
  let lastDailyArchiveDate = initialDailyStats.newest_day || null

  function archiveZoneParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: DAILY_ARCHIVE_TIMEZONE,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(date)
    return Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, Number(part.value)]))
  }

  function todayInArchiveZone(date = new Date()) {
    const p = archiveZoneParts(date)
    return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`
  }

  function dailyArchiveDue() {
    if (!DAILY_ARCHIVE_ENABLED || !diskdb.isEnabled()) return false
    const [hour, minute] = DAILY_ARCHIVE_TIME.split(':').map(n => Number(n))
    const p = archiveZoneParts()
    const today = todayInArchiveZone()
    const pastSchedule = p.hour > hour || (p.hour === hour && p.minute >= minute)
    return pastSchedule && lastDailyArchiveDate !== today
  }

  let dailyArchiveRunning = false
  async function dailyArchiveTick() {
    if (dailyArchiveRunning || refreshCycleInFlight || !dailyArchiveDue()) return
    const db = mongoose.connection.db
    if (!db) return
    dailyArchiveRunning = true
    try {
      const r = await persistDailyArchiveToDisk(db)
      lastDailyArchiveAt = Date.now()
      lastDailyArchiveDate = r.date || todayInArchiveZone()
      console.log(`  DailyArchive → saved ${r.unique ?? r.stored ?? 0} articles for ${lastDailyArchiveDate} (rolling ${diskDailyDays}d)`)
    } catch (e) {
      console.warn('dailyArchiveTick error:', e.message)
    } finally {
      dailyArchiveRunning = false
    }
  }
  if (DAILY_ARCHIVE_ENABLED && diskdb.isEnabled()) {
    const t = setInterval(dailyArchiveTick, DAILY_ARCHIVE_CHECK_MS)
    if (t.unref) t.unref()
    setTimeout(() => dailyArchiveTick().catch(() => {}), 2500).unref?.()
    console.log(`  DailyArchive → enabled (${DAILY_ARCHIVE_TIME} ${DAILY_ARCHIVE_TIMEZONE}; rolling ${diskDailyDays} daily snapshots)`)
  }

  // ── Prediction daily archive ───────────────────────────────────────────────
  // This is the durable audit trail for "what did the dashboard recommend
  // yesterday for today?" Redis/API caches are intentionally short-lived, so the
  // prediction rows need their own daily Mongo snapshot.
  const PREDICTION_DAILY_ARCHIVE_ENABLED = process.env.PREDICTION_DAILY_ARCHIVE_ENABLED !== 'false'
  const PREDICTION_DAILY_ARCHIVE_TIME = process.env.PREDICTION_DAILY_ARCHIVE_TIME || '19:55'
  const PREDICTION_DAILY_ARCHIVE_TIMEZONE = process.env.PREDICTION_DAILY_ARCHIVE_TIMEZONE || MARKET_WINDOW_TIME_ZONE
  const PREDICTION_DAILY_ARCHIVE_CHECK_MS = Math.max(60_000, Number(process.env.PREDICTION_DAILY_ARCHIVE_CHECK_MS || 5 * 60_000))
  const PREDICTION_DAILY_ARCHIVE_HORIZON = process.env.PREDICTION_DAILY_ARCHIVE_HORIZON || '1d'
  const PREDICTION_DAILY_ARCHIVE_MAX_RAW = process.env.PREDICTION_DAILY_ARCHIVE_MAX_RAW || '75'
  const PREDICTION_DAILY_ARCHIVE_MAX_HIGH = process.env.PREDICTION_DAILY_ARCHIVE_MAX_HIGH || '10'
  const PREDICTION_DAILY_ARCHIVE_DAYS = process.env.PREDICTION_DAILY_ARCHIVE_DAYS || '4'
  const PREDICTION_DAILY_ARCHIVE_RETENTION_DAYS = process.env.PREDICTION_DAILY_ARCHIVE_RETENTION_DAYS || process.env.PREDICTION_ARCHIVE_RETENTION_DAYS || '3'
  const PREDICTION_DAILY_LABEL_ENABLED = process.env.PREDICTION_DAILY_LABEL_ENABLED !== 'false'
  const PREDICTION_DAILY_TRAIN_ENABLED = process.env.PREDICTION_DAILY_TRAIN_ENABLED !== 'false'
  let predictionArchiveRunning = false
  let lastPredictionArchiveDate = null

  function predictionArchiveZoneParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: PREDICTION_DAILY_ARCHIVE_TIMEZONE,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(date)
    return Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, Number(part.value)]))
  }

  function todayInPredictionArchiveZone(date = new Date()) {
    const p = predictionArchiveZoneParts(date)
    return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`
  }

  function predictionArchiveDue() {
    if (!PREDICTION_DAILY_ARCHIVE_ENABLED) return false
    const [hour, minute] = PREDICTION_DAILY_ARCHIVE_TIME.split(':').map(n => Number(n))
    const p = predictionArchiveZoneParts()
    const today = todayInPredictionArchiveZone()
    const pastSchedule = p.hour > hour || (p.hour === hour && p.minute >= minute)
    return pastSchedule && lastPredictionArchiveDate !== today
  }

  async function runPredictionNodeScript(scriptName, args = [], timeout = 300000) {
    const { execFile } = await import('node:child_process')
    const scriptPathCandidates = [
      path.join(PROJECT_ROOT, 'scripts', scriptName),
      path.join(SERVER_DIR, 'scripts', scriptName),
    ]
    const scriptPath = scriptPathCandidates.find(candidate => fs.existsSync(candidate))
    if (!scriptPath) throw new Error(`Prediction archive script missing: ${scriptName}`)
    const mongoUri = process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://mongo:27017/feedflash'
    return await new Promise((resolve, reject) => {
      execFile(process.execPath, [scriptPath, ...args], {
        cwd: fs.existsSync(path.join(PROJECT_ROOT, 'scripts')) ? PROJECT_ROOT : SERVER_DIR,
        timeout,
        maxBuffer: 16 * 1024 * 1024,
        env: {
          ...process.env,
          MONGODB_URI: mongoUri,
          MONGO_URI: mongoUri,
          MONGO_DB: 'feedflash',
          MONGODB_DB: 'feedflash',
          FLASHFEED_API_BASE_URL: process.env.FLASHFEED_API_BASE_URL || `http://127.0.0.1:${PORT}`,
        },
      }, (error, stdout, stderr) => {
        if (error) {
          error.stdout = stdout
          error.stderr = stderr
          reject(error)
          return
        }
        resolve({ stdout: String(stdout || ''), stderr: String(stderr || '') })
      })
    })
  }

  async function predictionDailyArchiveTick() {
    if (predictionArchiveRunning || refreshCycleInFlight || !predictionArchiveDue()) return
    predictionArchiveRunning = true
    const today = todayInPredictionArchiveZone()
    try {
      const archiveArgs = [
        '--horizon', PREDICTION_DAILY_ARCHIVE_HORIZON,
        '--maxRaw', PREDICTION_DAILY_ARCHIVE_MAX_RAW,
        '--maxHighConviction', PREDICTION_DAILY_ARCHIVE_MAX_HIGH,
        '--days', PREDICTION_DAILY_ARCHIVE_DAYS,
        '--retentionDays', PREDICTION_DAILY_ARCHIVE_RETENTION_DAYS,
        '--tag', 'daily',
      ]
      const saved = await runPredictionNodeScript('save_daily_prediction_snapshot.js', archiveArgs, 8 * 60_000)
      if (PREDICTION_DAILY_LABEL_ENABLED) {
        await runPredictionNodeScript('label_next_day_prediction_outcomes.js', ['--limit', '30'], 5 * 60_000)
      }
      if (PREDICTION_DAILY_TRAIN_ENABLED) {
        await runPredictionNodeScript('train_next_session_prediction_model.js', [], 4 * 60_000)
      }
      lastPredictionArchiveDate = today
      console.log(`  PredictionArchive → saved daily next-session rows for ${today}: ${String(saved.stdout || '').slice(0, 240).replace(/\s+/g, ' ')}`)
    } catch (e) {
      console.warn('predictionDailyArchiveTick error:', e.stderr || e.message || e)
    } finally {
      predictionArchiveRunning = false
    }
  }

  if (PREDICTION_DAILY_ARCHIVE_ENABLED) {
    const t = setInterval(predictionDailyArchiveTick, PREDICTION_DAILY_ARCHIVE_CHECK_MS)
    if (t.unref) t.unref()
    setTimeout(() => predictionDailyArchiveTick().catch(() => {}), 5000).unref?.()
    console.log(`  PredictionArchive → enabled (${PREDICTION_DAILY_ARCHIVE_TIME} ${PREDICTION_DAILY_ARCHIVE_TIMEZONE}; horizon ${PREDICTION_DAILY_ARCHIVE_HORIZON}; rolling ${PREDICTION_DAILY_ARCHIVE_RETENTION_DAYS} prediction days)`)
  }

  // ── Auto-grab background job ────────────────────────────────────────────────
  // On the site (recent ping) → live UI handles news. Away → grab + archive to
  // the 'auto' bucket (2-day retention, then the sweeper auto-deletes it).
  const AUTO_GRAB_ENABLED = process.env.AUTO_GRAB_ENABLED !== 'false'
  const AUTO_GRAB_INTERVAL_MS = Number(process.env.AUTO_GRAB_INTERVAL_MS || 5 * 60 * 1000)
  const AUTO_GRAB_RUN_FETCH = process.env.AUTO_GRAB_RUN_FETCH !== 'false'
  let autoGrabRunning = false
  async function autoGrabTick() {
    if (autoGrabRunning || siteOpen() || !diskdb.isEnabled() || refreshCycleInFlight) return
    const db = mongoose.connection.db
    if (!db) return
    autoGrabRunning = true
    try {
      if (AUTO_GRAB_RUN_FETCH) {
        refreshCycleInFlight = true
        try { await runDataRefreshCycle(db, { mode: 'fast' }) }
        catch (_) {}
        finally { refreshCycleInFlight = false }
      }
      const r = diskdb.storeNews(await collectRecentNewsFromMongo(db, diskAutoDays, 3000), 'auto')
      if (r.stored) console.log(`  AutoGrab → archived ${r.stored} news to hard disk (away mode, ${diskAutoDays}d)`)
    } catch (e) { console.warn('autoGrabTick error:', e.message) }
    finally { autoGrabRunning = false }
  }
  if (AUTO_GRAB_ENABLED && diskdb.isEnabled()) {
    const t = setInterval(autoGrabTick, AUTO_GRAB_INTERVAL_MS)
    if (t.unref) t.unref()
    console.log(`  AutoGrab → enabled (every ${Math.round(AUTO_GRAB_INTERVAL_MS / 1000)}s while away → 'auto' ${diskAutoDays}d)`)
  }

  // ── On-site auto-fetch ──────────────────────────────────────────────────────
  // While someone is USING the website (recent presence ping), automatically grab
  // new articles every ONSITE_FETCH_INTERVAL_MS (default 20 min) and mirror them to
  // the hard-disk 'fetch' bucket (deleted after DISK_TTL_FETCH_DAYS = 3 days).
  //
  // It's driven two ways so the update is responsive: (1) the presence ping triggers
  // a check on each heartbeat, so a fresh visit grabs news right away, and (2) a
  // lightweight timer checks once a minute as a backstop. A due-check limits the
  // actual fetch to at most once per interval, and the shared refreshCycleInFlight
  // guard keeps it from overlapping Run Now / Auto-watch / the away auto-grabber.
  const ONSITE_FETCH_ENABLED = process.env.ONSITE_FETCH_ENABLED !== 'false'
  const ONSITE_FETCH_INTERVAL_MS = Number(process.env.ONSITE_FETCH_INTERVAL_MS || 20 * 60 * 1000) // 20 min
  const ONSITE_FETCH_CHECK_MS = Math.max(15_000, Math.min(ONSITE_FETCH_INTERVAL_MS, 60_000))      // check cadence
  let onSiteFetchRunning = false
  let lastOnSiteFetchAt = null
  const onSiteFetchDue = () =>
    ONSITE_FETCH_ENABLED && siteOpen() && (Date.now() - (lastOnSiteFetchAt || 0)) >= ONSITE_FETCH_INTERVAL_MS
  async function onSiteAutoFetchTick() {
    if (onSiteFetchRunning || refreshCycleInFlight) return
    if (!onSiteFetchDue()) return                 // on-site + at most once per interval
    const db = mongoose.connection.db
    if (!db) return
    onSiteFetchRunning = true
    refreshCycleInFlight = true
    try {
      await runDataRefreshCycle(db, { mode: process.env.ONSITE_FETCH_MODE || 'fast' })  // grab new articles
      persistFetchNewsToDisk(db).catch(() => {})   // → 'fetch' bucket (3-day retention, then auto-deleted)
      lastOnSiteFetchAt = Date.now()
      console.log(`  OnSiteAutoFetch → grabbed new articles (on-site, every ${Math.round(ONSITE_FETCH_INTERVAL_MS / 60000)} min; hard-disk 'fetch' ${diskFetchDays}d)`)
    } catch (e) { console.warn('onSiteAutoFetchTick error:', e.message) }
    finally { refreshCycleInFlight = false; onSiteFetchRunning = false }
  }
  // expose so the presence-ping handler can trigger an immediate check on each heartbeat
  triggerOnSiteAutoFetch = () => { onSiteAutoFetchTick().catch(() => {}) }
  if (ONSITE_FETCH_ENABLED) {
    const t = setInterval(onSiteAutoFetchTick, ONSITE_FETCH_CHECK_MS)
    if (t.unref) t.unref()
    console.log(`  OnSiteAutoFetch → enabled (every ${Math.round(ONSITE_FETCH_INTERVAL_MS / 60000)} min while on-site → 'fetch' ${diskFetchDays}d)`)
  }

app.listen(PORT, () => {
    console.log()
    console.log('  ⚡ FlashFeed API')
    console.log('  ─────────────────────────────────────')
    console.log('  Server  →  http://localhost:' + PORT)
    console.log('  Health  →  http://localhost:' + PORT + '/api/health')
    console.log('  Docs    →  README-MONGODB.md')
    console.log()
  })
}

start()
