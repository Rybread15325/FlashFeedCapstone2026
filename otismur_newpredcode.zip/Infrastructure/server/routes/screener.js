import { Router } from 'express'
import mongoose from 'mongoose'
import Screener from '../models/Screener.js'

const router = Router()
const NON_STOCK_TICKERS = new Set([
  'BTC', 'ETH', 'LTC', 'DOGE', 'SOL', 'ADA', 'XRP', 'BNB', 'DOT', 'AVAX',
  'MATIC', 'SHIB', 'TRX', 'BCH', 'LINK', 'ATOM', 'UNI', 'ETC', 'FIL',
  'USD', 'USDT', 'USDC', 'SPOT',
])
const US_EXCHANGES = new Set(['NASDAQ', 'NYSE', 'AMEX'])
const MAX_SIGNAL_CHANGE_PCT = Math.max(10, Number(process.env.MAX_SIGNAL_CHANGE_PCT || 300))
const MARKET_WINDOW_TIME_ZONE = process.env.MARKET_WINDOW_TIMEZONE || 'America/New_York'
const HIGH_CONVICTION_MIN_REL_VOLUME = Math.max(0, Number(process.env.HIGH_CONVICTION_MIN_REL_VOLUME || 1))
const HIGH_CONVICTION_MIN_ABS_CHANGE = Math.max(0, Number(process.env.HIGH_CONVICTION_MIN_ABS_CHANGE || 0.5))
const STRUCTURED_NEWS_SOURCE_RE = /finviz|tradingview|benzinga|pr newswire|business wire|access newswire|accesswire|globenewswire|sec|edgar|fda|dow jones|interactive brokers|td ameritrade|schwab|nasdaq|nyse/i
const POSITIVE_CATALYST_RE = /\b(contract|award|order|customer win|partnership|collaboration|strategic alliance|earnings beat|beats?|revenue growth|raises? guidance|guidance raise|guidance increase|outlook raised|upgrade|price target raised|buyback|repurchase|fda approval|clearance|pdufa|clinical positive|positive trial|merger|acquisition|takeover|definitive agreement|major corporate update|launch|patent|short squeeze|squeeze)\b/i
const NEGATIVE_OR_WEAK_CATALYST_RE = /\b(offering|registered direct|atm offering|dilution|reverse split|bankruptcy|default|delisting|going concern|investigation|lawsuit|downgrade|guidance cut|misses?|fda rejection|clinical negative|termination)\b/i

function normalizeScreenerView(value) {
  const raw = String(value || 'all').toLowerCase()
  if (raw === 'pred' || raw === 'prediction' || raw === 'predictions' || raw === 'predicted_up') return 'predicted_increases'
  if (raw === 'high_conviction' || raw === 'highconviction' || raw === 'high_conviction_tab') return 'high_conviction_next_day'
  return raw
}

function normalizeExchange(value) {
  const raw = String(value || '').trim().toUpperCase()
  if (raw === 'NYSEAMERICAN' || raw === 'NYSE AMERICAN') return 'AMEX'
  if (raw === 'NAS') return 'NASDAQ'
  return raw
}

function escapeRegExp(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function timestampSeconds(value) {
  if (!value) return 0
  if (value instanceof Date) return Math.floor(value.getTime() / 1000)
  const n = Number(value)
  if (Number.isFinite(n) && n > 0) return n > 1_000_000_000_000 ? Math.floor(n / 1000) : Math.floor(n)
  const ms = Date.parse(value)
  return Number.isFinite(ms) ? Math.floor(ms / 1000) : 0
}

function easternParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: MARKET_WINDOW_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date)
  return Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, Number(part.value)]))
}

function easternLocalToUtc(year, month, day, hour, minute = 0, second = 0) {
  const target = Date.UTC(year, month - 1, day, hour, minute, second)
  let guess = target
  for (let i = 0; i < 4; i += 1) {
    const parts = easternParts(new Date(guess))
    const actual = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second)
    const diff = target - actual
    if (diff === 0) break
    guess += diff
  }
  return new Date(guess)
}

function shiftLocalDate(year, month, day, deltaDays) {
  const shifted = new Date(Date.UTC(year, month - 1, day + deltaDays))
  return { year: shifted.getUTCFullYear(), month: shifted.getUTCMonth() + 1, day: shifted.getUTCDate() }
}

function localWeekday(year, month, day) {
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay()
}

function previousTradingDateParts(year, month, day) {
  let shifted = shiftLocalDate(year, month, day, -1)
  while ([0, 6].includes(localWeekday(shifted.year, shifted.month, shifted.day))) shifted = shiftLocalDate(shifted.year, shifted.month, shifted.day, -1)
  return shifted
}

function mostRecentFridayParts(year, month, day) {
  let shifted = { year, month, day }
  while (localWeekday(shifted.year, shifted.month, shifted.day) !== 5) shifted = shiftLocalDate(shifted.year, shifted.month, shifted.day, -1)
  return shifted
}

function marketPredictionContext(now = new Date()) {
  const parts = easternParts(now)
  const weekday = localWeekday(parts.year, parts.month, parts.day)
  const minutes = Number(parts.hour || 0) * 60 + Number(parts.minute || 0)
  const preStart = 4 * 60
  const regularStart = 9 * 60 + 30
  const regularEnd = 16 * 60
  const afterEnd = 20 * 60
  const isWeekday = weekday >= 1 && weekday <= 5
  let session = 'closed'
  let target = 'next_regular_session'
  let startParts
  let startHour = 16
  let startMinute = 0
  if (!isWeekday) {
    session = 'weekend'
    target = 'next_premarket_open'
    startParts = mostRecentFridayParts(parts.year, parts.month, parts.day)
  } else if (minutes >= preStart && minutes < regularStart) {
    session = 'premarket'
    target = 'regular_session_risers'
    startParts = previousTradingDateParts(parts.year, parts.month, parts.day)
  } else if (minutes >= regularStart && minutes < regularEnd) {
    session = 'regular'
    target = 'late_day_and_afterhours_continuation'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
    startHour = 4
  } else if (minutes >= regularEnd && minutes < afterEnd) {
    session = 'afterhours'
    target = 'afterhours_and_next_premarket_risers'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
    startHour = 9
    startMinute = 30
  } else if (minutes < preStart) {
    session = 'overnight'
    target = 'premarket_risers'
    startParts = previousTradingDateParts(parts.year, parts.month, parts.day)
  } else {
    session = 'closed_post_afterhours'
    target = 'next_premarket_open'
    startParts = { year: parts.year, month: parts.month, day: parts.day }
  }
  const start = easternLocalToUtc(startParts.year, startParts.month, startParts.day, startHour, startMinute)
  const startSec = Math.floor(start.getTime() / 1000)
  const endSec = Math.floor(now.getTime() / 1000)
  return {
    session,
    target,
    timezone: MARKET_WINDOW_TIME_ZONE,
    evidence_window_start: start.toISOString(),
    evidence_window_start_sec: startSec,
    evidence_window_end: now.toISOString(),
    evidence_window_end_sec: endSec,
    evidence_window_hours: Number(Math.max(0, (endSec - startSec) / 3600).toFixed(2)),
    includes_weekend_carry: ['weekend', 'premarket', 'overnight'].includes(session) && localWeekday(startParts.year, startParts.month, startParts.day) === 5,
  }
}

function tickerCsvContains(value, ticker) {
  const wanted = String(ticker || '').toUpperCase()
  if (!wanted) return false
  return String(value || '')
    .split(',')
    .map(part => part.trim().toUpperCase())
    .includes(wanted)
}

function candidateTickersFromArticle(row = {}) {
  const candidates = new Set()
  for (const part of String(row.ticker || '').split(',')) {
    const t = part.trim().toUpperCase()
    if (t) candidates.add(t)
  }
  for (const field of ['tickers', 'matched_mover_tickers', 'tickers_mentioned']) {
    const values = Array.isArray(row[field]) ? row[field] : []
    for (const value of values) {
      const t = String(value || '').trim().toUpperCase()
      if (t) candidates.add(t)
    }
  }
  return candidates
}

function normalizedWords(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function companyAliases(company = '') {
  const normalized = normalizedWords(company)
  if (!normalized) return []
  const stripped = normalized
    .replace(/\b(incorporated|inc|corp|corporation|co|company|plc|ltd|limited|adr|class a|common stock)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  const aliases = new Set([normalized, stripped].filter(value => value && value.length >= 3))
  const words = stripped.split(' ').filter(Boolean)
  if (words.length >= 2) aliases.add(words.slice(0, 2).join(' '))
  if (words[0] && words[0].length >= 5) aliases.add(words[0])
  return Array.from(aliases).filter(value => value.length >= 3)
}

function articleLooksRelevantForTicker(row = {}, ticker = '', company = '') {
  const wanted = String(ticker || '').toUpperCase()
  if (!wanted) return false
  const candidates = candidateTickersFromArticle(row)
  if (!candidates.has(wanted)) return false
  if (wanted.length > 1) return true

  const title = String(row.title || '')
  const text = normalizedWords([
    row.title,
    row.summary,
    row.description,
    row.contentText,
    row.content_text,
    row.content,
    row.url,
  ].join(' '))
  const aliases = companyAliases(company)
  if (aliases.some(alias => text.includes(alias))) return true

  // Single-letter tickers are high-risk because vendor feeds may map foreign
  // suffixes such as S.T or unrelated strings like S1 into ticker "S".
  if (new RegExp(`^\\s*\\$?${escapeRegExp(wanted)}\\s*:`, 'i').test(title)) return true
  if (new RegExp(`\\b${escapeRegExp(wanted)}\\s+(stock|shares|equity)\\b`, 'i').test(title)) return true
  return false
}

function normalizeSearchQuery(value) {
  return String(value || '').trim().slice(0, 80)
}

function normalizeTickerSearch(value) {
  const raw = normalizeSearchQuery(value).replace(/^\$/, '').toUpperCase()
  return /^[A-Z][A-Z0-9.-]{0,5}$/.test(raw) ? raw : ''
}

function isSecFilingDoc(row = {}) {
  return Boolean(
    row.is_sec_filing ||
    row.isFiling ||
    row.source_type === 'filing' ||
    /sec|edgar/i.test(String(row.source || '')) ||
    /filings?/i.test(String(row.category || '')) ||
    String(row.event_type || '').toLowerCase() === 'sec_filing'
  )
}

function filingContentLength(row = {}) {
  return Math.max(
    String(row.contentText || '').length,
    String(row.content_text || '').length,
    String(row.content || '').length,
    String(row.summary || '').length
  )
}

function canonicalPredictionSignal(row = {}, requestedHorizon = '1d', predictionContext = null) {
  const modelSignal = row.model_signal || null
  const baselineSignal = row.baseline_signal || null
  const active = modelSignal || baselineSignal || null
  if (!active) return null

  const predictedReturn = Number(
    active.predicted_return_1d ??
    active.predicted_return_next_day ??
    active.predicted_return_60m ??
    active.predicted_return_5m
  )
  const hasReturn = Number.isFinite(predictedReturn)
  const direction = String(active.direction || '').toLowerCase() || (hasReturn ? (predictedReturn > 0 ? 'up' : predictedReturn < 0 ? 'down' : 'watch') : 'watch')
  const horizons = Array.isArray(row.horizons_minutes) ? row.horizons_minutes.map(Number) : []
  const requested = String(requestedHorizon || '1d').toLowerCase()
  const generatedAtSec = Number(row.signal_sec || 0) || null
  const staleForSession = Boolean(
    predictionContext?.evidence_window_start_sec &&
    generatedAtSec &&
    generatedAtSec < Number(predictionContext.evidence_window_start_sec)
  )
  const supported =
    requested === '5m' ? horizons.includes(5) :
    requested === '15m' ? horizons.includes(15) :
    requested === '60m' || requested === '1h' ? horizons.includes(60) :
    Boolean(active.predicted_return_1d ?? active.predicted_return_next_day)

  return {
    horizon: supported ? requested : (active.predicted_return_60m != null ? '60m' : active.predicted_return_5m != null ? '5m' : 'signal'),
    requested_horizon: requested,
    horizon_supported: supported,
    is_next_day_proxy: requested === '1d' && !supported,
    predictedReturn: hasReturn ? Number(predictedReturn.toFixed(3)) : null,
    predictedDirection: direction,
    confidence: Number(active.confidence ?? 0),
    probabilityUp: active.probability_up == null ? null : Number(active.probability_up),
    modelVersion: active.model_version || row.model_signal?.model_version || null,
    model: active.model || row.model_signal?.model || row.baseline_signal?.model || null,
    predictionSession: active.prediction_session || row.prediction_session || row.features?.prediction_session || null,
    predictionTarget: active.prediction_target || row.prediction_target || row.features?.prediction_target || null,
    evidenceWindowStartSec: active.evidence_window_start_sec || row.evidence_window_start_sec || row.features?.evidence_window_start_sec || null,
    evidenceWindowEndSec: active.evidence_window_end_sec || row.evidence_window_end_sec || row.features?.evidence_window_end_sec || null,
    evidenceWindowHours: active.evidence_window_hours ?? row.features?.evidence_window_hours ?? null,
    generatedAt: row.signal_at || (row.signal_sec ? new Date(Number(row.signal_sec) * 1000) : null),
    generatedAtSec,
    staleForCurrentSession: staleForSession,
    source: row.source || 'prediction_signals',
    decision: row.decision || row.trade_watch?.decision || '',
    rank: row.rank ?? null,
    featureWindowStart: active.evidence_window_start_sec || row.evidence_window_start_sec || row.features?.evidence_window_start_sec || null,
    featureWindowEnd: row.signal_sec || null,
    features: row.features || null,
  }
}

function isCleanListedUsRow(row) {
  if (!row?.ticker || row.ticker.includes('.')) return false
  if (NON_STOCK_TICKERS.has(row.ticker)) return false
  if (row.quote_status && row.quote_status !== 'priced') return false
  if (row.price == null || row.change_pct == null) return false
  if (Number(row.price) <= 0) return false
  if (!Number.isFinite(Number(row.change_pct))) return false
  if (Math.abs(Number(row.change_pct)) > MAX_SIGNAL_CHANGE_PCT) return false
  const exchange = normalizeExchange(row.exchange)
  return US_EXCHANGES.has(exchange)
}

function recentArticleMatch(days = 3) {
  const n = Number(days || 0)
  if (!Number.isFinite(n) || n <= 0) return {}

  const cutoffMs = Date.now() - n * 86_400_000
  const cutoffSec = Math.floor(cutoffMs / 1000)
  const cutoffDate = new Date(cutoffMs)

  return {
    $or: [
      { publish_date: { $gte: cutoffDate } },
      { publish_date: { $gte: cutoffSec } },
      { fetched_date: { $gte: cutoffDate } },
      { fetched_date: { $gte: cutoffSec } },
      { detected_at: { $gte: cutoffDate } },
      { detected_at: { $gte: cutoffSec } },
      { createdAt: { $gte: cutoffDate } },
    ],
  }
}

function articleWindowMatchFromSec(cutoffSec) {
  const sec = Number(cutoffSec || 0)
  if (!Number.isFinite(sec) || sec <= 0) return {}
  const cutoffDate = new Date(sec * 1000)
  return {
    $or: [
      { publish_date: { $gte: cutoffDate } },
      { publish_date: { $gte: sec } },
      { fetched_date: { $gte: cutoffDate } },
      { fetched_date: { $gte: sec } },
      { detected_at: { $gte: cutoffDate } },
      { detected_at: { $gte: sec } },
      { createdAt: { $gte: cutoffDate } },
    ],
  }
}

function sentimentScore(row) {
  const total = Math.max(1, Number(row.count || 0))
  if (row.weighted_score_sum != null) {
    const denominator = Number(row.weight_sum || total)
    return denominator ? Number((Number(row.weighted_score_sum || 0) / (denominator + 1.5)).toFixed(3)) : 0
  }
  if (row.score_sum != null) return Number((Number(row.score_sum || 0) / (total + 2)).toFixed(3))
  const priorNeutralWeight = 2
  return Number((((row.bullish || 0) - (row.bearish || 0)) / (total + priorNeutralWeight)).toFixed(3))
}

function stableHash(value) {
  let hash = 0
  const text = String(value || '')
  for (let i = 0; i < text.length; i += 1) hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0
  return Math.abs(hash)
}

function derivedNumber(ticker, min, max, decimals = 2, salt = '') {
  const pct = (stableHash(`${ticker}:${salt}`) % 10000) / 10000
  return Number((min + (max - min) * pct).toFixed(decimals))
}

function nullableNumber(value) {
  if (value == null || value === '') return null
  const n = Number(value)
  return Number.isFinite(n) ? n : null
}

function nullableFixed(value, decimals = 2) {
  const n = nullableNumber(value)
  return n == null ? null : Number(n.toFixed(decimals))
}

function marketCapBucket(marketCap) {
  const cap = Number(marketCap || 0)
  if (cap >= 200e9) return 'Mega'
  if (cap >= 10e9) return 'Large'
  if (cap >= 2e9) return 'Mid'
  if (cap >= 300e6) return 'Small'
  if (cap > 0) return 'Micro'
  return 'Unknown'
}

function sourceTextForRow(row = {}) {
  return `${row.quote_source || ''} ${row.source || ''} ${row.screener_source || ''} ${row.finviz_filter || ''}`.toLowerCase()
}

function normalizeScreenerMarketCap(value, row = {}) {
  const cap = nullableNumber(value)
  if (cap == null) return null
  if (sourceTextForRow(row).includes('finviz') && cap > 0 && cap < 10_000_000) return Math.round(cap * 1_000_000)
  return cap
}

function topMoverMarketCapDollars(marketCap) {
  const cap = Number(marketCap || 0)
  if (!Number.isFinite(cap) || cap <= 0) return 0
  // Feeds are mixed: some rows store market cap in dollars, others in millions
  // (e.g. META near 1,570,903 means about $1.57T). For top-mover suitability,
  // normalize enough to avoid mega-caps crowding a small-cap mover watchlist.
  if (cap >= 200_000 && cap < 10_000_000) return cap * 1_000_000
  return cap
}

function rollingWindowMinutes(row) {
  const tier = String(row.market_cap_tier || row.finviz_market_cap_tier || '').toLowerCase()
  const bucket = String(row.market_cap_bucket || '').toLowerCase()
  if (tier === 'nano' || tier === 'micro' || bucket === 'micro') return 5
  if (tier === 'small' || bucket === 'small') return 15
  if (tier === 'mid' || bucket === 'mid') return 30
  if (tier === 'large' || bucket === 'large') return 60
  if (tier === 'mega' || bucket === 'mega') return 120
  return 30
}

function resolvedRollingWindowMinutes(row, override = null) {
  const explicit = Number(override)
  if (Number.isFinite(explicit) && explicit > 0) return Math.max(1, Math.min(4320, explicit))
  return rollingWindowMinutes(row)
}

function normalizeScreenerRow(doc = {}) {
  const ticker = String(doc.ticker || '').toUpperCase()
  const hasStoredPrice = doc.price != null
  const price = nullableFixed(doc.price, 2)
  const change = doc.change_pct ?? doc.change_percent
  const changePct = nullableFixed(change, 2)
  const volume = nullableNumber(doc.volume)
  const avgVolume = nullableNumber(doc.avg_volume)
  const storedRelVolume = nullableNumber(doc.rel_volume ?? doc.relative_volume)
  const relVolume = storedRelVolume != null
    ? Number(storedRelVolume.toFixed(2))
    : volume != null && avgVolume ? Number((volume / Math.max(1, avgVolume)).toFixed(2)) : null
  const marketCap = normalizeScreenerMarketCap(doc.market_cap, doc)
  const avgSentiment = Number(doc.avg_sentiment ?? doc.news_sentiment ?? doc.structured_sentiment ?? 0)

  return {
    ticker,
    company: doc.company || '',
    price,
    change_pct: changePct,
    volume,
    avg_volume: avgVolume,
    rel_volume: relVolume,
    market_cap: marketCap,
    market_cap_tier: doc.market_cap_tier || doc.finviz_market_cap_tier || '',
    market_cap_bucket: marketCapBucket(marketCap),
    sector: doc.sector || 'Unclassified',
    industry: doc.industry || 'Unclassified',
    country: doc.country || (US_EXCHANGES.has(normalizeExchange(doc.exchange)) ? 'USA' : ''),
    exchange: normalizeExchange(doc.exchange),
    index: doc.index || '',
    avg_sentiment: avgSentiment,
    social_sentiment: Number(doc.social_sentiment ?? 0),
    structured_sentiment: Number(doc.structured_sentiment ?? doc.news_sentiment ?? avgSentiment),
    message_count: Number(doc.message_count ?? 0),
    news_article_count: Number(doc.news_article_count ?? 0),
    bullish_count: Number(doc.bullish_count ?? 0),
    bearish_count: Number(doc.bearish_count ?? 0),
    neutral_count: Number(doc.neutral_count ?? 0),
    sources: doc.sources || [],
    pe_ratio: nullableNumber(doc.pe_ratio ?? doc.pe),
    forward_pe: nullableNumber(doc.forward_pe),
    peg: nullableNumber(doc.peg),
    ps_ratio: nullableNumber(doc.ps_ratio),
    pb_ratio: nullableNumber(doc.pb_ratio),
    dividend_yield: nullableNumber(doc.dividend_yield),
    eps_growth_this_y: nullableNumber(doc.eps_growth_this_y),
    eps_growth_next_y: nullableNumber(doc.eps_growth_next_y),
    sales_growth: nullableNumber(doc.sales_growth),
    gross_margin: nullableNumber(doc.gross_margin),
    operating_margin: nullableNumber(doc.operating_margin),
    roe: nullableNumber(doc.roe),
    debt_equity: nullableNumber(doc.debt_equity),
    beta: nullableNumber(doc.beta),
    rsi: nullableNumber(doc.rsi),
    sma20: nullableNumber(doc.sma20),
    sma50: nullableNumber(doc.sma50),
    sma200: nullableNumber(doc.sma200),
    perf_week: nullableNumber(doc.perf_week),
    perf_month: nullableNumber(doc.perf_month),
    perf_quarter: nullableNumber(doc.perf_quarter),
    perf_half: nullableNumber(doc.perf_half),
    perf_year: nullableNumber(doc.perf_year),
    perf_ytd: nullableNumber(doc.perf_ytd),
    atr: nullableNumber(doc.atr),
    gap: nullableNumber(doc.gap),
    analyst: doc.analyst || null,
    target_price: nullableFixed(doc.target_price, 2),
    inst_own: nullableNumber(doc.inst_own),
    insider_own: nullableNumber(doc.insider_own),
    float_short: nullableNumber(doc.float_short),
    earnings_date: doc.earnings_date || null,
    previous_close: nullableFixed(doc.previous_close, 2),
    quote_source: doc.quote_source || null,
    quote_updated_at: doc.quote_updated_at || null,
    quote_status: doc.quote_status || (hasStoredPrice ? 'priced' : 'missing'),
  }
}

function socialTimeStages() {
  return [
    {
      $addFields: {
        _time_raw: {
          $ifNull: [
            '$fetched_at',
            { $ifNull: ['$detected_at', { $ifNull: ['$timestamp', { $ifNull: ['$created_at', '$publish_date'] }] }] },
          ],
        },
      },
    },
    {
      $addFields: {
        _event_sec: {
          $switch: {
            branches: [
              { case: { $eq: [{ $type: '$_time_raw' }, 'date'] }, then: { $floor: { $divide: [{ $toLong: '$_time_raw' }, 1000] } } },
              { case: { $in: [{ $type: '$_time_raw' }, ['int', 'long', 'double', 'decimal']] }, then: { $toLong: '$_time_raw' } },
              {
                case: { $eq: [{ $type: '$_time_raw' }, 'string'] },
                then: { $floor: { $divide: [{ $toLong: { $dateFromString: { dateString: '$_time_raw', onError: new Date(0) } } }, 1000] } },
              },
            ],
            default: 0,
          },
        },
      },
    },
  ]
}

async function loadArticleStatsForTickers(db, tickers, days = 3, options = {}) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()
  const recentCutoffSec = Math.floor((Date.now() - Math.max(1, Number(days || 3)) * 86_400_000) / 1000)
  const sessionCutoffSec = Number(options.predictionContext?.evidence_window_start_sec || 0)
  const articleWindowMatch = options.predictionContext
    ? articleWindowMatchFromSec(Math.min(sessionCutoffSec || recentCutoffSec, recentCutoffSec))
    : recentArticleMatch(days)

  const rows = await db.collection('articles').aggregate([
    { $match: {
      $and: [
        articleWindowMatch,
        { $or: [
          { ticker: { $exists: true, $nin: ['', null] } },
          { tickers: { $type: 'array', $ne: [] } },
          { matched_mover_tickers: { $exists: true, $ne: [] } },
          { tickers_mentioned: { $exists: true, $ne: [] } },
        ] },
      ],
    } },
    {
      $addFields: {
        _ticker_parts: {
          $map: {
            input: {
              $setUnion: [
                { $split: [{ $toUpper: { $toString: { $ifNull: ['$ticker', ''] } } }, ','] },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$tickers' }, '$tickers', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$matched_mover_tickers' }, '$matched_mover_tickers', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$tickers_mentioned' }, '$tickers_mentioned', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
              ],
            },
            as: 'ticker_part',
            in: { $trim: { input: '$$ticker_part' } },
          },
        },
      },
    },
    { $unwind: '$_ticker_parts' },
    { $match: { _ticker_parts: { $in: wanted } } },
    {
      $addFields: {
        _article_kind: {
          $cond: [
            { $eq: [{ $toLower: { $toString: { $ifNull: ['$article_kind', ''] } } }, 'structured'] },
            'structured',
            {
              $cond: [
                {
                  $or: [
                    { $in: [{ $toLower: { $toString: { $ifNull: ['$article_kind', ''] } } }, ['public', 'unstructured']] },
                    { $in: ['$category', ['unstructured_public_title', 'public_news', 'public_market_news']] },
                    { $eq: ['$collector', 'unstructured_news_title_only_v1'] },
                  ],
                },
                'public',
                'structured',
              ],
            },
          ],
        },
      },
    },
    { $match: { _article_kind: 'structured' } },
    {
      $addFields: {
        _sentiment_direction: {
          $switch: {
            branches: [
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bull|positive' } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bear|negative' } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    {
      $addFields: {
        _score: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: '$sentiment_score' }, ['int', 'long', 'double', 'decimal']] }, then: { $toDouble: '$sentiment_score' } },
              { case: { $in: [{ $type: '$ml_confidence' }, ['int', 'long', 'double', 'decimal']] }, then: { $multiply: ['$_sentiment_direction', { $toDouble: '$ml_confidence' }] } },
            ],
            default: '$_sentiment_direction',
          },
        },
        _is_sec_filing: {
          $or: [
            { $eq: ['$is_sec_filing', true] },
            { $eq: ['$isFiling', true] },
            { $eq: ['$source_type', 'filing'] },
            { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$source', ''] } } }, regex: 'sec|edgar' } },
            { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$category', ''] } } }, regex: 'filings?' } },
            { $eq: [{ $toLower: { $toString: { $ifNull: ['$event_type', ''] } } }, 'sec_filing'] },
          ],
        },
        _content_text: {
          $concat: [
            { $toString: { $ifNull: ['$contentText', ''] } },
            ' ',
            { $toString: { $ifNull: ['$content_text', ''] } },
            ' ',
            { $toString: { $ifNull: ['$content', ''] } },
            ' ',
            { $toString: { $ifNull: ['$summary', ''] } },
          ],
        },
      },
    },
    {
      $addFields: {
        _content_length: { $strLenCP: '$_content_text' },
        _filing_form_text: {
          $toLower: {
            $concat: [
              { $toString: { $ifNull: ['$formType', ''] } },
              ' ',
              { $toString: { $ifNull: ['$form_type', ''] } },
              ' ',
              { $toString: { $ifNull: ['$title', ''] } },
            ],
          },
        },
      },
    },
    {
      $addFields: {
        _source_weight: {
          $switch: {
            branches: [
              {
                case: {
                  $and: [
                    '$_is_sec_filing',
                    { $lt: ['$_content_length', 200] },
                  ],
                },
                then: 0.03,
              },
              {
                case: {
                  $and: [
                    '$_is_sec_filing',
                    {
                      $or: [
                        { $eq: ['$filingUsedInSentiment', false] },
                        { $eq: ['$filing_used_in_sentiment', false] },
                      ],
                    },
                  ],
                },
                then: 0.03,
              },
              {
                case: {
                  $and: [
                    '$_is_sec_filing',
                    { $gte: ['$_content_length', 200] },
                    { $regexMatch: { input: '$_filing_form_text', regex: '8-k|material|current report' } },
                  ],
                },
                then: 0.75,
              },
              {
                case: {
                  $and: [
                    '$_is_sec_filing',
                    { $gte: ['$_content_length', 200] },
                    { $regexMatch: { input: '$_filing_form_text', regex: '10-k|10-q' } },
                  ],
                },
                then: 0.35,
              },
              {
                case: {
                  $and: [
                    '$_is_sec_filing',
                    { $gte: ['$_content_length', 200] },
                  ],
                },
                then: 0.25,
              },
              {
                case: {
                  $and: [
                    {
                      $or: [
                        { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$source', ''] } } }, regex: 'sec|edgar' } },
                        { $eq: [{ $toLower: { $toString: { $ifNull: ['$event_type', ''] } } }, 'sec_filing'] },
                      ],
                    },
                    { $lte: [{ $abs: '$_score' }, 0.08] },
                  ],
                },
                then: 0.15,
              },
              {
                case: {
                  $in: [
                    { $toLower: { $toString: { $ifNull: ['$event_type', ''] } } },
                    ['earnings_beat', 'earnings_miss', 'guidance_raise', 'guidance_cut', 'fda_approval', 'fda_rejection', 'clinical_positive', 'clinical_negative', 'public_offering', 'bankruptcy_default'],
                  ],
                },
                then: 1.35,
              },
            ],
            default: 1,
          },
        },
      },
    },
    {
      $group: {
        _id: '$_ticker_parts',
        count: { $sum: 1 },
        bullish: { $sum: { $cond: [{ $gt: ['$_score', 0.08] }, 1, 0] } },
        bearish: { $sum: { $cond: [{ $lt: ['$_score', -0.08] }, 1, 0] } },
        neutral: { $sum: { $cond: [{ $lte: [{ $abs: '$_score' }, 0.08] }, 1, 0] } },
        score_sum: { $sum: '$_score' },
        weighted_score_sum: { $sum: { $multiply: ['$_score', '$_source_weight'] } },
        weight_sum: { $sum: '$_source_weight' },
        filing_count: { $sum: { $cond: ['$_is_sec_filing', 1, 0] } },
        filing_used_count: {
          $sum: {
            $cond: [
              {
                $and: [
                  '$_is_sec_filing',
                  { $gte: ['$_content_length', 200] },
                  { $ne: ['$filingUsedInSentiment', false] },
                  { $ne: ['$filing_used_in_sentiment', false] },
                ],
              },
              1,
              0,
            ],
          },
        },
        filing_score_sum: {
          $sum: {
            $cond: [
              {
                $and: [
                  '$_is_sec_filing',
                  { $ne: ['$filingUsedInSentiment', false] },
                  { $ne: ['$filing_used_in_sentiment', false] },
                ],
              },
              '$_score',
              0,
            ],
          },
        },
        filing_weight_sum: {
          $sum: {
            $cond: [
              {
                $and: [
                  '$_is_sec_filing',
                  { $ne: ['$filingUsedInSentiment', false] },
                  { $ne: ['$filing_used_in_sentiment', false] },
                ],
              },
              '$_source_weight',
              0,
            ],
          },
        },
        filing_latest: { $max: { $cond: ['$_is_sec_filing', '$publish_date', null] } },
        sources: { $addToSet: '$source' },
        latest_publish: { $max: '$publish_date' },
      },
    },
  ]).toArray()

  return new Map(rows.map(row => [String(row._id || '').toUpperCase(), row]))
}

function socialTickerCandidateStages() {
  const stringSplit = (field) => ({
    $cond: [
      { $eq: [{ $type: field }, 'string'] },
      { $split: [field, ','] },
      [],
    ],
  })
  const arrayOrStringSplit = (field) => ({
    $cond: [
      { $isArray: field },
      field,
      stringSplit(field),
    ],
  })

  return [
    {
      $addFields: {
        _ticker_primary_values_raw: {
          $concatArrays: [
            stringSplit('$ticker'),
            stringSplit('$symbol'),
            stringSplit('$cashtag'),
            arrayOrStringSplit('$tickers_mentioned'),
          ],
        },
        _ticker_text_cashtags: {
          $map: {
            input: {
              $regexFindAll: {
                input: {
                  $concat: [
                    { $toString: { $ifNull: ['$text', ''] } },
                    ' ',
                    { $toString: { $ifNull: ['$content', ''] } },
                    ' ',
                    { $toString: { $ifNull: ['$title', ''] } },
                  ],
                },
                regex: /\$[A-Za-z][A-Za-z0-9.-]{0,5}\b/,
              },
            },
            as: 'tag',
            in: '$$tag.match',
          },
        },
      },
    },
    {
      $addFields: {
        _ticker_values_raw: {
          $cond: [
            {
              $gt: [
                {
                  $size: {
                    $filter: {
                      input: { $ifNull: ['$_ticker_primary_values_raw', []] },
                      as: 'raw',
                      cond: { $ne: [{ $trim: { input: { $toString: '$$raw' } } }, ''] },
                    },
                  },
                },
                0,
              ],
            },
            '$_ticker_primary_values_raw',
            { $ifNull: ['$_ticker_text_cashtags', []] },
          ],
        },
      },
    },
    {
      $addFields: {
        _ticker_candidates: {
          $filter: {
            input: {
              $map: {
                input: '$_ticker_values_raw',
                as: 'raw',
                in: {
                  $trim: {
                    input: {
                      $replaceAll: {
                        input: { $toUpper: { $toString: '$$raw' } },
                        find: { $literal: '$' },
                        replacement: '',
                      },
                    },
                    chars: ' ,;#',
                  },
                },
              },
            },
            as: 'candidate',
            cond: {
              $regexMatch: {
                input: '$$candidate',
                regex: '^[A-Z][A-Z0-9.-]{0,5}$',
              },
            },
          },
        },
      },
    },
  ]
}

function socialMatchForWindow(tickers, windowMinutes) {
  const sinceSec = Math.floor(Date.now() / 1000) - windowMinutes * 60
  return {
    _event_sec: { $gte: sinceSec },
    _ticker_candidates: { $in: tickers },
  }
}

async function loadAdaptiveSocialStatsForRows(db, rows, windowOverride = null) {
  const byWindow = new Map()
  for (const row of rows) {
    const window = resolvedRollingWindowMinutes(row, windowOverride)
    if (!byWindow.has(window)) byWindow.set(window, [])
    byWindow.get(window).push(row.ticker)
  }

  const or = Array.from(byWindow.entries()).map(([window, tickers]) => socialMatchForWindow(tickers, window))
  if (!or.length) return new Map()

  const results = await db.collection('socials').aggregate([
    ...socialTimeStages(),
    ...socialTickerCandidateStages(),
    { $match: { $or: or } },
    { $unwind: '$_ticker_candidates' },
    { $match: { _ticker_candidates: { $in: rows.map(row => row.ticker) } } },
    {
      $addFields: {
        _norm_platform: {
          $switch: {
            branches: [
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$platform', ''] } } }, regex: 'stocktwits' } }, then: 'StockTwits' },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$platform', ''] } } }, regex: 'twitter|x' } }, then: 'Twitter' },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$platform', ''] } } }, regex: 'reddit' } }, then: 'Reddit' },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$platform', ''] } } }, regex: 'bluesky|bsky' } }, then: 'Bluesky' },
            ],
            default: { $ifNull: ['$platform', 'Unknown'] },
          },
        },
        _score: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: '$sentiment_score' }, ['int', 'long', 'double', 'decimal']] }, then: { $toDouble: '$sentiment_score' } },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bull|positive' } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bear|negative' } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    {
      $group: {
        _id: '$_ticker_candidates',
        count: { $sum: 1 },
        sentiment: { $avg: '$_score' },
        bullish: { $sum: { $cond: [{ $gt: ['$_score', 0.15] }, 1, 0] } },
        bearish: { $sum: { $cond: [{ $lt: ['$_score', -0.15] }, 1, 0] } },
        platforms: { $addToSet: '$_norm_platform' },
        stocktwits_count: { $sum: { $cond: [{ $eq: ['$_norm_platform', 'StockTwits'] }, 1, 0] } },
        stocktwits_score_sum: { $sum: { $cond: [{ $eq: ['$_norm_platform', 'StockTwits'] }, '$_score', 0] } },
        stocktwits_bullish: { $sum: { $cond: [{ $and: [{ $eq: ['$_norm_platform', 'StockTwits'] }, { $gt: ['$_score', 0.15] }] }, 1, 0] } },
        stocktwits_bearish: { $sum: { $cond: [{ $and: [{ $eq: ['$_norm_platform', 'StockTwits'] }, { $lt: ['$_score', -0.15] }] }, 1, 0] } },
        latest_post: { $max: '$_event_sec' },
      },
    },
  ]).toArray()

  return new Map(results.map(row => [String(row._id || '').toUpperCase(), row]))
}

async function loadMessageDensityTrendsForTickers(db, tickers = []) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()
  const nowSec = Math.floor(Date.now() / 1000)
  const sinceSec = nowSec - 120 * 60

  const docs = await db.collection('socials').aggregate([
    ...socialTimeStages(),
    ...socialTickerCandidateStages(),
    { $match: { _event_sec: { $gte: sinceSec }, _ticker_candidates: { $in: wanted } } },
    { $unwind: '$_ticker_candidates' },
    { $match: { _ticker_candidates: { $in: wanted } } },
    {
      $addFields: {
        _score: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: '$sentiment_score' }, ['int', 'long', 'double', 'decimal']] }, then: { $toDouble: '$sentiment_score' } },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bull|positive' } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bear|negative' } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    { $project: { ticker: '$_ticker_candidates', event_sec: '$_event_sec', score: '$_score' } },
    { $limit: 80000 },
  ]).toArray().catch(() => [])

  const byTicker = new Map()
  for (const doc of docs) {
    const ticker = String(doc.ticker || '').toUpperCase()
    if (!ticker) continue
    const current = byTicker.get(ticker) || []
    current.push({ eventSec: Number(doc.event_sec || 0), score: Number(doc.score || 0) })
    byTicker.set(ticker, current)
  }

  const result = new Map()
  for (const ticker of wanted) {
    const events = byTicker.get(ticker) || []
    const countIn = (startAgeMin, endAgeMin = 0) => {
      const start = nowSec - startAgeMin * 60
      const end = nowSec - endAgeMin * 60
      return events.filter(item => item.eventSec >= start && item.eventSec < end).length
    }
    const count5 = countIn(5)
    const count15 = countIn(15)
    const count30 = countIn(30)
    const count60 = countIn(60)
    const prev15Count = countIn(30, 15)
    const prev60Count = countIn(120, 60)
    const density5 = Number((count5 / 5).toFixed(3))
    const density15 = Number((count15 / 15).toFixed(3))
    const density30 = Number((count30 / 30).toFixed(3))
    const density60 = Number((count60 / 60).toFixed(3))
    const prevDensity = Number((prev15Count / 15).toFixed(3))
    const prevDensity60 = Number((prev60Count / 60).toFixed(3))
    const change = Number((density15 - prevDensity).toFixed(3))
    const changePct = prevDensity > 0
      ? Number(((change / prevDensity) * 100).toFixed(1))
      : density15 > 0 ? 100 : 0
    const frontLoaded = density15 > 0 ? clamp(density5 / Math.max(0.001, density15), 0, 3) : 0
    const improvingVsPrev = prevDensity > 0 ? clamp(density15 / prevDensity, 0, 4) : (density15 > 0 ? 2 : 0)
    const sustained = density60 > 0 ? clamp(density30 / Math.max(0.001, density60), 0, 2.5) : 0
    const sentimentAvg = events.length
      ? events.reduce((sum, item) => sum + Number(item.score || 0), 0) / events.length
      : 0
    const rising = Boolean(count15 >= 2 && (density5 >= density15 * 1.15 || density15 >= prevDensity * 1.25 || (prevDensity === 0 && density15 > 0)))
    const trend =
      rising ? 'rising' :
      density15 > 0 && density15 < prevDensity * 0.75 ? 'falling' :
      density15 > 0 ? 'steady' : 'none'
    const score = Math.round(clamp(
      Math.min(1, density15 / 0.5) * 34 +
      Math.min(1, Math.max(0, improvingVsPrev - 1) / 2) * 34 +
      Math.min(1, Math.max(0, frontLoaded - 1) / 1.5) * 18 +
      Math.min(1, Math.max(0, sustained - 1) / 1) * 8 +
      Math.max(0, sentimentAvg) * 6,
      0,
      100
    ))
    result.set(ticker, {
      message_density_now: density5,
      message_density_5m: density5,
      message_density_15m: density15,
      message_density_30m: density30,
      message_density_60m: density60,
      message_density_prev_window: prevDensity,
      message_density_prev_60m: prevDensity60,
      message_density_change: change,
      message_density_change_pct: changePct,
      message_density_trend: trend,
      message_density_rising: rising,
      message_density_score: score,
      message_density_event_count_60m: count60,
      message_density_sentiment: Number(clamp(sentimentAvg, -1, 1).toFixed(3)),
    })
  }
  return result
}

async function loadLatestPredictionsForTickers(db, tickers = [], horizon = '1d', options = {}) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()

  const rows = await db.collection('prediction_signals').aggregate([
    { $match: { ticker: { $in: wanted } } },
    { $sort: { signal_sec: -1, rank: 1 } },
    {
      $group: {
        _id: '$ticker',
        doc: { $first: '$$ROOT' },
      },
    },
  ]).toArray()

 return new Map(rows.map(row => [
    String(row._id || '').toUpperCase(),
    canonicalPredictionSignal(row.doc || {}, horizon, options.predictionContext || null),
  ]))
}

async function loadAiEvidenceForTickers(db, tickers = [], days = 3, options = {}) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()
  const recentCutoffSec = Math.floor((Date.now() - Math.max(1, Number(days || 3)) * 86_400_000) / 1000)
  const sessionCutoffSec = Number(options.predictionContext?.evidence_window_start_sec || 0)
  const articleWindowMatch = options.predictionContext
    ? articleWindowMatchFromSec(Math.min(sessionCutoffSec || recentCutoffSec, recentCutoffSec))
    : recentArticleMatch(days)

  const rows = await db.collection('articles').aggregate([
    {
      $match: {
        $and: [
          articleWindowMatch,
          {
            $or: [
              { ticker: { $exists: true, $nin: ['', null] } },
              { tickers: { $type: 'array', $ne: [] } },
              { matched_mover_tickers: { $exists: true, $ne: [] } },
              { tickers_mentioned: { $exists: true, $ne: [] } },
            ],
          },
        ],
      },
    },
    {
      $addFields: {
        _ticker_parts: {
          $map: {
            input: {
              $setUnion: [
                { $split: [{ $toUpper: { $toString: { $ifNull: ['$ticker', ''] } } }, ','] },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$tickers' }, '$tickers', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$matched_mover_tickers' }, '$matched_mover_tickers', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
                {
                  $map: {
                    input: { $cond: [{ $isArray: '$tickers_mentioned' }, '$tickers_mentioned', []] },
                    as: 'ticker_value',
                    in: { $toUpper: { $toString: '$$ticker_value' } },
                  },
                },
              ],
            },
            as: 'ticker_part',
            in: { $trim: { input: '$$ticker_part' } },
          },
        },
      },
    },
    { $unwind: '$_ticker_parts' },
    { $match: { _ticker_parts: { $in: wanted } } },
    {
      $addFields: {
        _sentiment_direction: {
          $switch: {
            branches: [
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bull|positive' } }, then: 1 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$sentiment', ''] } } }, regex: 'bear|negative' } }, then: -1 },
            ],
            default: 0,
          },
        },
      },
    },
    {
      $addFields: {
        _score: {
          $switch: {
            branches: [
              { case: { $in: [{ $type: '$sentiment_score' }, ['int', 'long', 'double', 'decimal']] }, then: { $toDouble: '$sentiment_score' } },
              { case: { $in: [{ $type: '$ml_confidence' }, ['int', 'long', 'double', 'decimal']] }, then: { $multiply: ['$_sentiment_direction', { $toDouble: '$ml_confidence' }] } },
            ],
            default: '$_sentiment_direction',
          },
        },
        _source_quality: {
          $switch: {
            branches: [
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$source', ''] } } }, regex: 'sec|edgar' } }, then: 1.2 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$source', ''] } } }, regex: 'pr newswire|business wire|globenewswire|access' } }, then: 1.05 },
              { case: { $regexMatch: { input: { $toLower: { $toString: { $ifNull: ['$source', ''] } } }, regex: 'tradingview|finviz|benzinga' } }, then: 0.9 },
            ],
            default: 0.8,
          },
        },
        _event_quality: {
          $switch: {
            branches: [
              {
                case: {
                  $in: [
                    { $toLower: { $toString: { $ifNull: ['$event_type', ''] } } },
                    ['earnings_beat', 'guidance_raise', 'fda_approval', 'clinical_positive', 'partnership_contract', 'mna_positive'],
                  ],
                },
                then: 1.25,
              },
              {
                case: {
                  $in: [
                    { $toLower: { $toString: { $ifNull: ['$event_type', ''] } } },
                    ['earnings_miss', 'guidance_cut', 'fda_rejection', 'clinical_negative', 'public_offering', 'bankruptcy_default'],
                  ],
                },
                then: 1.25,
              },
            ],
            default: 1,
          },
        },
      },
    },
    {
      $group: {
        _id: '$_ticker_parts',
        articles: { $sum: 1 },
        weighted_sum: { $sum: { $multiply: ['$_score', '$_source_quality', '$_event_quality'] } },
        weight_sum: { $sum: { $multiply: ['$_source_quality', '$_event_quality'] } },
        bullish: { $sum: { $cond: [{ $gt: ['$_score', 0.12] }, 1, 0] } },
        bearish: { $sum: { $cond: [{ $lt: ['$_score', -0.12] }, 1, 0] } },
        source_count: { $addToSet: '$source' },
        event_count: { $addToSet: '$event_type' },
        latest_publish: { $max: '$publish_date' },
      },
    },
  ]).toArray()

  return new Map(rows.map(row => {
    const avg = Number(row.weight_sum || 0) ? Number(row.weighted_sum || 0) / Number(row.weight_sum || 1) : 0
    const agreement = row.articles ? Math.abs(Number(row.bullish || 0) - Number(row.bearish || 0)) / Math.max(1, Number(row.articles || 0)) : 0
    const sourceDiversity = Array.isArray(row.source_count) ? row.source_count.filter(Boolean).length : 0
    const aiScore = Math.round(clamp(((avg + 1) / 2) * 72 + Math.min(18, row.articles * 2) + Math.min(10, sourceDiversity * 2), 0, 100))
    return [String(row._id || '').toUpperCase(), {
      ai_score: aiScore,
      ai_sentiment_score: Number(clamp(avg, -1, 1).toFixed(3)),
      ai_confidence: Number(clamp((Math.min(1, Number(row.articles || 0) / 8) * 0.7) + (agreement * 0.3), 0, 1).toFixed(3)),
      ai_article_count: Number(row.articles || 0),
      ai_bullish_articles: Number(row.bullish || 0),
      ai_bearish_articles: Number(row.bearish || 0),
      ai_source_count: sourceDiversity,
      ai_event_count: Array.isArray(row.event_count) ? row.event_count.filter(Boolean).length : 0,
      ai_latest_publish: row.latest_publish || null,
    }]
  }))
}

async function loadPredictionTickers(db, search, exactTickerSearch) {
  if (search) return null

  const rows = await db.collection('prediction_signals')
    .find({ ticker: { $exists: true, $ne: null } }, { projection: { ticker: 1 } })
    .sort({ signal_sec: -1 })
    .limit(2000)
    .toArray()
    .catch(() => [])

  const tickers = new Set(rows.map(row => String(row.ticker || '').toUpperCase()).filter(Boolean))
  return tickers.size ? tickers : null
}

async function loadMomentumContextForTickers(db, tickers = []) {
  const wanted = new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean))
  if (!wanted.size) return new Map()

  const snapshots = await db.collection('finviz_momentum_snapshots')
    .find({}, { projection: { snapshot_sec: 1, rows: 1 } })
    .sort({ snapshot_sec: -1 })
    .limit(30)
    .toArray()
    .catch(() => [])

  const byTicker = new Map()
  for (const snapshot of snapshots) {
    const rows = Array.isArray(snapshot.rows) ? snapshot.rows : []
    for (const row of rows) {
      const ticker = String(row.ticker || '').toUpperCase()
      if (!wanted.has(ticker)) continue
      const current = byTicker.get(ticker) || {
        appearances: 0,
        latestRank: null,
        previousRank: null,
        bestRank: null,
        latestChangePct: null,
        latestRelVolume: null,
        latestSnapshotSec: null,
      }
      current.appearances += 1
      const rank = Number(row.rank || 999)
      if (current.latestSnapshotSec == null || Number(snapshot.snapshot_sec || 0) > current.latestSnapshotSec) {
        current.previousRank = current.latestRank
        current.latestRank = rank
        current.latestChangePct = Number(row.change_pct || 0)
        current.latestRelVolume = Number(row.rel_volume || 0)
        current.latestSnapshotSec = Number(snapshot.snapshot_sec || 0)
      }
      current.bestRank = current.bestRank == null ? rank : Math.min(current.bestRank, rank)
      byTicker.set(ticker, current)
    }
  }

  for (const [ticker, ctx] of byTicker.entries()) {
    const rankStrength = ctx.latestRank ? clamp((101 - ctx.latestRank) / 100, 0, 1) : 0
    const persistence = clamp(ctx.appearances / Math.max(1, snapshots.length), 0, 1)
    const relVolStrength = clamp(Math.log1p(Math.max(0, ctx.latestRelVolume || 0)) / Math.log1p(30), 0, 1)
    const changeStrength = clamp(Math.abs(Number(ctx.latestChangePct || 0)) / 25, 0, 1)
    const rankTrend = ctx.previousRank && ctx.latestRank ? clamp((ctx.previousRank - ctx.latestRank) / 20, -1, 1) : 0
    ctx.momentum_score = Math.round(clamp(
      rankStrength * 38 +
      persistence * 18 +
      relVolStrength * 20 +
      changeStrength * 14 +
      Math.max(0, rankTrend) * 10,
      0,
      100
    ))
    ctx.rank_trend = Number(rankTrend.toFixed(3))
    ctx.snapshot_count = snapshots.length
    ctx.source = 'finviz_momentum_snapshots'
    byTicker.set(ticker, ctx)
  }

  return byTicker
}

async function loadCorrelationContextForTickers(db, tickers = []) {
  const wanted = Array.from(new Set(tickers.map(t => String(t || '').toUpperCase()).filter(Boolean)))
  if (!wanted.length) return new Map()
  const map = new Map()

  const stored = await db.collection('correlations').find(
    { $or: [{ ticker: { $in: wanted } }, { symbol: { $in: wanted } }] },
    { projection: { ticker: 1, symbol: 1, score: 1, correlation: 1, correlation_score: 1, sentiment_correlation: 1, news_correlation: 1, updated_at: 1, created_at: 1 } }
  ).toArray().catch(() => [])

  for (const row of stored) {
    const ticker = String(row.ticker || row.symbol || '').toUpperCase()
    const raw = Number(row.correlation_score ?? row.score ?? row.correlation ?? row.sentiment_correlation ?? row.news_correlation)
    if (!ticker || !Number.isFinite(raw)) continue
    map.set(ticker, {
      correlation_score: raw > 1 ? clamp(raw / 100, -1, 1) : clamp(raw, -1, 1),
      correlation_source: 'correlations_collection',
      correlation_samples: null,
      correlation_updated_at: row.updated_at || row.created_at || null,
    })
  }

  const labelRows = await db.collection('prediction_signals').aggregate([
    {
      $match: {
        ticker: { $in: wanted },
        'labels.return_5m.labeled': true,
        'labels.return_5m.direction_correct': { $in: [true, false] },
      },
    },
    {
      $group: {
        _id: '$ticker',
        samples: { $sum: 1 },
        correct: { $sum: { $cond: ['$labels.return_5m.direction_correct', 1, 0] } },
        avg_return_5m: { $avg: '$labels.return_5m.return_pct' },
        latest_signal_sec: { $max: '$signal_sec' },
      },
    },
  ]).toArray().catch(() => [])

  for (const row of labelRows) {
    const ticker = String(row._id || '').toUpperCase()
    if (map.has(ticker)) continue
    const samples = Number(row.samples || 0)
    const accuracy = samples ? Number(row.correct || 0) / samples : 0.5
    map.set(ticker, {
      correlation_score: Number(clamp((accuracy - 0.5) * 2, -1, 1).toFixed(3)),
      correlation_source: 'intraday_label_accuracy_proxy',
      correlation_samples: samples,
      correlation_accuracy: Number(accuracy.toFixed(3)),
      avg_return_5m: row.avg_return_5m == null ? null : Number(Number(row.avg_return_5m).toFixed(3)),
      correlation_updated_at: row.latest_signal_sec ? new Date(Number(row.latest_signal_sec) * 1000) : null,
    })
  }

  return map
}

async function loadCatalystsForTickers(db, rowsOrTickers = [], days = 3) {
  const companyByTicker = new Map()
  const wanted = new Set(rowsOrTickers.map(item => {
    const ticker = String(typeof item === 'string' ? item : item?.ticker || '').toUpperCase()
    if (ticker && typeof item === 'object') companyByTicker.set(ticker, item.company || item.companyName || '')
    return ticker
  }).filter(Boolean))
  if (!wanted.size) return new Map()

  const docs = await db.collection('articles').find(
    {
      $and: [
        recentArticleMatch(days),
        {
          $or: [
            { ticker: { $exists: true, $nin: ['', null] } },
            { tickers: { $exists: true, $ne: [] } },
            { matched_mover_tickers: { $exists: true, $ne: [] } },
            { tickers_mentioned: { $exists: true, $ne: [] } },
          ],
        },
      ],
    },
    {
      projection: {
        title: 1,
        source: 1,
        url: 1,
        ticker: 1,
        tickers: 1,
        matched_mover_tickers: 1,
        tickers_mentioned: 1,
        source_type: 1,
        category: 1,
        event_type: 1,
        event_score: 1,
        publish_date: 1,
        fetched_date: 1,
        detected_at: 1,
        sentiment: 1,
        sentiment_score: 1,
        ml_confidence: 1,
        is_sec_filing: 1,
        isFiling: 1,
        content: 1,
        contentText: 1,
        content_text: 1,
        accessionNumber: 1,
        accession_number: 1,
        formType: 1,
        form_type: 1,
      },
    }
  ).sort({ publish_date: -1, fetched_date: -1, detected_at: -1 }).limit(5000).toArray()

  const byTicker = new Map()
  for (const doc of docs) {
    const candidates = candidateTickersFromArticle(doc)
    const score = Number(doc.sentiment_score ?? (doc.sentiment === 'bullish' ? doc.ml_confidence || 1 : doc.sentiment === 'bearish' ? -(doc.ml_confidence || 1) : 0))
    const filing = isSecFilingDoc(doc)
    const contentLength = filingContentLength(doc)
    for (const ticker of candidates) {
      if (!wanted.has(ticker)) continue
      if (!articleLooksRelevantForTicker(doc, ticker, companyByTicker.get(ticker) || '')) continue
      const item = {
        type: filing ? 'sec_filing' : (doc.event_type || doc.category || 'news'),
        source: doc.source || '',
        title: doc.title || '',
        publishedAt: timestampSeconds(doc.publish_date || doc.fetched_date || doc.detected_at) || null,
        url: doc.url || '',
        sentiment: doc.sentiment || 'neutral',
        sentimentScore: Number.isFinite(score) ? Number(score.toFixed(3)) : 0,
        relevanceScore: Number(doc.event_score || 0),
        isSecFiling: filing,
        filingContentStatus: filing ? (contentLength >= 200 ? 'content_extracted' : 'missing_or_weak') : null,
        filingContentLength: filing ? contentLength : null,
        accessionNumber: doc.accessionNumber || doc.accession_number || null,
        formType: doc.formType || doc.form_type || null,
      }
      const current = byTicker.get(ticker) || []
      current.push(item)
      byTicker.set(ticker, current)
    }
  }

  for (const [ticker, items] of byTicker.entries()) {
    items.sort((a, b) => {
      const scoreDiff = Math.abs(Number(b.sentimentScore || 0)) - Math.abs(Number(a.sentimentScore || 0))
      if (scoreDiff) return scoreDiff
      return Number(b.publishedAt || 0) - Number(a.publishedAt || 0)
    })
    byTicker.set(ticker, items.slice(0, 5))
  }
  return byTicker
}

function enrichScreenerRow(row, articleRow, socialRow, windowOverride = null) {
  const newsScore = articleRow ? sentimentScore(articleRow) : Number(row.structured_sentiment || 0)
  const socialCount = Number(socialRow?.count || 0)
  const socialScore = socialCount ? Number(Number(socialRow.sentiment || 0).toFixed(3)) : Number(row.social_sentiment || 0)
  const rollingWindow = resolvedRollingWindowMinutes(row, windowOverride)
  const stocktwitsCount = Number(socialRow?.stocktwits_count || 0)
  const stocktwitsScore = stocktwitsCount
    ? Number((Number(socialRow?.stocktwits_score_sum || 0) / Math.max(1, stocktwitsCount)).toFixed(3))
    : 0
  const stocktwitsDensity = Number((stocktwitsCount / Math.max(1, rollingWindow)).toFixed(3))
  const articleCount = Number(articleRow?.count || row.news_article_count || 0)
  const totalWeight = articleCount + socialCount * 0.75
  const avgSentiment = totalWeight
    ? Number(((newsScore * articleCount + socialScore * socialCount * 0.75) / totalWeight).toFixed(3))
    : Number(row.avg_sentiment || 0)

  return {
    ...row,
    country: row.country || 'USA',
    rolling_window_minutes: rollingWindow,
    avg_sentiment: avgSentiment,
    structured_sentiment: newsScore,
    filing_sentiment: Number(articleRow?.filing_used_count || 0)
      ? Number((Number(articleRow?.filing_score_sum || 0) / Math.max(1, Number(articleRow?.filing_used_count || 0))).toFixed(3))
      : 0,
    filing_article_count: Number(articleRow?.filing_count || 0),
    filing_used_count: Number(articleRow?.filing_used_count || 0),
    filing_weight_sum: Number(articleRow?.filing_weight_sum || 0),
    filing_latest: articleRow?.filing_latest || null,
    social_sentiment: socialScore,
    social_message_sentiment: socialScore,
    social_message_density: Number((socialCount / Math.max(1, rollingWindow)).toFixed(3)),
    stocktwits_message_sentiment: stocktwitsScore,
    stocktwits_message_density: stocktwitsDensity,
    stocktwits_message_count: stocktwitsCount,
    message_count: socialCount,
    news_article_count: articleCount,
    bullish_count: Number(articleRow?.bullish || 0) + Number(socialRow?.bullish || 0),
    bearish_count: Number(articleRow?.bearish || 0) + Number(socialRow?.bearish || 0),
    neutral_count: Number(articleRow?.neutral || 0),
    sources: [...(articleRow?.sources || []), ...(socialRow?.platforms || []), row.quote_source].filter(Boolean).slice(0, 8),
    latest_publish: articleRow?.latest_publish || null,
    latest_social: socialRow?.latest_post || null,
  }
}

function attachPredictionAndCatalyst(row, predictionMap, catalystMap, horizon) {
  const prediction = predictionMap.get(row.ticker) || null
  const catalysts = catalystMap.get(row.ticker) || []
  const mainCatalyst = catalysts[0] || null
  const filingCatalyst = catalysts.find(item => item.isSecFiling && item.filingContentStatus === 'content_extracted') || null
  return {
    ...row,
    prediction,
    prediction_status: prediction ? 'available' : 'no_prediction',
    prediction_horizon_requested: String(horizon || '1d'),
    prediction_direction: prediction?.predictedDirection || null,
    predicted_return: prediction?.predictedReturn ?? null,
    prediction_confidence: prediction?.confidence ?? null,
    prediction_generated_at: prediction?.generatedAt || null,
    catalysts,
    main_catalyst: mainCatalyst,
    sec_filing_contributed: Boolean(filingCatalyst && Number(row.filing_used_count || 0) > 0),
    sentiment_breakdown: {
      newsSentiment: Number(row.structured_sentiment || 0),
      socialSentiment: Number(row.social_sentiment || 0),
      filingSentiment: Number(row.filing_sentiment || 0),
      combinedSentiment: Number(row.avg_sentiment || 0),
      sentimentUpdatedAt: row.latest_publish || row.latest_social || null,
    },
    companyName: row.company || '',
    changePercent: row.change_pct,
    marketCap: row.market_cap,
    screenerSource: row.quote_source || row.screener_source || row.source || null,
  }
}

function fallbackMomentumContext(row = {}) {
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const rsi = Number(row.rsi || 50)
  const baseScore = Math.round(clamp(Math.abs(changePct), 0, 100))
  const relVolBonus = clamp((relVolume - 1) * 10, 0, 20)
  const rsiAdjustment = rsi < 30 ? -5 : rsi > 70 ? -5 : 5
  return {
    source: 'technical_screener_fields',
    reason: 'fallback_from_local_screener_magnitude',
    momentum_score: Math.round(clamp(baseScore + relVolBonus + rsiAdjustment, 0, 100)),
    change_pct: changePct,
    rel_volume: relVolume,
    rsi,
    computed_at: new Date().toISOString(),
  }
}

function attachPredictionContext(row, aiMap, momentumMap, correlationMap) {
  const ai = aiMap.get(row.ticker) || null
  const momentum = momentumMap.get(row.ticker) || null
  const correlation = correlationMap.get(row.ticker) || null
  const neutralCorrelation = {
    correlation_score: 0,
    correlation_source: 'neutral_no_correlation_rows',
    correlation_samples: 0,
    correlation_accuracy: null,
    correlation_updated_at: null,
  }
  const momentumEvidence = momentum?.source === 'finviz_momentum_snapshots' ? momentum : null
  const fallbackMomentum = momentumEvidence ? null : fallbackMomentumContext(row)
  const actualMomentum = momentumEvidence || fallbackMomentum
  const correlationEvidence = correlation || neutralCorrelation
  const positiveCorrelationEvidence = correlationEvidence.correlation_source === 'neutral_no_correlation_rows' ? null : correlationEvidence
  const catalysts = Array.isArray(row.catalysts) ? row.catalysts : []
  const catalystScores = catalysts.map(item => Number(item.sentimentScore || 0)).filter(Number.isFinite)
  const positiveCatalystGate = Boolean(
    catalystScores.some(score => score > 0.05) ||
    Number(row.structured_sentiment || 0) > 0.05 ||
    Number(row.social_sentiment || 0) > 0.08 ||
    Number(ai?.ai_score || 50) >= 60 ||
    Number(positiveCorrelationEvidence?.correlation_score || 0) > 0.12 ||
    row.prediction?.predictedDirection === 'up'
  )
  const rsi = Number(row.rsi || 50)
  const sma20 = Number(row.sma20 || 0)
  const sma50 = Number(row.sma50 || 0)
  const price = Number(row.price || 0)
  const perfWeek = Number(row.perf_week || 0)
  const perfMonth = Number(row.perf_month || 0)
  const rsiConstructive = rsi > 35 && rsi < 72 ? 1 : rsi <= 35 ? 0.55 : 0.25
  const trendConstructive =
    price && sma20 && price >= sma20 ? 0.35 : 0
  const mediumTrendConstructive =
    sma20 && sma50 && sma20 >= sma50 ? 0.25 : 0
  const performanceConstructive =
    perfWeek > 0 && perfMonth > -10 ? 0.25 : perfWeek < -10 ? -0.15 : 0
  const rawTechnicalMomentumScore = Math.round(clamp(
    rsiConstructive * 45 +
    trendConstructive * 100 +
    mediumTrendConstructive * 100 +
    performanceConstructive * 100,
    0,
    100
  ))
  const technicalMomentumScore = positiveCatalystGate ? rawTechnicalMomentumScore : 50

  return {
    ...row,
    ai_score: ai?.ai_score ?? null,
    ai_sentiment_score: ai?.ai_sentiment_score ?? 0,
    ai_confidence: ai?.ai_confidence ?? 0,
    ai_article_count: ai?.ai_article_count ?? 0,
    ai_bullish_articles: ai?.ai_bullish_articles ?? 0,
    ai_bearish_articles: ai?.ai_bearish_articles ?? 0,
    ai_source_count: ai?.ai_source_count ?? 0,
    ai_event_count: ai?.ai_event_count ?? 0,
    ai_context: ai,
    positive_catalyst_gate: positiveCatalystGate,
    momentum_score: actualMomentum?.momentum_score ?? null,
    technical_momentum_score: technicalMomentumScore,
    raw_technical_momentum_score: rawTechnicalMomentumScore,
    momentum_context: actualMomentum ? {
      ...actualMomentum,
      technical_momentum_score: technicalMomentumScore,
      raw_technical_momentum_score: rawTechnicalMomentumScore,
      positive_catalyst_gate: positiveCatalystGate,
    } : null,
    correlation_score: correlationEvidence.correlation_score,
    correlation_context: correlationEvidence,
  }
}

function clamp(value, min, max) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(min, Math.min(max, n))
}

function publicNextSessionModelStatus(model = null) {
  if (!model) return null
  return {
    status: model.status || 'missing',
    samples: Number(model.samples || 0),
    min_samples: Number(model.min_samples || 0),
    live_enabled: Boolean(model.live_enabled),
    validation_status: model.validation_status || model.status || 'missing',
    validation_reason: model.validation_reason || model.reason || null,
    required_accuracy: model.required_accuracy ?? null,
    selected_threshold: model.selected_threshold ?? null,
    updated_at: model.updated_at || null,
  }
}

function isNonActionablePublicEquity(row = {}) {
  const ticker = String(row.ticker || '').toUpperCase()
  const company = String(row.company || row.companyName || '').toLowerCase()
  if (ticker === 'SPACEX' || ticker === 'SPCX' || /space exploration technologies|^spacex\b/.test(company)) {
    return {
      blocked: true,
      riskFlag: 'NON_ACTIONABLE_PRIVATE_EXPOSURE',
      reason: 'Private/synthetic SpaceX exposure should not be sent as a public-equity next-day prediction.',
    }
  }
  return { blocked: false }
}

function catalystAlignmentDetails(row = {}) {
  const catalysts = Array.isArray(row.catalysts) ? row.catalysts : []
  const tradability = isNonActionablePublicEquity(row)
  if (tradability.blocked) {
    return { aligned: false, score: 0, matchedTerms: [], riskFlag: tradability.riskFlag, reason: tradability.reason }
  }
  if (!catalysts.length) return { aligned: false, score: 0, matchedTerms: [], reason: 'no_catalysts' }
  if (catalysts.some(item => item.isSecFiling && item.filingContentStatus === 'content_extracted')) {
    return { aligned: true, score: 1, matchedTerms: ['sec_filing_content'], reason: 'usable_sec_filing' }
  }

  const ticker = String(row.ticker || '').toUpperCase()
  const stop = new Set([
    'inc', 'corp', 'corporation', 'company', 'group', 'holdings', 'holding',
    'limited', 'ltd', 'plc', 'class', 'ordinary', 'common', 'sponsored',
    'adr', 'ads', 'sa', 'the', 'and', 'new', 'old', 'global',
  ])
  const companyTokens = Array.from(new Set(
    String(row.company || row.companyName || '')
      .toLowerCase()
      .match(/[a-z]{3,}/g)
      ?.filter(token => !stop.has(token))
      .slice(0, 6) || []
  ))

  let score = 0
  const matchedTerms = new Set()
  const tickerRegex = ticker
    ? new RegExp(`(^|[^a-z0-9])\\$?${ticker.toLowerCase()}([^a-z0-9]|$)`, 'i')
    : null
  for (const item of catalysts.slice(0, 5)) {
    const title = String(item.title || '').toLowerCase()
    if (!title) continue
    if (tickerRegex?.test(title)) {
      score = Math.max(score, 0.75)
      matchedTerms.add(ticker)
    }
    const tokenHits = companyTokens.filter(token => title.includes(token))
    if (tokenHits.length >= 2) {
      score = Math.max(score, 0.70)
      tokenHits.forEach(token => matchedTerms.add(token))
    } else if (tokenHits.length === 1 && tokenHits[0].length >= 5) {
      score = Math.max(score, 0.45)
      matchedTerms.add(tokenHits[0])
    }
  }

  return {
    aligned: score >= 0.45,
    score: Number(score.toFixed(2)),
    matchedTerms: Array.from(matchedTerms),
    reason: score >= 0.45 ? 'matched_ticker_or_company_in_title' : 'no_ticker_or_company_match_in_catalyst_titles',
  }
}

function sourceCredibilityScore(source = '') {
  const text = String(source || '').toLowerCase()
  if (/sec|edgar|fda|nasdaq|nyse|official filing/.test(text)) return 1
  if (/reuters|dow jones|wall street journal|bloomberg|associated press|marketwatch/.test(text)) return 0.92
  if (/benzinga|tradingview|finviz|broker|analyst|platform/.test(text)) return 0.84
  if (/business wire|pr newswire|globenewswire|access newswire|accesswire|newswire/.test(text)) return 0.78
  if (/stocktwits|reddit|twitter|x\/twitter|bluesky|social/.test(text)) return 0.48
  return text ? 0.62 : 0.35
}

function catalystMaterialityScore(catalyst = {}) {
  const text = `${catalyst.type || ''} ${catalyst.title || ''}`.toLowerCase()
  let score = 0.35
  if (/fda|approval|phase|clinical|trial|pdufa|patent|regulatory/.test(text)) score = Math.max(score, 0.95)
  if (/earnings|guidance|revenue|profit|beat|raise|forecast|outlook/.test(text)) score = Math.max(score, 0.85)
  if (/contract|partnership|award|order|launch|listing|customer/.test(text)) score = Math.max(score, 0.78)
  if (/merger|acquisition|buyout|strategic alternatives|takeover/.test(text)) score = Math.max(score, 0.9)
  if (/buyback|dividend|special dividend|insider buy|purchase plan/.test(text)) score = Math.max(score, 0.72)
  if (/offering|dilution|bankruptcy|default|investigation|lawsuit|downgrade|miss|cut|rejection/.test(text)) score = Math.min(score, 0.25)
  return score
}

function structuredCatalystType(catalyst = {}) {
  const text = `${catalyst.type || ''} ${catalyst.title || ''}`.toLowerCase()
  if (/contract|award|order|customer win|purchase order/.test(text)) return 'contract'
  if (/earnings|eps|revenue|beat|profit|quarter/.test(text)) return 'earnings'
  if (/guidance|outlook|forecast|raises?|increase/.test(text)) return 'guidance_increase'
  if (/upgrade|price target|initiates? at buy|overweight|outperform/.test(text)) return 'analyst_upgrade'
  if (/buyback|repurchase|dividend/.test(text)) return 'buyback_or_capital_return'
  if (/fda|approval|clearance|clinical|trial|phase|pdufa/.test(text)) return 'fda_or_clinical'
  if (/merger|acquisition|takeover|definitive agreement|strategic alternatives/.test(text)) return 'merger_acquisition'
  if (/partnership|collaboration|strategic alliance/.test(text)) return 'partnership'
  if (/financing|credit facility|loan|investment/.test(text)) return NEGATIVE_OR_WEAK_CATALYST_RE.test(text) ? 'financing_risk' : 'positive_financing'
  if (/short squeeze|squeeze/.test(text)) return 'short_squeeze_catalyst'
  if (/launch|patent|listing|major corporate update|corporate update/.test(text)) return 'major_corporate_update'
  if (/sec_filing|8-k|material/.test(text)) return 'sec_material_update'
  return catalyst.title ? 'structured_news' : 'none'
}

function structuredCatalystSentiment(catalyst = {}, row = {}) {
  const text = `${catalyst.type || ''} ${catalyst.title || ''} ${catalyst.sentiment || ''}`.toLowerCase()
  const explicit = Number(catalyst.sentimentScore)
  if (Number.isFinite(explicit) && Math.abs(explicit) > 0.05) return clamp(explicit, -1, 1)
  if (NEGATIVE_OR_WEAK_CATALYST_RE.test(text)) return -0.45
  if (POSITIVE_CATALYST_RE.test(text)) return 0.62
  return clamp(Number(row.structured_sentiment || 0), -1, 1)
}

function analyzePositiveStructuredNews(row = {}) {
  const catalysts = Array.isArray(row.catalysts) ? row.catalysts : []
  const unique = new Map()
  for (const item of catalysts) {
    const key = normalizedWords(`${item.title || ''} ${item.source || ''}`).slice(0, 180)
    if (!key || unique.has(key)) continue
    unique.set(key, item)
  }
  const candidates = Array.from(unique.values()).filter(item => (
    item.isSecFiling ||
    STRUCTURED_NEWS_SOURCE_RE.test(String(item.source || '')) ||
    sourceCredibilityScore(item.source) >= 0.72
  ))
  let best = null
  let bestScore = 0
  for (const item of candidates) {
    const sentiment = structuredCatalystSentiment(item, row)
    const type = structuredCatalystType(item)
    const sourceCred = sourceCredibilityScore(item.source)
    const freshness = freshnessScoreFromSeconds(item.publishedAt)
    const materiality = catalystMaterialityScore(item)
    const positivePattern = POSITIVE_CATALYST_RE.test(`${item.type || ''} ${item.title || ''}`)
    const stalePenalty = freshness < 0.3 ? 0.25 : 0
    const boilerplatePenalty = item.isSecFiling && item.filingContentStatus !== 'content_extracted' ? 0.22 : 0
    const negativePenalty = NEGATIVE_OR_WEAK_CATALYST_RE.test(`${item.type || ''} ${item.title || ''}`) ? 0.45 : 0
    const score = clamp(
      Math.max(0, sentiment) * 0.32 +
      sourceCred * 0.16 +
      freshness * 0.18 +
      materiality * 0.18 +
      (positivePattern ? 0.16 : 0.02) -
      stalePenalty -
      boilerplatePenalty -
      negativePenalty,
      0,
      1
    )
    if (score > bestScore) {
      bestScore = score
      best = { item, type, sentiment, sourceCred, freshness, materiality, positivePattern }
    }
  }
  const ageMinutes = best?.item?.publishedAt
    ? Math.max(0, Math.round((Date.now() / 1000 - Number(best.item.publishedAt || 0)) / 60))
    : null
  const confidence = clamp(
    bestScore * 0.76 +
    Math.min(1, Number(row.news_article_count || 0) / 5) * 0.14 +
    (Number(row.message_density_score || 0) >= 50 ? 0.10 : 0),
    0,
    1
  )
  return {
    structured_news_score: Number(bestScore.toFixed(3)),
    structured_news_available: Boolean(best && bestScore >= 0.28),
    best_structured_catalyst_headline: best?.item?.title || null,
    best_structured_catalyst_source: best?.item?.source || null,
    best_structured_catalyst_age_minutes: ageMinutes,
    structured_catalyst_type: best?.type || null,
    structured_catalyst_sentiment: best ? Number(best.sentiment.toFixed(3)) : Number(clamp(row.structured_sentiment || 0, -1, 1).toFixed(3)),
    structured_catalyst_confidence: Number(confidence.toFixed(3)),
    structured_news_reason: best
      ? `${best.type} from ${best.item.source || 'structured source'} scored with freshness/source/materiality checks`
      : 'No fresh positive structured catalyst passed source, freshness, duplicate, and boilerplate checks.',
  }
}

function computeShortSqueezeSignal(row = {}) {
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const marketCap = topMoverMarketCapDollars(row.market_cap)
  const floatShort = nullableNumber(row.float_short)
  const floatOrShortAvailable = floatShort != null && floatShort > 0
  const messageScore = clamp(Number(row.message_density_score || 0) / 100, 0, 1)
  const catalystSupport = Math.max(
    Number(row.structured_news_score || 0),
    Number(row.structured_catalyst_confidence || 0),
    Number(row.catalyst_score || 0)
  )
  const volumeComponent = clamp(Math.log1p(Math.max(0, relVolume - 1)) / Math.log(18), 0, 1)
  const accelerationComponent = clamp(Math.max(0, changePct) / 18, 0, 1)
  const capComponent = marketCap > 0 && marketCap < 300e6 ? 1 : marketCap > 0 && marketCap < 2e9 ? 0.72 : marketCap > 0 && marketCap < 10e9 ? 0.35 : 0.08
  const floatComponent = floatOrShortAvailable ? clamp(floatShort / 30, 0, 1) : 0
  const catalystComponent = clamp(catalystSupport, 0, 1)
  const socialComponent = messageScore
  const volatilityOnly = relVolume >= 3 && Math.abs(changePct) >= 8 && catalystComponent < 0.2 && socialComponent < 0.25 && !floatOrShortAvailable
  const proxyUsed = !floatOrShortAvailable
  const scoreRaw = floatOrShortAvailable
    ? (floatComponent * 36 + volumeComponent * 20 + accelerationComponent * 16 + socialComponent * 13 + catalystComponent * 10 + capComponent * 5)
    : (volumeComponent * 26 + accelerationComponent * 22 + socialComponent * 20 + catalystComponent * 20 + capComponent * 12)
  const evidenceCount = [
    floatOrShortAvailable && floatShort >= 8,
    relVolume >= 1.8,
    changePct >= 4,
    Number(row.message_density_rising || false),
    catalystComponent >= 0.35,
    marketCap > 0 && marketCap < 2e9,
  ].filter(Boolean).length
  const supported = evidenceCount >= (floatOrShortAvailable ? 2 : 3) && !volatilityOnly
  const score = Math.round(clamp(supported ? scoreRaw : Math.min(scoreRaw, 42), 0, 100))
  const components = {
    float_short_pct: floatOrShortAvailable ? Number(floatShort.toFixed(2)) : null,
    volume_component: Number(volumeComponent.toFixed(3)),
    acceleration_component: Number(accelerationComponent.toFixed(3)),
    market_cap_component: Number(capComponent.toFixed(3)),
    message_density_component: Number(socialComponent.toFixed(3)),
    catalyst_component: Number(catalystComponent.toFixed(3)),
    evidence_count: evidenceCount,
    volatility_only_blocked: volatilityOnly,
  }
  const reasons = []
  if (floatOrShortAvailable) reasons.push(`float short ${floatShort.toFixed(1)}%`)
  else reasons.push('direct float/short interest unavailable; proxy score used')
  if (relVolume >= 1.8) reasons.push(`${relVolume.toFixed(2)}x relative volume`)
  if (changePct >= 4) reasons.push(`${changePct.toFixed(1)}% price acceleration`)
  if (row.message_density_rising) reasons.push('message density rising')
  if (catalystComponent >= 0.35) reasons.push('catalyst/news support')
  if (volatilityOnly) reasons.push('high volatility alone capped the squeeze score')
  return {
    short_squeeze_score: score,
    short_squeeze_available: supported || floatOrShortAvailable,
    short_squeeze_reason: reasons.join('; '),
    short_squeeze_components: components,
    float_or_short_interest_available: floatOrShortAvailable,
    squeeze_proxy_used: proxyUsed,
    squeeze_signal: score >= 62 && supported ? 'supported_squeeze_setup' : score >= 42 ? 'watch_proxy_squeeze_setup' : 'no_clear_squeeze_setup',
    squeeze_evidence_supported: supported,
  }
}

function attachProfessorFeedbackSignals(row = {}, densityTrend = null) {
  const withDensity = {
    ...row,
    ...(densityTrend || {
      message_density_now: 0,
      message_density_5m: 0,
      message_density_15m: 0,
      message_density_30m: 0,
      message_density_60m: 0,
      message_density_prev_window: 0,
      message_density_change: 0,
      message_density_change_pct: 0,
      message_density_trend: 'none',
      message_density_rising: false,
      message_density_score: 0,
    }),
  }
  const structured = analyzePositiveStructuredNews(withDensity)
  const withStructured = { ...withDensity, ...structured }
  const squeeze = computeShortSqueezeSignal(withStructured)
  return { ...withStructured, ...squeeze }
}

function freshnessScoreFromSeconds(publishedAt) {
  const sec = Number(publishedAt || 0)
  if (!Number.isFinite(sec) || sec <= 0) return 0.25
  const ageHours = Math.max(0, (Date.now() / 1000 - sec) / 3600)
  if (ageHours <= 2) return 1
  if (ageHours <= 6) return 0.9
  if (ageHours <= 18) return 0.72
  if (ageHours <= 36) return 0.48
  if (ageHours <= 72) return 0.3
  return 0.12
}

function catalystReactionContext(row = {}, catalyst = null, predictionContext = null) {
  const publishSec = timestampSeconds(
    catalyst?.publishedAt ||
    catalyst?.publish_date ||
    catalyst?.fetched_date ||
    catalyst?.detected_at ||
    row.latest_publish
  )
  const quoteSec = timestampSeconds(
    row.quote_updated_at ||
    row.quote_time ||
    row.price_updated_at ||
    row.updated_at ||
    predictionContext?.evidence_window_end_sec
  )
  const nowSec = Number(predictionContext?.evidence_window_end_sec || Math.floor(Date.now() / 1000))
  const reactionAnchorSec = quoteSec || nowSec
  const reactionHours = publishSec
    ? Math.max(0, (reactionAnchorSec - publishSec) / 3600)
    : null
  if (!publishSec) {
    return {
      catalyst_published_at: null,
      quote_updated_at: quoteSec ? new Date(quoteSec * 1000).toISOString() : null,
      reaction_hours: null,
      market_had_regular_reaction: false,
      catalyst_timing_bucket: 'unknown_catalyst_time',
      priced_in_multiplier: 1,
      unrealized_multiplier: 1,
      priced_in_reason: 'no catalyst timestamp; use price move only',
    }
  }

  const publishedParts = easternParts(new Date(publishSec * 1000))
  const quoteParts = quoteSec ? easternParts(new Date(quoteSec * 1000)) : null
  const publishedMinutes = Number(publishedParts.hour || 0) * 60 + Number(publishedParts.minute || 0)
  const quoteMinutes = quoteParts ? Number(quoteParts.hour || 0) * 60 + Number(quoteParts.minute || 0) : null
  const publishedWeekday = localWeekday(publishedParts.year, publishedParts.month, publishedParts.day)
  const isPublishedWeekday = publishedWeekday >= 1 && publishedWeekday <= 5
  const preStart = 4 * 60
  const regularStart = 9 * 60 + 30
  const regularEnd = 16 * 60
  const afterEnd = 20 * 60
  const publishedDateKey = `${publishedParts.year}-${publishedParts.month}-${publishedParts.day}`
  const quoteDateKey = quoteParts ? `${quoteParts.year}-${quoteParts.month}-${quoteParts.day}` : null
  const quoteIsLaterTradingDay = Boolean(quoteDateKey && quoteDateKey !== publishedDateKey && quoteMinutes != null && quoteMinutes >= regularStart)
  const duringRegular = isPublishedWeekday && publishedMinutes >= regularStart && publishedMinutes < regularEnd
  const premarket = isPublishedWeekday && publishedMinutes >= preStart && publishedMinutes < regularStart
  const afterhours = isPublishedWeekday && publishedMinutes >= regularEnd && publishedMinutes < afterEnd
  const overnightOrWeekend = !isPublishedWeekday || publishedMinutes < preStart || publishedMinutes >= afterEnd
  const marketHadRegularReaction = Boolean(
    (duringRegular && reactionHours != null && reactionHours >= 1.5) ||
    (premarket && quoteMinutes != null && (quoteDateKey !== publishedDateKey || quoteMinutes >= regularEnd)) ||
    ((afterhours || overnightOrWeekend) && quoteIsLaterTradingDay)
  )
  const catalystTimingBucket = duringRegular
    ? 'regular_session_catalyst'
    : premarket
      ? 'premarket_catalyst'
      : afterhours
        ? 'afterhours_catalyst'
        : 'overnight_or_weekend_catalyst'
  const incompleteRegularReaction = !marketHadRegularReaction && (premarket || afterhours || overnightOrWeekend || (reactionHours != null && reactionHours < 1.5))
  const pricedInMultiplier = incompleteRegularReaction
    ? 0.45
    : reactionHours != null && reactionHours < 4
      ? 0.75
      : 1
  const unrealizedMultiplier = incompleteRegularReaction
    ? 1.22
    : reactionHours != null && reactionHours < 4
      ? 1.08
      : marketHadRegularReaction
        ? 0.92
        : 1
  const pricedInReason = incompleteRegularReaction
    ? 'fresh catalyst has not had a full regular-session reaction window'
    : marketHadRegularReaction
      ? 'regular market had time to react; price move counts more as priced in'
      : 'partial reaction window'

  return {
    catalyst_published_at: new Date(publishSec * 1000).toISOString(),
    quote_updated_at: quoteSec ? new Date(quoteSec * 1000).toISOString() : null,
    reaction_hours: Number(reactionHours.toFixed(2)),
    market_had_regular_reaction: marketHadRegularReaction,
    catalyst_timing_bucket: catalystTimingBucket,
    priced_in_multiplier: Number(pricedInMultiplier.toFixed(2)),
    unrealized_multiplier: Number(unrealizedMultiplier.toFixed(2)),
    priced_in_reason: pricedInReason,
  }
}

function decisionMapQuadrantForPrediction(sentiment, changePct) {
  const sent = Number(sentiment || 0)
  const change = Number(changePct || 0)
  const sentimentThreshold = 0.08
  const priceThreshold = 0.5
  if (sent >= sentimentThreshold && change >= priceThreshold) {
    return { quadrant: 'Q1', label: 'bullish_alignment', score: 1, explanation: 'positive sentiment and positive price action are aligned' }
  }
  if (sent <= -sentimentThreshold && change <= -priceThreshold) {
    return { quadrant: 'Q3', label: 'bearish_alignment', score: 0, explanation: 'negative sentiment and negative price action are aligned bearish' }
  }
  if (sent <= -sentimentThreshold && change >= priceThreshold) {
    return { quadrant: 'Q2', label: 'risky_price_sentiment_divergence', score: 0.12, explanation: 'price is rising while sentiment is negative' }
  }
  if (sent >= sentimentThreshold && change <= -priceThreshold) {
    return { quadrant: 'Q4', label: 'bullish_unrealized_or_failed_reaction', score: 0.62, explanation: 'sentiment is positive but price has not fully reacted yet' }
  }
  return { quadrant: 'Neutral', label: 'mixed_or_early_setup', score: 0.38, explanation: 'sentiment and price action are mixed or early' }
}

function marketCapMoveProfile(marketCap) {
  const cap = topMoverMarketCapDollars(marketCap)
  if (cap > 0 && cap < 300e6) return { bucket: 'Micro', base: 0.8, ceiling: 18, multiplier: 1.35 }
  if (cap < 2e9) return { bucket: 'Small', base: 0.7, ceiling: 14, multiplier: 1.2 }
  if (cap < 10e9) return { bucket: 'Mid', base: 0.55, ceiling: 10, multiplier: 1 }
  if (cap < 200e9) return { bucket: 'Large', base: 0.35, ceiling: 6, multiplier: 0.72 }
  if (cap >= 200e9) return { bucket: 'Mega', base: 0.25, ceiling: 3.5, multiplier: 0.45 }
  return { bucket: 'Unknown', base: 0.45, ceiling: 8, multiplier: 0.85 }
}

function computeNextDayUpsidePrediction(row = {}, context = {}) {
  const catalysts = Array.isArray(row.catalysts) ? row.catalysts : []
  const mainCatalyst = row.main_catalyst || catalysts[0] || null
  const marketCapProfile = marketCapMoveProfile(row.market_cap)
  const catalystAlignment = context.catalystAlignment || catalystAlignmentDetails(row)
  const catalystScores = catalysts.map(item => Number(item.sentimentScore || 0)).filter(Number.isFinite)
  const avgCatalystSentiment = catalystScores.length
    ? clamp(catalystScores.reduce((sum, score) => sum + score, 0) / catalystScores.length, -1, 1)
    : 0
  const sourceScores = [
    ...(row.sources || []),
    ...catalysts.map(item => item.source),
  ].map(sourceCredibilityScore)
  const sourceCredibility = sourceScores.length
    ? clamp(sourceScores.reduce((sum, score) => sum + score, 0) / sourceScores.length, 0, 1)
    : 0.35
  const catalystFreshness = mainCatalyst ? freshnessScoreFromSeconds(mainCatalyst.publishedAt) : 0.2
  const catalystMateriality = mainCatalyst ? catalystMaterialityScore(mainCatalyst) : 0.2
  const catalystPolarity = clamp(Math.max(0, avgCatalystSentiment, Number(row.structured_sentiment || 0), Number(row.filing_sentiment || 0)), 0, 1)
  const catalystScore = clamp(
    catalystPolarity * 0.34 +
    sourceCredibility * 0.16 +
    catalystFreshness * 0.18 +
    catalystMateriality * 0.18 +
    Number(catalystAlignment.score || 0) * 0.14,
    0,
    1
  )
  const structuredNewsScore = clamp(
    Math.max(0, Number(row.structured_sentiment || 0)) * 0.36 +
    Math.min(1, Number(row.news_article_count || 0) / 8) * 0.22 +
    sourceCredibility * 0.16 +
    catalystScore * 0.18 +
    Number(row.structured_news_score || 0) * 0.08,
    0,
    1
  )
  const socialDensity = Number(row.social_message_density ?? row.stocktwits_message_density ?? 0)
  const unstructuredScore = clamp(
    Math.max(0, Number(row.social_sentiment || row.social_message_sentiment || 0)) * 0.45 +
    Math.max(0, Number(row.stocktwits_message_sentiment || 0)) * 0.20 +
    Math.min(1, Number(row.message_count || row.stocktwits_message_count || 0) / 40) * 0.20 +
    Math.min(1, socialDensity / 0.35) * 0.15,
    0,
    1
  )
  const sentimentScore = clamp(
    Number(row.structured_sentiment || 0) * 0.36 +
    Number(row.filing_sentiment || 0) * 0.18 +
    Number(row.social_sentiment || row.social_message_sentiment || 0) * 0.18 +
    Number(row.ai_sentiment_score || 0) * 0.28,
    -1,
    1
  )
  const sentimentUpsideScore = clamp((sentimentScore + 0.15) / 1.15, 0, 1)
  const momentumRaw = row.momentum_score == null ? 50 : Number(row.momentum_score)
  const technicalRaw = row.raw_technical_momentum_score == null ? Number(row.technical_momentum_score || 50) : Number(row.raw_technical_momentum_score)
  const momentumScore = clamp(((momentumRaw - 35) / 65) * 0.62 + ((technicalRaw - 40) / 60) * 0.38, 0, 1)
  const relVolume = Number(row.rel_volume || 0)
  const volumeScore = clamp(Math.log1p(Math.max(0, relVolume - 0.75)) / Math.log(12), 0, 1)
  const changePct = Number(row.change_pct || 0)
  const positiveReaction = Math.max(0, changePct)
  const reactionContext = catalystReactionContext(row, mainCatalyst, context.predictionContext || null)
  const rawPricedInPenalty = clamp(
    positiveReaction > 25 ? 0.8 :
      positiveReaction > 15 ? 0.55 :
        positiveReaction > 8 ? 0.28 :
          positiveReaction > 4 ? 0.12 : 0,
    0,
    0.85
  )
  const pricedInPenalty = clamp(rawPricedInPenalty * Number(reactionContext.priced_in_multiplier || 1), 0, 0.85)
  const unrealizedCatalystScore = clamp(
    catalystScore *
    (1 - pricedInPenalty) *
    (changePct < 2 ? 1.12 : 1) *
    Number(reactionContext.unrealized_multiplier || 1),
    0,
    1
  )
  const correlation = Number(row.correlation_score || 0)
  const correlationAvailable = Boolean(row.correlation_context && row.correlation_context?.correlation_source !== 'neutral_no_correlation_rows')
  const correlationIndependenceScore = correlationAvailable
    ? clamp(0.55 + correlation * 0.45, 0, 1)
    : 0.35
  const aiAvailable = row.ai_score != null && Number(row.ai_article_count || 0) > 0
  const aiScore = aiAvailable ? clamp((Number(row.ai_score) - 40) / 60, 0, 1) : 0
  const aiConfidence = clamp(row.ai_confidence ?? 0, 0, 1)
  const messageDensityScore = clamp(Number(row.message_density_score || 0) / 100, 0, 1)
  const squeezeEvidenceScore = row.squeeze_evidence_supported
    ? clamp(Number(row.short_squeeze_score || 0) / 100, 0, 1)
    : clamp(Number(row.short_squeeze_score || 0) / 100, 0, 0.42)
  const quadrant = decisionMapQuadrantForPrediction(sentimentScore, changePct)
  const riskFlags = Array.isArray(context.riskFlags) ? context.riskFlags : []
  const riskPenalty = clamp(
    (riskFlags.includes('CATALYST_TICKER_MISMATCH') ? 0.28 : 0) +
    (riskFlags.includes('NON_ACTIONABLE_PRIVATE_EXPOSURE') ? 0.8 : 0) +
    (riskFlags.includes('NEGATIVE_PRIMARY_CATALYST') ? 0.24 : 0) +
    (riskFlags.includes('AI_DISAGREES') ? 0.18 : 0) +
    (riskFlags.includes('NEGATIVE_CORRELATION_HISTORY') ? 0.18 : 0) +
    (riskFlags.includes('RECENT_EXTREME_MOVE_ALREADY_OCCURRED') ? (row.squeeze_evidence_supported ? 0.12 : 0.26) : 0) +
    (riskFlags.includes('EXTREME_VOLATILITY') ? (row.squeeze_evidence_supported ? 0.03 : 0.12) : 0) +
    (riskFlags.includes('NO_CLEAR_CATALYST') ? 0.20 : 0),
    0,
    0.9
  )
  const evidenceComposite = clamp(
    catalystScore * 0.14 +
    catalystFreshness * 0.08 +
    structuredNewsScore * 0.12 +
    unstructuredScore * 0.06 +
    messageDensityScore * 0.07 +
    squeezeEvidenceScore * 0.07 +
    sentimentUpsideScore * 0.12 +
    momentumScore * 0.10 +
    volumeScore * 0.09 +
    correlationIndependenceScore * 0.07 +
    unrealizedCatalystScore * 0.09 +
    aiScore * 0.07 +
    aiConfidence * 0.04 +
    quadrant.score * 0.06,
    0,
    1
  )
  const bearishDrag = clamp(Math.max(0, -sentimentScore) * 0.45 + Math.max(0, -avgCatalystSentiment) * 0.35, 0, 0.7)
  const effectiveEvidence = clamp(evidenceComposite - pricedInPenalty * 0.24 - riskPenalty * 0.55 - bearishDrag, 0, 1)
  const rawPredictedPercent = marketCapProfile.base + marketCapProfile.ceiling * marketCapProfile.multiplier * Math.pow(effectiveEvidence, 1.38)
  const riskAdjustedCeiling = riskFlags.includes('RECENT_EXTREME_MOVE_ALREADY_OCCURRED')
    ? (row.squeeze_evidence_supported ? Math.min(marketCapProfile.ceiling + 2, 16) : Math.min(2.5, marketCapProfile.ceiling))
    : riskFlags.includes('EXTREME_VOLATILITY')
      ? (row.squeeze_evidence_supported ? Math.min(marketCapProfile.ceiling + 1.5, 14) : Math.min(6, marketCapProfile.ceiling))
      : marketCapProfile.ceiling +
        (marketCapProfile.bucket === 'Mega' && catalystScore > 0.85 ? 2.5 : 0) +
        (row.squeeze_evidence_supported && ['Micro', 'Small'].includes(marketCapProfile.bucket) ? 4 : 0) +
        (Number(row.structured_news_score || 0) >= 0.7 && ['Micro', 'Small', 'Mid'].includes(marketCapProfile.bucket) ? 2 : 0)
  const predictedPercent = Number(clamp(rawPredictedPercent, -6, riskAdjustedCeiling).toFixed(2))
  const confidence = Number(clamp(
    0.08 +
    effectiveEvidence * 0.46 +
    Number(context.reliability || 0) * 0.22 +
    catalystFreshness * 0.08 +
    sourceCredibility * 0.06 +
    aiConfidence * 0.06 +
    quadrant.score * 0.04 -
    riskPenalty * 0.22,
    0.05,
    0.92
  ).toFixed(3))
  const explanationParts = []
  if (catalystScore >= 0.65) explanationParts.push('strong fresh catalyst')
  else if (catalystScore >= 0.42) explanationParts.push('moderate catalyst support')
  if (['Micro', 'Small', 'Mid'].includes(marketCapProfile.bucket)) explanationParts.push(`${marketCapProfile.bucket.toLowerCase()} cap can move more on credible news`)
  if (volumeScore >= 0.55) explanationParts.push('unusual relative volume')
  if (momentumScore >= 0.55) explanationParts.push('supportive early momentum')
  if (unrealizedCatalystScore >= 0.55) explanationParts.push('catalyst may not be fully priced in')
  if (messageDensityScore >= 0.45 && row.message_density_rising) explanationParts.push('message density is rising')
  if (squeezeEvidenceScore >= 0.55) explanationParts.push('evidence-backed short-squeeze setup')
  if (correlationIndependenceScore >= 0.65) explanationParts.push('stock-specific/correlation support')
  if (pricedInPenalty >= 0.35) explanationParts.push('priced-in penalty for an already large move')
  if (riskPenalty >= 0.25) explanationParts.push('risk flags reduce conviction')
  if (!explanationParts.length) explanationParts.push('mixed evidence keeps expected move conservative')

  return {
    final_predicted_percent: predictedPercent,
    confidence,
    market_cap_bucket: marketCapProfile.bucket,
    catalyst_score: Number(catalystScore.toFixed(3)),
    freshness_score: Number(catalystFreshness.toFixed(3)),
    structured_news_score: Number(structuredNewsScore.toFixed(3)),
    structured_news_available: Boolean(row.structured_news_available),
    best_structured_catalyst_headline: row.best_structured_catalyst_headline || null,
    best_structured_catalyst_source: row.best_structured_catalyst_source || null,
    best_structured_catalyst_age_minutes: row.best_structured_catalyst_age_minutes ?? null,
    structured_catalyst_type: row.structured_catalyst_type || null,
    structured_catalyst_sentiment: row.structured_catalyst_sentiment ?? null,
    structured_catalyst_confidence: row.structured_catalyst_confidence ?? null,
    unstructured_social_score: Number(unstructuredScore.toFixed(3)),
    message_density_score: Number(messageDensityScore.toFixed(3)),
    message_density_trend: row.message_density_trend || 'none',
    message_density_rising: Boolean(row.message_density_rising),
    message_density_change_pct: row.message_density_change_pct ?? null,
    short_squeeze_score: Number(squeezeEvidenceScore.toFixed(3)),
    short_squeeze_available: Boolean(row.short_squeeze_available),
    short_squeeze_reason: row.short_squeeze_reason || null,
    short_squeeze_components: row.short_squeeze_components || null,
    float_or_short_interest_available: Boolean(row.float_or_short_interest_available),
    squeeze_proxy_used: Boolean(row.squeeze_proxy_used),
    squeeze_signal: row.squeeze_signal || null,
    sentiment_score: Number(sentimentScore.toFixed(3)),
    momentum_score: Number(momentumScore.toFixed(3)),
    volume_score: Number(volumeScore.toFixed(3)),
    correlation_independence_score: Number(correlationIndependenceScore.toFixed(3)),
    priced_in_penalty: Number(pricedInPenalty.toFixed(3)),
    raw_priced_in_penalty: Number(rawPricedInPenalty.toFixed(3)),
    unrealized_catalyst_score: Number(unrealizedCatalystScore.toFixed(3)),
    ai_score: Number(aiScore.toFixed(3)),
    ai_raw_score: aiAvailable ? Number(row.ai_score) : null,
    ai_available: aiAvailable,
    ai_article_count: Number(row.ai_article_count || 0),
    source_credibility_score: Number(sourceCredibility.toFixed(3)),
    correlation_available: correlationAvailable,
    raw_correlation_score: Number(correlation.toFixed(3)),
    correlation_source: row.correlation_context?.correlation_source || null,
    correlation_samples: row.correlation_context?.correlation_samples ?? null,
    decision_map_quadrant: quadrant.quadrant,
    decision_map_quadrant_label: quadrant.label,
    decision_map_quadrant_score: Number(quadrant.score.toFixed(3)),
    catalyst_published_at: reactionContext.catalyst_published_at,
    quote_updated_at: reactionContext.quote_updated_at,
    catalyst_reaction_hours: reactionContext.reaction_hours,
    market_had_regular_reaction: reactionContext.market_had_regular_reaction,
    catalyst_timing_bucket: reactionContext.catalyst_timing_bucket,
    priced_in_reason: reactionContext.priced_in_reason,
    evidence_composite: Number(evidenceComposite.toFixed(3)),
    effective_evidence: Number(effectiveEvidence.toFixed(3)),
    risk_flags: riskFlags,
    final_explanation: explanationParts.join('; '),
  }
}

function highConvictionGuardDetails(row = {}, options = {}) {
  const debug = row.prediction_debug || row.dashboard_assessment?.predictionDebug || row.dashboard_assessment?.nextDayPrediction || {}
  const components = row.dashboard_assessment?.components || {}
  const riskFlags = Array.from(new Set([
    ...(Array.isArray(row.risk_flags) ? row.risk_flags : []),
    ...(Array.isArray(debug.risk_flags) ? debug.risk_flags : []),
  ]))
  const finalScore = Number(row.final_prediction_score ?? row.dashboard_assessment?.finalScore ?? 0)
  const predictedPercent = Number(row.final_predicted_percent ?? row.predicted_return ?? debug.final_predicted_percent ?? 0)
  const confidence = Number(row.prediction_confidence ?? debug.confidence ?? row.prediction?.confidence ?? 0)
  const marketCapBucket = String(debug.market_cap_bucket || row.market_cap_bucket || '').trim()
  const minFinalScore = Number(options.minFinalScore ?? 70)
  const minConfidence = Number(options.minConfidence ?? 0.58)
  const minPredictedReturn = Number(options.minPredictedReturn ?? 3)
  const hasStrongStructuredNews = Boolean(
    debug.structured_news_available === true &&
    Number(debug.structured_news_score || 0) >= 0.45 &&
    Number(debug.structured_catalyst_confidence || 0) >= 0.45
  )
  const hasEvidenceBackedSqueeze = Boolean(
    debug.short_squeeze_available === true &&
    Number(debug.short_squeeze_score || 0) >= 55 &&
    !debug.short_squeeze_components?.volatility_only_blocked
  )
  const hasRisingMessageDensity = Boolean(debug.message_density_rising === true && Number(debug.message_density_score || 0) >= 45)
  const professorEvidence = hasStrongStructuredNews || hasEvidenceBackedSqueeze || (hasRisingMessageDensity && (Number(debug.structured_news_score || 0) >= 0.35 || Number(debug.short_squeeze_score || 0) >= 45))
  const purchaseGrade = purchaseGradeHighConvictionDetails(row, {
    debug,
    riskFlags,
    finalScore,
    predictedPercent,
    confidence,
    hasStrongStructuredNews,
    hasEvidenceBackedSqueeze,
    hasRisingMessageDensity,
    professorEvidence,
    minFinalScore,
    minConfidence,
    minPredictedReturn,
  })
  const hardBlocks = new Set([
    'NEGATIVE_PRIMARY_CATALYST',
    'TECHNICALS_GATED_NO_POSITIVE_DRIVER',
    'AI_DISAGREES',
    'WEAK_MOMENTUM_CONFIRMATION',
    'NO_MOMENTUM_HISTORY',
    'NO_CORRELATION_HISTORY',
    'NEGATIVE_CORRELATION_HISTORY',
    'MODERATE_NEGATIVE_CORRELATION',
    'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
    'RECENT_LARGE_MOVE',
    ...(hasEvidenceBackedSqueeze ? [] : ['EXTREME_VOLATILITY']),
    'SOCIAL_ONLY_SIGNAL',
    'LOW_MODEL_CONFIDENCE_NO_CONFIRMATION',
    'CATALYST_TICKER_MISMATCH',
    'NON_ACTIONABLE_PRIVATE_EXPOSURE',
    'MEGA_CAP_LOW_TOP_MOVER_ODDS',
    'LARGE_CAP_WEAK_ACTIVITY',
    'SEC_CONTENT_MISSING',
  ])
  const failures = []
  if (finalScore < minFinalScore && !(professorEvidence && finalScore >= Math.max(62, minFinalScore - 12))) failures.push(`final_score_below_${minFinalScore}`)
  if (!Number.isFinite(predictedPercent) || predictedPercent < minPredictedReturn) failures.push(`predicted_percent_below_${minPredictedReturn}`)
  if ((!Number.isFinite(confidence) || confidence < minConfidence) && !(professorEvidence && confidence >= Math.max(0.35, minConfidence - 0.18))) failures.push(`confidence_below_${minConfidence}`)
  if (!marketCapBucket || marketCapBucket === 'Unknown') failures.push('market_cap_unknown')
  if (Number(debug.catalyst_score || 0) < 0.5 && !professorEvidence) failures.push('weak_catalyst_score')
  if (Number(debug.freshness_score || 0) < 0.3) failures.push('stale_catalyst')
  if (Number(debug.structured_news_score || 0) < 0.25 && !row.sec_filing_contributed && !hasEvidenceBackedSqueeze) failures.push('weak_structured_news')
  if (Number(debug.volume_score || 0) < 0.15 && Number(row.rel_volume || 0) < 1.2) failures.push('weak_volume_confirmation')
  if (Number(debug.momentum_score || 0) < 0.25 && !hasRisingMessageDensity) failures.push('weak_momentum_score')
  if (debug.ai_available !== true && !professorEvidence) failures.push('missing_ai_evidence')
  if (debug.ai_available === true && Number(debug.ai_raw_score || 0) < 55 && !professorEvidence) failures.push('weak_ai_score')
  if (debug.correlation_available !== true && !professorEvidence) failures.push('missing_correlation_history')
  if (debug.correlation_available === true && Number(debug.raw_correlation_score || 0) < -0.1) failures.push('negative_correlation_history')
  if (Number(debug.priced_in_penalty || 0) > 0.35 && !hasEvidenceBackedSqueeze) failures.push('too_priced_in')
  if (Number(debug.unrealized_catalyst_score || 0) < 0.3 && !hasEvidenceBackedSqueeze) failures.push('weak_unrealized_catalyst')
  if (!['Q1', 'Q4'].includes(String(debug.decision_map_quadrant || '')) && !hasEvidenceBackedSqueeze) failures.push('unsupported_decision_map_quadrant')
  if (components.positiveCatalystGate === false) failures.push('positive_catalyst_gate_failed')
  riskFlags.filter(flag => hardBlocks.has(flag)).forEach(flag => failures.push(`risk_block_${flag}`))
  purchaseGrade.missing_evidence_flags.forEach(flag => {
    if ([
      'little_evidence',
      'weak_or_missing_catalyst',
      'weak_message_density_confirmation',
      'volatility_only_or_proxy_dominant',
      'poor_risk_reward',
      'fallback_confidence_dominant',
    ].includes(flag)) failures.push(`purchase_grade_${flag}`)
  })
  if (purchaseGrade.false_positive_risk_score >= 70 && purchaseGrade.high_conviction_tier !== 'strict') failures.push('purchase_grade_false_positive_risk')
  if (purchaseGrade.high_conviction_tier !== 'strict') failures.push(`high_conviction_tier_${purchaseGrade.high_conviction_tier}`)

  return {
    pass: failures.length === 0 && purchaseGrade.high_conviction_tier === 'strict',
    failures,
    ...purchaseGrade,
    checked: {
      final_score: finalScore,
      predicted_percent: Number.isFinite(predictedPercent) ? predictedPercent : null,
      confidence: Number.isFinite(confidence) ? confidence : null,
      market_cap_bucket: marketCapBucket || null,
      catalyst_score: debug.catalyst_score ?? null,
      freshness_score: debug.freshness_score ?? null,
      structured_news_score: debug.structured_news_score ?? null,
      volume_score: debug.volume_score ?? null,
      momentum_score: debug.momentum_score ?? null,
      ai_available: debug.ai_available ?? null,
      ai_raw_score: debug.ai_raw_score ?? null,
      correlation_available: debug.correlation_available ?? null,
      raw_correlation_score: debug.raw_correlation_score ?? null,
      priced_in_penalty: debug.priced_in_penalty ?? null,
      unrealized_catalyst_score: debug.unrealized_catalyst_score ?? null,
      decision_map_quadrant: debug.decision_map_quadrant ?? null,
      structured_news_available: debug.structured_news_available ?? null,
      structured_catalyst_confidence: debug.structured_catalyst_confidence ?? null,
      message_density_rising: debug.message_density_rising ?? null,
      message_density_score: debug.message_density_score ?? null,
      short_squeeze_available: debug.short_squeeze_available ?? null,
      short_squeeze_score: debug.short_squeeze_score ?? null,
      professor_evidence: professorEvidence,
      evidence_quality_score: purchaseGrade.evidence_quality_score,
      purchase_confidence_score: purchaseGrade.purchase_confidence_score,
      false_positive_risk_score: purchaseGrade.false_positive_risk_score,
      high_conviction_tier: purchaseGrade.high_conviction_tier,
    },
  }
}

function purchaseGradeHighConvictionDetails(row = {}, context = {}) {
  const debug = context.debug || row.prediction_debug || row.dashboard_assessment?.predictionDebug || {}
  const riskFlags = Array.from(new Set([
    ...(Array.isArray(context.riskFlags) ? context.riskFlags : []),
    ...(Array.isArray(row.risk_flags) ? row.risk_flags : []),
    ...(Array.isArray(debug.risk_flags) ? debug.risk_flags : []),
  ]))
  const finalScore = Number(context.finalScore ?? row.final_prediction_score ?? row.dashboard_assessment?.finalScore ?? 0)
  const predictedPercent = Number(context.predictedPercent ?? row.final_predicted_percent ?? row.predicted_return ?? debug.final_predicted_percent ?? 0)
  const confidence = Number(context.confidence ?? row.prediction_confidence ?? debug.confidence ?? row.prediction?.confidence ?? 0)
  const structuredScore = Number(debug.structured_news_score ?? row.structured_news_score ?? 0)
  const structuredConfidence = Number(debug.structured_catalyst_confidence ?? row.structured_catalyst_confidence ?? 0)
  const squeezeScore = Number(debug.short_squeeze_score ?? row.short_squeeze_score ?? 0)
  const densityScore = Number(debug.message_density_score ?? row.message_density_score ?? 0)
  const relVolume = Number(row.rel_volume || 0)
  const changePct = Number(row.change_pct || 0)
  const momentumScore = Number(debug.momentum_score ?? row.momentum_score ?? 0)
  const sentimentScore = Number(debug.sentiment_score ?? row.social_sentiment ?? row.structured_sentiment ?? 0)
  const catalystScore = Number(debug.catalyst_score ?? row.dashboard_assessment?.components?.catalystSentiment ?? 0)
  const pricedInPenalty = Number(debug.priced_in_penalty || 0)
  const unrealizedCatalyst = Number(debug.unrealized_catalyst_score || 0)
  const hasStrongStructuredNews = Boolean(context.hasStrongStructuredNews) || (debug.structured_news_available === true && structuredScore >= 0.45 && structuredConfidence >= 0.45)
  const hasEvidenceBackedSqueeze = Boolean(context.hasEvidenceBackedSqueeze) || (debug.short_squeeze_available === true && squeezeScore >= 65 && !debug.short_squeeze_components?.volatility_only_blocked)
  const hasRisingMessageDensity = Boolean(context.hasRisingMessageDensity) || (debug.message_density_rising === true && densityScore >= 55)
  const unusualVolume = relVolume >= 2 || Number(debug.volume_score || 0) >= 0.25
  const supportiveMomentum = changePct >= 2 || momentumScore >= 0.25 || Number(row.momentum_score || 0) >= 58
  const positiveSentiment = sentimentScore >= 0.08 || Number(row.structured_sentiment || 0) >= 0.08 || Number(row.social_sentiment || 0) >= 0.08
  const acceptablePricedIn = pricedInPenalty <= (hasEvidenceBackedSqueeze ? 0.60 : 0.35)
  const catalystOrSqueeze = hasStrongStructuredNews || hasEvidenceBackedSqueeze || (structuredScore >= 0.35 && catalystScore > 0)
  const independentSignals = [
    catalystOrSqueeze,
    hasRisingMessageDensity,
    unusualVolume,
    supportiveMomentum,
    positiveSentiment,
    unrealizedCatalyst >= 0.30 || hasEvidenceBackedSqueeze,
    finalScore >= Number(context.minFinalScore ?? 78),
    confidence >= Number(context.minConfidence ?? 0.45),
  ].filter(Boolean).length

  const missing = []
  if (!catalystOrSqueeze) missing.push('weak_or_missing_catalyst')
  if (!hasStrongStructuredNews && structuredScore < 0.35 && !hasEvidenceBackedSqueeze) missing.push('weak_or_missing_structured_news')
  if (!hasRisingMessageDensity) missing.push('weak_message_density_confirmation')
  if (!unusualVolume) missing.push('weak_relative_volume')
  if (!supportiveMomentum) missing.push('weak_momentum_or_price_acceleration')
  if (!positiveSentiment) missing.push('weak_or_negative_sentiment')
  if (!acceptablePricedIn) missing.push('poor_risk_reward')
  if (independentSignals < 4) missing.push('little_evidence')
  if (row.prediction?.is_next_day_proxy || riskFlags.includes('PROXY_ONLY') || row.prediction_status === 'fallback_candidate') missing.push('fallback_confidence_dominant')
  if (debug.squeeze_proxy_used && !hasStrongStructuredNews && densityScore < 60) missing.push('volatility_only_or_proxy_dominant')

  const severeRisks = new Set([
    'NEGATIVE_PRIMARY_CATALYST',
    'TECHNICALS_GATED_NO_POSITIVE_DRIVER',
    'AI_DISAGREES',
    'WEAK_MOMENTUM_CONFIRMATION',
    'NO_MOMENTUM_HISTORY',
    'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
    'RECENT_LARGE_MOVE',
    'EXTREME_VOLATILITY',
    'SOCIAL_ONLY_SIGNAL',
    'CATALYST_TICKER_MISMATCH',
    'NON_ACTIONABLE_PRIVATE_EXPOSURE',
  ])
  const severeRiskCount = riskFlags.filter(flag => severeRisks.has(flag) && !(hasEvidenceBackedSqueeze && ['RECENT_LARGE_MOVE', 'EXTREME_VOLATILITY', 'WEAK_MOMENTUM_CONFIRMATION', 'NO_MOMENTUM_HISTORY'].includes(flag))).length
  const evidenceQualityScore = Math.round(clamp(
    (hasStrongStructuredNews ? 22 : structuredScore * 22) +
    (hasEvidenceBackedSqueeze ? 22 : Math.min(14, squeezeScore / 100 * 22)) +
    (hasRisingMessageDensity ? 16 : Math.min(10, densityScore / 100 * 16)) +
    (unusualVolume ? 12 : Math.min(8, relVolume / 2 * 12)) +
    (supportiveMomentum ? 10 : 0) +
    (positiveSentiment ? 8 : 0) +
    (unrealizedCatalyst >= 0.30 ? 6 : 0) +
    (acceptablePricedIn ? 4 : 0),
    0,
    100
  ))
  const falsePositiveRiskScore = Math.round(clamp(
    missing.length * 8 +
    severeRiskCount * 14 +
    (pricedInPenalty > 0.45 && !hasEvidenceBackedSqueeze ? 16 : 0) +
    (Math.abs(changePct) > 20 && !hasEvidenceBackedSqueeze ? 18 : 0) +
    (debug.squeeze_proxy_used && !hasStrongStructuredNews ? 8 : 0) +
    (confidence < 0.40 ? 10 : 0),
    0,
    100
  ))
  const purchaseConfidenceScore = Math.round(clamp(
    evidenceQualityScore * 0.55 +
    finalScore * 0.20 +
    clamp(confidence, 0, 1) * 100 * 0.15 +
    Math.min(100, Math.max(0, predictedPercent) * 8) * 0.10 -
    falsePositiveRiskScore * 0.28,
    0,
    100
  ))
  const strict = evidenceQualityScore >= 72 &&
    purchaseConfidenceScore >= 64 &&
    falsePositiveRiskScore <= 45 &&
    independentSignals >= 5 &&
    catalystOrSqueeze &&
    hasRisingMessageDensity &&
    unusualVolume &&
    acceptablePricedIn &&
    severeRiskCount === 0 &&
    Number.isFinite(predictedPercent) &&
    predictedPercent >= Number(context.minPredictedReturn ?? 1.5)
  const speculative = !strict && evidenceQualityScore >= 50 && purchaseConfidenceScore >= 42 && falsePositiveRiskScore < 75 && independentSignals >= 3
  const tier = strict ? 'strict' : speculative ? 'speculative' : 'rejected'
  const whyHigh = strict
    ? [
      hasStrongStructuredNews ? 'fresh structured catalyst' : null,
      hasEvidenceBackedSqueeze ? 'evidence-backed squeeze setup' : null,
      hasRisingMessageDensity ? 'rising message density' : null,
      unusualVolume ? 'unusual relative volume' : null,
      supportiveMomentum ? 'supportive momentum' : null,
      positiveSentiment ? 'positive/improving sentiment' : null,
    ].filter(Boolean)
    : []
  const whyNot = tier === 'strict'
    ? []
    : [
      ...missing,
      ...(severeRiskCount ? [`${severeRiskCount}_severe_risk_flags`] : []),
      ...(falsePositiveRiskScore >= 70 ? ['high_false_positive_risk'] : []),
      ...(purchaseConfidenceScore < 64 ? ['purchase_confidence_below_strict'] : []),
      ...(evidenceQualityScore < 72 ? ['evidence_quality_below_strict'] : []),
    ]
  return {
    high_conviction_tier: tier,
    purchase_confidence_score: purchaseConfidenceScore,
    evidence_quality_score: evidenceQualityScore,
    false_positive_risk_score: falsePositiveRiskScore,
    why_high_conviction: whyHigh,
    why_not_high_conviction: Array.from(new Set(whyNot)),
    missing_evidence_flags: Array.from(new Set(missing)),
    postmortem_adjustment_reason: tier === 'strict'
      ? 'promoted only after multi-signal purchase-grade evidence gate'
      : 'downgraded unless catalyst/squeeze, rising density, volume, momentum, sentiment, and risk/reward clear the purchase-grade gate',
  }
}

function highConvictionPublicFields(guard = {}) {
  return {
    high_conviction_tier: guard.high_conviction_tier || 'rejected',
    purchase_confidence_score: guard.purchase_confidence_score ?? 0,
    evidence_quality_score: guard.evidence_quality_score ?? 0,
    false_positive_risk_score: guard.false_positive_risk_score ?? 100,
    why_high_conviction: guard.why_high_conviction || [],
    why_not_high_conviction: guard.why_not_high_conviction || [],
    missing_evidence_flags: guard.missing_evidence_flags || [],
    postmortem_adjustment_reason: guard.postmortem_adjustment_reason || null,
  }
}

function localDateKey(date = new Date()) {
  const parts = easternParts(date)
  return `${String(parts.year).padStart(4, '0')}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`
}

function shiftDateKey(dateKey, deltaDays) {
  const [year, month, day] = String(dateKey || '').split('-').map(Number)
  if (!year || !month || !day) return ''
  const shifted = shiftLocalDate(year, month, day, deltaDays)
  return `${String(shifted.year).padStart(4, '0')}-${String(shifted.month).padStart(2, '0')}-${String(shifted.day).padStart(2, '0')}`
}

function debugFromSnapshotRow(row = {}) {
  return row.prediction_debug ||
    row.dashboard_assessment?.predictionDebug ||
    row.dashboard_assessment?.nextDayPrediction ||
    row.high_conviction_guard?.checked ||
    {}
}

function snapshotRowGuardProxy(row = {}) {
  const debug = debugFromSnapshotRow(row)
  const guard = row.high_conviction_guard || {}
  return {
    high_conviction_tier: row.high_conviction_tier || guard.high_conviction_tier || (row.high_conviction ? 'strict' : 'speculative'),
    purchase_confidence_score: row.purchase_confidence_score ?? guard.purchase_confidence_score ?? null,
    evidence_quality_score: row.evidence_quality_score ?? guard.evidence_quality_score ?? null,
    false_positive_risk_score: row.false_positive_risk_score ?? guard.false_positive_risk_score ?? null,
    missing_evidence_flags: row.missing_evidence_flags || guard.missing_evidence_flags || [],
    why_high_conviction: row.why_high_conviction || guard.why_high_conviction || [],
    why_not_high_conviction: row.why_not_high_conviction || guard.why_not_high_conviction || [],
    debug,
  }
}

function postmortemActualMove(row = {}, outcome = null, current = null) {
  const labeled = outcome?.outcome && outcome.outcome.outcome_status === 'labeled' ? outcome.outcome : row.outcome
  const actual = Number(
    labeled?.close_return_pct ??
    labeled?.last_return_pct ??
    labeled?.high_return_pct ??
    current?.change_pct
  )
  return Number.isFinite(actual) ? Number(actual.toFixed(2)) : null
}

function postmortemMethodologyReason(row = {}, actualMove = null, currentGuard = null) {
  const proxy = snapshotRowGuardProxy(row)
  const debug = proxy.debug
  const wasHigh = Boolean(row.high_conviction)
  const isMajorWinner = Number(actualMove) >= 8
  const isFalsePositive = wasHigh && Number(actualMove) <= -3
  if (isMajorWinner && !wasHigh) {
    if (Number(debug.short_squeeze_score || 0) >= 65) return 'promote SURG-type evidence-backed squeeze with rising density into strict tier'
    if (Number(debug.structured_news_score || 0) >= 0.45) return 'promote fresh structured-news breakout with rising density into strict tier'
    return 'winner missed by prior broad predicted-up/high-conviction separation; require purchase-grade audit'
  }
  if (isFalsePositive) {
    if ((row.risk_flags || []).includes('WEAK_MOMENTUM_CONFIRMATION')) return 'downgrade WULF-type weak-momentum rows unless catalyst/squeeze/density evidence is strong'
    if ((row.risk_flags || []).includes('NO_CLEAR_CATALYST') || proxy.missing_evidence_flags.includes('weak_or_missing_catalyst')) return 'reject weak-catalyst high-score rows from strict high conviction'
    return 'raise false-positive risk penalty for high-conviction rows that lack independent confirmation'
  }
  if (currentGuard?.high_conviction_tier === 'strict' && !wasHigh) return 'new purchase-grade gate would promote based on stronger multi-signal evidence'
  if (currentGuard && currentGuard.high_conviction_tier !== 'strict' && wasHigh) return 'new purchase-grade gate would downgrade prior weak-evidence high conviction'
  return 'new methodology records tier/evidence/risk reason for auditability'
}

function dashboardAssessment(row = {}, predictionContext = null) {
  const catalysts = Array.isArray(row.catalysts) ? row.catalysts : []
  const catalystScores = catalysts.map(item => Number(item.sentimentScore || 0)).filter(Number.isFinite)
  const mainCatalyst = row.main_catalyst || catalysts[0] || null
  const catalystAlignment = catalystAlignmentDetails(row)
  const hasUsableFiling =
    catalysts.some(item => item.isSecFiling && item.filingContentStatus === 'content_extracted') ||
    Number(row.filing_used_count || 0) > 0
  const newsScore = clamp(row.structured_sentiment, -1, 1)
  const socialScore = clamp(row.social_sentiment, -1, 1)
  const filingScore = hasUsableFiling ? clamp(row.filing_sentiment, -1, 1) : 0
  const catalystScore = catalystScores.length ? clamp(catalystScores.reduce((sum, n) => sum + n, 0) / catalystScores.length, -1, 1) : 0
  const correlationScore = clamp(row.correlation_score, -1, 1)
  const aiAvailable = row.ai_score != null && Number(row.ai_article_count || 0) > 0
  const aiScoreRaw = aiAvailable ? Number(row.ai_score) : null
  const aiScore = aiAvailable ? clamp((Number(aiScoreRaw) - 50) / 50, -1, 1) : 0
  const aiConfidence = clamp(row.ai_confidence, 0, 1)
  const messageDensityScore = clamp(Number(row.message_density_score || 0) / 100, 0, 1)
  const squeezeScore = row.squeeze_evidence_supported
    ? clamp(Number(row.short_squeeze_score || 0) / 100, 0, 1)
    : clamp(Number(row.short_squeeze_score || 0) / 100, 0, 0.42)
  const structuredCatalystScore = clamp(Number(row.structured_news_score || 0), 0, 1)
  const positiveCatalystGate = Boolean(
    (catalystAlignment.aligned && (catalystScore > 0.05 || newsScore > 0.05 || filingScore > 0.05)) ||
    (row.structured_news_available && structuredCatalystScore >= 0.35) ||
    (row.squeeze_evidence_supported && squeezeScore >= 0.45) ||
    (row.message_density_rising && (structuredCatalystScore >= 0.35 || catalystScore > 0.05 || Number(row.short_squeeze_score || 0) >= 55)) ||
    socialScore > 0.08 ||
    correlationScore > 0.12 ||
    (catalystAlignment.aligned && aiScore > 0.12 && aiConfidence >= 0.35)
  )
  const priceScore = clamp(Number(row.change_pct || 0) / 12, -1, 1)
  const relVolumeScore = clamp((Number(row.rel_volume || 0) - 1) / 4, 0, 1)
  const momentumScoreRaw = row.momentum_score == null ? null : Number(row.momentum_score)
  const momentumScore = momentumScoreRaw == null ? 0 : clamp((momentumScoreRaw - 50) / 50, -1, 1)
  const technicalMomentumScoreRaw = row.technical_momentum_score == null ? 50 : Number(row.technical_momentum_score)
  const rawTechnicalMomentumScoreRaw = row.raw_technical_momentum_score == null ? technicalMomentumScoreRaw : Number(row.raw_technical_momentum_score)
  const technicalMomentumScore = positiveCatalystGate ? clamp((technicalMomentumScoreRaw - 50) / 50, -1, 1) : 0
  const crossSourceAgreement = clamp(
    [
      newsScore,
      socialScore,
      filingScore,
      catalystScore,
      aiScore,
      momentumScore,
      correlationScore,
      messageDensityScore,
      squeezeScore,
    ].filter(value => Math.abs(value) > 0.05).reduce((sum, value) => sum + (value > 0 ? 1 : -1), 0) / 5,
    -1,
    1
  )
  const evidenceScore = Number((
    priceScore * 0.10 +
    relVolumeScore * 0.08 +
    newsScore * 0.14 +
    structuredCatalystScore * 0.08 +
    socialScore * 0.08 +
    messageDensityScore * 0.07 +
    squeezeScore * 0.07 +
    filingScore * 0.10 +
    catalystScore * 0.10 +
    aiScore * 0.12 +
    momentumScore * 0.09 +
    technicalMomentumScore * 0.04 +
    correlationScore * 0.08 +
    crossSourceAgreement * 0.05
  ).toFixed(3))
  const evidenceItems =
    Number(row.news_article_count || 0) +
    Number(row.message_count || 0) +
    catalysts.length +
    Number(row.filing_used_count || 0) +
    Number(row.ai_article_count || 0) +
    Number(row.correlation_context?.correlation_samples || 0)
  const reliability = clamp(
    (Number(row.news_article_count || 0) > 0 ? 0.2 : 0) +
    (Number(row.message_count || 0) > 0 ? 0.2 : 0) +
    (catalysts.length > 0 ? 0.25 : 0) +
    (hasUsableFiling ? 0.2 : 0) +
    (row.prediction ? 0.15 : 0) +
    (Number(row.ai_article_count || 0) > 0 ? Math.min(0.12, aiConfidence * 0.12) : 0) +
    (row.momentum_context ? 0.08 : 0) +
    (Number(row.message_density_score || 0) >= 45 ? 0.06 : 0) +
    (row.squeeze_evidence_supported ? 0.08 : 0) +
    (row.structured_news_available ? 0.08 : 0) +
    (Number(row.correlation_context?.correlation_samples || 0) >= 5 || row.correlation_context?.correlation_source === 'correlations_collection' ? 0.10 : 0),
    0,
    1
  )
  const direction =
    evidenceScore >= 0.18 ? 'bullish_watch' :
    evidenceScore <= -0.18 ? 'bearish_watch' :
    'neutral_watch'
  const warnings = []
  if (!row.prediction) warnings.push('No stored prediction signal exists for this ticker.')
  if (row.prediction?.staleForCurrentSession) warnings.push('Stored prediction signal is older than the current market-session evidence window.')
  if (row.prediction?.is_next_day_proxy) warnings.push('Stored signal is a shorter-horizon proxy, not a true next-day prediction.')
  if (String(row.ticker || '').length === 1) warnings.push('Single-letter ticker: catalysts require company-aware matching.')
  if (!catalysts.length) warnings.push('No recent catalyst passed relevance checks.')
  if (catalysts.length && !catalystAlignment.aligned) warnings.push(`Recent catalyst is not clearly matched to this ticker/company: ${catalystAlignment.reason}.`)
  if (!positiveCatalystGate && rawTechnicalMomentumScoreRaw > 58) warnings.push('Technical setup is visible but ignored until a positive catalyst/driver exists.')
  if (Number(row.filing_article_count || 0) && !hasUsableFiling) warnings.push('SEC filing rows exist but no usable extracted filing text contributed.')
  if (!row.ai_article_count) warnings.push('No AI/news ranking evidence found in the selected article window.')
  if (row.correlation_context?.correlation_source === 'neutral_no_correlation_rows') warnings.push('No stored correlation rows or mature label proxy for this ticker; correlation component is neutral.')

  // Compute a final prediction score (0-100) combining prediction confidence, evidence, and reliability
  const prediction = row.prediction
  let predConfScore = prediction?.confidence != null ? clamp(prediction.confidence, 0, 1) * 100 : 0
  const probabilityScore = prediction?.probabilityUp != null ? clamp(prediction.probabilityUp, 0, 1) * 100 : 50
  let predictedReturnScore = prediction?.predictedReturn != null ? clamp(Number(prediction.predictedReturn) / 6, -1, 1) * 50 + 50 : 50
  const evidenceScorePct = clamp(evidenceScore, -1, 1) * 50 + 50 // map -1..1 to 0..100
  const reliabilityScore = reliability * 100
  const aiScorePct = aiAvailable ? clamp(aiScoreRaw, 0, 100) : 0
  const momentumScorePct = clamp(momentumScoreRaw, 0, 100)
  const correlationScorePct = correlationScore * 50 + 50
  const marketCap = topMoverMarketCapDollars(row.market_cap)
  const proxyPenalty = prediction?.is_next_day_proxy ? 20 : 0
  const noPredictionPenalty = !prediction ? 30 : 0
  const stalePenalty = warnings.filter(w => w.includes('stale') || w.includes('old') || w.includes('proxy')).length * 5

  // Risk flags
  const riskFlags = []
  if (!prediction) riskFlags.push('NO_TRUE_1D_MODEL')
  if (prediction?.staleForCurrentSession) riskFlags.push('STALE_SESSION_PREDICTION')
  if (prediction?.is_next_day_proxy) riskFlags.push('PROXY_ONLY')
  if (!catalysts.length) riskFlags.push('NO_CLEAR_CATALYST')
  if (catalystAlignment.riskFlag) riskFlags.push(catalystAlignment.riskFlag)
  else if (catalysts.length && !catalystAlignment.aligned) riskFlags.push('CATALYST_TICKER_MISMATCH')
  if (!positiveCatalystGate) riskFlags.push('TECHNICALS_GATED_NO_POSITIVE_DRIVER')
  if (Number(row.filing_article_count || 0) && !hasUsableFiling) riskFlags.push('SEC_CONTENT_MISSING')
  if (mainCatalyst && Number(mainCatalyst.sentimentScore || 0) < -0.2) riskFlags.push('NEGATIVE_PRIMARY_CATALYST')
  if (Number(row.message_count || 0) > 0 && !Number(row.news_article_count || 0) && !Number(row.ai_article_count || 0) && !row.squeeze_evidence_supported) riskFlags.push('SOCIAL_ONLY_SIGNAL')
  if (Number(row.ai_article_count || 0) > 0 && Number(row.ai_score || 50) < 45) riskFlags.push('AI_DISAGREES')
  if (
    prediction &&
    Number(prediction.confidence || 0) < 0.18 &&
    Number(row.structured_news_score || 0) < 0.35 &&
    Number(row.message_density_score || 0) < 45 &&
    !row.squeeze_evidence_supported
  ) riskFlags.push('LOW_MODEL_CONFIDENCE_NO_CONFIRMATION')
  if (row.momentum_score == null) riskFlags.push('NO_MOMENTUM_HISTORY')
  else if (Number(row.momentum_score) < 40) riskFlags.push('WEAK_MOMENTUM_CONFIRMATION')
  if (row.correlation_context == null || row.correlation_context?.correlation_source === 'neutral_no_correlation_rows') riskFlags.push('NO_CORRELATION_HISTORY')
  else if (Number(row.correlation_context?.correlation_samples || 0) >= 5 && Number(row.correlation_score || 0) < -0.1) riskFlags.push('NEGATIVE_CORRELATION_HISTORY')
  else if (Number(row.correlation_score || 0) <= -0.15 && row.correlation_context?.correlation_source !== 'neutral_no_correlation_rows') riskFlags.push('MODERATE_NEGATIVE_CORRELATION')
  if (String(row.ticker || '').length === 1) riskFlags.push('SINGLE_LETTER_TICKER')
  // Penalize stocks that already had an extreme recent move (already extended)
  const changePct = Math.abs(Number(row.change_pct || 0))
  const relVolumeRaw = Number(row.rel_volume || 0)
  if (changePct > 20) riskFlags.push(row.squeeze_evidence_supported ? 'SQUEEZE_EXTREME_MOVE_RISK' : 'RECENT_EXTREME_MOVE_ALREADY_OCCURRED')
  else if (changePct > 10) riskFlags.push('RECENT_LARGE_MOVE')
  if (relVolumeRaw > 10) riskFlags.push(row.squeeze_evidence_supported ? 'SQUEEZE_VOLATILITY_RISK' : 'EXTREME_VOLATILITY')
  if (marketCap >= 200e9 && (relVolumeRaw < 4 || changePct < 12)) riskFlags.push('MEGA_CAP_LOW_TOP_MOVER_ODDS')
  else if (marketCap >= 50e9 && relVolumeRaw < 1.5 && changePct < 5) riskFlags.push('LARGE_CAP_WEAK_ACTIVITY')
  // Apply a penalty for already-extended stocks to prevent top-gainer leakage
  const squeezeBreakoutConfirmed = Boolean(
    row.squeeze_evidence_supported &&
    Number(row.short_squeeze_score || 0) >= 70 &&
    Number(row.message_density_score || 0) >= 45 &&
    (Number(row.structured_news_score || 0) >= 0.28 || Number(row.rel_volume || 0) >= 20)
  )
  const extensionPenalty = squeezeBreakoutConfirmed
    ? (changePct > 40 ? 6 : changePct > 20 ? 3 : 0)
    : changePct > 20 ? Math.min(30, Math.round(changePct / 3)) : changePct > 10 ? Math.min(15, Math.round(changePct / 5)) : 0
  const topMoverSuitabilityPenalty = riskFlags.includes('MEGA_CAP_LOW_TOP_MOVER_ODDS') ? 18 : riskFlags.includes('LARGE_CAP_WEAK_ACTIVITY') ? 8 : 0
  const aiPenalty = riskFlags.includes('AI_DISAGREES') ? 8 : 0
  const weakMomentumPenalty = riskFlags.includes('WEAK_MOMENTUM_CONFIRMATION') ? 6 : 0
  const negativeCorrelationPenalty = riskFlags.includes('NEGATIVE_CORRELATION_HISTORY') ? 8 : 0
  const moderateNegativeCorrelationPenalty = riskFlags.includes('MODERATE_NEGATIVE_CORRELATION') ? 5 : 0
  const missingCorrelationPenalty = riskFlags.includes('NO_CORRELATION_HISTORY') ? 2 : 0
  const catalystMismatchPenalty = riskFlags.includes('CATALYST_TICKER_MISMATCH') ? 18 : 0
  const nonActionablePenalty = riskFlags.includes('NON_ACTIONABLE_PRIVATE_EXPOSURE') ? 35 : 0
  const nextDayPrediction = computeNextDayUpsidePrediction(row, {
    catalystAlignment,
    riskFlags,
    reliability,
    predictionContext,
  })
  const effectivePredictedReturn = Number(nextDayPrediction.final_predicted_percent || 0)
  predictedReturnScore = clamp(effectivePredictedReturn / 12, -1, 1) * 50 + 50
  predConfScore = Math.max(predConfScore, Number(nextDayPrediction.confidence || 0) * 100)
  const nextDayUpsideScore = clamp(effectivePredictedReturn / 12, 0, 1) * 100
  const decisionMapScorePct = clamp(nextDayPrediction.decision_map_quadrant_score, 0, 1) * 100
  const unrealizedScorePct = clamp(nextDayPrediction.unrealized_catalyst_score, 0, 1) * 100
  const sourceCredibilityPct = clamp(nextDayPrediction.source_credibility_score, 0, 1) * 100
  const messageDensityPct = messageDensityScore * 100
  const squeezePct = squeezeScore * 100
  const structuredCatalystPct = structuredCatalystScore * 100
  const squeezeBreakoutBonus = squeezeBreakoutConfirmed
    ? clamp(
      4 +
      Math.min(7, Number(row.short_squeeze_score || 0) / 14) +
      Math.min(5, Number(row.message_density_score || 0) / 20) +
      Math.min(4, Math.log1p(Math.max(0, Number(row.rel_volume || 0))) / Math.log(100) * 4),
      0,
      18
    )
    : 0
  const lowConfidenceSpeculationPenalty = (
    Number(nextDayPrediction.confidence || 0) < 0.35 &&
    !squeezeBreakoutConfirmed &&
    structuredCatalystScore < 0.45 &&
    messageDensityScore < 0.45
  ) ? 12 : 0

  const finalPredictionScore = Math.round(Math.max(0, Math.min(100,
    probabilityScore * 0.10 +
    predConfScore * 0.12 +
    predictedReturnScore * 0.11 +
    nextDayUpsideScore * 0.12 +
    evidenceScorePct * 0.09 +
    reliabilityScore * 0.08 +
    aiScorePct * 0.08 +
    momentumScorePct * 0.08 +
    correlationScorePct * 0.04 +
    decisionMapScorePct * 0.05 +
    unrealizedScorePct * 0.05 +
    sourceCredibilityPct * 0.03 +
    messageDensityPct * 0.04 +
    squeezePct * 0.05 +
    structuredCatalystPct * 0.04 +
    squeezeBreakoutBonus +
    catalystScores.length * 2.5 -
    proxyPenalty -
    noPredictionPenalty -
    stalePenalty -
    extensionPenalty -
    topMoverSuitabilityPenalty -
    aiPenalty -
    weakMomentumPenalty -
    negativeCorrelationPenalty -
    moderateNegativeCorrelationPenalty -
    missingCorrelationPenalty -
    catalystMismatchPenalty -
    nonActionablePenalty -
    lowConfidenceSpeculationPenalty
  )))

  // Quality label based on final score and model type
  let signalQuality = 'insufficient_evidence'
  const blocksHighQuality = [
    'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
    'AI_DISAGREES',
    'NEGATIVE_CORRELATION_HISTORY',
    'MODERATE_NEGATIVE_CORRELATION',
    'WEAK_MOMENTUM_CONFIRMATION',
    'EXTREME_VOLATILITY',
    'SOCIAL_ONLY_SIGNAL',
    'CATALYST_TICKER_MISMATCH',
    'NON_ACTIONABLE_PRIVATE_EXPOSURE',
  ].some(flag => riskFlags.includes(flag))
  const hasProfessorEvidence = Boolean(squeezeBreakoutConfirmed || row.structured_news_available || row.message_density_rising)
  if (prediction && !prediction.is_next_day_proxy && Number(nextDayPrediction.confidence || 0) >= 0.60 && finalPredictionScore >= 74 && (catalysts.length >= 1 || hasProfessorEvidence) && !blocksHighQuality) {
    signalQuality = 'high_quality'
  } else if (prediction && Number(nextDayPrediction.confidence || 0) >= 0.45 && finalPredictionScore >= 58 && (catalysts.length >= 1 || hasProfessorEvidence)) {
    signalQuality = 'medium_quality'
  } else if (prediction && Number(nextDayPrediction.confidence || 0) >= 0.30 && finalPredictionScore >= 35) {
    signalQuality = 'low_quality'
  } else if (prediction && prediction.is_next_day_proxy) {
    signalQuality = 'proxy_only'
  }

  return {
    assessmentType: 'evidence_score_not_trained_prediction',
    direction,
    evidenceScore,
    reliability: Number(reliability.toFixed(2)),
    evidenceItems,
    finalScore: finalPredictionScore,
    signalQuality,
    riskFlags,
    components: {
      modelProbability: Number((probabilityScore / 100).toFixed(3)),
      modelConfidence: Number((predConfScore / 100).toFixed(3)),
      predictedReturn: Number(((predictedReturnScore - 50) / 50).toFixed(3)),
      nextDayPredictedPercent: nextDayPrediction.final_predicted_percent,
      nextDayConfidence: nextDayPrediction.confidence,
      priceMove: Number(priceScore.toFixed(3)),
      relativeVolume: Number(relVolumeScore.toFixed(3)),
      newsSentiment: Number(newsScore.toFixed(3)),
      socialSentiment: Number(socialScore.toFixed(3)),
      filingSentiment: Number(filingScore.toFixed(3)),
      catalystSentiment: Number(catalystScore.toFixed(3)),
      structuredCatalyst: Number(structuredCatalystScore.toFixed(3)),
      messageDensity: Number(messageDensityScore.toFixed(3)),
      shortSqueeze: Number(squeezeScore.toFixed(3)),
      positiveCatalystGate,
      aiAvailable,
      aiScore: Number(aiScore.toFixed(3)),
      aiRawScore: aiScoreRaw,
      aiConfidence: Number(aiConfidence.toFixed(3)),
      momentum: Number(momentumScore.toFixed(3)),
      technicalMomentum: Number(technicalMomentumScore.toFixed(3)),
      rawTechnicalMomentum: Number(clamp((rawTechnicalMomentumScoreRaw - 50) / 50, -1, 1).toFixed(3)),
      correlation: Number(correlationScore.toFixed(3)),
      crossSourceAgreement: Number(crossSourceAgreement.toFixed(3)),
      catalystAlignment: catalystAlignment.score,
      decisionMapQuadrant: nextDayPrediction.decision_map_quadrant,
      sourceCredibility: nextDayPrediction.source_credibility_score,
      freshness: nextDayPrediction.freshness_score,
      unrealizedCatalyst: nextDayPrediction.unrealized_catalyst_score,
      pricedInPenalty: nextDayPrediction.priced_in_penalty,
      squeezeBreakoutConfirmed,
      squeezeBreakoutBonus: Number(squeezeBreakoutBonus.toFixed(2)),
      lowConfidenceSpeculationPenalty,
    },
    scoreBreakdown: {
      probability: Number((probabilityScore * 0.10).toFixed(2)),
      confidence: Number((predConfScore * 0.12).toFixed(2)),
      predictedReturn: Number((predictedReturnScore * 0.12).toFixed(2)),
      nextDayUpside: Number((nextDayUpsideScore * 0.12).toFixed(2)),
      evidence: Number((evidenceScorePct * 0.10).toFixed(2)),
      reliability: Number((reliabilityScore * 0.08).toFixed(2)),
      ai: Number((aiScorePct * 0.09).toFixed(2)),
      momentum: Number((momentumScorePct * 0.08).toFixed(2)),
      correlation: Number((correlationScorePct * 0.05).toFixed(2)),
      decisionMap: Number((decisionMapScorePct * 0.06).toFixed(2)),
      unrealizedCatalyst: Number((unrealizedScorePct * 0.05).toFixed(2)),
      sourceCredibility: Number((sourceCredibilityPct * 0.03).toFixed(2)),
      messageDensity: Number((messageDensityPct * 0.04).toFixed(2)),
      shortSqueeze: Number((squeezePct * 0.05).toFixed(2)),
      structuredCatalyst: Number((structuredCatalystPct * 0.04).toFixed(2)),
      catalystBonus: catalystScores.length * 2.5,
      penalties: {
        proxyPenalty,
        noPredictionPenalty,
        stalePenalty,
        extensionPenalty,
        topMoverSuitabilityPenalty,
        aiPenalty,
        weakMomentumPenalty,
        negativeCorrelationPenalty,
        moderateNegativeCorrelationPenalty,
        missingCorrelationPenalty,
        catalystMismatchPenalty,
        nonActionablePenalty,
        lowConfidenceSpeculationPenalty,
      },
      bonuses: {
        squeezeBreakoutBonus: Number(squeezeBreakoutBonus.toFixed(2)),
      },
    },
    nextDayPrediction,
    predictionDebug: {
      final_predicted_percent: nextDayPrediction.final_predicted_percent,
      confidence: nextDayPrediction.confidence,
      market_cap_bucket: nextDayPrediction.market_cap_bucket,
      catalyst_score: nextDayPrediction.catalyst_score,
      freshness_score: nextDayPrediction.freshness_score,
      structured_news_score: nextDayPrediction.structured_news_score,
      structured_news_available: nextDayPrediction.structured_news_available,
      structured_news_reason: row.structured_news_reason || null,
      best_structured_catalyst_headline: nextDayPrediction.best_structured_catalyst_headline,
      best_structured_catalyst_source: nextDayPrediction.best_structured_catalyst_source,
      best_structured_catalyst_age_minutes: nextDayPrediction.best_structured_catalyst_age_minutes,
      structured_catalyst_type: nextDayPrediction.structured_catalyst_type,
      structured_catalyst_sentiment: nextDayPrediction.structured_catalyst_sentiment,
      structured_catalyst_confidence: nextDayPrediction.structured_catalyst_confidence,
      unstructured_social_score: nextDayPrediction.unstructured_social_score,
      message_density_now: row.message_density_now ?? 0,
      message_density_5m: row.message_density_5m ?? 0,
      message_density_15m: row.message_density_15m ?? 0,
      message_density_30m: row.message_density_30m ?? 0,
      message_density_60m: row.message_density_60m ?? 0,
      message_density_prev_window: row.message_density_prev_window ?? 0,
      message_density_change: row.message_density_change ?? 0,
      message_density_change_pct: row.message_density_change_pct ?? 0,
      message_density_trend: nextDayPrediction.message_density_trend,
      message_density_rising: nextDayPrediction.message_density_rising,
      message_density_score: row.message_density_score ?? 0,
      short_squeeze_score: row.short_squeeze_score ?? 0,
      short_squeeze_available: nextDayPrediction.short_squeeze_available,
      short_squeeze_reason: nextDayPrediction.short_squeeze_reason,
      short_squeeze_components: nextDayPrediction.short_squeeze_components,
      float_or_short_interest_available: nextDayPrediction.float_or_short_interest_available,
      squeeze_proxy_used: nextDayPrediction.squeeze_proxy_used,
      squeeze_signal: nextDayPrediction.squeeze_signal,
      squeeze_breakout_confirmed: squeezeBreakoutConfirmed,
      squeeze_breakout_bonus: Number(squeezeBreakoutBonus.toFixed(2)),
      low_confidence_speculation_penalty: lowConfidenceSpeculationPenalty,
      sentiment_score: nextDayPrediction.sentiment_score,
      momentum_score: nextDayPrediction.momentum_score,
      volume_score: nextDayPrediction.volume_score,
    correlation_independence_score: nextDayPrediction.correlation_independence_score,
    priced_in_penalty: nextDayPrediction.priced_in_penalty,
      raw_priced_in_penalty: nextDayPrediction.raw_priced_in_penalty,
    unrealized_catalyst_score: nextDayPrediction.unrealized_catalyst_score,
    ai_score: nextDayPrediction.ai_score,
      ai_raw_score: nextDayPrediction.ai_raw_score,
      ai_available: nextDayPrediction.ai_available,
      ai_article_count: nextDayPrediction.ai_article_count,
      source_credibility_score: nextDayPrediction.source_credibility_score,
      correlation_available: nextDayPrediction.correlation_available,
      raw_correlation_score: nextDayPrediction.raw_correlation_score,
      correlation_source: nextDayPrediction.correlation_source,
      correlation_samples: nextDayPrediction.correlation_samples,
      decision_map_quadrant: nextDayPrediction.decision_map_quadrant,
      catalyst_published_at: nextDayPrediction.catalyst_published_at,
      quote_updated_at: nextDayPrediction.quote_updated_at,
      catalyst_reaction_hours: nextDayPrediction.catalyst_reaction_hours,
      market_had_regular_reaction: nextDayPrediction.market_had_regular_reaction,
      catalyst_timing_bucket: nextDayPrediction.catalyst_timing_bucket,
      priced_in_reason: nextDayPrediction.priced_in_reason,
      risk_flags: riskFlags,
      final_explanation: nextDayPrediction.final_explanation,
    },
    mainCatalyst,
    warnings,
  }
}

function companyCatalystAligned(row = {}) {
  return catalystAlignmentDetails(row).aligned
}

function isShadowFallbackPredictionQuery(query = {}) {
  return normalizeScreenerView(query.view || '') === 'predicted_increases' && String(query.model_live || '') !== 'true'
}

function isDecisionMapUpCandidate(row = {}, query = {}) {
  const minRelVolume = Math.max(0, Number(query.minScreenerRelVolume || query.min_relative_volume || 1))
  const minAbsChange = Math.max(0, Number(query.minScreenerAbsChange || query.min_abs_change || 0.5))
  const minScore = Math.max(0, Number(query.min_decision_score || query.minDecisionScore || 65))
  const shadowFallback = isShadowFallbackPredictionQuery(query)
  const riskFlags = Array.isArray(row.risk_flags) ? row.risk_flags : []
  const score = Number(row.final_prediction_score || row.dashboard_assessment?.finalScore || 0)
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const hasPositiveDriver = Boolean(
    row.dashboard_assessment?.components?.positiveCatalystGate ||
    Number(row.structured_sentiment || 0) > 0.05 ||
    Number(row.social_sentiment || 0) > 0.08 ||
    Number(row.ai_score || 50) >= 58 ||
    Number(row.correlation_score || 0) > 0.12
  )
  const hasEvidence = Boolean(
    (row.catalysts || []).length ||
    Number(row.news_article_count || 0) > 0 ||
    Number(row.message_count || 0) > 0 ||
    Number(row.ai_article_count || 0) > 0
  )
  const hardBlocks = new Set([
    'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
    'EXTREME_VOLATILITY',
    'CATALYST_TICKER_MISMATCH',
    'NON_ACTIONABLE_PRIVATE_EXPOSURE',
  ])
  if (!shadowFallback) {
    [
      'TECHNICALS_GATED_NO_POSITIVE_DRIVER',
      'AI_DISAGREES',
      'WEAK_MOMENTUM_CONFIRMATION',
      'NEGATIVE_CORRELATION_HISTORY',
      'MODERATE_NEGATIVE_CORRELATION',
      'MEGA_CAP_LOW_TOP_MOVER_ODDS',
      'LARGE_CAP_WEAK_ACTIVITY',
    ].forEach(flag => hardBlocks.add(flag))
  }

  if (shadowFallback) {
    const hasActivity = changePct > 0 || relVolume >= minRelVolume || Math.abs(changePct) >= minAbsChange
    if (!hasActivity) return false
  } else {
    if (changePct <= 0 || Math.abs(changePct) < minAbsChange) return false
    if (relVolume < minRelVolume) return false
  }
  if (score < minScore) return false
  if (shadowFallback) {
    if (!hasPositiveDriver && !hasEvidence && relVolume < Math.max(1.2, minRelVolume)) return false
  } else if (!hasPositiveDriver || !hasEvidence) {
    return false
  }
  if (riskFlags.some(flag => hardBlocks.has(flag))) return false
  if (!shadowFallback && query.require_catalyst_alignment !== 'false' && (row.catalysts || []).length && !companyCatalystAligned(row)) return false
  return true
}

function marketCapAwareActivityPass(row = {}, query = {}) {
  const cap = topMoverMarketCapDollars(row.market_cap)
  const relVolume = Number(row.rel_volume || 0)
  const absChange = Math.abs(Number(row.change_pct || 0))
  let bucketMinRel = 1
  let bucketMinChange = 0.5
  if (cap >= 200e9) {
    bucketMinRel = 2.5
    bucketMinChange = 4
  } else if (cap >= 10e9) {
    bucketMinRel = 1.5
    bucketMinChange = 3
  } else if (cap >= 2e9) {
    bucketMinRel = 1.2
    bucketMinChange = 2
  } else if (cap >= 300e6) {
    bucketMinRel = 1
    bucketMinChange = 1
  }
  const minRel = Math.max(bucketMinRel, Number(query.minScreenerRelVolume || query.min_relative_volume || 0))
  const minChange = Math.max(bucketMinChange, Number(query.minScreenerAbsChange || query.min_abs_change || 0))
  return relVolume >= minRel && absChange >= minChange
}

function passesActionablePredictedUpGate(row = {}, query = {}) {
  if (!row.prediction) return false
  const predictedReturn = Number(row.predicted_return)
  const confidence = Number(row.prediction?.confidence ?? row.prediction_confidence ?? 0)
  const finalScore = Number(row.final_prediction_score || 0)
  const direction = String(row.prediction_direction || row.prediction?.predictedDirection || '').toLowerCase()
  const quality = String(row.signal_quality || '')
  const riskFlags = Array.isArray(row.risk_flags) ? row.risk_flags : []
  const minScore = Number(query.min_actionable_score || query.minFinalScore || 65)
  const minConfidence = Number(query.min_actionable_confidence || query.minConfidence || 0.35)
  const minReturn = Number(query.min_actionable_return || query.minPredictedReturn || 1.50)
  const hardBlocks = new Set([
    'NO_CLEAR_CATALYST',
    'TECHNICALS_GATED_NO_POSITIVE_DRIVER',
    'CATALYST_TICKER_MISMATCH',
    'NON_ACTIONABLE_PRIVATE_EXPOSURE',
    'PROXY_ONLY',
    'NO_TRUE_1D_MODEL',
    'STALE_SESSION_PREDICTION',
    'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
    'EXTREME_VOLATILITY',
    'MEGA_CAP_LOW_TOP_MOVER_ODDS',
    'LARGE_CAP_WEAK_ACTIVITY',
    'AI_DISAGREES',
    'WEAK_MOMENTUM_CONFIRMATION',
    'NEGATIVE_CORRELATION_HISTORY',
    'MODERATE_NEGATIVE_CORRELATION',
    'NEGATIVE_PRIMARY_CATALYST',
    'SOCIAL_ONLY_SIGNAL',
  ])

  if (row.prediction.is_next_day_proxy || !row.prediction.horizon_supported) return false
  if (direction !== 'up') return false
  if (!Number.isFinite(predictedReturn) || predictedReturn < minReturn) return false
  if (!Number.isFinite(confidence) || confidence < minConfidence) return false
  if (!['medium_quality', 'high_quality'].includes(quality)) return false
  if (finalScore < minScore) return false
  if (!row.dashboard_assessment?.components?.positiveCatalystGate) return false
  if (!marketCapAwareActivityPass(row, query)) return false
  if (query.require_catalyst_alignment !== 'false' && !companyCatalystAligned(row)) return false
  if (riskFlags.some(flag => hardBlocks.has(flag))) return false
  return true
}

function passesActionablePredictedUpGateFallback(row = {}, query = {}) {
  // Relaxed gate used when the next-session calibrator is not live.
  // Accept rows with strong screener evidence even without a stored prediction.
  const predictedReturn = Number(row.predicted_return ?? row.prediction?.predictedReturn ?? row.change_pct ?? 0)
  const confidence = Number(row.prediction?.confidence ?? row.prediction_confidence ?? row.ai_confidence ?? 0.35)
  const finalScore = Number(row.final_prediction_score || 60)
  const relVolume = Number(row.rel_volume || 0)
  const hasCatalyst = Boolean((row.catalysts || []).length) || Number(row.news_article_count || 0) > 0
  const momentumOk = Number(row.momentum_score || 0) >= 40
  const minScore = Number(query.min_actionable_score || query.minFinalScore || 60)
  const minConfidence = Number(query.min_actionable_confidence || query.minConfidence || 0.25)
  const minReturn = Number(query.min_actionable_return || query.minPredictedReturn || 0.5)

  if (finalScore < minScore) return false
  if (confidence < minConfidence) return false
  if (predictedReturn < minReturn) return false
  // require at least one of: catalyst, relatvie volume spike, or momentum confirmation
  if (!hasCatalyst && relVolume < 1.2 && !momentumOk) return false
  // filter severe risk flags
  const riskFlags = Array.isArray(row.risk_flags) ? row.risk_flags : []
  const hardBlocks = new Set(['RECENT_EXTREME_MOVE_ALREADY_OCCURRED', 'EXTREME_VOLATILITY', 'NON_ACTIONABLE_PRIVATE_EXPOSURE'])
  if (riskFlags.some(f => hardBlocks.has(f))) return false
  if (query.require_catalyst_alignment !== 'false' && hasCatalyst && !companyCatalystAligned(row)) return false
  return true
}

function decorateDecisionMapPredictionCandidate(row = {}) {
  if (row.prediction) return row
  const score = Number(row.final_prediction_score || row.dashboard_assessment?.finalScore || 0)
  return {
    ...row,
    prediction_status: 'decision_map_candidate',
    prediction_direction: 'up',
    predicted_return: null,
    prediction_confidence: null,
    decision_candidate: true,
    decision_candidate_score: score,
    decision_candidate_source: 'screener_first_decision_map',
    signal_quality: row.signal_quality === 'insufficient_evidence' ? 'decision_map_candidate' : row.signal_quality,
    risk_flags: Array.from(new Set([...(row.risk_flags || []), 'NO_TRUE_1D_MODEL'])),
  }
}

function hasShadowFallbackEvidence(row = {}, query = {}) {
  const minScore = Math.max(0, Number(query.min_decision_score || query.minDecisionScore || 40))
  const score = Number(row.evidence_score ?? row.final_prediction_score ?? row.dashboard_assessment?.finalScore ?? 0)
  const changePct = Number(row.change_pct || 0)
  const relVolume = Number(row.rel_volume || 0)
  const hasCatalyst = Boolean((row.catalysts || []).length) || Number(row.news_article_count || 0) > 0
  const hasSocial = Number(row.message_count || 0) > 0
  const hasAi = Number(row.ai_score || 0) >= 50 || Number(row.ai_article_count || 0) > 0
  const hasMomentum = Number(row.momentum_score || 0) >= 35
  const hasCorrelation = Number(row.correlation_score || 0) > -0.25
  const riskFlags = Array.isArray(row.risk_flags) ? row.risk_flags : []
  const hardBlocks = new Set(['RECENT_EXTREME_MOVE_ALREADY_OCCURRED', 'EXTREME_VOLATILITY', 'NON_ACTIONABLE_PRIVATE_EXPOSURE'])
  if (riskFlags.some(flag => hardBlocks.has(flag))) return false
  if (score < minScore) return false
  return changePct > 0 || relVolume >= 1 || hasCatalyst || hasSocial || hasAi || hasMomentum || hasCorrelation
}

function applyPostEnrichmentFilters(rows, query) {
  const search = normalizeSearchQuery(query.search || query.q || '')
  const exactTicker = normalizeTickerSearch(search)
  const companySearch = search && !exactTicker ? search.toLowerCase() : ''
  const view = normalizeScreenerView(query.view || '')
  const source = String(query.source || '').trim().toLowerCase()
  const catalyst = String(query.catalyst || query.category || '').trim().toLowerCase()
  const sentiment = String(query.sentiment || '').trim().toLowerCase()
  const minPredictedReturn = query.min_predicted_return == null || query.min_predicted_return === ''
    ? null
    : Number(query.min_predicted_return)
  const predictionDirection = String(query.prediction_direction || '').trim().toLowerCase()
  const keepSearchedTickerEvenWithoutPrediction = view === 'predicted_increases' && exactTicker

  return rows.filter(row => {
    if (exactTicker && row.ticker !== exactTicker) return false
    if (companySearch) {
      const haystack = `${row.ticker} ${row.company || ''}`.toLowerCase()
      if (!haystack.includes(companySearch)) return false
    }
    if (source) {
      const sources = new Set([...(row.sources || []), ...(row.catalysts || []).map(item => item.source)].map(value => String(value || '').toLowerCase()))
      if (![...sources].some(value => value.includes(source))) return false
    }
    if (catalyst) {
      const catalysts = row.catalysts || []
      if (!catalysts.some(item => `${item.type || ''} ${item.source || ''} ${item.title || ''}`.toLowerCase().includes(catalyst))) return false
    }
    if (sentiment === 'bullish' && Number(row.avg_sentiment || 0) <= 0.05) return false
    if (sentiment === 'bearish' && Number(row.avg_sentiment || 0) >= -0.05) return false
    if (sentiment === 'neutral' && Math.abs(Number(row.avg_sentiment || 0)) > 0.05) return false
    if (predictionDirection && row.prediction_direction !== predictionDirection) return false
    if (view === 'predicted_increases') {
      const modelLive = String(query.model_live || '') === 'true'
      if (keepSearchedTickerEvenWithoutPrediction) return true

      // If calibrator is live, require stored prediction rows (existing behavior)
      if (modelLive) {
        if (!row.prediction) {
          return query.include_decision_candidates === 'false'
            ? false
            : isDecisionMapUpCandidate(row, query)
        }
        const actionableOnly = query.actionable !== 'false'
        if (actionableOnly) return passesActionablePredictedUpGate(row, query)
        if (row.prediction.is_next_day_proxy) return false
        const predicted = Number(row.predicted_return)
        const direction = String(row.prediction_direction || '').toLowerCase()
        const storedModelIsUp = direction === 'up' || (Number.isFinite(predicted) && predicted > 0)
        if (!storedModelIsUp) return false
        if (Number.isFinite(minPredictedReturn) && Number.isFinite(predicted) && predicted < minPredictedReturn) return false
      } else {
        // Calibrator not live: use screener-first fallback logic and allow
        // candidates without stored model predictions. Rely on Decision Map
        // candidates and a relaxed actionable gate when requested.
        const actionableOnly = query.actionable !== 'false'
        if (!row.prediction) {
          // if no stored prediction, accept Decision Map up-candidates as fallback
          if (query.include_decision_candidates !== 'false' && (isDecisionMapUpCandidate(row, query) || hasShadowFallbackEvidence(row, query))) {
            // allow through
          } else {
            return false
          }
        } else {
          const direction = String(row.prediction_direction || row.prediction?.predictedDirection || '').toLowerCase()
          const predicted = Number(row.predicted_return ?? row.prediction?.predictedReturn)
          const storedModelIsUp = direction === 'up' || (Number.isFinite(predicted) && predicted > 0)
          if (!storedModelIsUp && !hasShadowFallbackEvidence(row, query)) return false
        }
        if (actionableOnly) {
          // use relaxed fallback gate
          if (!passesActionablePredictedUpGateFallback(row, query)) return false
        }
        // In shadow fallback mode we avoid strict minimum predicted-return
        // gating so that screener-first evidence can surface candidates.
        // The calibrated model still enforces minPredictedReturn when live.
        const predicted = Number(row.predicted_return ?? row.prediction?.predictedReturn ?? row.change_pct ?? 0)
      }
    }
    if (view === 'news_catalysts' && !(row.catalysts || []).length) return false
    return true
  })
}

// GET /api/screener/assessment?tickers=S,VRDN,GME
// Truthful dashboard opinion for named tickers. This does not manufacture a
// model prediction when prediction_signals has no row.
router.get('/assessment', async (req, res) => {
  try {
    const rawTickers = String(req.query.tickers || req.query.search || '')
      .split(',')
      .map(t => normalizeTickerSearch(t))
      .filter(Boolean)
    const tickers = Array.from(new Set(rawTickers)).slice(0, 25)
    if (!tickers.length) {
      return res.status(400).json({ ok: false, error: 'Provide tickers=S,VRDN,GME or search=S.' })
    }

    const horizon = String(req.query.horizon || '1d').toLowerCase()
    const days = Math.max(1, Math.min(30, Number(req.query.days || 3)))
    const predictionContext = marketPredictionContext()
    const rows = await Screener.find({ ticker: { $in: tickers } }).lean()
    let data = rows
      .map(normalizeScreenerRow)
      .filter(row => tickers.includes(row.ticker))

    if (mongoose.connection.db && data.length) {
      const [articleMap, socialMap, densityMap, predictionMap, catalystMap, aiMap, momentumMap, correlationMap] = await Promise.all([
        loadArticleStatsForTickers(mongoose.connection.db, tickers, days, { predictionContext }),
        loadAdaptiveSocialStatsForRows(mongoose.connection.db, data, null),
        loadMessageDensityTrendsForTickers(mongoose.connection.db, tickers),
        loadLatestPredictionsForTickers(mongoose.connection.db, tickers, horizon, { predictionContext }),
        loadCatalystsForTickers(mongoose.connection.db, data, days),
        loadAiEvidenceForTickers(mongoose.connection.db, tickers, days, { predictionContext }),
        loadMomentumContextForTickers(mongoose.connection.db, tickers),
        loadCorrelationContextForTickers(mongoose.connection.db, tickers),
      ])
      data = data
        .map(row => enrichScreenerRow(row, articleMap.get(row.ticker), socialMap.get(row.ticker), null))
        .map(row => attachPredictionAndCatalyst(row, predictionMap, catalystMap, horizon))
        .map(row => attachPredictionContext(row, aiMap, momentumMap, correlationMap))
        .map(row => attachProfessorFeedbackSignals(row, densityMap.get(row.ticker)))
        .map(row => {
          const da = dashboardAssessment(row, predictionContext)
          const assessedRow = {
            ...row,
            dashboard_assessment: da,
            final_prediction_score: da.finalScore,
            stored_predicted_return: row.predicted_return ?? null,
            final_predicted_percent: da.nextDayPrediction?.final_predicted_percent ?? null,
            predicted_return: da.nextDayPrediction?.final_predicted_percent ?? row.predicted_return ?? null,
            prediction_confidence: Math.max(Number(row.prediction_confidence || 0), Number(da.nextDayPrediction?.confidence || 0)),
            prediction_debug: da.predictionDebug,
            prediction_explanation: da.predictionDebug?.final_explanation || null,
            signal_quality: da.signalQuality,
            risk_flags: da.riskFlags,
            score_breakdown: da.scoreBreakdown,
          }
          const highConvictionGuard = highConvictionGuardDetails(assessedRow)
          return {
            ...assessedRow,
            high_conviction: highConvictionGuard.pass,
            high_conviction_guard: highConvictionGuard,
          }
        })
    }

    const found = new Set(data.map(row => row.ticker))
    for (const ticker of tickers) {
      if (!found.has(ticker)) {
        data.push({
          ticker,
          prediction_status: 'not_in_screener_universe',
          prediction: null,
          catalysts: [],
          dashboard_assessment: {
            assessmentType: 'evidence_score_not_trained_prediction',
            direction: 'unknown',
            evidenceScore: 0,
            reliability: 0,
            evidenceItems: 0,
            components: {},
            mainCatalyst: null,
            warnings: ['Ticker is not present in the current screener collection.'],
          },
        })
      }
    }

    // Add detailed audit information for exact ticker assessments so UI can
    // show why a ticker was included/excluded.
    data = data.map(row => {
      const ticker = String(row.ticker || '').toUpperCase()
      const inScreener = rows.some(r => String(r.ticker || '').toUpperCase() === ticker)
      const inPredictionSignals = Boolean(row.prediction)
      const inMomentum = Boolean(row.momentum_score || row.momentum_context || false)
      const decisionCandidate = Boolean(row.decision_candidate || isDecisionMapUpCandidate(row, {}))
      const structuredNews = Number(row.news_article_count || 0)
      const unstructured = Number(row.message_count || 0)
      const session = row.prediction_session || null
      const gates = []
      if (row.risk_flags && row.risk_flags.length) gates.push(...row.risk_flags)
      if (!inScreener) gates.push('NOT_IN_SCREENER')
      if (row.prediction && row.prediction.is_next_day_proxy) gates.push('PROXY_PREDICTION')
      const calibratorRejected = String(req.query.model_live || '') === 'false' && !row.prediction
      const fallbackAccepted = String(req.query.model_live || '') !== 'true' && (decisionCandidate || inScreener)

      return {
        ...row,
        audit: {
          in_screener: inScreener,
          in_prediction_signals: inPredictionSignals,
          in_momentum: inMomentum,
          in_decision_map: decisionCandidate,
          structured_news_count: structuredNews,
          unstructured_social_count: unstructured,
          session: session,
          gates_applied: gates,
          calibrator_rejected: calibratorRejected,
          fallback_accepted: fallbackAccepted,
          final_inclusion: !(gates.length > 0 && !fallbackAccepted),
        },
      }
    })

    data.sort((a, b) => tickers.indexOf(a.ticker) - tickers.indexOf(b.ticker))
    res.json({
      ok: true,
      horizon,
      days,
      generatedAt: new Date().toISOString(),
      prediction_session_context: predictionContext,
      explanation: 'prediction is the stored model signal when present; dashboard_assessment is a transparent evidence score and is not a trained next-day prediction.',
      rows: data,
      summary: {
        requested: tickers.length,
        withStoredPrediction: data.filter(row => row.prediction).length,
        withTrueRequestedHorizon: data.filter(row => row.prediction && row.prediction.horizon_supported).length,
        withProxyPrediction: data.filter(row => row.prediction?.is_next_day_proxy).length,
        withoutPrediction: data.filter(row => !row.prediction).length,
      },
    })
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message })
  }
})

// GET /api/screener/high-conviction-postmortem
// Audits saved predicted-up and High Conviction snapshots against realized
// outcomes. This is explicitly a methodology-debug endpoint, not a live picker.
router.get('/high-conviction-postmortem', async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, rows: [], error: 'MongoDB not connected' })

    const todayKey = localDateKey(new Date())
    const requestedDate = String(req.query.date || '').trim()
    const targetDate = requestedDate || shiftDateKey(todayKey, -1)
    let snapshot = await db.collection('daily_prediction_snapshots').findOne(
      { date_key: targetDate },
      { sort: { generated_at: -1 }, projection: { _id: 1, date_key: 1, generated_at: 1, generated_at_sec: 1, raw_rows: 1, high_conviction_rows: 1 } }
    )
    if (!snapshot && !requestedDate) {
      snapshot = await db.collection('daily_prediction_snapshots').findOne(
        {},
        { sort: { generated_at: -1 }, projection: { _id: 1, date_key: 1, generated_at: 1, generated_at_sec: 1, raw_rows: 1, high_conviction_rows: 1 } }
      )
    }
    if (!snapshot) {
      return res.json({
        ok: true,
        rows: [],
        count: 0,
        date_key: targetDate,
        note: 'No saved daily_prediction_snapshots row exists for the requested date. Run scripts/save_daily_prediction_snapshot.js before the next session to enable this audit.',
      })
    }

    const rawRows = Array.isArray(snapshot.raw_rows) ? snapshot.raw_rows : []
    const highRows = Array.isArray(snapshot.high_conviction_rows) ? snapshot.high_conviction_rows : []
    const highSet = new Set(highRows.map(row => String(row.ticker || '').toUpperCase()).filter(Boolean))
    const byTicker = new Map()
    rawRows.forEach(row => {
      const ticker = String(row.ticker || '').toUpperCase()
      if (ticker && !byTicker.has(ticker)) byTicker.set(ticker, { ...row, _snapshot_group: 'predicted_up' })
    })
    highRows.forEach(row => {
      const ticker = String(row.ticker || '').toUpperCase()
      if (!ticker) return
      const prior = byTicker.get(ticker) || {}
      byTicker.set(ticker, { ...prior, ...row, _snapshot_group: prior._snapshot_group ? 'predicted_up_and_high_conviction' : 'high_conviction' })
    })
    const tickers = [...byTicker.keys()]
    const [outcomes, currentRows] = await Promise.all([
      db.collection('prediction_outcomes')
        .find({ snapshot_id: snapshot._id, ticker: { $in: tickers } }, { projection: { ticker: 1, row_group: 1, outcome: 1 } })
        .toArray()
        .catch(() => []),
      Screener.find({ ticker: { $in: tickers } }, { ticker: 1, change_pct: 1, price: 1, rel_volume: 1 }).lean().catch(() => []),
    ])
    const outcomeByTicker = new Map()
    outcomes.forEach(outcome => {
      const ticker = String(outcome.ticker || '').toUpperCase()
      if (!ticker) return
      const existing = outcomeByTicker.get(ticker)
      if (!existing || outcome.row_group === 'raw_rows') outcomeByTicker.set(ticker, outcome)
    })
    const currentByTicker = new Map(currentRows.map(row => [String(row.ticker || '').toUpperCase(), row]))

    const rows = tickers.map(ticker => {
      const row = byTicker.get(ticker) || {}
      const proxy = snapshotRowGuardProxy(row)
      const debug = proxy.debug
      const currentGuard = purchaseGradeHighConvictionDetails(row, {
        debug,
        riskFlags: row.risk_flags || [],
        finalScore: row.final_prediction_score,
        predictedPercent: row.predicted_return,
        confidence: row.prediction_confidence,
        minFinalScore: 78,
        minConfidence: 0.45,
        minPredictedReturn: 1.5,
      })
      const actualMove = postmortemActualMove(row, outcomeByTicker.get(ticker), currentByTicker.get(ticker))
      const wasHigh = highSet.has(ticker) || Boolean(row.high_conviction)
      const majorWinner = Number(actualMove) >= Number(req.query.majorWinnerPct || 8)
      const falsePositive = wasHigh && Number(actualMove) <= Number(req.query.falsePositivePct || -3)
      const shouldHaveBeenHighConviction = Boolean(
        currentGuard.high_conviction_tier === 'strict' ||
        (majorWinner && currentGuard.evidence_quality_score >= 60 && currentGuard.false_positive_risk_score <= 60) ||
        (majorWinner && Number(debug.short_squeeze_score || 0) >= 65 && debug.message_density_rising === true) ||
        (majorWinner && Number(debug.structured_news_score || 0) >= 0.45 && debug.message_density_rising === true)
      )
      const catalystType = debug.structured_catalyst_type ||
        row.main_catalyst?.type ||
        (Number(debug.short_squeeze_score || 0) >= 65 ? 'short_squeeze' : row.main_catalyst?.source || null)
      return {
        ticker,
        yesterday_predicted_percent: row.predicted_return ?? row.prediction?.predictedReturn ?? null,
        yesterday_final_score: row.final_prediction_score ?? null,
        yesterday_high_conviction: wasHigh,
        today_actual_move: actualMove,
        catalyst_type: catalystType,
        message_density_trend: debug.message_density_trend || row.message_density_trend || null,
        message_density_rising: debug.message_density_rising ?? row.message_density_rising ?? null,
        squeeze_score: debug.short_squeeze_score ?? row.short_squeeze_score ?? null,
        structured_news_score: debug.structured_news_score ?? row.structured_news_score ?? null,
        evidence_quality: currentGuard.evidence_quality_score,
        purchase_confidence_score: currentGuard.purchase_confidence_score,
        false_positive_risk_score: currentGuard.false_positive_risk_score,
        high_conviction_tier: currentGuard.high_conviction_tier,
        risk_flags: row.risk_flags || [],
        missing_evidence_flags: currentGuard.missing_evidence_flags,
        should_have_been_high_conviction: shouldHaveBeenHighConviction,
        false_positive: falsePositive,
        methodology_fix_applied: postmortemMethodologyReason(row, actualMove, currentGuard),
        why_high_conviction: currentGuard.why_high_conviction,
        why_not_high_conviction: currentGuard.why_not_high_conviction,
        snapshot_group: row._snapshot_group,
      }
    }).sort((a, b) => {
      if (a.false_positive !== b.false_positive) return a.false_positive ? -1 : 1
      if (a.should_have_been_high_conviction !== b.should_have_been_high_conviction) return a.should_have_been_high_conviction ? -1 : 1
      return Number(b.today_actual_move ?? -999) - Number(a.today_actual_move ?? -999)
    })

    res.json({
      ok: true,
      snapshot_id: snapshot._id,
      date_key: snapshot.date_key,
      generated_at: snapshot.generated_at,
      rows,
      count: rows.length,
      summary: {
        predicted_up_count: rawRows.length,
        high_conviction_count: highRows.length,
        major_winners: rows.filter(row => Number(row.today_actual_move) >= Number(req.query.majorWinnerPct || 8)).length,
        missed_major_winners: rows.filter(row => row.should_have_been_high_conviction && !row.yesterday_high_conviction).length,
        false_positives: rows.filter(row => row.false_positive).length,
        strict_now: rows.filter(row => row.high_conviction_tier === 'strict').length,
        speculative_now: rows.filter(row => row.high_conviction_tier === 'speculative').length,
        rejected_now: rows.filter(row => row.high_conviction_tier === 'rejected').length,
      },
      methodology: 'High Conviction now optimizes purchase-grade precision: catalyst/squeeze, rising density, volume, momentum, sentiment, priced-in penalty, and risk flags determine strict/speculative/rejected tiers.',
    })
  } catch (err) {
    console.error('GET /api/screener/high-conviction-postmortem failed:', err)
    res.status(500).json({ ok: false, rows: [], error: String(err.message || err) })
  }
})

// GET /api/screener
router.get('/', async (req, res) => {
  try {
    const { sector, signal, orderBy = 'ticker', orderDir = 'asc', limit = 3000, days = 3 } = req.query
    const compact = ['1', 'true', 'yes'].includes(String(req.query.compact || '').toLowerCase())
    const windowOverride = req.query.window_minutes ? Number(req.query.window_minutes) : null
    const view = normalizeScreenerView(req.query.view || 'all')
    req.query.view = view
    const isPredictionView = view === 'predicted_increases' || view === 'high_conviction_next_day'
    const horizon = String(req.query.horizon || (isPredictionView ? '1d' : 'signal')).toLowerCase()
    const predictionContext = isPredictionView ? marketPredictionContext() : null
    const search = normalizeSearchQuery(req.query.search || req.query.q || '')
    const exactTickerSearch = normalizeTickerSearch(search)
    const evidenceHeavyViews = new Set(['predicted_increases', 'high_conviction_next_day', 'news_catalysts'])
    const fastCompactScreener = compact && !evidenceHeavyViews.has(view) && !search
    const filter = {
      exchange: { $in: Array.from(US_EXCHANGES) },
      ticker: { $not: /\./ },
      price: { $ne: null },
    }
    if (exactTickerSearch) {
      filter.ticker = exactTickerSearch
    } else if (search) {
      filter.$or = [
        { ticker: String(search).toUpperCase() },
        { company: { $regex: escapeRegExp(search), $options: 'i' } },
      ]
    }
    if (sector) filter.sector = sector
    if (req.query.exchange) filter.exchange = normalizeExchange(req.query.exchange)
    if (req.query.industry) filter.industry = req.query.industry
    if (req.query.country) filter.country = req.query.country
    if (req.query.market_cap) {
      const bucket = String(req.query.market_cap).toLowerCase()
      if (bucket === 'micro') filter.market_cap = { $gt: 0, $lt: 300e6 }
      if (bucket === 'small') filter.market_cap = { $gte: 300e6, $lt: 2e9 }
      if (bucket === 'mid') filter.market_cap = { $gte: 2e9, $lt: 10e9 }
      if (bucket === 'large') filter.market_cap = { $gte: 10e9, $lt: 200e9 }
      if (bucket === 'mega') filter.market_cap = { $gte: 200e9 }
    }
    if (req.query.price_range) {
      const pr = String(req.query.price_range)
      if (pr === 'under1') filter.price = { $gt: 0, $lt: 1 }
      if (pr === 'under5') filter.price = { $gt: 0, $lt: 5 }
      if (pr === 'under10') filter.price = { $gt: 0, $lt: 10 }
      if (pr === 'under20') filter.price = { $gt: 0, $lt: 20 }
      if (pr === 'over5') filter.price = { $gte: 5 }
      if (pr === 'over10') filter.price = { $gte: 10 }
      if (pr === 'over20') filter.price = { $gte: 20 }
      if (pr === 'over50') filter.price = { $gte: 50 }
      if (pr === 'over100') filter.price = { $gte: 100 }
    }
    if (req.query.price_change) {
      const pc = String(req.query.price_change)
      if (pc === 'up') filter.change_pct = { $gt: 0 }
      if (pc === 'down') filter.change_pct = { $lt: 0 }
      if (pc === 'up2') filter.change_pct = { $gte: 2 }
      if (pc === 'up5') filter.change_pct = { $gte: 5 }
      if (pc === 'up10') filter.change_pct = { $gte: 10 }
      if (pc === 'down2') filter.change_pct = { $lte: -2 }
      if (pc === 'down5') filter.change_pct = { $lte: -5 }
    }
    if (req.query.avg_volume) filter.volume = { ...(filter.volume || {}), $gte: Number(req.query.avg_volume) }
    if (req.query.rel_volume) {
      const rv = String(req.query.rel_volume)
      if (rv === 'over1') filter.rel_volume = { $gte: 1 }
      if (rv === 'over1_5') filter.rel_volume = { $gte: 1.5 }
      if (rv === 'over2') filter.rel_volume = { $gte: 2 }
      if (rv === 'over3') filter.rel_volume = { $gte: 3 }
    }
    if (req.query.rsi) {
      const rsi = String(req.query.rsi)
      if (rsi === 'oversold') filter.rsi = { $lt: 30 }
      if (rsi === 'overbought') filter.rsi = { $gt: 70 }
      if (rsi === 'neutral') filter.rsi = { $gte: 30, $lte: 70 }
    }
    if (signal === 'social_bullish') filter.social_sentiment = { $gte: 0.3 }
    if (signal === 'social_bearish') filter.social_sentiment = { $lte: -0.3 }
    if (signal === 'unusual_volume') filter.volume = { $gte: 30000000 }
    if (signal === 'top_gainers') filter.change_pct = { $gt: 0 }
    if (signal === 'top_losers') filter.change_pct = { $lt: 0 }

    const shadowPredictedFallback = view === 'predicted_increases' && !exactTickerSearch
    if (shadowPredictedFallback && !filter.$or) {
      filter.$or = [
        { change_pct: { $gt: 0 } },
        { rel_volume: { $gte: 1 } },
        { news_article_count: { $gt: 0 } },
        { message_count: { $gt: 0 } },
      ]
    }
    if (view === 'high_conviction_next_day' && !exactTickerSearch) {
      filter.change_pct = { $gt: 0 }
      filter.rel_volume = { $gte: Math.max(1, Number(req.query.minScreenerRelVolume || HIGH_CONVICTION_MIN_REL_VOLUME || 1)) }
      delete filter.$or
    }
    const dbOrderBy = isPredictionView && ['ticker', 'high_conviction_rank', 'final_prediction_score', 'evidence_score', 'fallback_confidence'].includes(String(orderBy))
      ? 'rel_volume'
      : orderBy
    const dbOrderDir = isPredictionView && dbOrderBy === 'rel_volume' ? 'desc' : orderDir
    const sort = { [dbOrderBy]: dbOrderDir === 'asc' ? 1 : -1 }
    const requestedLimit = Math.max(1, Math.min(5000, Number(limit || 3000)))
    const queryLimit = isPredictionView
      ? Math.max(Math.min(view === 'high_conviction_next_day' ? 5 : 1000, requestedLimit), view === 'predicted_increases' ? 180 : 5)
      : search || Object.keys(req.query).length > 6
        ? 5000
        : requestedLimit

    // Read next-session calibrator status early so post-enrichment filters
    // can use it to decide whether to use fallback candidates.
    let nextSessionModelDoc = null
    try {
      nextSessionModelDoc = mongoose.connection.db
        ? await mongoose.connection.db.collection('next_session_prediction_models').findOne({ _id: 'next_session_outcome_calibrator_v1' }).catch(() => null)
        : null
      req.query.model_live = nextSessionModelDoc && nextSessionModelDoc.live_enabled ? 'true' : 'false'
    } catch (e) {
      req.query.model_live = 'false'
    }

    // If the calibrator is not live, enable fallback for high-conviction view by default
    if (view === 'high_conviction_next_day' && String(req.query.model_live || '') !== 'true' && req.query.includeFallback == null) {
      req.query.includeFallback = 'true'
    }

    // When calibrator is shadow-only, default the predicted_increases view to
    // a screener-first (non-actionable) listing so the actionable gate doesn't
    // filter out all fallback candidates. The UI can still request actionable.
    if (view === 'predicted_increases' && String(req.query.model_live || '') !== 'true') {
      if (req.query.actionable == null) {
        req.query.actionable = 'false'
      }
      if (req.query.include_decision_candidates == null) {
        req.query.include_decision_candidates = 'true'
      }
      if (req.query.includeFallback == null) {
        req.query.includeFallback = 'true'
      }
    }

    // Relax decision-candidate minimum score slightly in fallback mode so
    // promising Decision Map candidates aren't excluded by the 65 default.
    if (view === 'predicted_increases' && String(req.query.model_live || '') !== 'true' && req.query.min_decision_score == null) {
      req.query.min_decision_score = String(Math.max(40, Number(process.env.FALLBACK_MIN_DECISION_SCORE || 40)))
    }

    if (view === 'high_conviction_next_day' && !search && mongoose.connection.db) {
      const fastStarted = Date.now()
      const maxPicks = Math.max(1, Math.min(10, Number(req.query.maxPicks || 5)))
      const minConfidence = Number(req.query.minConfidence || 0.45)
      const minFinalScore = Number(req.query.minFinalScore || 78)
      const minPredictedReturn = Number(req.query.minPredictedReturn || 1.50)
      const minScreenerRelVolume = Math.max(0, Number(req.query.minScreenerRelVolume || HIGH_CONVICTION_MIN_REL_VOLUME || 1))
      const minScreenerAbsChange = Math.max(0, Number(req.query.minScreenerAbsChange || HIGH_CONVICTION_MIN_ABS_CHANGE || 0.5))
      const snapshot = await mongoose.connection.db.collection('finviz_momentum_snapshots')
        .findOne({}, { sort: { snapshot_sec: -1 }, projection: { snapshot_sec: 1, rows: 1 } })
        .catch(() => null)
      const snapshotRows = Array.isArray(snapshot?.rows) ? snapshot.rows : []
      let candidateTickers = snapshotRows
        .filter(row => Number(row.change_pct || 0) > 0 && Number(row.rel_volume || 0) >= minScreenerRelVolume && Math.abs(Number(row.change_pct || 0)) >= minScreenerAbsChange)
        .sort((a, b) => {
          const aSqueezeShape = Number(a.rel_volume || 0) * Math.max(1, Number(a.change_pct || 0))
          const bSqueezeShape = Number(b.rel_volume || 0) * Math.max(1, Number(b.change_pct || 0))
          return bSqueezeShape - aSqueezeShape
        })
        .map(row => String(row.ticker || '').toUpperCase())
        .filter(Boolean)
      candidateTickers = Array.from(new Set(candidateTickers)).slice(0, Math.max(20, maxPicks * 6))

      if (!candidateTickers.length) {
        const fallbackDocs = await Screener.find({
          exchange: { $in: Array.from(US_EXCHANGES) },
          ticker: { $not: /\./ },
          price: { $ne: null },
          change_pct: { $gt: 0 },
          rel_volume: { $gte: minScreenerRelVolume },
        }).sort({ rel_volume: -1 }).limit(Math.max(20, maxPicks * 6)).lean()
        candidateTickers = fallbackDocs.map(row => String(row.ticker || '').toUpperCase()).filter(Boolean)
      }

      let rows = candidateTickers.length
        ? await Screener.find({ ticker: { $in: candidateTickers } }).lean()
        : []
      const orderMap = new Map(candidateTickers.map((ticker, idx) => [ticker, idx]))
      let data = rows
        .map(normalizeScreenerRow)
        .filter(isCleanListedUsRow)
        .sort((a, b) => (orderMap.get(a.ticker) ?? 9999) - (orderMap.get(b.ticker) ?? 9999))

      if (data.length) {
        const tickers = data.map(row => row.ticker)
        const [articleMap, socialMap, densityMap, predictionMap, catalystMap, aiMap, momentumMap, correlationMap] = await Promise.all([
          loadArticleStatsForTickers(mongoose.connection.db, tickers, Number(days || 3), { predictionContext }),
          loadAdaptiveSocialStatsForRows(mongoose.connection.db, data, windowOverride),
          loadMessageDensityTrendsForTickers(mongoose.connection.db, tickers),
          loadLatestPredictionsForTickers(mongoose.connection.db, tickers, horizon, { predictionContext }),
          loadCatalystsForTickers(mongoose.connection.db, data, Number(days || 3)),
          loadAiEvidenceForTickers(mongoose.connection.db, tickers, Number(days || 3), { predictionContext }),
          loadMomentumContextForTickers(mongoose.connection.db, tickers),
          loadCorrelationContextForTickers(mongoose.connection.db, tickers),
        ])
        data = data
          .map(row => enrichScreenerRow(row, articleMap.get(row.ticker), socialMap.get(row.ticker), windowOverride))
          .map(row => attachPredictionAndCatalyst(row, predictionMap, catalystMap, horizon))
          .map(row => attachPredictionContext(row, aiMap, momentumMap, correlationMap))
          .map(row => attachProfessorFeedbackSignals(row, densityMap.get(row.ticker)))
          .map(row => {
            const da = dashboardAssessment(row, predictionContext)
            const assessedRow = {
              ...row,
              dashboard_assessment: da,
              final_prediction_score: da.finalScore,
              stored_predicted_return: row.predicted_return ?? null,
              final_predicted_percent: da.nextDayPrediction?.final_predicted_percent ?? null,
              predicted_return: da.nextDayPrediction?.final_predicted_percent ?? row.predicted_return ?? null,
              prediction_confidence: Math.max(Number(row.prediction_confidence || 0), Number(da.nextDayPrediction?.confidence || 0)),
              prediction_debug: da.predictionDebug,
              prediction_explanation: da.predictionDebug?.final_explanation || null,
              signal_quality: da.signalQuality,
              risk_flags: da.riskFlags,
              score_breakdown: da.scoreBreakdown,
            }
            const highConvictionGuard = highConvictionGuardDetails(assessedRow, { minFinalScore, minConfidence, minPredictedReturn })
            return {
              ...assessedRow,
              ...highConvictionPublicFields(highConvictionGuard),
              high_conviction: highConvictionGuard.pass,
              high_conviction_guard: highConvictionGuard,
              model_mode: req.query.model_live === 'true' ? 'calibrator_live' : 'calibrator_shadow_fallback',
            }
          })
      }

      data.sort((a, b) => Number(b.final_prediction_score || 0) - Number(a.final_prediction_score || 0))
      const strictRows = data.filter(row => row.high_conviction)
      const fallbackRows = strictRows.length ? strictRows : data.filter(row => {
        const debug = row.prediction_debug || {}
        const professorEvidence = Boolean(
          (debug.short_squeeze_available && Number(debug.short_squeeze_score || 0) >= 55) ||
          (debug.structured_news_available && Number(debug.structured_news_score || 0) >= 0.35) ||
          (debug.message_density_rising && Number(debug.message_density_score || 0) >= 45)
        )
        const severe = new Set(['NON_ACTIONABLE_PRIVATE_EXPOSURE', 'CATALYST_TICKER_MISMATCH', 'NEGATIVE_PRIMARY_CATALYST'])
        if ((row.risk_flags || []).some(flag => severe.has(flag))) return false
        return professorEvidence && Number(row.final_prediction_score || 0) >= 50 && Number(row.predicted_return || 0) >= minPredictedReturn
      })
      data = fallbackRows.slice(0, maxPicks).map((row, idx) => ({
        ...row,
        high_conviction_rank: idx + 1,
        professor_sendable: Boolean(row.high_conviction),
        high_conviction_fallback: !row.high_conviction,
        signal_quality: !row.high_conviction && row.signal_quality === 'insufficient_evidence' ? 'speculative_fallback' : row.signal_quality,
      }))

      const totalSocialMessages = data.reduce((sum, row) => sum + Number(row.message_count || 0), 0)
      return res.json({
        ok: true,
        tickers: data,
        rows: data,
        count: data.length,
        view,
        filters_applied: {
          search,
          exact_ticker_search: exactTickerSearch || null,
          horizon,
          signal: signal || null,
        },
        prediction_session_context: predictionContext,
        next_session_model: publicNextSessionModelStatus(nextSessionModelDoc),
        prediction_note: 'Fast high-conviction path: latest active momentum snapshot first, then full enrichment for only top active candidates. Strict picks are sendable; fallback rows are labeled speculative.',
        diagnostics: {
          backend_count: data.length,
          backend_database_rows: rows.length,
          backend_clean_rows: rows.length,
          backend_enriched_rows: rows.length,
          backend_post_filter_rows: fallbackRows.length,
          query_limit: candidateTickers.length,
          requested_limit: requestedLimit,
          model_mode: nextSessionModelDoc?.live_enabled ? 'calibrator_live' : 'calibrator_shadow_fallback',
          high_conviction_fast_path: true,
          elapsed_ms: Date.now() - fastStarted,
          snapshot_sec: snapshot?.snapshot_sec || null,
        },
        summary: {
          priced: data.filter(row => row.price != null).length,
          gainers: data.filter(row => Number(row.change_pct || 0) > 0).length,
          active_social: data.filter(row => Number(row.message_count || 0) > 0).length,
          total_social_messages: totalSocialMessages,
        },
      })
    }

    if (view === 'high_conviction_next_day' && !search) {
      const predictionTickers = await loadPredictionTickers(mongoose.connection.db, search, exactTickerSearch)
      // Only restrict the DB query to stored prediction tickers when the
      // next-session calibrator is live. When it's shadow-only we want a
      // screener-first fallback universe instead of an empty result.
      if (predictionTickers && String(req.query.model_live || '') === 'true') {
        filter.ticker = { $in: Array.from(predictionTickers) }
      }
    }

    const fastCompactProjection = fastCompactScreener
      ? {
        ticker: 1,
        company: 1,
        exchange: 1,
        sector: 1,
        industry: 1,
        country: 1,
        price: 1,
        change_pct: 1,
        change_percent: 1,
        volume: 1,
        avg_volume: 1,
        rel_volume: 1,
        relative_volume: 1,
        market_cap: 1,
        market_cap_tier: 1,
        finviz_market_cap_tier: 1,
        structured_sentiment: 1,
        news_sentiment: 1,
        social_sentiment: 1,
        social_message_sentiment: 1,
        social_message_density: 1,
        stocktwits_message_sentiment: 1,
        stocktwits_message_density: 1,
        stocktwits_message_count: 1,
        message_count: 1,
        news_article_count: 1,
        bullish_count: 1,
        bearish_count: 1,
        neutral_count: 1,
        sources: 1,
        rsi: 1,
        sma20: 1,
        sma50: 1,
        sma200: 1,
        atr: 1,
        gap: 1,
        perf_week: 1,
        perf_month: 1,
        perf_quarter: 1,
        perf_half: 1,
        perf_year: 1,
        perf_ytd: 1,
        beta: 1,
        pe_ratio: 1,
        forward_pe: 1,
        ps_ratio: 1,
        pb_ratio: 1,
        dividend_yield: 1,
        analyst: 1,
        target_price: 1,
        inst_own: 1,
        insider_own: 1,
        float_short: 1,
        earnings_date: 1,
        quote_updated_at: 1,
        quote_status: 1,
      }
      : null
    const runScreenerQuery = (useHint = true) => {
      const query = Screener.find(filter, fastCompactProjection || undefined)
        .sort(sort)
        .limit(queryLimit)
        .lean()
      return useHint ? query.hint({ exchange: 1, price: 1, ticker: 1 }) : query
    }

    let rows
    const shouldUseScreenerHint = !isPredictionView
    try {
      rows = await runScreenerQuery(shouldUseScreenerHint)
    } catch (err) {
      if (!String(err?.message || '').includes('hint provided does not correspond to an existing index')) {
        throw err
      }
      rows = await runScreenerQuery(false)
    }

    let data = rows
      .map(normalizeScreenerRow)
      .filter(isCleanListedUsRow)
    const screenerDiagnosticCounts = {
      database_rows: rows.length,
      clean_rows: data.length,
      enriched_rows: 0,
      post_filter_rows: 0,
      final_rows: 0,
    }

    if (fastCompactScreener) {
      data = data.map(row => ({
        ...row,
        rolling_window_minutes: Number(windowOverride || row.rolling_window_minutes || 30),
        cache_status: 'fast_compact_screener',
      }))
    } else if (mongoose.connection.db && data.length) {
      const tickers = data.map(row => row.ticker)
      const [articleMap, socialMap, densityMap, predictionMap, catalystMap, aiMap, momentumMap, correlationMap] = await Promise.all([
        loadArticleStatsForTickers(mongoose.connection.db, tickers, Number(days || 3), { predictionContext }),
        loadAdaptiveSocialStatsForRows(mongoose.connection.db, data, windowOverride),
        loadMessageDensityTrendsForTickers(mongoose.connection.db, tickers),
        loadLatestPredictionsForTickers(mongoose.connection.db, tickers, horizon, { predictionContext }),
        loadCatalystsForTickers(mongoose.connection.db, data, Number(days || 3)),
        loadAiEvidenceForTickers(mongoose.connection.db, tickers, Number(days || 3), { predictionContext }),
        loadMomentumContextForTickers(mongoose.connection.db, tickers),
        loadCorrelationContextForTickers(mongoose.connection.db, tickers),
      ])
      data = data
        .map(row => enrichScreenerRow(row, articleMap.get(row.ticker), socialMap.get(row.ticker), windowOverride))
        .map(row => attachPredictionAndCatalyst(row, predictionMap, catalystMap, horizon))
        .map(row => attachPredictionContext(row, aiMap, momentumMap, correlationMap))
        .map(row => attachProfessorFeedbackSignals(row, densityMap.get(row.ticker)))
        .map(row => {
          const da = dashboardAssessment(row, predictionContext)
          const assessedRow = {
            ...row,
            dashboard_assessment: da,
            final_prediction_score: da.finalScore,
            stored_predicted_return: row.predicted_return ?? null,
            final_predicted_percent: da.nextDayPrediction?.final_predicted_percent ?? null,
            predicted_return: da.nextDayPrediction?.final_predicted_percent ?? row.predicted_return ?? null,
            prediction_confidence: Math.max(Number(row.prediction_confidence || 0), Number(da.nextDayPrediction?.confidence || 0)),
            prediction_debug: da.predictionDebug,
            prediction_explanation: da.predictionDebug?.final_explanation || null,
            signal_quality: da.signalQuality,
            risk_flags: da.riskFlags,
            score_breakdown: da.scoreBreakdown,
          }
          const highConvictionGuard = highConvictionGuardDetails(assessedRow)
          return {
            ...assessedRow,
            ...highConvictionPublicFields(highConvictionGuard),
            high_conviction: highConvictionGuard.pass,
            high_conviction_guard: highConvictionGuard,
          }
        })
    }
    screenerDiagnosticCounts.enriched_rows = fastCompactScreener ? 0 : data.length


    function decorateFallbackMetadata(row = {}, query = {}, context = null) {
      const modelLive = String(query.model_live || '') === 'true'
      const finalScore = Number(row.final_prediction_score || row.dashboard_assessment?.finalScore || 0)
      const evidenceScore = Math.round(clamp(finalScore, 0, 100))
      const storedConfidence = row.prediction?.confidence ?? row.prediction_confidence
      const predictedReturn = Number(row.predicted_return ?? row.prediction?.predictedReturn)
      const storedDirection = String(row.prediction_direction || row.prediction?.predictedDirection || '').toLowerCase()
      const inferredDir = storedDirection === 'up' || (Number.isFinite(predictedReturn) && predictedReturn > 0)
        ? 'up'
        : Number(row.change_pct || 0) >= 0 ? 'up' : 'watch'
      const fallbackConfidence = Number(clamp(Number.isFinite(Number(storedConfidence)) ? Number(storedConfidence) : ((evidenceScore - 30) / 70), 0.05, 0.95).toFixed(3))
      const reasonParts = []
      if (row.rel_volume && Number(row.rel_volume) > 1) reasonParts.push(`rel_volume:${Number(row.rel_volume).toFixed(2)}`)
      if (row.change_pct) reasonParts.push(`change_pct:${Number(row.change_pct).toFixed(2)}%`)
      if ((row.catalysts || []).length) reasonParts.push('structured_catalyst')
      if (Number(row.ai_score || 0) > 55) reasonParts.push('ai_support')
      if (Number(row.momentum_score || 0) >= 40) reasonParts.push('momentum_confirm')
      if (Number(row.correlation_score || 0) > 0) reasonParts.push('correlation_support')
      const reason_included = reasonParts.length ? `High evidence: ${reasonParts.join(', ')}` : 'Screener-first evidence'
      const catalyst = row.main_catalyst || (row.catalysts || [])[0] || null
      const snapshotAt = row.quote_updated_at || row.latest_publish || row.prediction_generated_at || null
      const generatedAt = row.prediction?.generatedAt || row.prediction_generated_at || new Date().toISOString()
      const highConvictionGuard = highConvictionGuardDetails(row)

      const base = {
        session: row.prediction_session || context?.session || null,
        change_percent: row.change_pct ?? null,
        relative_volume: row.rel_volume ?? null,
        model_mode: modelLive ? 'calibrator_live' : 'calibrator_shadow_fallback',
        fallback_prediction_direction: inferredDir,
        fallback_confidence: fallbackConfidence,
        evidence_score: evidenceScore,
        final_predicted_percent: row.final_predicted_percent ?? row.predicted_return ?? null,
        prediction_debug: row.prediction_debug || row.dashboard_assessment?.predictionDebug || null,
        prediction_explanation: row.prediction_explanation || row.dashboard_assessment?.predictionDebug?.final_explanation || null,
        high_conviction_fallback: Boolean(row.high_conviction || highConvictionGuard.pass),
        high_conviction_guard: row.high_conviction_guard || highConvictionGuard,
        ...highConvictionPublicFields(row.high_conviction_guard || highConvictionGuard),
        reason_included: row.prediction_explanation || reason_included,
        catalyst_summary: catalyst?.title || catalyst?.source || null,
        generated_at: generatedAt,
        screener_snapshot_at: snapshotAt,
        cache_status: row.cache_status || 'live_mongo_enriched',
      }
      // Only add fallback metadata when model is not live and no true prediction exists
      if (!modelLive && !row.prediction) {
        return { ...row, ...base, prediction_status: 'fallback_candidate' }
      }
      // If model is live or there is a prediction, still annotate model_mode
      return { ...row, ...base }
    }

    // Annotate fallback metadata for UI clarity before filtering.
    data = data.map(row => decorateFallbackMetadata(row, req.query, predictionContext))

    data = applyPostEnrichmentFilters(data, req.query)
    screenerDiagnosticCounts.post_filter_rows = data.length

    if (signal === 'bullish_news') data = data.filter(row => Number(row.structured_sentiment || 0) >= 0.2)
    if (signal === 'bearish_news') data = data.filter(row => Number(row.structured_sentiment || 0) <= -0.2)
    if (signal === 'oversold') data = data.filter(row => Number(row.rsi || 50) < 30)
    if (signal === 'overbought') data = data.filter(row => Number(row.rsi || 50) > 70)
    if (req.query.social_sentiment) {
      const ss = String(req.query.social_sentiment)
      data = data.filter(row => ss === 'bullish' ? Number(row.social_sentiment || 0) >= 0.2 : ss === 'bearish' ? Number(row.social_sentiment || 0) <= -0.2 : Math.abs(Number(row.social_sentiment || 0)) < 0.2)
    }
    if (req.query.news_sentiment) {
      const ns = String(req.query.news_sentiment)
      data = data.filter(row => ns === 'bullish' ? Number(row.structured_sentiment || 0) >= 0.2 : ns === 'bearish' ? Number(row.structured_sentiment || 0) <= -0.2 : Math.abs(Number(row.structured_sentiment || 0)) < 0.2)
    }
    if (req.query.stocktwits_sentiment) {
      const ss = String(req.query.stocktwits_sentiment)
      data = data.filter(row => ss === 'bullish' ? Number(row.stocktwits_message_sentiment || 0) >= 0.2 : ss === 'bearish' ? Number(row.stocktwits_message_sentiment || 0) <= -0.2 : Math.abs(Number(row.stocktwits_message_sentiment || 0)) < 0.2)
    }
    if (req.query.min_posts) data = data.filter(row => Number(row.message_count || 0) >= Number(req.query.min_posts))
    if (req.query.stocktwits_density) {
      const d = String(req.query.stocktwits_density)
      const threshold = d === 'over0_05' ? 0.05 : d === 'over0_1' ? 0.1 : d === 'over0_5' ? 0.5 : d === 'over1' ? 1 : 0
      data = data.filter(row => Number(row.stocktwits_message_density || 0) >= threshold)
    }

    if (view === 'predicted_increases' || view === 'high_conviction_next_day') {
      if (view === 'predicted_increases') {
        data = data.map(decorateDecisionMapPredictionCandidate)
      }
      // Sort by final_prediction_score descending for prediction-based views
      data.sort((a, b) => {
        const sa = Number(a.final_prediction_score ?? -Infinity)
        const sb = Number(b.final_prediction_score ?? -Infinity)
        if (Number.isFinite(sa) && Number.isFinite(sb) && sa !== sb) return sb - sa
        return Number(b.prediction_confidence || 0) - Number(a.prediction_confidence || 0)
      })
      // If high_conviction_next_day, apply strict gates and cap at 5
      if (view === 'high_conviction_next_day') {
        const maxPicks = Math.max(1, Math.min(10, Number(req.query.maxPicks || 5)))
        const minConfidence = Number(req.query.minConfidence || 0.45)
        const minFinalScore = Number(req.query.minFinalScore || 78)
        const minPredictedReturn = Number(req.query.minPredictedReturn || 1.50)
        const minScreenerRelVolume = Math.max(0, Number(req.query.minScreenerRelVolume || HIGH_CONVICTION_MIN_REL_VOLUME))
        const minScreenerAbsChange = Math.max(0, Number(req.query.minScreenerAbsChange || HIGH_CONVICTION_MIN_ABS_CHANGE))
        const requireTrue1d = req.query.requireTrue1d !== 'false'
        const requireCatalyst = req.query.requireCatalyst !== 'false'
        const strictRows = data.filter(row => {
          const guard = highConvictionGuardDetails(row, { minFinalScore, minConfidence, minPredictedReturn })
          if (!guard.pass) return false
          const professorEvidence = Boolean(guard.checked?.professor_evidence)
          const squeezeEvidence = Boolean(row.squeeze_evidence_supported || (row.prediction_debug?.short_squeeze_available && Number(row.prediction_debug?.short_squeeze_score || 0) >= 55))
          const score = Number(row.final_prediction_score || 0)
          const conf = Number(row.prediction_confidence ?? (row.prediction?.confidence ?? 0))
          if (score < minFinalScore) return false
          if (conf < minConfidence) return false
          if (requireCatalyst && !(row.catalysts || []).length && !professorEvidence) return false
          if (requireTrue1d && row.prediction?.is_next_day_proxy) return false
          if (Number(row.rel_volume || 0) < minScreenerRelVolume) return false
          if (Math.abs(Number(row.change_pct || 0)) < minScreenerAbsChange) return false
          if (Number(row.change_pct || 0) > 20 && !squeezeEvidence) return false // already extended unless squeeze-evidence-backed
          const riskFlags = row.risk_flags || []
          if (riskFlags.includes('RECENT_EXTREME_MOVE_ALREADY_OCCURRED')) return false
          if (riskFlags.includes('RECENT_LARGE_MOVE')) return false
          if (riskFlags.includes('EXTREME_VOLATILITY') && !squeezeEvidence) return false
          if (riskFlags.includes('MEGA_CAP_LOW_TOP_MOVER_ODDS')) return false
          if (riskFlags.includes('LARGE_CAP_WEAK_ACTIVITY')) return false
          if (riskFlags.includes('NO_TRUE_1D_MODEL')) return false
          if (riskFlags.includes('STALE_SESSION_PREDICTION')) return false
          if (riskFlags.includes('PROXY_ONLY') && requireTrue1d) return false
          if (riskFlags.includes('NO_CLEAR_CATALYST') && !professorEvidence) return false
          if (riskFlags.includes('TECHNICALS_GATED_NO_POSITIVE_DRIVER')) return false
          if (riskFlags.includes('NO_MOMENTUM_HISTORY') && !professorEvidence) return false
          if (riskFlags.includes('NO_CORRELATION_HISTORY') && !professorEvidence) return false
          if (riskFlags.includes('CATALYST_TICKER_MISMATCH')) return false
          if (riskFlags.includes('NON_ACTIONABLE_PRIVATE_EXPOSURE')) return false
          if (riskFlags.includes('AI_DISAGREES')) return false
          if (riskFlags.includes('WEAK_MOMENTUM_CONFIRMATION')) return false
          if (riskFlags.includes('NEGATIVE_CORRELATION_HISTORY')) return false
          if (riskFlags.includes('MODERATE_NEGATIVE_CORRELATION')) return false
          if (!row.dashboard_assessment?.components?.positiveCatalystGate) return false
          if (req.query.require_catalyst_alignment !== 'false' && (row.catalysts || []).length && !companyCatalystAligned(row) && !professorEvidence) return false
          if (Number(row.predicted_return || 0) < minPredictedReturn) return false
          return true
        })

        if (strictRows.length > 0) {
          data = strictRows.map((row, idx) => ({ ...row, high_conviction_rank: idx + 1, professor_sendable: true }))
          data = data.slice(0, maxPicks)
        } else if (req.query.includeFallback === 'true') {
          const fallbackRows = data.filter(row => {
            const predictedReturn = row.predicted_return ?? row.prediction?.predictedReturn
            if (!Number.isFinite(Number(predictedReturn))) return false
            if (Number(row.rel_volume || 0) < minScreenerRelVolume && Number(row.prediction_debug?.volume_score || 0) < 0.15) return false
            if (Math.abs(Number(row.change_pct || 0)) < minScreenerAbsChange && Number(row.prediction_debug?.momentum_score || 0) < 0.25) return false
            const relaxedGuard = highConvictionGuardDetails(row, { minFinalScore: Math.max(62, minFinalScore - 10), minConfidence: Math.max(0.3, minConfidence - 0.08), minPredictedReturn })
            return relaxedGuard.pass || Boolean(relaxedGuard.checked?.professor_evidence && Number(row.final_prediction_score || 0) >= Math.max(62, minFinalScore - 12))
          })
          const selectedFallbackRows = fallbackRows.length ? fallbackRows : data.filter(row => {
            const debug = row.prediction_debug || {}
            const professorEvidence = Boolean(
              (debug.short_squeeze_available && Number(debug.short_squeeze_score || 0) >= 55) ||
              (debug.structured_news_available && Number(debug.structured_news_score || 0) >= 0.35) ||
              (debug.message_density_rising && Number(debug.message_density_score || 0) >= 45)
            )
            const severe = new Set(['NON_ACTIONABLE_PRIVATE_EXPOSURE', 'CATALYST_TICKER_MISMATCH', 'NEGATIVE_PRIMARY_CATALYST'])
            if ((row.risk_flags || []).some(flag => severe.has(flag))) return false
            return professorEvidence && Number(row.final_prediction_score || 0) >= 50 && Number(row.predicted_return || 0) >= minPredictedReturn
          })
          data = selectedFallbackRows.map((row, idx) => {
            const fallbackGuard = highConvictionGuardDetails(row, { minFinalScore: Math.max(62, minFinalScore - 10), minConfidence: Math.max(0.3, minConfidence - 0.08), minPredictedReturn })
            return {
              ...row,
              ...highConvictionPublicFields(fallbackGuard),
              high_conviction_rank: idx + 1,
              professor_sendable: false,
              high_conviction_fallback: true,
              signal_quality: row.signal_quality === 'insufficient_evidence' ? 'speculative_fallback' : row.signal_quality,
              high_conviction_guard: fallbackGuard,
            }
          })
          data = data.slice(0, maxPicks)
        } else {
          data = []
        }
      } else if (req.query.actionable !== 'false') {
        const maxPicks = Math.max(1, Math.min(50, Number(req.query.maxPicks || 12)))
        data = data.map((row, idx) => ({ ...row, actionable_rank: idx + 1 }))
        data = data.slice(0, maxPicks)
      }
    } else if (view === 'news_catalysts') {
      data.sort((a, b) => Number(b.main_catalyst?.publishedAt || 0) - Number(a.main_catalyst?.publishedAt || 0))
    }

    data = data.slice(0, requestedLimit)
    screenerDiagnosticCounts.final_rows = data.length

    const activeSocialRows = data.filter(row => Number(row.message_count || 0) > 0)
    const totalSocialMessages = data.reduce((sum, row) => sum + Number(row.message_count || 0), 0)
    const totalStocktwitsMessages = data.reduce((sum, row) => sum + Number(row.stocktwits_message_count || 0), 0)
    const totalSocialDensity = data.reduce((sum, row) => sum + Number(row.message_count || 0) / Math.max(1, Number(row.rolling_window_minutes || 30)), 0)
    const proxyPredictionCount = data.filter(row => row.prediction?.is_next_day_proxy).length
    const trueRequestedPredictionCount = data.filter(row => row.prediction && row.prediction.horizon_supported).length
    const nextSessionModel = isPredictionView
      ? await mongoose.connection.db.collection('next_session_prediction_models').findOne({ _id: 'next_session_outcome_calibrator_v1' }).catch(() => null)
      : null
    const nextSessionModelStatus = publicNextSessionModelStatus(nextSessionModel)
    const modelReadinessPrefix = nextSessionModelStatus
      ? nextSessionModelStatus.live_enabled
        ? 'Next-session calibrator is live-validated. '
        : `Next-session calibrator is ${nextSessionModelStatus.status} (${nextSessionModelStatus.validation_reason || 'not live-validated'}). `
      : ''

    res.json({
      ok: true,
      // `rows` is retained for legacy clients. The current dashboard requests
      // compact mode so the same large array is not serialized twice.
      ...(compact ? {} : { rows: data }),
      tickers: data,
      count: data.length,
      view,
      filters_applied: {
        search,
        exact_ticker_search: exactTickerSearch || null,
        horizon,
        source: req.query.source || null,
        catalyst: req.query.catalyst || req.query.category || null,
        signal: signal || null,
      },
      prediction_session_context: predictionContext,
      next_session_model: nextSessionModelStatus,
      prediction_note: view === 'high_conviction_next_day'
        ? `${modelReadinessPrefix}Professor-facing shortlist: true requested-horizon prediction, positive catalyst gate, minimum score/confidence/return, and major red-flag exclusions.`
        : view === 'predicted_increases'
          ? proxyPredictionCount
            ? `${modelReadinessPrefix}Some rows are shorter-horizon proxy signals because no true 1d model field exists on those rows. Proxy rows should not be described as confirmed next-day model outputs.`
            : `${modelReadinessPrefix}Calibrator shadow fallback mode — showing screener-first actionable candidates. Stored prediction_signals are used when available; otherwise Decision Map candidates can qualify from relative-volume, price, catalyst, AI, momentum, or correlation evidence. Exact ticker search still audits rows that fail the default gates.`
          : undefined,
      prediction_gate_defaults: view === 'predicted_increases'
        ? {
          actionable: req.query.actionable !== 'false',
          min_model_score: Number(req.query.min_actionable_score || req.query.minFinalScore || 65),
          min_decision_candidate_score: Number(req.query.min_decision_score || req.query.minDecisionScore || 65),
          min_confidence: Number(req.query.min_actionable_confidence || req.query.minConfidence || 0.35),
          min_predicted_return: Number(req.query.min_actionable_return || req.query.minPredictedReturn || 1.50),
          min_screener_relative_volume: Number(req.query.minScreenerRelVolume || req.query.min_relative_volume || 1),
          min_screener_abs_price_change: Number(req.query.minScreenerAbsChange || req.query.min_abs_change || 0.5),
          market_cap_aware_activity: true,
          include_decision_candidates: req.query.include_decision_candidates !== 'false',
          top_mover_excludes: ['MEGA_CAP_LOW_TOP_MOVER_ODDS', 'LARGE_CAP_WEAK_ACTIVITY', 'RECENT_EXTREME_MOVE_ALREADY_OCCURRED', 'EXTREME_VOLATILITY', 'WEAK_MOMENTUM_CONFIRMATION', 'NEGATIVE_CORRELATION_HISTORY', 'MODERATE_NEGATIVE_CORRELATION', 'NEGATIVE_PRIMARY_CATALYST', 'SOCIAL_ONLY_SIGNAL'],
          max_picks: Number(req.query.maxPicks || 12),
          fallback_params_used: {
            actionable: req.query.actionable === 'false' ? false : true,
            include_decision_candidates: req.query.include_decision_candidates !== 'false',
            includeFallback: req.query.includeFallback === 'true',
            min_decision_score: Number(req.query.min_decision_score || req.query.minDecisionScore || 40),
          },
        }
        : view === 'high_conviction_next_day'
          ? {
            max_picks: Number(req.query.maxPicks || 5),
            min_final_score: Number(req.query.minFinalScore || 78),
            min_confidence: Number(req.query.minConfidence || 0.45),
            min_predicted_return: Number(req.query.minPredictedReturn || 1.50),
            min_screener_relative_volume: Number(req.query.minScreenerRelVolume || HIGH_CONVICTION_MIN_REL_VOLUME),
            min_screener_abs_price_change: Number(req.query.minScreenerAbsChange || HIGH_CONVICTION_MIN_ABS_CHANGE),
            require_true_1d: req.query.requireTrue1d !== 'false',
            require_catalyst: req.query.requireCatalyst !== 'false',
            include_fallback: req.query.includeFallback === 'true',
            excludes: [
              'NO_CLEAR_CATALYST',
              'TECHNICALS_GATED_NO_POSITIVE_DRIVER',
              'PROXY_ONLY',
              'NO_TRUE_1D_MODEL',
              'STALE_SESSION_PREDICTION',
              'RECENT_EXTREME_MOVE_ALREADY_OCCURRED',
              'RECENT_LARGE_MOVE',
              'EXTREME_VOLATILITY',
              'AI_DISAGREES',
              'WEAK_MOMENTUM_CONFIRMATION',
              'NEGATIVE_CORRELATION_HISTORY',
              'MODERATE_NEGATIVE_CORRELATION',
              'CATALYST_TICKER_MISMATCH',
              'NON_ACTIONABLE_PRIVATE_EXPOSURE',
            ],
          }
          : undefined,
      universe: 'NASDAQ / NYSE / AMEX listed stocks from numeric screeners',
      diagnostics: isPredictionView
        ? {
          backend_count: data.length,
          backend_database_rows: screenerDiagnosticCounts.database_rows,
          backend_clean_rows: screenerDiagnosticCounts.clean_rows,
          backend_enriched_rows: screenerDiagnosticCounts.enriched_rows,
          backend_post_filter_rows: screenerDiagnosticCounts.post_filter_rows,
          query_limit: queryLimit,
          requested_limit: requestedLimit,
          model_mode: nextSessionModelStatus?.live_enabled ? 'calibrator_live' : 'calibrator_shadow_fallback',
          fallback_params_used: {
            actionable: req.query.actionable === 'false' ? false : true,
            include_decision_candidates: req.query.include_decision_candidates !== 'false',
            includeFallback: req.query.includeFallback === 'true',
            min_decision_score: Number(req.query.min_decision_score || req.query.minDecisionScore || 40),
          },
          cache_status: data[0]?.cache_status || 'live_mongo_enriched',
          screener_snapshot_at: data[0]?.screener_snapshot_at || null,
        }
        : fastCompactScreener
          ? {
            backend_count: data.length,
            backend_database_rows: screenerDiagnosticCounts.database_rows,
            backend_clean_rows: screenerDiagnosticCounts.clean_rows,
            backend_enriched_rows: screenerDiagnosticCounts.enriched_rows,
            backend_post_filter_rows: screenerDiagnosticCounts.post_filter_rows,
            query_limit: queryLimit,
            requested_limit: requestedLimit,
            fast_compact_screener: true,
            skipped_prediction_evidence_join: true,
            cache_status: data[0]?.cache_status || 'fast_compact_screener',
          }
          : undefined,
      summary: {
        priced: data.filter(row => row.price != null).length,
        gainers: data.filter(row => Number(row.change_pct || 0) > 0).length,
        losers: data.filter(row => Number(row.change_pct || 0) < 0).length,
        unchanged: data.filter(row => Number(row.change_pct || 0) === 0).length,
        active_social: activeSocialRows.length,
        total_social_messages: totalSocialMessages,
        total_stocktwits_messages: totalStocktwitsMessages,
        avg_posts_per_active_social: activeSocialRows.length ? Number((totalSocialMessages / activeSocialRows.length).toFixed(2)) : 0,
        avg_social_density_per_ticker: data.length ? Number((totalSocialDensity / data.length).toFixed(3)) : 0,
        true_requested_predictions: trueRequestedPredictionCount,
        proxy_predictions: proxyPredictionCount,
      },
      exchanges: Array.from(US_EXCHANGES),
      rolling_windows: {
        selected: windowOverride || 'adaptive',
        nano_micro: 5,
        small: 15,
        mid: 30,
        large: 60,
        mega: 120,
      },
      excluded: ['OTC', 'crypto', 'unpriced/article-only rows', 'non-US exchanges'],
      max_abs_change_pct: MAX_SIGNAL_CHANGE_PCT,
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/screener/upsert  — upsert a single ticker
router.post('/upsert', async (req, res) => {
  try {
    const doc = await Screener.findOneAndUpdate(
      { ticker: req.body.ticker },
      { $set: { ...req.body, updated_at: new Date() } },
      { upsert: true, new: true }
    )
    res.json(doc)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
