import { Router } from 'express'
import mongoose from 'mongoose'
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const router = Router()

const US_EXCHANGES = new Set(['NASDAQ', 'NYSE', 'AMEX'])
const NON_STOCK_TICKERS = new Set([
  'BTC', 'ETH', 'LTC', 'DOGE', 'SOL', 'ADA', 'XRP', 'BNB', 'DOT', 'AVAX',
  'MATIC', 'SHIB', 'TRX', 'BCH', 'LINK', 'ATOM', 'UNI', 'ETC', 'FIL',
  'USD', 'USDT', 'USDC', 'SPOT',
])

const DEFAULT_THRESHOLDS = Object.freeze({
  minRelativeVolume: Number(process.env.DECISION_MAP_MIN_REL_VOLUME || 1),
  minAbsPriceChange: Number(process.env.DECISION_MAP_MIN_ABS_CHANGE || 0.5),
  positiveSentiment: Number(process.env.DECISION_MAP_POSITIVE_SENTIMENT || 0.12),
  negativeSentiment: Number(process.env.DECISION_MAP_NEGATIVE_SENTIMENT || -0.12),
  priceChange: Number(process.env.DECISION_MAP_PRICE_THRESHOLD || 0.5),
  minActivityScore: Number(process.env.DECISION_MAP_MIN_ACTIVITY_SCORE || 0),
  newsWindowHours: Number(process.env.DECISION_MAP_NEWS_WINDOW_HOURS || 24),
  socialWindowHours: Number(process.env.DECISION_MAP_SOCIAL_WINDOW_HOURS || 24),
  finvizStaleSeconds: Number(process.env.DECISION_MAP_FINVIZ_STALE_SECONDS || 45 * 60),
  maxAbsPriceChange: Number(process.env.DECISION_MAP_MAX_ABS_CHANGE || process.env.MAX_SIGNAL_CHANGE_PCT || 300),
})

const STRUCTURED_SOURCE_RE = /finviz|tradingview|pr newswire|business wire|access newswire|benzinga|sec|edgar|fda|globenewswire|dow jones|interactive brokers|td ameritrade|schwab/i
const SOCIAL_SOURCE_RE = /stocktwits|twitter|x\.com|reddit|bluesky|social/i
const MARKET_CAP_BUCKETS = new Set(['mega', 'large', 'mid', 'small', 'micro', 'nano'])
const DECISION_MAP_REDIS_TTL = Math.max(30, Number(process.env.DECISION_MAP_REDIS_TTL || 300))
const DECISION_MAP_PATH_TTL = Math.max(900, Number(process.env.DECISION_MAP_PATH_TTL || 6 * 60 * 60))
const DECISION_MAP_HISTORY_SECONDS = Math.max(DECISION_MAP_PATH_TTL, Number(process.env.DECISION_MAP_HISTORY_SECONDS || 14 * 60 * 60))
const DECISION_MAP_PATH_MAX = Math.max(12, Math.min(500, Number(process.env.DECISION_MAP_PATH_MAX || 180)))
const DECISION_MAP_PERSIST_MONGO = process.env.DECISION_MAP_PERSIST_MONGO !== 'false'
const DECISION_MAP_KAFKA_PUBLISH = process.env.DECISION_MAP_KAFKA_PUBLISH !== 'false'
const DECISION_MAP_POINT_INTERVAL_SECONDS = Math.max(15, Number(process.env.DECISION_MAP_POINT_INTERVAL_SECONDS || 60))
const DECISION_MAP_DEFAULT_PATH_POINTS = Math.max(12, Math.min(96, Number(process.env.DECISION_MAP_DEFAULT_PATH_POINTS || 60)))
const DECISION_MAP_MAX_PATH_POINTS = Math.max(DECISION_MAP_DEFAULT_PATH_POINTS, Math.min(180, Number(process.env.DECISION_MAP_MAX_PATH_POINTS || 96)))

function clamp(value, min, max) {
  const n = Number(value)
  if (!Number.isFinite(n)) return min
  return Math.max(min, Math.min(max, n))
}

function toNumber(value, fallback = null) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function toSec(value) {
  if (!value) return 0
  if (value instanceof Date) return Math.floor(value.getTime() / 1000)
  const n = Number(value)
  if (Number.isFinite(n) && n > 0) return n > 1_000_000_000_000 ? Math.floor(n / 1000) : Math.floor(n)
  const ms = Date.parse(String(value))
  return Number.isFinite(ms) ? Math.floor(ms / 1000) : 0
}

function redisFromReq(req) {
  const redis = req?.app?.locals?.redis
  const ready = typeof req?.app?.locals?.redisReady === 'function' ? req.app.locals.redisReady() : redis?.status === 'ready'
  return ready ? redis : null
}

function stableQuerySignature(query = {}) {
  const ignored = new Set(['fresh', '_', 't'])
  const normalized = {}
  for (const key of Object.keys(query).sort()) {
    if (ignored.has(key)) continue
    normalized[key] = String(query[key])
  }
  return Buffer.from(JSON.stringify(normalized)).toString('base64url').slice(0, 96) || 'default'
}

function quantizedNowSec() {
  const now = Math.floor(Date.now() / 1000)
  return Math.floor(now / DECISION_MAP_POINT_INTERVAL_SECONDS) * DECISION_MAP_POINT_INTERVAL_SECONDS
}

function pointJson(point = {}) {
  return JSON.stringify(point)
}

function parsePoint(raw) {
  if (!raw) return null
  try {
    const point = typeof raw === 'string' ? JSON.parse(raw) : raw
    return point && typeof point === 'object' ? point : null
  } catch (_) {
    return null
  }
}

function decisionMapPointForStorage(row = {}, snapshotSec = quantizedNowSec()) {
  const point = decisionPointFromValues({
    timestamp: snapshotSec,
    combinedSentiment: row.combinedSentiment,
    priceChangePct: row.priceChangePct,
    marketCapRelativeVolumeScore: row.marketCapRelativeVolumeScore,
    relativeVolume: row.relativeVolume,
    currentDollarVolume: row.currentDollarVolume,
    price: row.price,
    currentVolume: row.currentVolume,
    convictionScore: row.convictionScore,
  }, row)
  return {
    ...point,
    ticker: row.ticker,
    company: row.company || '',
    snapshotSec,
    timestamp: snapshotSec,
    generatedAt: new Date(snapshotSec * 1000).toISOString(),
    quadrant: row.quadrant || 'Neutral',
    pathDirection: row.path_direction || 'insufficient_history',
    pathColor: row.path_color || 'gray',
    activityScore: Number(row.activityScore || 0),
    convictionScore: Number(row.convictionScore || 0),
    relativeVolume: Number(row.relativeVolume || 0),
    currentDollarVolume: Number(row.currentDollarVolume || 0),
    liquidityScore: Number(row.liquidityScore || 0),
    liquidityStatus: row.liquidityStatus || '',
    liquidityDollarVolumeRatio: Number(row.liquidityDollarVolumeRatio || 0),
    marketCapBucket: row.marketCapBucket || '',
    catalystLabel: row.catalystLabel || '',
    riskFlags: Array.isArray(row.riskFlags) ? row.riskFlags.slice(0, 12) : [],
  }
}

function ageSeconds(sec) {
  const value = Number(sec || 0)
  if (!value) return null
  return Math.max(0, Math.floor(Date.now() / 1000) - value)
}

function normalizeMarketCap(raw, source = '') {
  const cap = Number(raw || 0)
  if (!Number.isFinite(cap) || cap <= 0) return null
  // FinViz exports commonly store market cap in millions. Example: 5984.29
  // means about $5.98B, not $5,984.
  if (/finviz/i.test(String(source || '')) && cap > 0 && cap < 10_000_000) return cap * 1_000_000
  return cap
}

function marketCapBucket(marketCap) {
  const cap = Number(marketCap || 0)
  if (cap >= 200e9) return 'Mega cap'
  if (cap >= 10e9) return 'Large cap'
  if (cap >= 2e9) return 'Mid cap'
  if (cap >= 300e6) return 'Small cap'
  if (cap >= 50e6) return 'Micro cap'
  if (cap > 0) return 'Nano cap'
  return 'Unknown cap'
}

function marketCapRelVolumeTarget(bucket) {
  const key = String(bucket || '').toLowerCase()
  if (key.includes('mega')) return 1.2
  if (key.includes('large')) return 1.5
  if (key.includes('mid')) return 1.8
  if (key.includes('small')) return 2.2
  if (key.includes('micro')) return 5
  if (key.includes('nano')) return 8
  return 2
}

function dollarVolumeTarget(bucket) {
  const key = String(bucket || '').toLowerCase()
  if (key.includes('mega')) return 30_000_000
  if (key.includes('large')) return 15_000_000
  if (key.includes('mid')) return 8_000_000
  if (key.includes('small')) return 3_000_000
  if (key.includes('micro')) return 1_000_000
  if (key.includes('nano')) return 500_000
  return 2_000_000
}

function capAdjustedRelVolumeScore(relativeVolume, bucket, dollarVolume = null) {
  const target = marketCapRelVolumeTarget(bucket)
  const relScore = clamp((Number(relativeVolume || 0) / target) * 62, 0, 100)
  const dollarTarget = dollarVolumeTarget(bucket)
  const dollarScore = clamp((Number(dollarVolume || 0) / dollarTarget) * 38, 0, 100)
  return clamp(relScore + dollarScore, 0, 100)
}

function decisionMapPathPointLimit(query = {}) {
  return Math.max(4, Math.min(DECISION_MAP_MAX_PATH_POINTS, Number(query.path_points || query.pathPoints || DECISION_MAP_DEFAULT_PATH_POINTS)))
}

function liquidityProfile(row = {}) {
  const currentDollarVolume = Number(row.currentDollarVolume || 0)
  const target = Math.max(1, Number(row.dollarVolumeTarget || dollarVolumeTarget(row.marketCapBucket)))
  const score = clamp((currentDollarVolume / target) * 100, 0, 100)
  const ratio = currentDollarVolume / target
  const status = ratio >= 1.2
    ? 'excellent'
    : ratio >= 0.8
      ? 'acceptable'
      : ratio >= 0.45
        ? 'thin'
        : 'poor'
  const risk = status === 'poor'
    ? 'POOR_LIQUIDITY'
    : status === 'thin'
      ? 'THIN_LIQUIDITY'
      : ''
  return {
    liquidityScore: Number(score.toFixed(1)),
    liquidityStatus: status,
    liquidityDollarVolume: Number(currentDollarVolume.toFixed(2)),
    liquidityTargetDollarVolume: Number(target.toFixed(2)),
    liquidityDollarVolumeRatio: Number(ratio.toFixed(3)),
    liquidityRiskFlag: risk,
  }
}

function normalizedMarketCapBucket(value = '') {
  const text = String(value || '').toLowerCase()
  for (const bucket of MARKET_CAP_BUCKETS) {
    if (text.includes(bucket)) return bucket
  }
  return ''
}

function relVolumeBucket(relativeVolume) {
  const rv = Number(relativeVolume || 0)
  if (rv >= 20) return 'extreme'
  if (rv >= 5) return 'high'
  if (rv >= 2) return 'medium'
  return 'low'
}

function sessionMetrics(doc = {}, requestedSession = 'auto') {
  const regular = {
    session: 'regular',
    price: toNumber(doc.price, null),
    changePct: toNumber(doc.change_pct ?? doc.change_percent, 0) || 0,
    volume: toNumber(doc.volume, 0) || 0,
  }
  const premarket = {
    session: 'premarket',
    price: toNumber(doc.premarket_price ?? doc.pre_market_price, null),
    changePct: toNumber(doc.premarket_change_pct ?? doc.pre_market_change_pct, null),
    volume: toNumber(doc.premarket_volume ?? doc.pre_market_volume, 0) || 0,
  }
  const postmarket = {
    session: 'postmarket',
    price: toNumber(doc.postmarket_price ?? doc.afterhours_price ?? doc.after_hours_price, null),
    changePct: toNumber(doc.postmarket_change_pct ?? doc.afterhours_change_pct ?? doc.after_hours_change_pct, null),
    volume: toNumber(doc.postmarket_volume ?? doc.afterhours_volume ?? doc.after_hours_volume, 0) || 0,
  }
  const all = [premarket, regular, postmarket].map(item => ({
    ...item,
    price: item.price ?? regular.price,
    changePct: item.changePct == null ? 0 : item.changePct,
    volume: item.volume || (item.session === 'regular' ? regular.volume : 0),
  }))
  const requested = String(requestedSession || 'auto').toLowerCase()
  let active = all.find(item => item.session === requested)
  if (!active) active = all.reduce((best, item) => Math.abs(item.changePct) > Math.abs(best.changePct) ? item : best, regular)
  return { active, premarket: all[0], regular: all[1], postmarket: all[2] }
}

function normalizeTicker(value) {
  const ticker = String(value || '').trim().replace(/^\$/, '').toUpperCase()
  return /^[A-Z][A-Z0-9.-]{0,5}$/.test(ticker) && !NON_STOCK_TICKERS.has(ticker) ? ticker : ''
}

function tickerValues(doc = {}) {
  const out = new Set()
  const push = (value) => {
    if (Array.isArray(value)) return value.forEach(push)
    String(value || '').split(/[,\s]+/).forEach(part => {
      const ticker = normalizeTicker(part)
      if (ticker) out.add(ticker)
    })
  }
  push(doc.ticker)
  push(doc.symbol)
  push(doc.tickers)
  push(doc.symbols)
  push(doc.matched_mover_tickers)
  push(doc.tickers_mentioned)
  const text = `${doc.text || ''} ${doc.content || ''} ${doc.title || ''}`
  for (const match of text.matchAll(/\$([A-Za-z][A-Za-z0-9.-]{0,5})\b/g)) {
    const ticker = normalizeTicker(match[1])
    if (ticker) out.add(ticker)
  }
  return Array.from(out)
}

function sentimentScore(doc = {}) {
  const direct = toNumber(doc.sentiment_score ?? doc.finbert_score ?? doc.vader_score ?? doc.gemini_sentiment, null)
  if (direct != null) return clamp(direct, -1, 1)
  const text = String(doc.sentiment || doc.label || '').toLowerCase()
  if (/bull|positive|buy|beat|raise|approval|award/.test(text)) return 0.65
  if (/bear|negative|sell|miss|cut|reject|offering|bankrupt/.test(text)) return -0.65
  return 0
}

function recencyWeight(eventSec, windowSec) {
  const age = Math.max(0, Math.floor(Date.now() / 1000) - Number(eventSec || 0))
  if (!eventSec || !windowSec) return 0.35
  return clamp(Math.exp(-age / Math.max(3600, windowSec / 2)), 0.1, 1)
}

function classifyCatalyst(doc = {}) {
  const text = `${doc.event_type || ''} ${doc.category || ''} ${doc.title || ''}`.toLowerCase()
  if (/sec|8-k|10-q|10-k|filing|edgar/.test(`${doc.source || ''} ${text}`)) return 'SEC filing'
  if (/fda|approval|clinical|trial|phase|drug|therapy/.test(text)) return 'FDA/clinical'
  if (/earnings|eps|revenue|guidance|quarter/.test(text)) return 'earnings'
  if (/contract|award|partnership|collaboration|customer|order/.test(text)) return 'contract/partnership'
  if (/buyback|dividend|repurchase/.test(text)) return 'capital return'
  if (/offering|dilution|bankrupt|default|delist/.test(text)) return 'financing/risk'
  if (/merger|acquisition|takeover|ipo/.test(text)) return 'corporate action'
  return doc.title ? 'news catalyst' : ''
}

function isSyntheticOrPrivate(row = {}) {
  const text = `${row.ticker || ''} ${row.company || ''} ${row.industry || ''}`.toLowerCase()
  return /etf|2x|3x|daily target|tradr|leverage shares|direxion|proshares|graniteshares|defiance|spacex|private/.test(text)
}

function sourceFilter(universe) {
  const value = String(universe || 'active_finviz').toLowerCase()
  if (value === 'all') return {}
  if (value === 'numeric_all') {
    return {
      quote_source: { $in: ['finviz_elite_screener', 'tradingview_numeric_screener'] },
      $or: [
        { finviz_status: { $exists: false } },
        { finviz_status: { $ne: 'dropped' } },
        { quote_source: 'tradingview_numeric_screener' },
      ],
    }
  }
  if (value === 'tradingview') return { quote_source: 'tradingview_numeric_screener' }
  return {
    quote_source: 'finviz_elite_screener',
    finviz_status: { $in: [null, 'same', 'added'] },
  }
}

function activeScreenerMatch(query = {}, thresholds) {
  const minRel = Math.max(0, Number(query.min_rel_volume ?? query.minRelativeVolume ?? thresholds.minRelativeVolume))
  return {
    ...sourceFilter(query.universe),
    ticker: { $not: /\./ },
    exchange: { $in: Array.from(US_EXCHANGES) },
    price: { $gt: 0 },
    volume: { $gt: 0 },
    rel_volume: { $gte: minRel },
  }
}

function normalizeScreenerRow(doc = {}, requestedSession = 'auto') {
  const volume = toNumber(doc.volume, 0) || 0
  const avgVolume = toNumber(doc.avg_volume, null)
  const relVolume = toNumber(doc.rel_volume ?? doc.relative_volume, null) ?? (avgVolume ? volume / Math.max(1, avgVolume) : 0)
  const source = doc.quote_source || doc.screener_source || doc.source || ''
  const isFinvizSource = /finviz/i.test(String(source || ''))
  const marketCap = normalizeMarketCap(doc.market_cap, source)
  const bucket = marketCapBucket(marketCap)
  const sessions = sessionMetrics(doc, requestedSession)
  const currentVolume = sessions.active.volume || volume
  const currentDollarVolume = Number(((sessions.active.price || 0) * currentVolume).toFixed(2))
  const quoteUpdatedAt = toSec(doc.quote_updated_at)
  const finvizSeenAt = isFinvizSource ? toSec(doc.finviz_seen_at) : 0
  return {
    ticker: normalizeTicker(doc.ticker),
    company: doc.company || '',
    price: sessions.active.price,
    regularPrice: sessions.regular.price,
    premarketPrice: sessions.premarket.price,
    postmarketPrice: sessions.postmarket.price,
    marketCap,
    rawMarketCap: toNumber(doc.market_cap, null),
    marketCapBucket: bucket,
    marketCapRelVolumeTarget: marketCapRelVolumeTarget(bucket),
    dollarVolumeTarget: dollarVolumeTarget(bucket),
    currentDollarVolume,
    marketCapRelativeVolumeScore: Number(capAdjustedRelVolumeScore(relVolume, bucket, currentDollarVolume).toFixed(2)),
    priceChangePct: sessions.active.changePct,
    regularChangePct: sessions.regular.changePct,
    premarketChangePct: sessions.premarket.changePct,
    postmarketChangePct: sessions.postmarket.changePct,
    relativeVolume: toNumber(relVolume, 0) || 0,
    currentVolume,
    regularVolume: sessions.regular.volume,
    premarketVolume: sessions.premarket.volume,
    postmarketVolume: sessions.postmarket.volume,
    averageVolume: avgVolume,
    exchange: doc.exchange || '',
    sector: doc.sector || '',
    industry: doc.industry || '',
    screenerSource: source,
    screenerStatus: isFinvizSource ? (doc.finviz_status || null) : null,
    quoteUpdatedAt,
    finvizSeenAt,
    quoteAgeSeconds: ageSeconds(quoteUpdatedAt),
    finvizAgeSeconds: ageSeconds(finvizSeenAt),
    activeSession: sessions.active.session,
    sessionMovement: sessions.active,
  }
}

async function activeScreenerRows(db, query, thresholds) {
  const limit = Math.max(1, Math.min(600, Number(query.limit || 150)))
  const internalLimit = Math.max(600, Math.min(1600, limit * 4))
  const sortField = String(query.sort || 'activity').toLowerCase()

  const loadRows = (match) => db.collection('screeners').aggregate([
      { $match: match },
      {
        $addFields: {
          _sourcePriority: {
            $switch: {
              branches: [
                { case: { $and: [{ $eq: ['$quote_source', 'finviz_elite_screener'] }, { $in: ['$finviz_status', ['same', 'added', null]] }] }, then: 3 },
                { case: { $eq: ['$quote_source', 'finviz_elite_screener'] }, then: 2 },
                { case: { $eq: ['$quote_source', 'tradingview_numeric_screener'] }, then: 1 },
              ],
              default: 0,
            },
          },
          activitySort: {
            $multiply: [
              { $ln: { $add: [{ $ifNull: ['$rel_volume', 0] }, 1] } },
              { $add: [{ $abs: { $ifNull: ['$change_pct', 0] } }, 1] },
            ],
          },
        },
      },
      { $sort: { ticker: 1, _sourcePriority: -1, quote_updated_at: -1, finviz_seen_at: -1, activitySort: -1 } },
      { $group: { _id: '$ticker', doc: { $first: '$$ROOT' } } },
      { $replaceRoot: { newRoot: '$doc' } },
      { $limit: internalLimit },
    ]).toArray()

  let rows = await loadRows(activeScreenerMatch(query, thresholds))
  if (!rows.length && String(query.universe || 'active_finviz').toLowerCase() === 'active_finviz') {
    rows = await loadRows(activeScreenerMatch({ ...query, universe: 'numeric_all' }, thresholds))
    rows = rows.map(row => ({ ...row, decision_map_universe_fallback: 'numeric_all' }))
  }

  const direction = String(query.direction || 'all').toLowerCase()
  const minAbsChange = Math.max(0, Number(query.min_abs_change ?? query.minAbsPriceChange ?? thresholds.minAbsPriceChange))
  const maxAbsChange = Math.max(minAbsChange, Number(thresholds.maxAbsPriceChange || 300))
  const normalized = rows.map(row => normalizeScreenerRow(row, query.session)).filter(row => {
    if (!row.ticker) return false
    const change = Number(row.priceChangePct || 0)
    if (Math.abs(change) > maxAbsChange) return false
    if (direction === 'up') return change >= minAbsChange
    if (direction === 'down') return change <= -minAbsChange
    return Math.abs(change) >= minAbsChange
  })
  const marketCapFilter = normalizedMarketCapBucket(query.market_cap_bucket || query.market_cap || '')
  const relBucketFilter = String(query.rel_volume_bucket || query.relative_volume_bucket || '').toLowerCase()
  const filtered = normalized.filter(row => {
    if (marketCapFilter && normalizedMarketCapBucket(row.marketCapBucket) !== marketCapFilter) return false
    if (['low', 'medium', 'high', 'extreme'].includes(relBucketFilter) && relVolumeBucket(row.relativeVolume) !== relBucketFilter) return false
    return true
  })
  filtered.sort((a, b) => {
    if (sortField === 'rel_volume') return b.relativeVolume - a.relativeVolume
    if (sortField === 'change' || sortField === 'postmarket_change' || sortField === 'premarket_change') return b.priceChangePct - a.priceChangePct
    if (sortField === 'market_cap_adjusted_relvol') return b.marketCapRelativeVolumeScore - a.marketCapRelativeVolumeScore
    return (b.marketCapRelativeVolumeScore * Math.max(1, Math.abs(b.priceChangePct))) - (a.marketCapRelativeVolumeScore * Math.max(1, Math.abs(a.priceChangePct)))
  })
  return filtered.slice(0, limit)
}

async function articleEvidence(db, tickers, windowHours) {
  const wanted = new Set(tickers)
  const windowSec = Math.max(1, Number(windowHours || 24)) * 3600
  const sinceSec = Math.floor(Date.now() / 1000) - windowSec
  const docs = await db.collection('articles').find({
    $or: [
      { publish_date: { $gte: sinceSec } },
      { fetched_date: { $gte: sinceSec } },
      { detected_at: { $gte: sinceSec } },
      { createdAt: { $gte: new Date(sinceSec * 1000) } },
    ],
  }, {
    projection: {
      ticker: 1, tickers: 1, matched_mover_tickers: 1, tickers_mentioned: 1,
      title: 1, source: 1, sentiment: 1, sentiment_score: 1, ml_confidence: 1,
      event_type: 1, category: 1, article_kind: 1, publish_date: 1, fetched_date: 1, detected_at: 1, url: 1,
    },
  }).sort({ publish_date: -1, fetched_date: -1, detected_at: -1 }).limit(12000).toArray()

  const map = new Map()
  for (const doc of docs) {
    const score = sentimentScore(doc)
    const eventSec = toSec(doc.publish_date) || toSec(doc.fetched_date) || toSec(doc.detected_at)
    const weight = recencyWeight(eventSec, windowSec)
    const catalyst = classifyCatalyst(doc)
    for (const ticker of tickerValues(doc)) {
      if (!wanted.has(ticker)) continue
      const current = map.get(ticker) || {
        count: 0, weightedScore: 0, weight: 0, bullish: 0, bearish: 0,
        structuredCount: 0, unstructuredCount: 0,
        latestSec: 0, latestTitles: [], catalysts: new Map(), sources: new Set(),
        structuredSources: new Set(), unstructuredSources: new Set(),
      }
      const sourceText = `${doc.source || ''} ${doc.article_kind || ''}`
      const isStructured = STRUCTURED_SOURCE_RE.test(sourceText) || !SOCIAL_SOURCE_RE.test(sourceText)
      current.count += 1
      if (isStructured) current.structuredCount += 1
      else current.unstructuredCount += 1
      current.weightedScore += score * weight
      current.weight += weight
      if (score > 0.12) current.bullish += 1
      if (score < -0.12) current.bearish += 1
      current.latestSec = Math.max(current.latestSec, eventSec)
      current.sources.add(doc.source || 'Unknown')
      if (isStructured) current.structuredSources.add(doc.source || 'Unknown')
      else current.unstructuredSources.add(doc.source || 'Unknown')
      if (doc.title && current.latestTitles.length < 3) {
        current.latestTitles.push({ title: doc.title, source: doc.source || '', url: doc.url || '', publishedAt: eventSec, sentiment: score, kind: isStructured ? 'structured' : 'unstructured' })
      }
      if (catalyst) current.catalysts.set(catalyst, (current.catalysts.get(catalyst) || 0) + 1)
      map.set(ticker, current)
    }
  }
  return map
}

async function socialEvidence(db, tickers, windowHours) {
  const wanted = new Set(tickers)
  const windowSec = Math.max(1, Number(windowHours || 24)) * 3600
  const sinceSec = Math.floor(Date.now() / 1000) - windowSec
  const docs = await db.collection('socials').find({
    $or: [
      { timestamp: { $gte: sinceSec } },
      { fetched_at: { $gte: sinceSec } },
      { created_at: { $gte: sinceSec } },
      { detected_at: { $gte: sinceSec } },
    ],
  }, {
    projection: {
      ticker: 1, symbol: 1, tickers_mentioned: 1, text: 1, content: 1, title: 1,
      platform: 1, source: 1, sentiment: 1, sentiment_score: 1, timestamp: 1, fetched_at: 1, created_at: 1, detected_at: 1,
    },
  }).sort({ timestamp: -1, fetched_at: -1, created_at: -1 }).limit(15000).toArray()

  const map = new Map()
  for (const doc of docs) {
    const score = sentimentScore(doc)
    const eventSec = toSec(doc.timestamp) || toSec(doc.fetched_at) || toSec(doc.created_at) || toSec(doc.detected_at)
    const weight = recencyWeight(eventSec, windowSec)
    for (const ticker of tickerValues(doc)) {
      if (!wanted.has(ticker)) continue
      const current = map.get(ticker) || { count: 0, weightedScore: 0, weight: 0, bullish: 0, bearish: 0, platforms: new Set(), latestSec: 0 }
      current.count += 1
      current.weightedScore += score * weight
      current.weight += weight
      if (score > 0.12) current.bullish += 1
      if (score < -0.12) current.bearish += 1
      current.platforms.add(doc.platform || doc.source || 'Unknown')
      current.latestSec = Math.max(current.latestSec, eventSec)
      map.set(ticker, current)
    }
  }
  return map
}

async function rollingVolumeEvidence(db, tickers) {
  const snapshots = await db.collection('finviz_momentum_snapshots')
    .find({}, { projection: { snapshot_sec: 1, rows: 1 } })
    .sort({ snapshot_sec: -1 })
    .limit(12)
    .toArray()
  const wanted = new Set(tickers)
  const map = new Map()
  for (const snapshot of snapshots.reverse()) {
    for (const row of snapshot.rows || []) {
      const ticker = normalizeTicker(row.ticker)
      if (!wanted.has(ticker)) continue
      const current = map.get(ticker) || []
      current.push({ snapshotSec: Number(snapshot.snapshot_sec || 0), volume: toNumber(row.volume, 0) || 0, relVolume: toNumber(row.rel_volume, 0) || 0 })
      map.set(ticker, current)
    }
  }
  const result = new Map()
  for (const [ticker, rows] of map.entries()) {
    const first = rows[0] || {}
    const last = rows[rows.length - 1] || {}
    result.set(ticker, {
      points: rows,
      rollingVolume: toNumber(last.volume, 0) || 0,
      volumeAcceleration: first.volume ? Number(((toNumber(last.volume, 0) || 0) / Math.max(1, first.volume)).toFixed(3)) : toNumber(last.relVolume, 0) || 0,
    })
  }
  return result
}

function quadrantFor(combinedSentiment, priceChangePct, thresholds) {
  const positiveSentiment = Number(thresholds.positiveSentiment)
  const negativeSentiment = Number(thresholds.negativeSentiment)
  const priceThreshold = Number(thresholds.priceChange)
  if (combinedSentiment >= positiveSentiment && priceChangePct >= priceThreshold) {
    return { quadrant: 'Q1', alignmentStatus: 'sentiment/price aligned bullish', aligned: true, direction: 'bullish' }
  }
  if (combinedSentiment <= negativeSentiment && priceChangePct <= -priceThreshold) {
    return { quadrant: 'Q3', alignmentStatus: 'sentiment/price aligned bearish', aligned: true, direction: 'bearish' }
  }
  if (combinedSentiment <= negativeSentiment && priceChangePct >= priceThreshold) {
    return { quadrant: 'Q2', alignmentStatus: 'divergence: negative sentiment but price rising', aligned: false, direction: 'contrarian_up' }
  }
  if (combinedSentiment >= positiveSentiment && priceChangePct <= -priceThreshold) {
    return { quadrant: 'Q4', alignmentStatus: 'divergence: positive sentiment but price falling', aligned: false, direction: 'failed_positive' }
  }
  return { quadrant: 'Neutral', alignmentStatus: 'neutral/mixed', aligned: false, direction: 'mixed' }
}

function scoreRow(row, article, social, volume, thresholds) {
  const liquidity = liquidityProfile(row)
  const newsSentiment = article?.weight ? article.weightedScore / article.weight : 0
  const socialSentiment = social?.weight ? social.weightedScore / social.weight : 0
  const newsCount = article?.count || 0
  const socialCount = social?.count || 0
  const combinedWeight = (newsCount ? 0.62 : 0) + (socialCount ? 0.38 : 0)
  const combinedSentiment = combinedWeight
    ? ((newsSentiment * (newsCount ? 0.62 : 0)) + (socialSentiment * (socialCount ? 0.38 : 0))) / combinedWeight
    : 0
  const quadrant = quadrantFor(combinedSentiment, row.priceChangePct, thresholds)
  const catalystLabel = article?.catalysts?.size
    ? Array.from(article.catalysts.entries()).sort((a, b) => b[1] - a[1])[0][0]
    : ''
  const latestNewsSec = article?.latestSec || 0
  const newsAgeHours = latestNewsSec ? (Math.floor(Date.now() / 1000) - latestNewsSec) / 3600 : null
  const rollingVolume = volume?.rollingVolume || row.currentVolume || 0
  const volumeAcceleration = volume?.volumeAcceleration || row.relativeVolume || 0
  const marketCapRelVolume = clamp(Number(row.marketCapRelativeVolumeScore || 0) / 100, 0, 1)
  const relVolumeScore = clamp((Math.log1p(row.relativeVolume) / Math.log(8)) * 0.55 + marketCapRelVolume * 0.45, 0, 1)
  const priceMoveScore = clamp(Math.abs(row.priceChangePct) / 12, 0, 1)
  const volumeScore = clamp(Math.log10(Math.max(1, row.currentVolume)) / 8, 0, 1)
  const activityScore = Math.round((relVolumeScore * 42 + priceMoveScore * 38 + volumeScore * 20) * 100) / 100
  const evidenceScore =
    (quadrant.aligned ? 18 : quadrant.quadrant === 'Neutral' ? 2 : -20) +
    (catalystLabel ? 12 : -18) +
    (marketCapRelVolume >= 0.75 ? 8 : marketCapRelVolume >= 0.5 ? 3 : -4) +
    Math.min(10, newsCount * 2) +
    Math.min(7, socialCount * 0.6) +
    (newsAgeHours != null && newsAgeHours <= 6 ? 4 : newsAgeHours != null && newsAgeHours > 18 ? -6 : 0)
  const convictionScore = Math.round(clamp(activityScore * 0.42 + evidenceScore, 0, 100))
  const riskFlags = []
  const reasons = []
  if (row.relativeVolume < thresholds.minRelativeVolume) riskFlags.push('WEAK_RELATIVE_VOLUME')
  if (row.relativeVolume < row.marketCapRelVolumeTarget) riskFlags.push('BELOW_MARKET_CAP_REL_VOLUME_TARGET')
  if (Number(row.currentDollarVolume || 0) < Number(row.dollarVolumeTarget || 0)) riskFlags.push('WEAK_CURRENT_DOLLAR_VOLUME')
  if (liquidity.liquidityRiskFlag) riskFlags.push(liquidity.liquidityRiskFlag)
  if (Math.abs(row.priceChangePct) < thresholds.minAbsPriceChange) riskFlags.push('LOW_PRICE_ACTIVITY')
  if (!catalystLabel) riskFlags.push('NO_CATALYST')
  if (!newsCount) riskFlags.push('NO_STRUCTURED_NEWS')
  if (!socialCount) riskFlags.push('NO_SOCIAL_CONFIRMATION')
  if (!quadrant.aligned && quadrant.quadrant !== 'Neutral') riskFlags.push('SENTIMENT_PRICE_DIVERGENCE')
  if (newsAgeHours != null && newsAgeHours > 18) riskFlags.push('STALE_NEWS')
  if (row.screenerStatus === 'dropped') riskFlags.push('NOT_ACTIVE_ON_FINVIZ')
  if (isSyntheticOrPrivate(row)) riskFlags.push('SYNTHETIC_OR_PRIVATE_EXPOSURE')
  if (row.finvizAgeSeconds != null && row.finvizAgeSeconds > thresholds.finvizStaleSeconds) riskFlags.push('STALE_FINVIZ_SCREENER')
  if (activityScore >= 65) reasons.push('high numerical activity from screener')
  reasons.push(`${row.activeSession} move ${row.priceChangePct >= 0 ? '+' : ''}${row.priceChangePct.toFixed(2)}%`)
    reasons.push(`${row.marketCapBucket}: ${row.relativeVolume.toFixed(2)}x rel vol vs ${row.marketCapRelVolumeTarget.toFixed(1)}x bucket target; $${Math.round(row.currentDollarVolume || 0).toLocaleString()} moment dollar volume`)
  if (quadrant.aligned) reasons.push(quadrant.alignmentStatus)
  if (catalystLabel) reasons.push(`catalyst: ${catalystLabel}`)
  if (socialCount) reasons.push('social confirmation present')
  if (newsCount) reasons.push('structured news present')
  const hasNews = newsCount > 0
  const hasSocial = socialCount > 0
  const decisionState = !catalystLabel && !hasNews && !hasSocial
    ? 'weak_no_catalyst'
    : (!quadrant.aligned && quadrant.quadrant !== 'Neutral')
      ? 'risky_uncertain'
      : quadrant.quadrant === 'Q1' && convictionScore >= 65
        ? 'strong_bullish_candidate'
        : quadrant.quadrant === 'Q1'
          ? 'moderate_bullish_candidate'
          : quadrant.quadrant === 'Q3'
            ? 'aligned_bearish_candidate'
            : 'neutral_watchlist'
  const supportLabel = hasNews && hasSocial
    ? 'structured news + social support'
    : hasNews
      ? 'structured news support'
      : hasSocial
        ? 'social/unstructured support'
        : 'movement without catalyst support'

  return {
    ...row,
    ...liquidity,
    rollingVolume,
    volumeAcceleration,
    structuredNewsSentiment: Number(newsSentiment.toFixed(3)),
    socialSentiment: Number(socialSentiment.toFixed(3)),
    combinedSentiment: Number(combinedSentiment.toFixed(3)),
    articleCount: newsCount,
    socialCount,
    structuredArticleCount: article?.structuredCount || 0,
    unstructuredArticleCount: article?.unstructuredCount || 0,
    relativeVolumeBucket: relVolumeBucket(row.relativeVolume),
    catalystLabel,
    quadrant: quadrant.quadrant,
    alignmentStatus: quadrant.alignmentStatus,
    decisionState,
    supportLabel,
    activityScore,
    convictionScore,
    riskFlags,
    reasons,
    latestNewsTitles: article?.latestTitles || [],
    newsSources: article ? Array.from(article.sources).slice(0, 8) : [],
    structuredNewsSources: article ? Array.from(article.structuredSources).slice(0, 8) : [],
    unstructuredNewsSources: article ? Array.from(article.unstructuredSources).slice(0, 8) : [],
    socialPlatforms: social ? Array.from(social.platforms).slice(0, 8) : [],
    lastUpdated: new Date(Math.max(row.quoteUpdatedAt || 0, latestNewsSec || 0, social?.latestSec || 0) * 1000).toISOString(),
    screenerFirst: true,
  }
}

function decisionPointFromValues(values = {}, current = {}) {
  const sentiment = toNumber(values.combinedSentiment ?? values.avg_sentiment ?? values.structured_sentiment ?? values.news_sentiment ?? values.social_sentiment, null)
  const sentimentEstimated = sentiment == null
  const xSentiment = sentimentEstimated ? Number(current.combinedSentiment || 0) : sentiment
  const changePct = toNumber(values.priceChangePct ?? values.change_pct ?? values.change_percent, current.priceChangePct || 0) || 0
  const relVolume = toNumber(values.relativeVolume ?? values.rel_volume ?? values.relative_volume, current.relativeVolume || 0) || 0
  const marketCapBucketValue = values.marketCapBucket || current.marketCapBucket
  const price = toNumber(values.price ?? values.currentPrice ?? current.price, current.price || 0) || 0
  const volume = toNumber(values.volume ?? values.currentVolume, current.currentVolume || 0) || 0
  const dollarVolume = toNumber(values.currentDollarVolume, price * volume) || 0
  const zScore = toNumber(values.marketCapRelativeVolumeScore, null) ?? capAdjustedRelVolumeScore(relVolume, marketCapBucketValue, dollarVolume)
  return {
    timestamp: Number(values.timestamp || values.snapshotSec || values.snapshot_sec || 0),
    x: Number((clamp(xSentiment, -1, 1) * 7).toFixed(3)),
    y: Number((clamp(changePct, -25, 25) / 25 * 4.8).toFixed(3)),
    z: Number((clamp(zScore, 0, 100) / 100 * 7).toFixed(3)),
    combinedSentiment: Number(clamp(xSentiment, -1, 1).toFixed(3)),
    priceChangePct: Number(changePct.toFixed(3)),
    marketCapRelativeVolumeScore: Number(clamp(zScore, 0, 100).toFixed(2)),
    relativeVolume: Number(relVolume.toFixed(3)),
    currentDollarVolume: Number(dollarVolume.toFixed(2)),
    convictionScore: values.convictionScore == null ? null : Number(values.convictionScore),
    sentimentEstimated,
  }
}

function pathDirectionFromPoints(points = [], current = {}) {
  if (!Array.isArray(points) || points.length < 2) {
    return {
      path_direction: 'insufficient_history',
      path_direction_score: 0,
      path_color: 'gray',
      path_explanation: 'Need at least two recent graph points to judge direction.',
      latest_point: points[points.length - 1] || null,
      previous_point: null,
      path_points_count: Array.isArray(points) ? points.length : 0,
      path_window_minutes: 0,
      time_lapse_available: false,
    }
  }
  const latest = points[points.length - 1]
  const previous = points[points.length - 2]
  const composite = (point) => (
    clamp(point.combinedSentiment, -1, 1) * 0.34 +
    clamp(point.priceChangePct / 12, -1, 1) * 0.32 +
    clamp(point.marketCapRelativeVolumeScore / 100, 0, 1) * 0.22 +
    clamp((point.convictionScore ?? current.convictionScore ?? 50) / 100, 0, 1) * 0.12
  )
  const recent = points.slice(-Math.min(8, points.length))
  const midpoint = Math.max(1, Math.floor(recent.length / 2))
  const firstHalf = recent.slice(0, midpoint)
  const secondHalf = recent.slice(midpoint)
  const avg = (items) => items.reduce((sum, point) => sum + composite(point), 0) / Math.max(1, items.length)
  const halfTrend = avg(secondHalf) - avg(firstHalf)
  const latestStep = composite(latest) - composite(previous)
  const wholePathTrend = composite(latest) - composite(recent[0])
  const delta = Number((halfTrend * 0.52 + latestStep * 0.28 + wholePathTrend * 0.20).toFixed(3))
  const direction = delta > 0.045 ? 'correct_direction' : delta < -0.045 ? 'wrong_direction' : 'neutral'
  const firstTimestamp = Number(recent[0]?.timestamp || 0)
  const latestTimestamp = Number(latest?.timestamp || 0)
  const pathWindowMinutes = firstTimestamp && latestTimestamp
    ? Math.max(0, Math.round((latestTimestamp - firstTimestamp) / 60))
    : 0
  return {
    path_direction: direction,
    path_direction_score: delta,
    path_color: direction === 'correct_direction' ? 'blue' : direction === 'wrong_direction' ? 'red' : 'gray',
    path_explanation: direction === 'correct_direction'
      ? 'Recent multi-point path improved on prediction-aligned sentiment, price movement, and market-cap-adjusted relative volume.'
      : direction === 'wrong_direction'
        ? 'Recent multi-point path deteriorated across the prediction-aligned movement composite.'
        : 'Recent movement is too small or mixed to call.',
    latest_point: latest,
    previous_point: previous,
    path_start_point: recent[0],
    path_points_count: points.length,
    path_window_minutes: pathWindowMinutes,
    path_delta_components: {
      half_trend: Number(halfTrend.toFixed(3)),
      latest_step: Number(latestStep.toFixed(3)),
      whole_path_trend: Number(wholePathTrend.toFixed(3)),
    },
    time_lapse_available: true,
  }
}

async function redisTickerPathEvidence(redis, scoredRows = [], maxPoints = 14) {
  if (!redis || !Array.isArray(scoredRows) || !scoredRows.length) return new Map()
  const tickers = scoredRows.map(row => normalizeTicker(row.ticker)).filter(Boolean)
  if (!tickers.length) return new Map()
  try {
    const zpipe = redis.pipeline()
    for (const ticker of tickers) {
      zpipe.zrevrange(`decision_map:path:${ticker}`, 0, Math.max(0, maxPoints - 1))
    }
    const zResults = await zpipe.exec()
    const keysByTicker = new Map()
    const getPipe = redis.pipeline()
    zResults.forEach((result, index) => {
      const keys = Array.isArray(result?.[1]) ? result[1].reverse() : []
      const ticker = tickers[index]
      keysByTicker.set(ticker, keys)
      keys.forEach(key => getPipe.get(key))
    })
    const getResults = await getPipe.exec()
    let cursor = 0
    const out = new Map()
    for (const ticker of tickers) {
      const keys = keysByTicker.get(ticker) || []
      const points = []
      for (let i = 0; i < keys.length; i += 1) {
        const parsed = parsePoint(getResults[cursor]?.[1])
        cursor += 1
        if (parsed) points.push(parsed)
      }
      if (points.length) out.set(ticker, points)
    }
    return out
  } catch (_) {
    return new Map()
  }
}

async function mongoDecisionMapPointEvidence(db, scoredRows = [], maxPoints = 14) {
  if (!db || !Array.isArray(scoredRows) || !scoredRows.length) return new Map()
  const tickers = scoredRows.map(row => normalizeTicker(row.ticker)).filter(Boolean)
  if (!tickers.length) return new Map()
  const currentByTicker = new Map(scoredRows.map(row => [normalizeTicker(row.ticker), row]))
  const sinceSec = Math.floor(Date.now() / 1000) - DECISION_MAP_HISTORY_SECONDS
  try {
    const docs = await db.collection('decision_map_points')
      .find({
        ticker: { $in: tickers },
        $or: [
          { snapshot_sec: { $gte: sinceSec } },
          { snapshotSec: { $gte: sinceSec } },
          { timestamp: { $gte: sinceSec } },
        ],
      }, {
        projection: {
          ticker: 1,
          snapshot_sec: 1,
          snapshotSec: 1,
          timestamp: 1,
          x: 1,
          y: 1,
          z: 1,
          combinedSentiment: 1,
          priceChangePct: 1,
          marketCapRelativeVolumeScore: 1,
          relativeVolume: 1,
          currentDollarVolume: 1,
          convictionScore: 1,
        },
      })
      .sort({ snapshot_sec: 1, snapshotSec: 1, timestamp: 1 })
      .toArray()

    const out = new Map()
    for (const doc of docs) {
      const ticker = normalizeTicker(doc.ticker)
      if (!ticker) continue
      const current = currentByTicker.get(ticker) || {}
      const timestamp = Number(doc.snapshot_sec || doc.snapshotSec || doc.timestamp || 0)
      const point = Number.isFinite(Number(doc.x)) && Number.isFinite(Number(doc.y)) && Number.isFinite(Number(doc.z))
        ? {
          timestamp,
          x: Number(doc.x),
          y: Number(doc.y),
          z: Number(doc.z),
          combinedSentiment: Number(doc.combinedSentiment ?? current.combinedSentiment ?? 0),
          priceChangePct: Number(doc.priceChangePct ?? current.priceChangePct ?? 0),
          marketCapRelativeVolumeScore: Number(doc.marketCapRelativeVolumeScore ?? current.marketCapRelativeVolumeScore ?? 0),
          relativeVolume: Number(doc.relativeVolume ?? current.relativeVolume ?? 0),
          currentDollarVolume: Number(doc.currentDollarVolume ?? current.currentDollarVolume ?? 0),
          convictionScore: doc.convictionScore == null ? null : Number(doc.convictionScore),
          sentimentEstimated: false,
        }
        : decisionPointFromValues({ ...doc, timestamp }, current)
      const points = out.get(ticker) || []
      points.push(point)
      if (points.length > maxPoints * 2) points.splice(0, points.length - maxPoints * 2)
      out.set(ticker, points)
    }
    for (const [ticker, points] of out.entries()) {
      out.set(ticker, points.slice(-maxPoints))
    }
    return out
  } catch (_) {
    return new Map()
  }
}

async function tickerPathEvidence(db, scoredRows = [], maxPoints = 14, redis = null) {
  const wanted = new Set(scoredRows.map(row => normalizeTicker(row.ticker)).filter(Boolean))
  if (!wanted.size) return new Map()
  const currentByTicker = new Map(scoredRows.map(row => [normalizeTicker(row.ticker), row]))
  const redisPaths = await redisTickerPathEvidence(redis, scoredRows, maxPoints)
  const mongoPointPaths = await mongoDecisionMapPointEvidence(db, scoredRows, maxPoints)
  const tickersNeedingSnapshots = new Set([...wanted].filter(ticker => {
    const redisCount = (redisPaths.get(ticker) || []).length
    const mongoCount = (mongoPointPaths.get(ticker) || []).length
    return Math.max(redisCount, mongoCount) < maxPoints
  }))
  const snapshots = tickersNeedingSnapshots.size ? await db.collection('finviz_momentum_snapshots')
    .find({}, { projection: { snapshot_sec: 1, rows: 1 } })
    .sort({ snapshot_sec: -1 })
    .limit(Math.max(4, maxPoints - 1))
    .toArray()
    .catch(() => []) : []

  const map = new Map()
  for (const [ticker, points] of redisPaths.entries()) {
    map.set(ticker, points.slice(-maxPoints))
  }
  for (const [ticker, points] of mongoPointPaths.entries()) {
    const existing = map.get(ticker) || []
    map.set(ticker, [...existing, ...points].slice(-maxPoints * 2))
  }
  for (const snapshot of snapshots.reverse()) {
    const snapshotSec = Number(snapshot.snapshot_sec || 0)
    for (const raw of snapshot.rows || []) {
      const ticker = normalizeTicker(raw.ticker)
      if (!tickersNeedingSnapshots.has(ticker)) continue
      const current = currentByTicker.get(ticker) || {}
      const points = map.get(ticker) || []
      points.push(decisionPointFromValues({ ...raw, snapshotSec }, current))
      map.set(ticker, points)
    }
  }

  for (const row of scoredRows) {
    const ticker = normalizeTicker(row.ticker)
    const points = map.get(ticker) || []
    const latestTs = toSec(row.quoteUpdatedAt) || Math.floor(Date.now() / 1000)
    points.push(decisionPointFromValues({
      timestamp: latestTs,
      combinedSentiment: row.combinedSentiment,
      priceChangePct: row.priceChangePct,
      marketCapRelativeVolumeScore: row.marketCapRelativeVolumeScore,
      relativeVolume: row.relativeVolume,
      convictionScore: row.convictionScore,
    }, row))
    const deduped = []
    const seen = new Set()
    for (const point of points) {
      const key = `${point.timestamp}:${point.y}:${point.z}`
      if (seen.has(key)) continue
      seen.add(key)
      deduped.push(point)
    }
    const pathPoints = deduped.slice(-maxPoints)
    const direction = pathDirectionFromPoints(pathPoints, row)
    map.set(ticker, {
      ticker_path: pathPoints,
      path_points: pathPoints,
      ...direction,
    })
  }
  return map
}

async function finvizFreshness(db, staleSeconds) {
  const latest = await db.collection('screeners').findOne(
    { quote_source: 'finviz_elite_screener', finviz_status: { $ne: 'dropped' } },
    { sort: { finviz_seen_at: -1, quote_updated_at: -1 }, projection: { ticker: 1, finviz_seen_at: 1, quote_updated_at: 1, finviz_status: 1 } }
  ).catch(() => null)
  const seenSec = toSec(latest?.finviz_seen_at) || toSec(latest?.quote_updated_at)
  const age = ageSeconds(seenSec)
  return {
    latestTicker: latest?.ticker || null,
    latestSeenAt: seenSec ? new Date(seenSec * 1000).toISOString() : null,
    ageSeconds: age,
    staleSeconds,
    isStale: age == null ? true : age > staleSeconds,
    note: age == null
      ? 'No FinViz screener timestamp found.'
      : age > staleSeconds
        ? 'FinViz screener data is stale; treat it as stored mover context, not live market truth.'
        : 'FinViz screener data is fresh enough for active mover context.',
  }
}

async function loadHotDecisionMap(req, db) {
  const redis = redisFromReq(req)
  if (!redis || req.query.fresh === '1') return null
  const signature = stableQuerySignature(req.query)
  try {
    const raw = await redis.get(`decision_map:latest:${signature}`)
    const parsed = raw ? JSON.parse(raw) : null
    if (parsed?.ok && Array.isArray(parsed.rows)) {
      const maxPoints = decisionMapPathPointLimit(req.query)
      const pathMap = await tickerPathEvidence(db, parsed.rows, maxPoints, redis)
      const rows = parsed.rows.map(row => ({ ...row, ...(pathMap.get(normalizeTicker(row.ticker)) || {}) }))
      return {
        ...parsed,
        rows,
        hot_data: {
          ...(parsed.hot_data || {}),
          served_from: 'redis_decision_map_hot_snapshot',
          path_hydrated: true,
          cache_signature: signature,
          redis_ttl_seconds: DECISION_MAP_REDIS_TTL,
        },
      }
    }
  } catch (_) {}
  return null
}

async function persistDecisionMapHotState(req, db, payload) {
  const redis = redisFromReq(req)
  const rows = Array.isArray(payload?.rows) ? payload.rows : []
  if (!rows.length) return { redis_points: 0, mongo_points: 0, kafka_queued: 0 }

  const snapshotSec = quantizedNowSec()
  const signature = stableQuerySignature(req.query)
  const points = rows
    .map(row => decisionMapPointForStorage(row, snapshotSec))
    .filter(point => point.ticker)

  let redisPoints = 0
  if (redis) {
    try {
      const pipe = redis.pipeline()
      const snapshotPayload = {
        ...payload,
        hot_data: {
          enabled: true,
          source: 'redis_decision_map_hot_snapshot',
          cache_signature: signature,
          snapshot_sec: snapshotSec,
          snapshot_at: new Date(snapshotSec * 1000).toISOString(),
          redis_ttl_seconds: DECISION_MAP_REDIS_TTL,
          path_ttl_seconds: DECISION_MAP_PATH_TTL,
          path_max_points: DECISION_MAP_PATH_MAX,
        },
      }
      pipe.set(`decision_map:latest:${signature}`, JSON.stringify(snapshotPayload), 'EX', DECISION_MAP_REDIS_TTL)
      pipe.set('decision_map:latest', JSON.stringify(snapshotPayload), 'EX', DECISION_MAP_REDIS_TTL)
      pipe.hset('decision_map:meta', {
        latest_signature: signature,
        latest_snapshot_sec: String(snapshotSec),
        latest_snapshot_at: new Date(snapshotSec * 1000).toISOString(),
        latest_count: String(rows.length),
        redis_ttl_seconds: String(DECISION_MAP_REDIS_TTL),
        path_ttl_seconds: String(DECISION_MAP_PATH_TTL),
        path_max_points: String(DECISION_MAP_PATH_MAX),
      })
      pipe.expire('decision_map:meta', DECISION_MAP_PATH_TTL)
      for (const point of points) {
        const pointKey = `decision_map:point:${point.ticker}:${point.snapshotSec}`
        pipe.set(pointKey, pointJson(point), 'EX', DECISION_MAP_PATH_TTL)
        pipe.zadd(`decision_map:path:${point.ticker}`, point.snapshotSec, pointKey)
        pipe.zadd('decision_map:active', point.snapshotSec, point.ticker)
        pipe.set(`decision_map:ticker:${point.ticker}:latest`, pointJson(point), 'EX', DECISION_MAP_PATH_TTL)
        pipe.expire(`decision_map:path:${point.ticker}`, DECISION_MAP_PATH_TTL)
        pipe.zremrangebyrank(`decision_map:path:${point.ticker}`, 0, -(DECISION_MAP_PATH_MAX + 1))
      }
      pipe.expire('decision_map:active', DECISION_MAP_PATH_TTL)
      await pipe.exec()
      redisPoints = points.length
    } catch (err) {
      console.warn('DecisionMap Redis hot write failed:', err.message)
    }
  }

  let mongoPoints = 0
  if (DECISION_MAP_PERSIST_MONGO) {
    try {
      await db.collection('decision_map_points').createIndex({ ticker: 1, snapshot_sec: -1 })
      await db.collection('decision_map_points').createIndex({ snapshot_sec: -1 })
      const result = await db.collection('decision_map_points').bulkWrite(points.map(point => ({
        updateOne: {
          filter: { _id: `${point.ticker}:${point.snapshotSec}` },
          update: {
            $set: {
              ...point,
              snapshot_sec: point.snapshotSec,
              generated_at: new Date(point.snapshotSec * 1000),
              updated_at: new Date(),
              source: 'decision_map_api',
            },
          },
          upsert: true,
        },
      })), { ordered: false })
      mongoPoints = Number(result.upsertedCount || 0) + Number(result.modifiedCount || 0)
    } catch (err) {
      console.warn('DecisionMap Mongo point persist failed:', err.message)
    }
  }

  publishDecisionMapPoints(points)
  return { redis_points: redisPoints, mongo_points: mongoPoints, kafka_queued: points.length }
}

function publishDecisionMapPoints(points = []) {
  if (!DECISION_MAP_KAFKA_PUBLISH || !Array.isArray(points) || !points.length) return
  const scriptCandidates = [
    path.join(process.cwd(), 'scripts', 'publish_decision_map_points.py'),
    path.join(process.cwd(), '..', 'scripts', 'publish_decision_map_points.py'),
  ]
  const scriptPath = scriptCandidates.find(candidate => fs.existsSync(candidate))
  if (!scriptPath) return
  const pythonCandidates = [
    process.env.PYTHON_BIN,
    '/opt/rssvenv/bin/python',
    'python3',
  ].filter(Boolean)
  const pythonBin = pythonCandidates.find(candidate => candidate === 'python3' || fs.existsSync(candidate)) || 'python3'
  try {
    const child = spawn(pythonBin, [scriptPath], {
      cwd: process.cwd(),
      env: {
        ...process.env,
        KAFKA_PUBLISH_NEWS: 'true',
      },
      stdio: ['pipe', 'ignore', 'ignore'],
    })
    child.stdin.end(JSON.stringify({ points }))
    child.unref?.()
  } catch (_) {}
}

router.get('/ram/status', async (req, res) => {
  try {
    const db = mongoose.connection.db
    const redis = redisFromReq(req)
    const status = {
      ok: true,
      redis_available: Boolean(redis),
      kafka_publish_enabled: DECISION_MAP_KAFKA_PUBLISH,
      mongo_persist_enabled: DECISION_MAP_PERSIST_MONGO,
      redis_ttl_seconds: DECISION_MAP_REDIS_TTL,
      path_ttl_seconds: DECISION_MAP_PATH_TTL,
      history_seconds: DECISION_MAP_HISTORY_SECONDS,
      path_max_points: DECISION_MAP_PATH_MAX,
      default_path_points: DECISION_MAP_DEFAULT_PATH_POINTS,
      max_path_points: DECISION_MAP_MAX_PATH_POINTS,
      point_interval_seconds: DECISION_MAP_POINT_INTERVAL_SECONDS,
    }
    if (redis) {
      const [meta, activeCount] = await Promise.all([
        redis.hgetall('decision_map:meta').catch(() => ({})),
        redis.zcard('decision_map:active').catch(() => 0),
      ])
      status.redis = {
        latest_snapshot_at: meta.latest_snapshot_at || null,
        latest_count: Number(meta.latest_count || 0),
        active_tickers: Number(activeCount || 0),
        latest_signature: meta.latest_signature || null,
      }
    }
    if (db) {
      const latest = await db.collection('decision_map_points')
        .findOne({}, { sort: { snapshot_sec: -1 }, projection: { ticker: 1, snapshot_sec: 1, generated_at: 1 } })
        .catch(() => null)
      status.mongo = {
        latest_ticker: latest?.ticker || null,
        latest_snapshot_sec: latest?.snapshot_sec || null,
        latest_snapshot_at: latest?.generated_at || null,
      }
    }
    res.json(status)
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) })
  }
})

router.get('/', async (req, res) => {
  try {
    const db = mongoose.connection.db
    if (!db) return res.status(503).json({ ok: false, error: 'MongoDB not connected' })
    const hot = await loadHotDecisionMap(req, db)
    if (hot) {
      res.set('X-Decision-Map-Store', 'redis-hot')
      return res.json(hot)
    }
    const redis = redisFromReq(req)

    const thresholds = {
      ...DEFAULT_THRESHOLDS,
      minRelativeVolume: Math.max(0, Number(req.query.min_rel_volume ?? req.query.minRelativeVolume ?? DEFAULT_THRESHOLDS.minRelativeVolume)),
      minAbsPriceChange: Math.max(0, Number(req.query.min_abs_change ?? req.query.minAbsPriceChange ?? DEFAULT_THRESHOLDS.minAbsPriceChange)),
      positiveSentiment: Number(req.query.positive_sentiment ?? DEFAULT_THRESHOLDS.positiveSentiment),
      negativeSentiment: Number(req.query.negative_sentiment ?? DEFAULT_THRESHOLDS.negativeSentiment),
      priceChange: Math.max(0, Number(req.query.price_threshold ?? DEFAULT_THRESHOLDS.priceChange)),
      minActivityScore: Math.max(0, Number(req.query.min_activity_score ?? DEFAULT_THRESHOLDS.minActivityScore)),
      newsWindowHours: Math.max(1, Math.min(168, Number(req.query.news_window_hours ?? DEFAULT_THRESHOLDS.newsWindowHours))),
      socialWindowHours: Math.max(1, Math.min(168, Number(req.query.social_window_hours ?? DEFAULT_THRESHOLDS.socialWindowHours))),
      finvizStaleSeconds: Math.max(300, Number(req.query.finviz_stale_seconds ?? DEFAULT_THRESHOLDS.finvizStaleSeconds)),
      maxAbsPriceChange: Math.max(1, Number(req.query.max_abs_change ?? req.query.maxAbsPriceChange ?? DEFAULT_THRESHOLDS.maxAbsPriceChange)),
    }

    const rows = await activeScreenerRows(db, req.query, thresholds)
    const tickers = rows.map(row => row.ticker)
    const [articles, socials, volumes, finviz] = await Promise.all([
      articleEvidence(db, tickers, thresholds.newsWindowHours),
      socialEvidence(db, tickers, thresholds.socialWindowHours),
      rollingVolumeEvidence(db, tickers),
      finvizFreshness(db, thresholds.finvizStaleSeconds),
    ])

    let scored = rows.map(row => scoreRow(row, articles.get(row.ticker), socials.get(row.ticker), volumes.get(row.ticker), thresholds))
    scored = scored.filter(row => row.activityScore >= thresholds.minActivityScore)
    const search = normalizeTicker(req.query.search || req.query.q || '')
    if (search) scored = scored.filter(row => row.ticker === search)
    const alignment = String(req.query.alignment || '').toLowerCase()
    if (alignment === 'aligned') scored = scored.filter(row => row.quadrant === 'Q1' || row.quadrant === 'Q3')
    if (alignment === 'divergence') scored = scored.filter(row => row.quadrant === 'Q2' || row.quadrant === 'Q4')

    const pathMap = await tickerPathEvidence(db, scored, decisionMapPathPointLimit(req.query), redis)
    scored = scored.map(row => ({ ...row, ...(pathMap.get(row.ticker) || {
      ticker_path: [],
      path_points: [],
      path_direction: 'insufficient_history',
      path_direction_score: 0,
      path_color: 'gray',
      path_explanation: 'No recent screener snapshots were available for this ticker.',
      latest_point: null,
      previous_point: null,
      time_lapse_available: false,
    }) }))

    const requestedUniverseSort = String(req.query.sort || '').toLowerCase()
    const defaultSortBy = ['postmarket_change', 'premarket_change', 'change'].includes(requestedUniverseSort)
      ? 'priceChangePct'
      : 'convictionScore'
    const sortBy = String(req.query.orderBy || req.query.sortBy || defaultSortBy)
    const sortDir = String(req.query.orderDir || 'desc').toLowerCase() === 'asc' ? 1 : -1
    scored.sort((a, b) => {
      const av = a[sortBy] ?? 0
      const bv = b[sortBy] ?? 0
      if (typeof av === 'string') return sortDir === 1 ? av.localeCompare(String(bv)) : String(bv).localeCompare(av)
      return sortDir === 1 ? Number(av || 0) - Number(bv || 0) : Number(bv || 0) - Number(av || 0)
    })

    const summary = scored.reduce((acc, row) => {
      acc[row.quadrant] = (acc[row.quadrant] || 0) + 1
      if (row.riskFlags.includes('SENTIMENT_PRICE_DIVERGENCE')) acc.divergence += 1
      if (row.catalystLabel) acc.withCatalyst += 1
      if (row.socialCount) acc.withSocial += 1
      return acc
    }, { Q1: 0, Q2: 0, Q3: 0, Q4: 0, Neutral: 0, divergence: 0, withCatalyst: 0, withSocial: 0 })

    const payload = {
      ok: true,
      generatedAt: new Date().toISOString(),
      universe: String(req.query.universe || 'active_finviz'),
      session: String(req.query.session || 'auto'),
      screener_first: true,
      no_fake_rows: true,
      hot_data: {
        enabled: Boolean(redis),
        source: redis ? 'computed_and_warming_redis' : 'mongo_compute_no_redis',
        kafka_publish_enabled: DECISION_MAP_KAFKA_PUBLISH,
        mongo_persist_enabled: DECISION_MAP_PERSIST_MONGO,
        path_store: 'decision_map:path:{ticker}',
        point_store: 'decision_map:point:{ticker}:{snapshotSec}',
      },
      freshness: { finviz },
      thresholds,
      count: scored.length,
      summary,
      rows: scored,
      methodology: {
        first_step: 'Query current numeric screener rows using price, relative volume, liquidity, exchange, and source freshness.',
        second_step: 'Attach structured news, social evidence, catalysts, and rolling volume evidence only after the screener universe exists.',
        axes: {
          x: 'combinedSentiment',
          y: 'priceChangePct',
          z: 'marketCapRelativeVolumeScore from bucket-specific relative volume plus current dollar volume (price * volume)',
          bubbleSize: 'rollingVolume / volumeAcceleration',
          marketCap: 'marketCapBucket + marketCap value are shown in row context and hover tooltip',
        },
      },
    }
    const persisted = await persistDecisionMapHotState(req, db, payload)
    payload.hot_data = { ...payload.hot_data, ...persisted }
    res.set('X-Decision-Map-Store', redis ? 'computed-redis-warmed' : 'computed-mongo')
    res.json(payload)
  } catch (err) {
    console.error('GET /api/decision-map failed:', err)
    res.status(500).json({ ok: false, error: err.message })
  }
})

export default router
