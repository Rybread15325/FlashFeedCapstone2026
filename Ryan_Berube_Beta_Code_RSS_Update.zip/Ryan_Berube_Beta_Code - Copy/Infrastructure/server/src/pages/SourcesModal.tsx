'use client'
import useSWR, { useSWRConfig } from 'swr'
import { useState } from 'react'
import { Modal } from '@/components/shared/Modal'

const fetcher = (url: string) => fetch(url).then(r => r.json())

const CATEGORIES = ['general', 'markets', 'equities', 'economy', 'filings', 'press_releases', 'fda', 'crypto', 'commodities']

interface SourceItem {
  id: string
  name: string
  url: string
  category: string
  active: boolean
  article_count?: number
}

interface Props {
  open: boolean
  onClose: () => void
}

export function SourcesModal({ open, onClose }: Props) {
  const { mutate: globalMutate } = useSWRConfig()
  const { data, mutate } = useSWR(open ? '/api/sources' : null, fetcher)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [category, setCategory] = useState('general')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const sources: SourceItem[] = data?.sources ?? []

  const refreshAll = () => { mutate(); globalMutate('/api/stats') }

  const addSource = async () => {
    if (!name.trim() || !url.trim()) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), url: url.trim(), category }),
      })
      const j = await res.json()
      if (!res.ok) { setError(j.error || 'Failed to add source'); return }
      setName(''); setUrl(''); setCategory('general')
      refreshAll()
    } catch {
      setError('Could not reach API')
    } finally {
      setLoading(false)
    }
  }

  const removeSource = async (id: string) => {
    await fetch(`/api/sources/${id}`, { method: 'DELETE' }).catch(() => {})
    refreshAll()
  }

  return (
    <Modal open={open} onClose={onClose} title="Sources" wide>
      <p className="text-neutral text-xs mb-3">RSS feeds that FlashFeed scrapes for articles.</p>

      {/* Add row */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <input
          value={name}
          onChange={e => { setName(e.target.value); setError('') }}
          placeholder="Feed name"
          className="flex-1 min-w-[120px] bg-bg border border-border text-sm text-white rounded px-3 py-2 focus:outline-none focus:border-accent placeholder:text-slate-600"
        />
        <input
          value={url}
          onChange={e => { setUrl(e.target.value); setError('') }}
          onKeyDown={e => e.key === 'Enter' && addSource()}
          placeholder="RSS URL"
          className="flex-[2] min-w-[180px] bg-bg border border-border text-sm text-white rounded px-3 py-2 focus:outline-none focus:border-accent placeholder:text-slate-600"
        />
        <select
          value={category}
          onChange={e => setCategory(e.target.value)}
          className="w-[130px] bg-bg border border-border text-sm text-neutral rounded px-3 py-2 focus:outline-none focus:border-accent"
        >
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button
          onClick={addSource}
          disabled={loading || !name.trim() || !url.trim()}
          className="px-4 py-2 bg-accent text-white text-sm font-medium rounded hover:bg-sky-400 disabled:opacity-50 transition-colors"
        >
          {loading ? 'Adding...' : 'Add'}
        </button>
      </div>

      {error && <div className="text-red-400 text-xs mb-3">{error}</div>}

      {/* Sources table */}
      <div className="bg-bg border border-border rounded-lg overflow-hidden">
        {!data ? (
          <div className="p-4 text-center text-neutral text-sm animate-pulse">Loading sources...</div>
        ) : sources.length === 0 ? (
          <div className="p-4 text-center text-neutral text-sm">No sources configured. Add an RSS feed above.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-border">
              <tr>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-wide text-neutral font-medium">Name</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-wide text-neutral font-medium">URL</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-wide text-neutral font-medium">Category</th>
                <th className="px-3 py-2 text-right text-[10px] uppercase tracking-wide text-neutral font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sources.map(s => (
                <tr key={s.id} className="border-b border-slate-700/30 last:border-b-0 hover:bg-card-hover">
                  <td className="px-3 py-2 text-white whitespace-nowrap">{s.name}</td>
                  <td className="px-3 py-2 text-neutral text-xs max-w-[220px] truncate" title={s.url}>{s.url}</td>
                  <td className="px-3 py-2 text-neutral text-xs">{s.category}</td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={() => removeSource(s.id)}
                      className="text-red-400 text-xs hover:text-red-300 transition-colors"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </Modal>
  )
}
