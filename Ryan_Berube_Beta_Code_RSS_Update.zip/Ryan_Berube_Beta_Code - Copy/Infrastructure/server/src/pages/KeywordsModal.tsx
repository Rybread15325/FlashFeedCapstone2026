'use client'
import useSWR, { useSWRConfig } from 'swr'
import { useState } from 'react'
import { clsx } from 'clsx'
import { Modal } from '@/components/shared/Modal'

const fetcher = (url: string) => fetch(url).then(r => r.json())

const CATEGORIES = ['general', 'fundamental', 'corporate', 'regulatory', 'analyst', 'legal', 'risk', 'macro']

interface KeywordItem {
  id: string
  word: string
  category: string
  active: boolean
}

interface Props {
  open: boolean
  onClose: () => void
}

export function KeywordsModal({ open, onClose }: Props) {
  const { mutate: globalMutate } = useSWRConfig()
  const { data, mutate } = useSWR(open ? '/api/settings/keywords' : null, fetcher)
  const [word, setWord] = useState('')
  const [category, setCategory] = useState('general')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const keywords: KeywordItem[] = data?.keywords ?? []

  // Refresh the highlight list on the News page after any change
  const refreshAll = () => { mutate(); globalMutate('/api/keywords') }

  const addKeyword = async () => {
    if (!word.trim()) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/settings/keywords', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word: word.trim(), category }),
      })
      const j = await res.json()
      if (!res.ok) { setError(j.error || 'Failed to add keyword'); return }
      setWord('')
      refreshAll()
    } catch {
      setError('Could not reach API')
    } finally {
      setLoading(false)
    }
  }

  const toggleActive = async (id: string, active: boolean) => {
    await fetch(`/api/settings/keywords/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active }),
    }).catch(() => {})
    refreshAll()
  }

  const remove = async (id: string) => {
    await fetch(`/api/settings/keywords/${id}`, { method: 'DELETE' }).catch(() => {})
    refreshAll()
  }

  return (
    <Modal open={open} onClose={onClose} title="Keywords" wide>
      <p className="text-neutral text-xs mb-3">
        Keywords pre-filter headlines before ML scoring. Only articles matching active keywords are prioritized.
      </p>

      {/* Add row */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <input
          value={word}
          onChange={e => { setWord(e.target.value); setError('') }}
          onKeyDown={e => e.key === 'Enter' && addKeyword()}
          placeholder="Keyword (e.g. Earnings)"
          className="flex-1 min-w-[160px] bg-bg border border-border text-sm text-white rounded px-3 py-2 focus:outline-none focus:border-accent placeholder:text-slate-600"
        />
        <select
          value={category}
          onChange={e => setCategory(e.target.value)}
          className="w-[140px] bg-bg border border-border text-sm text-neutral rounded px-3 py-2 focus:outline-none focus:border-accent"
        >
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button
          onClick={addKeyword}
          disabled={loading || !word.trim()}
          className="px-4 py-2 bg-accent text-white text-sm font-medium rounded hover:bg-sky-400 disabled:opacity-50 transition-colors"
        >
          {loading ? 'Adding...' : 'Add'}
        </button>
      </div>

      {error && <div className="text-red-400 text-xs mb-3">{error}</div>}

      {/* Keyword list */}
      <div className="bg-bg border border-border rounded-lg overflow-hidden">
        {!data ? (
          <div className="p-4 text-center text-neutral text-sm animate-pulse">Loading keywords...</div>
        ) : keywords.length === 0 ? (
          <div className="p-4 text-center text-neutral text-sm">No keywords configured.</div>
        ) : (
          <div className="divide-y divide-slate-700/30">
            {keywords.map(k => (
              <div key={k.id} className="flex items-center gap-3 px-3 py-2.5 hover:bg-card-hover">
                <button
                  onClick={() => toggleActive(k.id, !k.active)}
                  className={clsx(
                    'w-3 h-3 rounded-full border-2 flex-shrink-0 transition-colors',
                    k.active ? 'bg-bull border-bull' : 'bg-transparent border-slate-500'
                  )}
                  title={k.active ? 'Active — click to disable' : 'Inactive — click to enable'}
                />
                <span className={clsx('text-sm flex-1 truncate', k.active ? 'text-white' : 'text-neutral line-through')}>
                  {k.word}
                </span>
                <span className="text-xs border border-border text-neutral px-2 py-0.5 rounded flex-shrink-0">
                  {k.category}
                </span>
                <button
                  onClick={() => remove(k.id)}
                  className="text-red-400 text-xs hover:text-red-300 flex-shrink-0 px-1"
                  title="Remove keyword"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  )
}
