import assert from 'node:assert'
import {
  parseRssFeed, dictionarySentiment, extractTickers, matchKeywords,
  decodeEntities, fetchAllFeeds, DEFAULT_FEEDS, DEFAULT_KEYWORDS,
} from '../lib/rss.js'

let pass = 0
function check(name, fn) {
  try { fn(); pass++; console.log(`  ✓ ${name}`) }
  catch (e) { console.error(`  ✗ ${name}\n    ${e.message}`); process.exitCode = 1 }
}

// ─── Sample feeds ─────────────────────────────────────────────────────────────
const RSS2 = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
  <title>Test Feed</title>
  <item>
    <title><![CDATA[NVIDIA (NASDAQ: NVDA) beats earnings estimates, revenue surges 40%]]></title>
    <link>https://example.com/nvda-beats</link>
    <description><![CDATA[<p>Chipmaker <b>NVIDIA</b> posted record profit &amp; raised guidance.</p>]]></description>
    <pubDate>Wed, 10 Jun 2026 14:30:00 GMT</pubDate>
  </item>
  <item>
    <title>Acme Corp announces layoffs amid SEC investigation &amp; lawsuit</title>
    <link>https://example.com/acme-layoffs</link>
    <description>Workforce reduction of 5,000 jobs. $TSLA also mentioned here.</description>
    <pubDate>Wed, 10 Jun 2026 12:00:00 GMT</pubDate>
  </item>
  <item>
    <title>Quiet macro day: S&amp;P 500 little changed</title>
    <link>https://example.com/sp500-flat</link>
    <description>Markets steady.</description>
  </item>
  <item>
    <description>No title — should be skipped</description>
  </item>
</channel></rss>`

const ATOM = `<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>Atom Test</title>
  <entry>
    <title>Microsoft wins contract for cloud partnership with MSFT upside</title>
    <link rel="alternate" href="https://example.org/msft-contract"/>
    <summary>Big partnership deal announced. Dividend raised too.</summary>
    <updated>2026-06-10T10:00:00Z</updated>
  </entry>
  <entry>
    <title>Tariff probe deepens; bankruptcy fears at retailer</title>
    <link href="https://example.org/tariff-probe"/>
    <published>2026-06-10T09:00:00Z</published>
    <content type="html">&lt;p&gt;Recall and penalty risk grows.&lt;/p&gt;</content>
  </entry>
</feed>`

console.log('lib/rss.js unit tests')
console.log('─────────────────────')

// ─── Parser tests ─────────────────────────────────────────────────────────────
const rssArts = parseRssFeed(RSS2, 'TestSource', 'markets')
check('RSS2: parses 3 items, skips title-less item', () => assert.equal(rssArts.length, 3))
check('RSS2: CDATA title decoded', () =>
  assert.equal(rssArts[0].title, 'NVIDIA (NASDAQ: NVDA) beats earnings estimates, revenue surges 40%'))
check('RSS2: HTML stripped + entities decoded in content', () =>
  assert.ok(rssArts[0].content.includes('record profit & raised guidance') && !rssArts[0].content.includes('<b>')))
check('RSS2: entity in plain title decoded (&amp; → &)', () =>
  assert.ok(rssArts[2].title.includes('S&P 500')))
check('RSS2: pubDate parsed to unix seconds', () =>
  assert.equal(rssArts[0].publish_date, Math.floor(Date.parse('Wed, 10 Jun 2026 14:30:00 GMT') / 1000)))
check('RSS2: missing pubDate falls back to now', () =>
  assert.ok(Math.abs(rssArts[2].publish_date - Date.now() / 1000) < 5))
check('RSS2: source/category/url set', () => {
  assert.equal(rssArts[0].source, 'TestSource')
  assert.equal(rssArts[0].category, 'markets')
  assert.equal(rssArts[0].url, 'https://example.com/nvda-beats')
})

const atomArts = parseRssFeed(ATOM, 'AtomSource', 'economy')
check('Atom: parses 2 entries', () => assert.equal(atomArts.length, 2))
check('Atom: rel=alternate link extracted', () =>
  assert.equal(atomArts[0].url, 'https://example.org/msft-contract'))
check('Atom: plain link href extracted', () =>
  assert.equal(atomArts[1].url, 'https://example.org/tariff-probe'))
check('Atom: summary/content fallbacks work', () => {
  assert.ok(atomArts[0].content.includes('partnership deal'))
  assert.ok(atomArts[1].content.includes('Recall and penalty'))
})

// Stable IDs across separate parses (dedup correctness)
const again = parseRssFeed(RSS2, 'TestSource', 'markets')
check('IDs are stable across fetches (dedup-safe)', () => {
  assert.equal(rssArts[0].id, again[0].id)
  assert.equal(rssArts[2].id, again[2].id)
  assert.ok(rssArts[0].id.startsWith('rss-'))
})
check('Different URLs → different IDs', () =>
  assert.notEqual(rssArts[0].id, rssArts[1].id))

// ─── Sentiment tests ──────────────────────────────────────────────────────────
check('Sentiment: "beats earnings, surges" → bullish', () =>
  assert.equal(dictionarySentiment(rssArts[0].title, rssArts[0].content).sentiment, 'bullish'))
check('Sentiment: "layoffs, investigation, lawsuit" → bearish', () =>
  assert.equal(dictionarySentiment(rssArts[1].title, rssArts[1].content).sentiment, 'bearish'))
check('Sentiment: quiet macro → neutral', () =>
  assert.equal(dictionarySentiment(rssArts[2].title, rssArts[2].content).sentiment, 'neutral'))
check('Sentiment: confidence in [0,1]', () => {
  const { confidence } = dictionarySentiment(rssArts[0].title, rssArts[0].content)
  assert.ok(confidence > 0 && confidence <= 1)
})

// ─── Ticker extraction tests ──────────────────────────────────────────────────
check('Ticker: (NASDAQ: NVDA) pattern wins', () => {
  const r = extractTickers(rssArts[0].title, rssArts[0].content)
  assert.equal(r.ticker, 'NVDA')
  assert.equal(r.company, 'NVIDIA')
})
check('Ticker: $TSLA cashtag detected', () => {
  const r = extractTickers(rssArts[1].title, rssArts[1].content)
  assert.ok(r.tickers.includes('TSLA'))
})
check('Ticker: known symbol as whole word (MSFT)', () => {
  const r = extractTickers(atomArts[0].title, atomArts[0].content)
  assert.equal(r.ticker, 'MSFT')
  assert.equal(r.company, 'Microsoft')
})
check('Ticker: blacklist words never match (A, CEO, ALL, NOW as plain words)', () => {
  const r = extractTickers('A CEO said all is well for now and the deal is done', '')
  assert.ok(!r.tickers.includes('A') && !r.tickers.includes('CEO') && !r.tickers.includes('ALL'))
})
check('Ticker: none found → null', () => {
  const r = extractTickers('Quiet day in europe with nothing notable', '')
  assert.equal(r.ticker, null)
  assert.equal(r.company, null)
})

// ─── Keyword matching tests ───────────────────────────────────────────────────
const words = DEFAULT_KEYWORDS.map(k => k.word)
check('Keywords: Earnings + Beat matched (case-insensitive)', () => {
  const hits = matchKeywords(rssArts[0].title, rssArts[0].content, words)
  assert.ok(hits.includes('Earnings'))
  assert.ok(hits.includes('Beat'))
})
check('Keywords: Layoffs + Investigation + Lawsuit + SEC matched', () => {
  const hits = matchKeywords(rssArts[1].title, rssArts[1].content, words)
  for (const w of ['Layoffs', 'Investigation', 'Lawsuit', 'SEC']) assert.ok(hits.includes(w), `missing ${w}`)
})
check('Keywords: no match on quiet headline', () => {
  const hits = matchKeywords('Calm trading session continues', '', words)
  assert.equal(hits.length, 0)
})
check('Keywords: suffix-aware — "Beat" does not match "Beaten"', () => {
  const hits = matchKeywords('Beaten-down stocks recover', '', ['Beat'])
  assert.equal(hits.length, 0)
})
check('Keywords: suffix-aware — "Beat" matches "beats"', () => {
  const hits = matchKeywords('Apple beats expectations', '', ['Beat'])
  assert.deepEqual(hits, ['Beat'])
})
check('Keywords: e-drop — "Upgrade" matches "upgrading" and "upgraded"', () => {
  assert.deepEqual(matchKeywords('Analysts upgrading the stock', '', ['Upgrade']), ['Upgrade'])
  assert.deepEqual(matchKeywords('Shares upgraded to Buy', '', ['Upgrade']), ['Upgrade'])
})
check('Keywords: suffix-aware — "Miss" matches "missed" but never "mission"', () => {
  assert.deepEqual(matchKeywords('Company missed revenue estimates', '', ['Miss']), ['Miss'])
  assert.equal(matchKeywords('NASA mission launches today', '', ['Miss']).length, 0)
})

// ─── Entity decoder ───────────────────────────────────────────────────────────
check('Entities: numeric + hex + named', () =>
  assert.equal(decodeEntities('S&amp;P &#8212; up &#x2191; &quot;hi&quot;'), 'S&P — up ↑ "hi"'))

// ─── fetchAllFeeds against a local HTTP server ───────────────────────────────
import { createServer } from 'node:http'

const server = createServer((req, res) => {
  if (req.url === '/rss')  { res.writeHead(200, { 'Content-Type': 'application/rss+xml' }); res.end(RSS2) }
  else if (req.url === '/atom') { res.writeHead(200, { 'Content-Type': 'application/atom+xml' }); res.end(ATOM) }
  else if (req.url === '/slow') { /* never responds → timeout path */ }
  else { res.writeHead(404); res.end('nope') }
})
await new Promise(r => server.listen(0, '127.0.0.1', r))
const port = server.address().port
const base = `http://127.0.0.1:${port}`

const result = await fetchAllFeeds([
  { name: 'LocalRSS',  url: `${base}/rss`,  category: 'markets' },
  { name: 'LocalAtom', url: `${base}/atom`, category: 'economy' },
  { name: 'Broken404', url: `${base}/missing`, category: 'general' },
  { name: 'Timeout',   url: `${base}/slow`, category: 'general' },
], { timeoutMs: 1500 })

check('fetchAllFeeds: 5 articles from 2 good feeds', () => assert.equal(result.articles.length, 5))
check('fetchAllFeeds: 2 errors counted (404 + timeout), good feeds unaffected', () => {
  assert.equal(result.errors, 2)
  assert.equal(result.errorDetails.length, 2)
})
check('fetchAllFeeds: per-source counts', () => {
  assert.equal(result.perSource['LocalRSS'], 3)
  assert.equal(result.perSource['LocalAtom'], 2)
})
check('DEFAULT_FEEDS has the 28 feeds from the previous FlashFeed', () =>
  assert.equal(DEFAULT_FEEDS.length, 28))
check('DEFAULT_KEYWORDS has the 30 seed keywords', () =>
  assert.equal(DEFAULT_KEYWORDS.length, 30))

server.close()
console.log(`\n${pass} checks passed${process.exitCode ? ' (with FAILURES above)' : ' — all good ✓'}`)
