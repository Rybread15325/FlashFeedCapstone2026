// Integration test — boots the REAL routers (articles, settings, fetch) exactly
// as index.js mounts them, against in-memory fake models and two local RSS/Atom
// feeds. No MongoDB or internet needed. Run: node itest/run.mjs
import assert from 'node:assert/strict'
import http from 'node:http'
import express from 'express'

import articlesRouter from './routes/articles.js'
import settingsRouter from './routes/settings.js'
import fetchRouter from './routes/fetch.js'

// ─── Local feed fixtures ──────────────────────────────────────────────────────
const RSS = `<?xml version="1.0"?>
<rss version="2.0"><channel><title>LocalWire</title>
<item>
  <title><![CDATA[NVIDIA (NASDAQ: NVDA) beats earnings estimates, revenue surges 40%]]></title>
  <link>https://example.com/nvda-beats</link>
  <pubDate>Wed, 10 Jun 2026 14:00:00 GMT</pubDate>
  <description>Blowout quarter as data-center demand accelerates.</description>
</item>
<item>
  <title>SEC opens investigation into Acme lawsuit as layoffs follow</title>
  <link>https://example.com/acme-sec</link>
  <pubDate>Wed, 10 Jun 2026 13:00:00 GMT</pubDate>
  <description>Regulators probe disclosures.</description>
</item>
<item>
  <title>Calm trading session continues in Asia</title>
  <link>https://example.com/calm</link>
  <pubDate>Wed, 10 Jun 2026 12:00:00 GMT</pubDate>
  <description>Quiet day across the region.</description>
</item>
</channel></rss>`

const ATOM = `<?xml version="1.0"?>
<feed xmlns="http://www.w3.org/2005/Atom"><title>LocalAtom</title>
<entry>
  <title>$TSLA announces $5B buyback program</title>
  <link rel="alternate" href="https://example.com/tsla-buyback"/>
  <updated>2026-06-10T11:00:00Z</updated>
  <summary>Board approves repurchase plan.</summary>
</entry>
<entry>
  <title>Treasury yields drift lower ahead of auction</title>
  <link href="https://example.com/yields"/>
  <updated>2026-06-10T10:00:00Z</updated>
  <summary>Bond markets steady.</summary>
</entry>
</feed>`

// ─── Tiny test runner ─────────────────────────────────────────────────────────
let passed = 0
const failures = []
async function check(name, fn) {
  try { await fn(); passed++; console.log(`  ✓ ${name}`) }
  catch (e) { failures.push(name); console.log(`  ✗ ${name}\n    ${e.message}`) }
}

const j = (r) => r.json()

async function main() {
  // 1. Feed server
  const feedSrv = http.createServer((req, res) => {
    if (req.url === '/a.xml') { res.writeHead(200, { 'content-type': 'application/rss+xml' }); res.end(RSS) }
    else if (req.url === '/b.xml') { res.writeHead(200, { 'content-type': 'application/atom+xml' }); res.end(ATOM) }
    else { res.writeHead(404); res.end() }
  })
  await new Promise(r => feedSrv.listen(0, '127.0.0.1', r))
  const feedBase = `http://127.0.0.1:${feedSrv.address().port}`

  // 2. App wired exactly like index.js (relevant routers, same paths & order)
  const app = express()
  app.use(express.json({ limit: '2mb' }))
  app.use('/api/articles', articlesRouter)
  app.use('/api/settings', settingsRouter)
  app.use('/api', fetchRouter)
  const srv = http.createServer(app)
  await new Promise(r => srv.listen(0, '127.0.0.1', r))
  const base = `http://127.0.0.1:${srv.address().port}`
  const api = (p, opts) => fetch(base + p, opts)
  const post = (p, body) => api(p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  const patch = (p, body) => api(p, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  const del = (p) => api(p, { method: 'DELETE' })

  console.log('Integration: routers + fake models + local feeds')
  console.log('────────────────────────────────────────────────')

  // ── Sources: seeding + CRUD ────────────────────────────────────────────────
  let sources
  await check('GET /api/sources seeds the 28 default feeds on first call', async () => {
    sources = (await j(await api('/api/sources'))).sources
    assert.equal(sources.length, 28)
    assert.ok(sources.every(s => s.id && s.name && s.url && s.active === true))
  })

  await check('PATCH /api/sources/:id can deactivate every default', async () => {
    for (const s of sources) {
      const r = await patch(`/api/sources/${s.id}`, { active: false })
      assert.equal(r.status, 200)
    }
    const after = (await j(await api('/api/sources'))).sources
    assert.ok(after.every(s => s.active === false))
  })

  await check('POST /api/sources adds the two local feeds', async () => {
    const r1 = await post('/api/sources', { name: 'LocalWire', url: `${feedBase}/a.xml`, category: 'markets' })
    const r2 = await post('/api/sources', { name: 'LocalAtom', url: `${feedBase}/b.xml`, category: 'equities' })
    assert.equal(r1.status, 200); assert.equal(r2.status, 200)
    const d1 = await j(r1)
    assert.equal(d1.success, true)
    assert.equal(d1.source.name, 'LocalWire')
  })

  await check('POST /api/sources rejects duplicate name with 409', async () => {
    const r = await post('/api/sources', { name: 'LocalWire', url: 'https://elsewhere.example/feed' })
    assert.equal(r.status, 409)
  })

  await check('POST /api/sources rejects duplicate URL with 409', async () => {
    const r = await post('/api/sources', { name: 'Different Name', url: `${feedBase}/a.xml` })
    assert.equal(r.status, 409)
  })

  await check('POST /api/sources rejects missing fields with 400', async () => {
    assert.equal((await post('/api/sources', { name: 'NoUrl' })).status, 400)
  })

  // ── Fetch cycle ────────────────────────────────────────────────────────────
  let fetchResult
  await check('POST /api/fetch pulls 5 articles from the 2 active local feeds', async () => {
    const r = await post('/api/fetch', {})
    assert.equal(r.status, 200)
    fetchResult = await j(r)
    assert.equal(fetchResult.success, true)
    assert.equal(fetchResult.new_articles, 5)
    assert.equal(fetchResult.duplicates, 0)
    assert.equal(fetchResult.errors, 0)
    assert.equal(fetchResult.feeds, 2)
    assert.equal(fetchResult.total, 5)
    assert.ok(typeof fetchResult.ms === 'number')
  })

  await check('Second POST /api/fetch is fully deduplicated (0 new, 5 dups)', async () => {
    const r2 = await j(await post('/api/fetch', {}))
    assert.equal(r2.new_articles, 0)
    assert.equal(r2.duplicates, 5)
    assert.equal(r2.total, 5)
  })

  await check('Fetch updated per-source last_fetch and article_count', async () => {
    const after = (await j(await api('/api/sources'))).sources
    const wire = after.find(s => s.name === 'LocalWire')
    const atom = after.find(s => s.name === 'LocalAtom')
    assert.equal(wire.article_count, 3)
    assert.equal(atom.article_count, 2)
    assert.ok(wire.last_fetch)
  })

  // ── Articles listing ───────────────────────────────────────────────────────
  let arts
  await check('GET /api/articles returns 5 mapped articles, newest first', async () => {
    const d = await j(await api('/api/articles'))
    arts = d.articles
    assert.equal(d.total, 5)
    assert.equal(arts.length, 5)
    assert.ok(arts.every(a => a.id && a.title && typeof a.publish_date === 'number'))
    const dates = arts.map(a => a.publish_date)
    assert.deepEqual(dates, [...dates].sort((x, y) => y - x))
    assert.equal(arts[0].title.includes('NVIDIA'), true)
  })

  await check('Enrichment: NVDA article got ticker/sentiment/keywords', async () => {
    const nvda = arts.find(a => a.title.includes('NVIDIA'))
    assert.equal(nvda.ticker, 'NVDA')
    assert.equal(nvda.sentiment, 'bullish')
    assert.ok(nvda.keyword_match.includes('Earnings'))
    assert.ok(nvda.keyword_match.includes('Beat'))
    assert.ok(nvda.ml_confidence > 0 && nvda.ml_confidence <= 1)
  })

  await check('Enrichment: SEC/lawsuit article is bearish with keyword hits', async () => {
    const acme = arts.find(a => a.title.includes('Acme'))
    assert.equal(acme.sentiment, 'bearish')
    for (const w of ['SEC', 'Investigation', 'Lawsuit', 'Layoffs']) {
      assert.ok(acme.keyword_match.includes(w), `missing ${w}`)
    }
  })

  await check('Enrichment: $TSLA cashtag extracted, Buyback matched', async () => {
    const tsla = arts.find(a => a.title.includes('TSLA'))
    assert.equal(tsla.ticker, 'TSLA')
    assert.ok(tsla.keyword_match.includes('Buyback'))
  })

  await check('GET /api/articles?keywords_only=1 returns only keyword-matched', async () => {
    const d = await j(await api('/api/articles?keywords_only=1'))
    assert.equal(d.total, 3)
    assert.ok(d.articles.every(a => a.keyword_match.length > 0))
    assert.ok(!d.articles.some(a => a.title.includes('Calm trading')))
  })

  await check('GET /api/articles?search=nvidia matches case-insensitively', async () => {
    const d = await j(await api('/api/articles?search=nvidia'))
    assert.equal(d.total, 1)
    assert.ok(d.articles[0].title.includes('NVIDIA'))
  })

  await check('GET /api/articles?category=markets returns the 3 RSS items', async () => {
    const d = await j(await api('/api/articles?category=markets'))
    assert.equal(d.total, 3)
    assert.ok(d.articles.every(a => a.category === 'markets'))
  })

  await check('GET /api/articles?limit=2&offset=2 paginates with skip echo', async () => {
    const page = await j(await api('/api/articles?limit=2&offset=2'))
    assert.equal(page.articles.length, 2)
    assert.equal(page.total, 5)
    assert.equal(page.skip, 2)
    const all = await j(await api('/api/articles?limit=50'))
    assert.equal(page.articles[0].id, all.articles[2].id)
  })

  await check('GET /api/articles/:id returns one article', async () => {
    const one = await j(await api(`/api/articles/${arts[0].id}`))
    assert.equal(one.title, arts[0].title)
  })

  // ── Stats ──────────────────────────────────────────────────────────────────
  await check('GET /api/stats groups by source and category, sorted', async () => {
    const d = await j(await api('/api/stats'))
    assert.deepEqual(d.sources.map(s => s.source), ['LocalWire', 'LocalAtom'])
    assert.deepEqual(d.sources.map(s => s.count), [3, 2])
    const mk = d.categories.find(c => c.category === 'markets')
    assert.equal(mk.count, 3)
  })

  // ── Keywords CRUD (popup API: /api/settings/keywords) ─────────────────────
  let kw
  await check('GET /api/settings/keywords lists the 30 seeded keywords', async () => {
    kw = (await j(await api('/api/settings/keywords'))).keywords
    assert.equal(kw.length, 30)
    assert.ok(kw.every(k => k.id && k.word && k.category && k.active === true))
    // sorted by category then word
    const key = k => `${k.category}~${k.word}`
    assert.deepEqual(kw.map(key), [...kw].sort((a, b) => key(a) < key(b) ? -1 : 1).map(key))
  })

  let added
  await check('POST /api/settings/keywords adds a new keyword', async () => {
    const r = await post('/api/settings/keywords', { word: 'Stablecoin', category: 'crypto' })
    assert.equal(r.status, 200)
    added = (await j(r)).keyword
    assert.equal(added.word, 'Stablecoin')
    assert.equal(added.category, 'crypto')
  })

  await check('POST duplicate keyword → 409 (case-insensitive)', async () => {
    assert.equal((await post('/api/settings/keywords', { word: 'stablecoin' })).status, 409)
    assert.equal((await post('/api/settings/keywords', { word: 'EARNINGS' })).status, 409)
  })

  await check('GET /api/keywords (highlight feed) includes active words only', async () => {
    const d = await j(await api('/api/keywords'))
    assert.ok(d.keywords.some(k => k.keyword === 'Stablecoin'))
    assert.equal(d.keywords.length, 31)
    assert.ok(d.keywords.every(k => typeof k.keyword === 'string' && k.category))
  })

  await check('PATCH /api/settings/keywords/:id deactivates; highlight feed drops it', async () => {
    const r = await patch(`/api/settings/keywords/${added.id}`, { active: false })
    assert.equal(r.status, 200)
    const d = await j(await api('/api/keywords'))
    assert.ok(!d.keywords.some(k => k.keyword === 'Stablecoin'))
    assert.equal(d.keywords.length, 30)
  })

  await check('DELETE /api/settings/keywords/:id removes it from the full list', async () => {
    assert.equal((await del(`/api/settings/keywords/${added.id}`)).status, 200)
    const after = (await j(await api('/api/settings/keywords'))).keywords
    assert.equal(after.length, 30)
    assert.ok(!after.some(k => k.word === 'Stablecoin'))
  })

  await check('PATCH/DELETE unknown keyword id → 404', async () => {
    assert.equal((await patch('/api/settings/keywords/nope123', { active: true })).status, 404)
    assert.equal((await del('/api/settings/keywords/nope123')).status, 404)
  })

  // ── Source deletion ────────────────────────────────────────────────────────
  await check('DELETE /api/sources/:id removes a source', async () => {
    const list = (await j(await api('/api/sources'))).sources
    const victim = list.find(s => s.name === 'LocalAtom')
    assert.equal((await del(`/api/sources/${victim.id}`)).status, 200)
    const after = (await j(await api('/api/sources'))).sources
    assert.equal(after.length, list.length - 1)
    assert.ok(!after.some(s => s.name === 'LocalAtom'))
  })

  // ── Misc endpoints the TopBar uses ─────────────────────────────────────────
  await check('GET /api/status and /api/market/status respond', async () => {
    const s = await j(await api('/api/status'))
    assert.equal(s.ok, true)
    assert.equal(s.database.articles, 5)
    const m = await api('/api/market/status')
    assert.equal(m.status, 200)
  })

  // ── SSE watch mode ─────────────────────────────────────────────────────────
  await check('GET /api/watch streams SSE start + cycle lines ("new articles")', async () => {
    const { text, ctype } = await new Promise((resolve, reject) => {
      const req = http.get(`${base}/api/watch?interval=10`, res => {
        const ctype = res.headers['content-type'] || ''
        let buf = ''
        const timer = setTimeout(() => { req.destroy(); resolve({ text: buf, ctype }) }, 4000)
        res.on('data', c => {
          buf += c
          if (buf.includes('new articles')) { clearTimeout(timer); req.destroy(); resolve({ text: buf, ctype }) }
        })
        res.on('error', () => { clearTimeout(timer); resolve({ text: buf, ctype }) })
      })
      req.on('error', e => (e.code === 'ECONNRESET' ? resolve({ text: '', ctype: '' }) : reject(e)))
    })
    assert.ok(ctype.startsWith('text/event-stream'), `bad content-type: ${ctype}`)
    assert.ok(text.includes('event: start'))
    assert.ok(text.includes('Watch mode starting'))
    assert.ok(text.includes('event: line'))
    assert.ok(text.includes('new articles'))
  })

  feedSrv.close(); srv.close()
  console.log(`\n${passed} checks passed${failures.length ? ` — ${failures.length} FAILED: ${failures.join(', ')}` : ' — all good ✓'}`)
  process.exit(failures.length ? 1 : 0)
}

main().catch(e => { console.error('HARNESS CRASH:', e); process.exit(1) })
