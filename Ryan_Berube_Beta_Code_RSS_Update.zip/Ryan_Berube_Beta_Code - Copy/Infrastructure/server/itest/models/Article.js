import { makeModel } from './_fakeModel.js'
export default makeModel('Article', {})
