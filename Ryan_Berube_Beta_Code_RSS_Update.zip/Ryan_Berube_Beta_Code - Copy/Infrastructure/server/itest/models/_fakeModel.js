// In-memory stand-in for the Mongoose models, implementing exactly the
// query surface used by routes/articles.js, routes/fetch.js, routes/settings.js
// and lib/rss.js (seedDefaultsIfEmpty). Used ONLY by the integration test
// harness — the real app keeps the real Mongoose models.

let idCounter = 1
const nextId = () => `fid${String(idCounter++).padStart(8, '0')}`

const clone = d => (d == null ? d : structuredClone(d))

function getPath(obj, path) {
  return String(path).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj)
}
function setPath(obj, path, value) {
  const keys = String(path).split('.')
  let o = obj
  for (let i = 0; i < keys.length - 1; i++) {
    if (o[keys[i]] == null || typeof o[keys[i]] !== 'object') o[keys[i]] = {}
    o = o[keys[i]]
  }
  o[keys[keys.length - 1]] = value
}

function eq(a, b) {
  if (a instanceof Date || b instanceof Date) {
    return new Date(a).getTime() === new Date(b).getTime()
  }
  return a === b
}

function matchCond(val, cond) {
  if (cond instanceof RegExp) return typeof val === 'string' && cond.test(val)
  if (cond !== null && typeof cond === 'object' && !Array.isArray(cond) && !(cond instanceof Date)) {
    for (const [op, arg] of Object.entries(cond)) {
      switch (op) {
        case '$ne':     if (eq(val, arg)) return false; break
        case '$exists': if ((val !== undefined) !== !!arg) return false; break
        case '$gte':    if (!(val >= arg)) return false; break
        case '$lte':    if (!(val <= arg)) return false; break
        case '$gt':     if (!(val > arg)) return false; break
        case '$lt':     if (!(val < arg)) return false; break
        case '$in':     if (!Array.isArray(arg) || !arg.some(a => eq(val, a))) return false; break
        case '$regex': {
          const re = arg instanceof RegExp ? arg : new RegExp(arg, cond.$options || '')
          if (typeof val !== 'string' || !re.test(val)) return false
          break
        }
        case '$options': break // consumed by $regex
        default: throw new Error(`fake model: unsupported query operator "${op}"`)
      }
    }
    return true
  }
  return eq(val, cond)
}

function matches(doc, filter = {}) {
  for (const [key, cond] of Object.entries(filter)) {
    if (key === '_id') {
      if (String(doc._id) !== String(cond)) return false
      continue
    }
    if (!matchCond(getPath(doc, key), cond)) return false
  }
  return true
}

function cmpVals(a, b) {
  const av = a instanceof Date ? a.getTime() : a
  const bv = b instanceof Date ? b.getTime() : b
  if (av === bv) return 0
  if (av === undefined || av === null) return -1
  if (bv === undefined || bv === null) return 1
  return av < bv ? -1 : 1
}

function sortDocs(docs, spec) {
  const keys = Object.entries(spec)
  return [...docs].sort((a, b) => {
    for (const [k, dir] of keys) {
      const c = cmpVals(getPath(a, k), getPath(b, k))
      if (c !== 0) return dir < 0 ? -c : c
    }
    return 0
  })
}

function applyUpdate(doc, update = {}) {
  let modified = false
  if (update.$set) {
    for (const [k, v] of Object.entries(update.$set)) { setPath(doc, k, clone(v)); modified = true }
  }
  if (update.$inc) {
    for (const [k, v] of Object.entries(update.$inc)) { setPath(doc, k, (getPath(doc, k) || 0) + v); modified = true }
  }
  if (modified) doc.updatedAt = new Date()
  return modified
}

class Query {
  constructor(run) { this._run = run; this._sort = null; this._skip = 0; this._limit = Infinity }
  sort(s)  { this._sort = s; return this }
  skip(n)  { this._skip = Math.max(0, Number(n) || 0); return this }
  limit(n) { const x = Number(n); this._limit = x > 0 ? x : Infinity; return this }
  lean()   { return this }
  exec()   { return Promise.resolve(this._run(this)) }
  then(onF, onR) { return this.exec().then(onF, onR) }
  catch(onR)     { return this.exec().catch(onR) }
}

export function makeModel(name, defaults = {}) {
  const docs = []

  const insertDoc = (data) => {
    const now = new Date()
    const doc = { ...clone(defaults), ...clone(data), _id: nextId(), createdAt: now, updatedAt: now }
    docs.push(doc)
    return doc
  }

  return {
    modelName: name,

    find(filter = {}) {
      return new Query(q => {
        let r = docs.filter(d => matches(d, filter))
        if (q._sort) r = sortDocs(r, q._sort)
        r = r.slice(q._skip, q._limit === Infinity ? undefined : q._skip + q._limit)
        return r.map(clone)
      })
    },

    findOne(filter = {}) {
      return new Query(() => clone(docs.find(d => matches(d, filter)) ?? null))
    },

    countDocuments(filter = {}) {
      return Promise.resolve(docs.filter(d => matches(d, filter)).length)
    },

    estimatedDocumentCount() {
      return Promise.resolve(docs.length)
    },

    insertMany(arr, _opts) {
      return Promise.resolve(arr.map(d => clone(insertDoc(d))))
    },

    create(data) {
      return Promise.resolve(clone(insertDoc(data)))
    },

    findByIdAndUpdate(id, update, _opts) {
      const doc = docs.find(d => String(d._id) === String(id))
      if (!doc) return Promise.resolve(null)
      applyUpdate(doc, update)
      return Promise.resolve(clone(doc))
    },

    findByIdAndDelete(id) {
      const i = docs.findIndex(d => String(d._id) === String(id))
      if (i === -1) return Promise.resolve(null)
      const [removed] = docs.splice(i, 1)
      return Promise.resolve(clone(removed))
    },

    updateOne(filter, update) {
      const doc = docs.find(d => matches(d, filter))
      if (!doc) return Promise.resolve({ matchedCount: 0, modifiedCount: 0 })
      const modified = applyUpdate(doc, update)
      return Promise.resolve({ matchedCount: 1, modifiedCount: modified ? 1 : 0 })
    },

    bulkWrite(ops, _opts) {
      let upsertedCount = 0, modifiedCount = 0, matchedCount = 0
      for (const op of ops) {
        const u = op.updateOne
        if (!u) throw new Error('fake model: only updateOne bulk ops are supported')
        const doc = docs.find(d => matches(d, u.filter))
        if (doc) {
          matchedCount++
          if (u.update.$set && applyUpdate(doc, { $set: u.update.$set })) modifiedCount++
          // $setOnInsert is intentionally a no-op on matched docs (Mongo semantics)
        } else if (u.upsert) {
          const seed = {}
          for (const [k, v] of Object.entries(u.filter)) {
            if (v === null || typeof v !== 'object' || v instanceof Date) seed[k] = v
          }
          insertDoc({ ...seed, ...(u.update.$setOnInsert || {}), ...(u.update.$set || {}) })
          upsertedCount++
        }
      }
      return Promise.resolve({ upsertedCount, modifiedCount, matchedCount })
    },

    aggregate(pipeline) {
      let rows = docs.map(clone)
      for (const stage of pipeline) {
        if (stage.$group) {
          const { _id: idExpr, ...accs } = stage.$group
          const field = String(idExpr).startsWith('$') ? String(idExpr).slice(1) : null
          const groups = new Map()
          for (const r of rows) {
            const key = field ? getPath(r, field) : idExpr
            const mk = key === undefined ? '__undefined__' : JSON.stringify(key)
            if (!groups.has(mk)) groups.set(mk, { _id: key === undefined ? null : key, __rows: [] })
            groups.get(mk).__rows.push(r)
          }
          rows = [...groups.values()].map(g => {
            const out = { _id: g._id }
            for (const [accName, accSpec] of Object.entries(accs)) {
              if (accSpec.$sum !== undefined) {
                out[accName] = typeof accSpec.$sum === 'number'
                  ? g.__rows.length * accSpec.$sum
                  : g.__rows.reduce((s, r) => s + (Number(getPath(r, String(accSpec.$sum).slice(1))) || 0), 0)
              } else {
                throw new Error(`fake model: unsupported accumulator in $group: ${accName}`)
              }
            }
            return out
          })
        } else if (stage.$sort) {
          rows = sortDocs(rows, stage.$sort)
        } else {
          throw new Error(`fake model: unsupported aggregate stage ${Object.keys(stage)[0]}`)
        }
      }
      return Promise.resolve(rows)
    },

    // Test helpers
    __reset() { docs.length = 0 },
    __all()   { return docs.map(clone) },
  }
}
