import { makeModel } from './_fakeModel.js'
export default makeModel('Source', { category: 'general', active: true, article_count: 0 })
