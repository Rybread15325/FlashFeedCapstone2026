import { makeModel } from './_fakeModel.js'
export default makeModel('Keyword', { category: 'general', active: true, hits: 0 })
