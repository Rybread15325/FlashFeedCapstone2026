import { Router } from 'express'
import Keyword from '../models/Keyword.js'
import { seedDefaultsIfEmpty, escapeRegex } from '../lib/rss.js'

const router  = Router()
let settings  = { refreshInterval: 60, sentimentThreshold: 0.2 }

router.get('/',  (req, res) => res.json(settings))
router.post('/', (req, res) => {
  settings = { ...settings, ...req.body }
  res.json({ ok: true, settings })
})

// ─── Keyword management (used by the Keywords popup on the News page) ────────
// Same API shape as the previous FlashFeed: /api/settings/keywords

// GET /api/settings/keywords — full list (seeds the 30 defaults on first run)
router.get('/keywords', async (req, res) => {
  try {
    await seedDefaultsIfEmpty(null, Keyword)
    const docs = await Keyword.find().sort({ category: 1, word: 1 }).lean()
    res.json({
      keywords: docs.map(k => ({
        id:       String(k._id),
        word:     k.word,
        category: k.category || 'general',
        active:   k.active !== false,
        hits:     k.hits || 0,
      })),
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/settings/keywords — add { word, category }
router.post('/keywords', async (req, res) => {
  try {
    const { word, category = 'general' } = req.body || {}
    if (!word?.trim()) return res.status(400).json({ error: 'word is required' })
    await seedDefaultsIfEmpty(null, Keyword)

    const clean = word.trim()
    const exists = await Keyword.findOne({ word: { $regex: `^${escapeRegex(clean)}$`, $options: 'i' } })
    if (exists) return res.status(409).json({ error: 'Keyword already exists' })

    const doc = await Keyword.create({
      word: clean,
      category: (category || 'general').trim() || 'general',
      active: true,
    })
    res.json({
      success: true,
      keyword: { id: String(doc._id), word: doc.word, category: doc.category, active: true },
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// PATCH /api/settings/keywords/:id — toggle { active }
router.patch('/keywords/:id', async (req, res) => {
  try {
    const { active } = req.body || {}
    const doc = await Keyword.findByIdAndUpdate(req.params.id, { $set: { active: !!active } }, { new: true })
    if (!doc) return res.status(404).json({ error: 'Keyword not found' })
    res.json({ success: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// DELETE /api/settings/keywords/:id
router.delete('/keywords/:id', async (req, res) => {
  try {
    const doc = await Keyword.findByIdAndDelete(req.params.id)
    if (!doc) return res.status(404).json({ error: 'Keyword not found' })
    res.json({ success: true, removed: doc.word })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
