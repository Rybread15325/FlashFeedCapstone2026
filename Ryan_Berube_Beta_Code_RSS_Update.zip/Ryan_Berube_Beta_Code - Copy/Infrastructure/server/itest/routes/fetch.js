import { Router } from 'express'
import Article    from '../models/Article.js'
import Source     from '../models/Source.js'
import Keyword    from '../models/Keyword.js'
import {
  fetchAllFeeds, dictionarySentiment, extractTickers, matchKeywords,
  seedDefaultsIfEmpty,
} from '../lib/rss.js'

const router = Router()

// ─── Core fetch cycle: pull every active RSS source → MongoDB ─────────────────
// (Replaces the old Claude-generated mock articles with REAL articles from the
//  internet, using the same RSS pipeline the previous FlashFeed used.)
async function runFetchCycle() {
  const t0 = Date.now()

  // First run ever? Seed the default feed + keyword lists.
  await seedDefaultsIfEmpty(Source, Keyword)

  const sources = await Source.find({ active: { $ne: false } }).lean()
  const keywordDocs = await Keyword.find({ active: { $ne: false } }).lean()
  const activeWords = keywordDocs.map(k => k.word)

  if (!sources.length) {
    return { success: true, new_articles: 0, duplicates: 0, errors: 0, total: await Article.countDocuments(), ms: Date.now() - t0, feeds: 0 }
  }

  // 1. Download + parse all feeds (5 at a time, 15 s timeout each)
  const { articles, errors, errorDetails } = await fetchAllFeeds(
    sources.map(s => ({ name: s.name || s.url, url: s.url, category: s.category || 'general' }))
  )

  // 2. Enrich: ticker extraction, dictionary sentiment, keyword matches
  const enriched = articles.map(a => {
    const { ticker, company } = extractTickers(a.title, a.content)
    const { sentiment, confidence } = dictionarySentiment(a.title, a.content)
    const keyword_match = matchKeywords(a.title, a.content, activeWords)
    return { ...a, ticker, company, sentiment, ml_confidence: confidence, keyword_match }
  })

  // 3. Upsert into MongoDB ($setOnInsert so re-fetches never clobber existing docs)
  let newCount = 0
  if (enriched.length) {
    const ops = enriched.map(a => ({
      updateOne: {
        filter: { article_id: a.id },
        update: {
          $setOnInsert: {
            article_id:    a.id,
            title:         a.title,
            content:       a.content || undefined,
            url:           a.url || '#',
            source:        a.source,
            category:      a.category,
            publish_date:  new Date(a.publish_date * 1000),
            fetched_date:  new Date(a.fetched_date * 1000),
            ticker:        a.ticker || undefined,
            company:       a.company || undefined,
            sentiment:     a.sentiment,
            ml_confidence: a.ml_confidence,
            keyword_match: a.keyword_match,
          },
        },
        upsert: true,
      },
    }))
    const result = await Article.bulkWrite(ops, { ordered: false })
    newCount = result.upsertedCount ?? 0
  }

  const duplicates = Math.max(0, enriched.length - newCount)
  const total = await Article.countDocuments()

  // 4. Update per-source bookkeeping (last_fetch + article_count) — best effort
  Promise.allSettled(sources.map(async (s) => {
    const count = await Article.countDocuments({ source: s.name || s.url })
    await Source.updateOne({ _id: s._id }, { $set: { last_fetch: new Date(), article_count: count } })
  })).catch(() => {})

  return {
    success: true,
    new_articles: newCount,
    duplicates,
    errors,
    error_details: errorDetails,
    total,
    feeds: sources.length,
    ms: Date.now() - t0,
  }
}

// ─── POST /api/fetch — pull real articles from all active RSS sources ────────
router.post('/fetch', async (req, res) => {
  try {
    const result = await runFetchCycle()
    res.json(result)
  } catch (err) {
    res.status(500).json({ success: false, error: err.message })
  }
})

// ─── GET /api/watch?interval=60 — SSE loop: fetch every N seconds ────────────
// Powers the "Auto" button in the top bar.
router.get('/watch', (req, res) => {
  const raw = parseInt(req.query.interval ?? '60', 10)
  const intervalSec = Math.max(10, Math.min(3600, isNaN(raw) ? 60 : raw))

  res.set({
    'Content-Type':  'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection':    'keep-alive',
    'X-Accel-Buffering': 'no',
  })
  res.flushHeaders?.()

  const send = (event, data) => {
    try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`) } catch { /* client gone */ }
  }

  let closed = false
  let timer = null
  let cycle = 0

  const stop = () => {
    closed = true
    if (timer) clearTimeout(timer)
    try { res.end() } catch {}
  }
  req.on('close', stop)

  send('start', { message: `Watch mode starting — fetching every ${intervalSec}s…`, ts: Date.now() })

  const loop = async () => {
    if (closed) return
    cycle++
    send('line', { text: `Cycle #${cycle} — fetching RSS feeds…`, ts: Date.now() })
    try {
      const r = await runFetchCycle()
      send('line', {
        text: `Cycle #${cycle} complete — ${r.new_articles} new articles, ${r.duplicates} duplicates, ${r.errors} errors (${(r.ms / 1000).toFixed(1)}s) · ${r.total} total`,
        ts: Date.now(),
      })
    } catch (e) {
      send('line', { text: `Cycle #${cycle} failed: ${e.message}`, ts: Date.now() })
    }
    if (!closed) timer = setTimeout(loop, intervalSec * 1000)
  }
  loop()
})

// ─── Sources management (used by the Sources popup on the News page) ─────────

// GET /api/sources — list all RSS sources (seeds defaults on first run)
router.get('/sources', async (req, res) => {
  try {
    await seedDefaultsIfEmpty(Source, null)
    const docs = await Source.find().sort({ createdAt: 1 }).lean()
    res.json({
      sources: docs.map(s => ({
        id:            String(s._id),
        name:          s.name || s.url,
        url:           s.url,
        category:      s.category || 'general',
        active:        s.active !== false,
        last_fetch:    s.last_fetch || null,
        article_count: s.article_count || 0,
      })),
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/sources — add a new RSS source
router.post('/sources', async (req, res) => {
  try {
    const { name, url, category = 'general' } = req.body || {}
    if (!name?.trim() || !url?.trim()) {
      return res.status(400).json({ error: 'name and url are required' })
    }
    await seedDefaultsIfEmpty(Source, null)

    const cleanName = name.trim()
    const cleanUrl  = url.trim()
    if (await Source.findOne({ name: cleanName })) {
      return res.status(409).json({ error: 'A source with that name already exists' })
    }
    if (await Source.findOne({ url: cleanUrl })) {
      return res.status(409).json({ error: 'A source with that URL already exists' })
    }

    const doc = await Source.create({
      name: cleanName,
      url: cleanUrl,
      category: (category || 'general').trim() || 'general',
      active: true,
    })
    res.json({
      success: true,
      source: { id: String(doc._id), name: doc.name, url: doc.url, category: doc.category, active: true },
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// PATCH /api/sources/:id — toggle a source on/off
router.patch('/sources/:id', async (req, res) => {
  try {
    const { active } = req.body || {}
    const doc = await Source.findByIdAndUpdate(req.params.id, { $set: { active: !!active } }, { new: true })
    if (!doc) return res.status(404).json({ error: 'Source not found' })
    res.json({ success: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// DELETE /api/sources/:id — remove a source
router.delete('/sources/:id', async (req, res) => {
  try {
    const doc = await Source.findByIdAndDelete(req.params.id)
    if (!doc) return res.status(404).json({ error: 'Source not found' })
    res.json({ success: true, removed: doc.name || doc.url })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── Status endpoints (unchanged behaviour) ──────────────────────────────────

router.get('/status', async (req, res) => {
  try {
    res.json({ ok: true, database: { articles: await Article.countDocuments() } })
  } catch (e) {
    res.json({ ok: false, error: e.message })
  }
})

router.get('/market/status', (req, res) => {
  const now  = new Date()
  const day  = now.getUTCDay()
  const h    = now.getUTCHours()
  const m    = now.getUTCMinutes()
  const open = day >= 1 && day <= 5 && (h > 13 || (h === 13 && m >= 30)) && h < 20
  res.json({ open })
})

router.get('/stats', async (req, res) => {
  try {
    const [sources, categories] = await Promise.all([
      Article.aggregate([
        { $group: { _id: '$source', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      Article.aggregate([
        { $group: { _id: '$category', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ])
    ])

    res.json({
      sources: sources.map(s => ({ source: s._id, count: s.count })),
      categories: categories.map(c => ({ category: c._id, count: c.count }))
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── GET /api/keywords — ACTIVE managed keywords (for headline highlighting) ──
// Previously this derived "keywords" from article tickers; now it returns the
// real keyword list managed in the Keywords popup.
router.get('/keywords', async (req, res) => {
  try {
    await seedDefaultsIfEmpty(null, Keyword)
    const docs = await Keyword.find({ active: { $ne: false } }).sort({ word: 1 }).lean()
    res.json({
      keywords: docs.map(k => ({ keyword: k.word, category: k.category || 'general' })),
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
