# Tests (safe to delete — not used by the app)

These folders verify the RSS fetching + Sources/Keywords features without
needing MongoDB or internet access. The running app never imports anything
from here.

## tests/rss.test.mjs — unit tests
Checks the RSS/Atom parser, sentiment scoring, ticker extraction, and
keyword matching in `lib/rss.js`.

    node tests/rss.test.mjs

## itest/run.mjs — integration tests
Boots the real API routes (articles, settings, fetch) exactly as index.js
mounts them, but against in-memory fake database models (`itest/models/`)
and two local test feeds. Covers the full flow: seeding the 28 default
sources + 30 default keywords, sources/keywords add/toggle/remove,
fetching real RSS, deduplication on re-fetch, article filters
(keywords_only / search / category / pagination), stats, and the
SSE "Auto" watch mode.

    node itest/run.mjs

IMPORTANT: `itest/models/` are FAKE in-memory stand-ins used only by this
harness. The real app uses the real Mongoose models in `/models`.
