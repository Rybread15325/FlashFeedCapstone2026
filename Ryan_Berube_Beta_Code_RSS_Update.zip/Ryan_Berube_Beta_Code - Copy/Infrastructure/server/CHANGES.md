# Changes — Real RSS fetching + Sources/Keywords popups
(June 11, 2026)

## What this update does
1. **Real articles** — the Fetch and Auto buttons now pull live articles from
   RSS/Atom feeds on the internet (28 financial feeds seeded by default),
   instead of generating fake articles with Claude. Articles are deduplicated,
   tagged with tickers, scored bullish/bearish/neutral, and matched against
   your keyword list.
2. **Sources popup** — new "Sources" button on the News page (next to
   "+ Add Filter"). Add/remove RSS feeds, see per-feed article counts and
   last fetch time.
3. **Keywords popup** — new "Keywords" button on the News page. Add, toggle,
   and remove keywords (30 seeded by default). Active keywords drive the
   "Keywords Only" filter and the yellow headline highlighting.
4. Settings page is unchanged — it never had Sources/Keywords, and still
   doesn't. Management lives in the News page popups.

## NOT touched (per your instruction)
- index.js, db.js, package.json, package-lock.json, seed.js
- Server startup, MongoDB connection, CORS, ports
- All other routes (screener, social, correlation) and all other pages
- No new npm dependencies — runs on exactly what you already have installed

## New files
- lib/rss.js .................. RSS/Atom parser, feed fetcher, sentiment,
                                ticker extraction, keyword matcher,
                                default feeds + keywords, seeding helper
- src/pages/SourcesModal.tsx .. Sources popup
- src/pages/KeywordsModal.tsx . Keywords popup
- tests/ and itest/ ........... test suites (safe to delete; see itest/README.md)

## Modified files
- routes/fetch.js ........ POST /api/fetch now does real RSS fetching;
                           added GET /api/watch (SSE, powers the Auto button),
                           GET/POST/PATCH/DELETE /api/sources,
                           GET /api/keywords now returns managed keywords.
                           /api/status, /api/market/status, /api/stats unchanged.
- routes/settings.js ..... existing GET/POST /api/settings unchanged; added
                           GET/POST/PATCH/DELETE /api/settings/keywords.
- routes/articles.js ..... GET /api/articles now honors category, search,
                           keywords_only, and offset params the News page
                           was already sending. Everything else unchanged.
- models/Source.js ....... added optional `category` field (additive only)
- models/Keyword.js ...... added optional `category` field (additive only)
- src/pages/NewsPage.tsx . wires in the two popup buttons + modals
- src/pages/ArticleFilters.tsx . accepts an optional `extra` slot for buttons
- src/pages/NewsRow.tsx .. headline highlighting now matches word variants
                           ("Beat" highlights "beats"/"beating") and never
                           partial words ("Miss" won't light up "mission");
                           small time-format hardening
- src/lib/types.ts ....... added optional fetched_date to the Article type

## Verified
- 35 unit tests + 29 integration tests, all passing (parser, dedup on
  re-fetch, enrichment, every new endpoint, filters, pagination, SSE watch)
- Frontend builds cleanly (vite) and the touched files type-check (tsc)

## Notes for deployment
- Existing articles in MongoDB are untouched; re-fetching never overwrites
  previously stored articles (insert-only upserts).
- First call to the Sources or Keywords popup (or first Fetch) auto-seeds
  the 28 default feeds / 30 default keywords if your collections are empty.
- Some default feeds may 404 or block in production (feed URLs rot over
  time, and a few publishers block cloud IPs). Failures are counted and
  reported per fetch — they never break the cycle. Remove dead ones in
  the Sources popup.
- If you copy this folder fresh somewhere without node_modules,
  run `npm install` once (no dependency changes were made).
