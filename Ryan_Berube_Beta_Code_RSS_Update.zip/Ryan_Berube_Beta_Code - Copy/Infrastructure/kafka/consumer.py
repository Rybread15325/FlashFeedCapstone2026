import json, logging, os
from dotenv import load_dotenv
from confluent_kafka import Consumer, KafkaError
from pymongo import MongoClient, UpdateOne
import redis as redis_lib

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', 'server', '.env'))
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('consumer')

KAFKA_SERVERS = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
KAFKA_TOPIC   = os.getenv('KAFKA_TOPIC',              'flashfeed-events')
KAFKA_GROUP   = os.getenv('KAFKA_GROUP_ID',           'feedflash-consumer-group')
MONGO_URI     = os.getenv('MONGODB_URI',              'mongodb://localhost:27017/feedflash')
REDIS_URL     = os.getenv('REDIS_URL',                'redis://localhost:6379')
CACHE_KEY     = 'articles:feed:latest'
CACHE_TTL     = 60

def run():
    consumer = Consumer({
        'bootstrap.servers':  KAFKA_SERVERS,
        'group.id':           KAFKA_GROUP,
        'auto.offset.reset':  'earliest',
        'enable.auto.commit': False,
    })
    consumer.subscribe([KAFKA_TOPIC])
    mongo = MongoClient(MONGO_URI)
    col   = mongo.get_default_database()['articles']
    rds   = redis_lib.from_url(REDIS_URL, decode_responses=True)
    log.info('Consumer ready — topic: %s', KAFKA_TOPIC)

    try:
        while True:
            msgs = consumer.consume(num_messages=50, timeout=1.0)
            if not msgs:
                continue
            articles = []
            for msg in msgs:
                if msg.error():
                    if msg.error().code() != KafkaError._PARTITION_EOF:
                        log.error('Kafka error: %s', msg.error())
                    continue
                try:
                    articles.append(json.loads(msg.value().decode()))
                except Exception as e:
                    log.warning('Bad message: %s', e)
            if not articles:
                continue
            ops = [
                UpdateOne({'article_id': a['article_id']}, {'$setOnInsert': a}, upsert=True)
                for a in articles if a.get('article_id')
            ]
            if ops:
                result = col.bulk_write(ops, ordered=False)
                log.info('MongoDB: %d inserted', result.upserted_count)
            latest = list(col.find({}, {'_id': 0}).sort('publish_date', -1).limit(50))
            for a in latest:
                pub = a.get('publish_date')
                if pub and hasattr(pub, 'isoformat'):
                    a['publish_date'] = pub.isoformat()
            rds.setex(CACHE_KEY, CACHE_TTL, json.dumps(latest))
            log.info('Redis refreshed — %d articles', len(latest))
            consumer.commit(asynchronous=False)
    except KeyboardInterrupt:
        log.info('Shutting down')
    finally:
        consumer.close()
        mongo.close()

if __name__ == '__main__':
    run()
