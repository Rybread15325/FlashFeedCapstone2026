'use client'
import { useMemo, useState } from 'react'
import useSWR from 'swr'
import { RollingWindowsTable } from './RollingWindowsTable'

const fetcher = (url: string) => fetch(url).then(r => r.json())

// Standalone Rolling Window tab: pick a ticker (dropdown or type), see its
// rolling sentiment windows.
export function RollingWindowView({ initialTicker = 'AAPL' }: { initialTicker?: string }) {
  const [input, setInput] = useState(initialTicker)
  const [ticker, setTicker] = useState(initialTicker.toUpperCase())

  // Populate the dropdown from the screener's tracked stocks.
  const { data: screener } = useSWR('/api/screener?limit=500', fetcher, { revalidateOnFocus: false })
  const stocks: string[] = useMemo(() => {
    const rows: any[] = screener?.rows ?? screener?.data ?? (Array.isArray(screener) ? screener : [])
    const tickers = rows.map(r => String(r.ticker || '').toUpperCase()).filter(Boolean)
    return Array.from(new Set(tickers)).sort()
  }, [screener])

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 flex-wrap">
        {/* Stock dropdown */}
        <select
          value={stocks.includes(ticker) ? ticker : ''}
          onChange={e => { const v = e.target.value; if (v) { setInput(v); setTicker(v) } }}
          className="bg-bg border border-border text-sm text-neutral rounded px-2 py-1.5 focus:outline-none focus:border-accent max-w-[200px]"
        >
          <option value="">Select stock ▾{stocks.length ? ` (${stocks.length})` : ''}</option>
          {stocks.map(t => <option key={t} value={t}>{t}</option>)}
        </select>

        {/* Or type a ticker */}
        <input
          value={input}
          onChange={e => setInput(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === 'Enter' && setTicker(input.trim().toUpperCase())}
          placeholder="Ticker…"
          className="w-[120px] bg-bg border border-border text-sm text-white rounded px-3 py-1.5 font-mono focus:outline-none focus:border-accent"
        />
        <button
          onClick={() => setTicker(input.trim().toUpperCase())}
          className="px-3 py-1.5 bg-accent text-white text-sm rounded hover:bg-sky-400"
        >
          Load
        </button>
        <span className="ml-auto text-lg font-bold text-white">{ticker}</span>
      </div>

      <div className="bg-surface border border-border rounded-lg p-3">
        {ticker
          ? <RollingWindowsTable ticker={ticker} />
          : <div className="text-sm text-neutral py-2">Select or enter a ticker to see its rolling sentiment windows.</div>}
      </div>
    </div>
  )
}
