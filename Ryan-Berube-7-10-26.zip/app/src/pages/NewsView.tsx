'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import useSWR from 'swr'
import Chart from 'chart.js/auto'
import { clsx } from 'clsx'

const fetcher = (u: string) => fetch(u).then(r => r.json())

// Chart windows (styled like the reference dashboard). Server clamps to 3d of data.
const WINDOWS: { label: string; minutes: number }[] = [
  { label: '15m', minutes: 15 }, { label: '30m', minutes: 30 }, { label: '1h', minutes: 60 },
  { label: '4h', minutes: 240 }, { label: '1d', minutes: 1440 }, { label: '1w', minutes: 10080 },
]

function bucketFor(minutes: number): number {
  if (minutes <= 60) return 1
  if (minutes <= 240) return 5
  if (minutes <= 1440) return 15
  return 60
}

interface SeriesRow { bucket_sec: number; message_count: number; message_density: number; sentiment: number; bullish: number; bearish: number }
interface Marker { time: number; type: 'entry' | 'exit'; price: number }

const fmtClock = (sec?: number | null) => sec ? new Date(sec * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'America/New_York' }) : ''
const fmtWhen = (sec?: number | null) => sec ? new Date(sec * 1000).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''
// sentiment (-1..1) -> 0..10 score, neutral = 5 ("Mid")
const toScore10 = (s: number) => Math.max(0, Math.min(10, (s + 1) / 2 * 10))

export function NewsView({ initialTicker = 'AAPL' }: { initialTicker?: string }) {
  const [input, setInput] = useState(initialTicker)
  const [ticker, setTicker] = useState(initialTicker.toUpperCase())
  const [win, setWin] = useState(240)
  const [stockPage, setStockPage] = useState(0)
  const bucket = bucketFor(win)

  // Alphabetical list of all screener tickers, for the dropdown + 5-per-page navigator.
  const { data: screenerData } = useSWR('/api/screener?limit=2000', fetcher, { revalidateOnFocus: false })
  const allTickers: string[] = useMemo(() => {
    const rows: any[] = screenerData?.rows ?? screenerData?.data ?? (Array.isArray(screenerData) ? screenerData : [])
    const set = new Set<string>()
    for (const r of rows) {
      const t = (r?.ticker || r?.symbol || '').toString().toUpperCase().trim()
      if (t) set.add(t)
    }
    return Array.from(set).sort()
  }, [screenerData])

  const PAGE = 5
  const pageCount = Math.max(1, Math.ceil(allTickers.length / PAGE))
  const pageTickers = allTickers.slice(stockPage * PAGE, stockPage * PAGE + PAGE)

  // Keep the visible page in sync with the selected ticker.
  const selectStock = (t: string) => {
    const up = t.toUpperCase()
    setInput(up)
    setTicker(up)
    const idx = allTickers.indexOf(up)
    if (idx >= 0) setStockPage(Math.floor(idx / PAGE))
  }

  const { data: keystats } = useSWR(ticker ? `/api/ticker/${ticker}/keystats` : null, fetcher, { revalidateOnFocus: false })
  const { data: priceInfo } = useSWR(ticker ? `/api/prices/${ticker}` : null, fetcher, { refreshInterval: 60_000 })
  const { data: priceData } = useSWR(ticker ? `/api/charts/${ticker}?range=1d&interval=1m` : null, fetcher, { refreshInterval: 60_000 })
  const { data: series } = useSWR(ticker ? `/api/social/series/${ticker}?window_minutes=${win}&bucket_minutes=${bucket}` : null, fetcher, { refreshInterval: 30_000 })
  const { data: fiveMin } = useSWR(ticker ? `/api/social/series/${ticker}?window_minutes=60&bucket_minutes=5` : null, fetcher, { refreshInterval: 30_000 })
  const { data: signals } = useSWR(ticker ? `/api/sentchart/signals/${ticker}?window=full` : null, fetcher, { refreshInterval: 60_000 })
  const { data: feed } = useSWR(ticker ? `/api/social?ticker=${ticker}&limit=25` : null, fetcher, { refreshInterval: 30_000 })
  const { data: newsData } = useSWR(ticker ? `/api/articles?ticker=${ticker}&limit=12&recent_days=30` : null, fetcher, { refreshInterval: 60_000 })

  const rows: SeriesRow[] = series?.rows ?? []
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const chartRef = useRef<Chart | null>(null)

  // Company / sector line + current price.
  const company = keystats?.company || keystats?.name || keystats?.longName || ''
  const sector = keystats?.sector || ''
  const industry = keystats?.industry || ''
  const badge = keystats?.market_cap_tier || keystats?.index || ''
  const price = priceInfo?.price ?? (priceData?.candles?.length ? priceData.candles[priceData.candles.length - 1].close : null)

  // 5-minute rolling tiles (last 5m bucket).
  const last5 = (fiveMin?.rows ?? []).slice(-1)[0] as SeriesRow | undefined
  const has5mMsgs = !!last5 && last5.message_count > 0
  const rollingScore5 = has5mMsgs ? toScore10(last5!.sentiment) : null
  const rollingDensity5 = last5?.message_count ?? 0

  // Align price onto the sentiment buckets.
  const pricePoints = useMemo(() => {
    const candles: Array<{ time: number; close: number }> = priceData?.candles ?? []
    if (!candles.length || !rows.length) return rows.map(() => null as number | null)
    let ci = 0, lastc: number | null = null
    return rows.map(r => {
      while (ci < candles.length && candles[ci].time <= r.bucket_sec) { lastc = candles[ci].close; ci++ }
      return lastc
    })
  }, [priceData, rows])

  const densityMax = Math.max(1, ...rows.map(r => r.message_count))

  useEffect(() => {
    if (!canvasRef.current) return
    chartRef.current?.destroy()
    if (!rows.length) { chartRef.current = null; return }
    chartRef.current = new Chart(canvasRef.current, {
      type: 'line',
      data: {
        labels: rows.map(r => fmtClock(r.bucket_sec)),
        datasets: [
          { label: 'Density', data: rows.map(r => (r.message_count / densityMax) * 10),
            borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.18)', borderWidth: 1.5, pointRadius: 0, tension: 0.4, yAxisID: 'yScale', fill: true, order: 2 },
          { label: 'Score', data: rows.map(r => toScore10(r.sentiment)),
            borderColor: '#3b82f6', borderDash: [6, 4], borderWidth: 2, pointRadius: 0, tension: 0.3, yAxisID: 'yScale', fill: false, order: 1 },
          { label: 'Price', data: pricePoints,
            borderColor: '#ef4444', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.25, yAxisID: 'yPrice', fill: false, spanGaps: true, order: 0 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false, animation: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false }, tooltip: { enabled: true } },
        scales: {
          x: { ticks: { color: '#64748b', maxTicksLimit: 12, font: { size: 9 } }, grid: { color: 'rgba(148,163,184,0.05)' } },
          yPrice: { position: 'left', ticks: { color: '#ef4444', font: { size: 9 }, callback: (v) => '$' + Number(v).toFixed(2) }, grid: { display: false } },
          yScale: { position: 'right', min: 0, max: 10, ticks: { color: '#22c55e', stepSize: 1, font: { size: 9 } }, grid: { color: 'rgba(148,163,184,0.05)' } },
        },
      },
    })
    return () => { chartRef.current?.destroy() }
  }, [rows, pricePoints, densityMax])

  const markers: Marker[] = signals?.markers ?? []
  const lastMarker = markers.length ? markers[markers.length - 1] : null
  const openPosition = lastMarker?.type === 'entry'
  const posts: any[] = Array.isArray(feed) ? feed : []
  const articles: any[] = newsData?.articles ?? []
  const updated = new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })

  const Tile = ({ label, value, tone = 'text-white', sub }: { label: string; value: string; tone?: string; sub?: string }) => (
    <div className="flex-1 min-w-0 px-4 py-3 text-center border-r border-border last:border-r-0">
      <div className="text-[10px] text-neutral uppercase tracking-wide">{label}</div>
      <div className={clsx('text-2xl font-semibold font-mono mt-1', tone)}>{value}</div>
      {sub && <div className="text-[10px] text-slate-500 mt-0.5">{sub}</div>}
    </div>
  )

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-start gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-accent">{ticker}</span>
            {badge && <span className="text-[10px] font-bold uppercase bg-accent/20 text-accent px-2 py-0.5 rounded">{badge}</span>}
            {/* Dropdown of all stocks, next to the name */}
            <select value={allTickers.includes(ticker) ? ticker : ''} onChange={e => e.target.value && selectStock(e.target.value)}
              className="bg-bg border border-border text-xs text-white rounded px-2 py-1 font-mono focus:outline-none focus:border-accent max-w-[120px]">
              {!allTickers.includes(ticker) && <option value="">{ticker}</option>}
              {allTickers.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="text-xs text-neutral mt-0.5">
            {[company, sector, industry].filter(Boolean).join(' · ') || 'Sentiment dashboard'}
          </div>
          <div className="text-[11px] text-accent mt-0.5">Updated: {updated}</div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {/* Dropdown — pick any stock */}
          <select value={allTickers.includes(ticker) ? ticker : ''} onChange={e => e.target.value && selectStock(e.target.value)}
            title="Select any stock"
            className="bg-bg border border-border text-sm text-white rounded px-2 py-1.5 font-mono focus:outline-none focus:border-accent max-w-[130px] cursor-pointer">
            <option value="" disabled>{allTickers.length ? 'Select stock…' : 'Loading…'}</option>
            {!allTickers.includes(ticker) && ticker && <option value={ticker}>{ticker}</option>}
            {allTickers.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <input value={input} onChange={e => setInput(e.target.value.toUpperCase())}
            onKeyDown={e => e.key === 'Enter' && setTicker(input.trim().toUpperCase())}
            placeholder="Ticker…"
            className="w-[110px] bg-bg border border-border text-sm text-white rounded px-3 py-1.5 font-mono focus:outline-none focus:border-accent" />
          <button onClick={() => setTicker(input.trim().toUpperCase())}
            className="px-3 py-1.5 bg-accent text-white text-sm rounded hover:bg-sky-400">Load</button>
        </div>
      </div>

      {/* 5-per-page alphabetical stock navigator */}
      {allTickers.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap bg-surface border border-border rounded-lg px-3 py-2">
          <button onClick={() => setStockPage(p => Math.max(0, p - 1))} disabled={stockPage === 0}
            className="px-2 py-1 text-sm rounded border border-border text-neutral hover:text-white disabled:opacity-30 disabled:cursor-not-allowed" aria-label="Previous 5 stocks">←</button>
          <div className="flex items-center gap-1.5 flex-wrap">
            {pageTickers.map(t => (
              <button key={t} onClick={() => selectStock(t)}
                className={clsx('px-3 py-1 text-xs font-mono rounded transition-colors',
                  t === ticker ? 'bg-accent text-white' : 'bg-bg text-neutral border border-border hover:text-white')}>
                {t}
              </button>
            ))}
          </div>
          <button onClick={() => setStockPage(p => Math.min(pageCount - 1, p + 1))} disabled={stockPage >= pageCount - 1}
            className="px-2 py-1 text-sm rounded border border-border text-neutral hover:text-white disabled:opacity-30 disabled:cursor-not-allowed" aria-label="Next 5 stocks">→</button>
          <span className="ml-auto text-[11px] text-slate-500">Page {stockPage + 1} / {pageCount} · {allTickers.length} stocks</span>
        </div>
      )}

      {/* Composite / Sentiment / Trust / Impact tiles */}
      <div className="flex bg-surface border border-border rounded-lg overflow-hidden">
        <Tile label="Composite" value="– –" />
        <Tile label="Sentiment" value={rollingScore5 != null ? rollingScore5.toFixed(1) : '– –'}
          tone={rollingScore5 == null ? 'text-white' : rollingScore5 >= 6 ? 'text-emerald-400' : rollingScore5 <= 4 ? 'text-red-400' : 'text-white'} />
        <Tile label="Trust" value="– –" />
        <Tile label="Impact" value="– –" />
      </div>

      {/* Price / Rolling score / Rolling density */}
      <div className="relative flex bg-surface border border-border rounded-lg overflow-hidden">
        <Tile label="Current Price" value={price != null ? `$${Number(price).toFixed(2)}` : '– –'} />
        <Tile label="Rolling Score · 5m" value={rollingScore5 != null ? rollingScore5.toFixed(1) : '– –'}
          tone={rollingScore5 == null ? 'text-white' : rollingScore5 >= 6 ? 'text-emerald-400' : rollingScore5 <= 4 ? 'text-red-400' : 'text-white'} />
        <Tile label="Rolling Density · 5m" value={`${rollingDensity5} msgs/5m`} tone="text-emerald-400" />
        {!has5mMsgs && (
          <div className="absolute top-1 right-3 text-[10px] text-slate-500">No scored messages in 5m window</div>
        )}
      </div>

      {/* Chart window pills */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-neutral">Chart window:</span>
        {WINDOWS.map(w => (
          <button key={w.minutes} onClick={() => setWin(w.minutes)}
            className={clsx('px-3 py-1 text-xs rounded transition-colors',
              win === w.minutes ? 'bg-accent text-white' : 'bg-bg text-neutral border border-border hover:text-white')}>
            {w.label}
          </button>
        ))}
      </div>

      {/* Combined chart */}
      <div className="bg-surface border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-1 flex-wrap gap-2">
          <div>
            <div className="text-xs text-white font-medium uppercase tracking-wide">Price · Rolling Score · Message Density</div>
            <div className="text-[10px] text-slate-500">All times in Eastern Time (ET)</div>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1"><span className="inline-block w-3 h-0.5 bg-red-500" /> Price</span>
            <span className="flex items-center gap-1"><span className="inline-block w-3 h-0.5 bg-blue-500" style={{ borderTop: '2px dashed #3b82f6' }} /> Score</span>
            <span className="flex items-center gap-1"><span className="inline-block w-3 h-0.5 bg-emerald-500" /> Density</span>
            <button onClick={() => setWin(240)} className="px-2 py-0.5 rounded border border-border text-neutral hover:text-white">Reset Zoom</button>
          </div>
        </div>
        <div style={{ height: 340 }}>
          {rows.length ? <canvas ref={canvasRef} /> : (
            <div className="h-full flex items-center justify-center text-neutral text-sm">No social activity for {ticker} in this window.</div>
          )}
        </div>
      </div>

      {/* Entry / Exit screener */}
      <div className={clsx('rounded-lg border p-3',
        openPosition ? 'bg-emerald-500/10 border-emerald-500/40' : lastMarker ? 'bg-red-500/10 border-red-500/40' : 'bg-surface border-border')}>
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-[10px] uppercase tracking-wide text-neutral">Entry / Exit signal</span>
          {lastMarker ? (
            <span className={clsx('text-sm font-bold', openPosition ? 'text-emerald-400' : 'text-red-400')}>
              {openPosition ? '▲ ENTER' : '▼ EXIT'} @ ${lastMarker.price?.toFixed?.(2)} · {fmtWhen(lastMarker.time)}
            </span>
          ) : <span className="text-sm text-neutral">No entry/exit signal for the current session.</span>}
          {typeof signals?.trades === 'number' && <span className="ml-auto text-[11px] text-neutral">{signals.trades} trade(s) · {signals?.messages ?? 0} msgs</span>}
        </div>
      </div>

      {/* Messages + news + reserved 3D chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        <div className="bg-surface border border-border rounded-lg overflow-hidden flex flex-col">
          <div className="px-3 py-2 border-b border-border text-xs text-neutral uppercase tracking-wide">Live Messages</div>
          <div className="divide-y divide-slate-700/30 overflow-y-auto" style={{ maxHeight: 300 }}>
            {posts.length ? posts.map((p, i) => {
              const score = p.sentiment_score ?? null
              const tone = (score ?? 0) > 0.15 ? 'text-emerald-400' : (score ?? 0) < -0.15 ? 'text-red-400' : 'text-slate-400'
              return (
                <div key={i} className="px-3 py-2">
                  <div className="flex items-center gap-2 text-[11px] mb-0.5">
                    <span className={clsx('font-mono', tone)}>{score != null ? `${score >= 0 ? '+' : ''}${Number(score).toFixed(4)}` : '—'}</span>
                    {p.author && <span className="text-accent truncate">@{p.author}</span>}
                    <span className="text-slate-500 ml-auto">{p.platform || 'social'}</span>
                  </div>
                  <div className="text-xs text-slate-200 line-clamp-3">{p.text || p.title || '—'}</div>
                </div>
              )
            }) : <div className="px-3 py-8 text-center text-neutral text-sm">No recent messages for {ticker}.</div>}
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="px-3 py-2 border-b border-border text-xs text-neutral uppercase tracking-wide">Recent News</div>
          <div className="divide-y divide-slate-700/30 overflow-y-auto" style={{ maxHeight: 300 }}>
            {articles.length ? articles.map((a, i) => (
              <a key={a.id || a.article_id || i} href={a.url || '#'} target="_blank" rel="noreferrer" className="block px-3 py-2 hover:bg-bg/40">
                <div className="text-sm text-white line-clamp-2">{a.title || a.headline}</div>
                <div className="text-[11px] text-neutral mt-0.5">
                  {a.source} · {fmtWhen(a.publish_date || a.fetched_date)}
                  {a.sentiment && <span className={clsx('ml-2 font-mono', a.sentiment === 'bullish' ? 'text-emerald-400' : a.sentiment === 'bearish' ? 'text-red-400' : 'text-slate-400')}>{a.sentiment}</span>}
                </div>
              </a>
            )) : <div className="px-3 py-8 text-center text-neutral text-sm">No recent news for {ticker}.</div>}
          </div>
        </div>

        {/* Reserved (blank) slot for 3D charts — intentionally empty for now */}
        <div className="bg-surface border border-dashed border-border rounded-lg" style={{ minHeight: 300 }} />
      </div>
    </div>
  )
}
