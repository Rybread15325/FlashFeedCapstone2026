'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import useSWR from 'swr'
import { clsx } from 'clsx'
import { CandlestickChart } from './CandlestickChart'

const fetcher = (u: string) => fetch(u).then(r => r.json())

const PAGE_SIZE = 9  // stocks per page (arrow-paginated, Finviz-style)

const LATEST_NEWS = [
  { value: '0', label: 'Any' },
  { value: '1', label: 'Today' },
  { value: '3', label: '3 Days' },
  { value: '7', label: 'This Week' },
  { value: '30', label: 'This Month' },
]

const num = (v: any) => (v == null || Number.isNaN(Number(v)) ? null : Number(v))
function compact(n: any) {
  const v = num(n); if (v == null) return '–'
  const a = Math.abs(v)
  if (a >= 1e12) return (v / 1e12).toFixed(2) + 'T'
  if (a >= 1e9) return (v / 1e9).toFixed(2) + 'B'
  if (a >= 1e6) return (v / 1e6).toFixed(2) + 'M'
  if (a >= 1e3) return (v / 1e3).toFixed(1) + 'K'
  return String(v)
}
const pct = (v: any) => (num(v) == null ? '–' : `${Number(v).toFixed(2)}%`)
const money = (v: any) => (num(v) == null ? '–' : `$${Number(v).toFixed(2)}`)
const fmtWhen = (sec?: number | null) => (sec ? new Date(sec * 1000).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '')

// One Finviz-style mirror card: chart + fundamentals + news + a reserved 3D slot.
function MirrorCard({ row, recentDays, keyword }: { row: any; recentDays: string; keyword: string }) {
  const ticker = String(row.ticker || '').toUpperCase()

  // Lazy-load: only fetch this card's chart + news once it scrolls into view, so
  // every stock renders reliably instead of firing a burst of 9 requests at once.
  const cardRef = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    const el = cardRef.current
    if (!el || visible) return
    const io = new IntersectionObserver((entries) => {
      if (entries.some(e => e.isIntersecting)) { setVisible(true); io.disconnect() }
    }, { rootMargin: '300px' })
    io.observe(el)
    return () => io.disconnect()
  }, [visible])

  const { data: chart } = useSWR(ticker && visible ? `/api/charts/${ticker}?range=6mo&interval=1d` : null, fetcher, { revalidateOnFocus: false })
  const rd = recentDays && recentDays !== '0' ? recentDays : '30'
  const { data: newsData } = useSWR(ticker && visible ? `/api/articles?ticker=${ticker}&limit=8&recent_days=${rd}` : null, fetcher, { revalidateOnFocus: false })

  const candles = (chart?.candles ?? []).map((c: any) => ({
    time: c.time, open: c.open, high: c.high, low: c.low, close: c.close,
  }))
  let articles: any[] = newsData?.articles ?? []
  if (keyword.trim()) {
    const kw = keyword.trim().toLowerCase()
    articles = articles.filter(a => String(a.title || a.headline || '').toLowerCase().includes(kw))
  }

  const change = num(row.change_pct)
  const F: Array<[string, string]> = [
    ['Market Cap', compact(row.market_cap)],
    ['P/E', num(row.pe_ratio) == null ? '–' : Number(row.pe_ratio).toFixed(2)],
    ['Forward P/E', num(row.forward_pe) == null ? '–' : Number(row.forward_pe).toFixed(2)],
    ['PEG', num(row.peg) == null ? '–' : Number(row.peg).toFixed(2)],
    ['P/S', num(row.ps_ratio) == null ? '–' : Number(row.ps_ratio).toFixed(2)],
    ['P/B', num(row.pb_ratio) == null ? '–' : Number(row.pb_ratio).toFixed(2)],
    ['Dividend', pct(row.dividend_yield)],
    ['EPS next Y', pct(row.eps_growth_next_y)],
    ['EPS this Y', pct(row.eps_growth_this_y)],
    ['Sales Q/Q', pct(row.sales_growth)],
    ['Insider Own', pct(row.insider_own)],
    ['Inst Own', pct(row.inst_own)],
    ['Short Float', pct(row.float_short)],
    ['ROE', pct(row.roe)],
    ['Beta', num(row.beta) == null ? '–' : Number(row.beta).toFixed(2)],
    ['Avg Volume', compact(row.avg_volume)],
    ['Analyst', row.analyst || (num(row.target_price) != null ? 'rated' : '–')],
    ['Target Price', money(row.target_price)],
    ['52W Range', num(row.low_52w) != null && num(row.high_52w) != null ? `${Number(row.low_52w).toFixed(2)} - ${Number(row.high_52w).toFixed(2)}` : '–'],
    ['Earnings', row.earnings_date || '–'],
  ]

  return (
    <div ref={cardRef} className="bg-surface border border-border rounded-lg overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1.6fr)_minmax(240px,1fr)] gap-0">
        {/* Chart */}
        <div className="p-3 border-b lg:border-b-0 lg:border-r border-border">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-xl font-bold text-accent">{ticker}</span>
            <span className="text-sm text-white font-mono">{money(row.price)}</span>
            {change != null && (
              <span className={clsx('text-xs font-mono', change >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                {change >= 0 ? '+' : ''}{change.toFixed(2)}%
              </span>
            )}
            <span className="ml-auto text-[10px] text-slate-500">{row.exchange || ''}{row.index ? ` · ${row.index}` : ''}</span>
          </div>
          <div style={{ height: 200 }}>
            {candles.length ? <CandlestickChart candles={candles as any} />
              : <div className="h-full flex items-center justify-center text-neutral text-xs">Loading chart…</div>}
          </div>
        </div>

        {/* Fundamentals */}
        <div className="p-3">
          <div className="text-xs text-white font-medium mb-1">{row.company || ticker}</div>
          <div className="text-[10px] text-neutral mb-2">{[row.country, row.sector, row.industry].filter(Boolean).join(' · ')}</div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px]">
            {F.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2 border-b border-border/30 py-0.5">
                <span className="text-neutral">{k}</span>
                <span className="text-slate-200 font-mono truncate">{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* News for this stock */}
      <div className="border-t border-border">
        <div className="px-3 py-1.5 text-[10px] text-neutral uppercase tracking-wide bg-bg/30">Recent News</div>
        <div className="divide-y divide-slate-700/30 max-h-[180px] overflow-y-auto">
          {articles.length ? articles.map((a, i) => (
            <a key={a.id || a.article_id || i} href={a.url || '#'} target="_blank" rel="noreferrer" className="block px-3 py-1.5 hover:bg-bg/40">
              <span className="text-[11px] text-slate-500 font-mono mr-2">{fmtWhen(a.publish_date || a.fetched_date)}</span>
              <span className="text-xs text-sky-300 hover:underline">{a.title || a.headline}</span>
              <span className="text-[10px] text-neutral ml-1">({a.source})</span>
            </a>
          )) : <div className="px-3 py-3 text-center text-neutral text-xs">No recent news for {ticker}.</div>}
        </div>
      </div>

      {/* Reserved slot for the 3D chart (to be added) */}
      <div className="border-t border-border px-3 py-4 text-center bg-bg/20">
        <div className="text-[10px] text-slate-600 uppercase tracking-wide">3D Chart</div>
        <div className="text-[11px] text-slate-500 mt-1">Reserved — 3D view for {ticker} will render here.</div>
      </div>
    </div>
  )
}

// News Mirror: a Finviz-style mirror for EVERY stock, arrow-paginated.
export function NewsMirror() {
  const [page, setPage] = useState(0)
  const [recentDays, setRecentDays] = useState('0')
  const [keyword, setKeyword] = useState('')
  const [search, setSearch] = useState('')

  const { data: screener } = useSWR('/api/screener?limit=2000', fetcher, { revalidateOnFocus: false })
  const rows: any[] = useMemo(() => {
    const r: any[] = screener?.rows ?? screener?.data ?? (Array.isArray(screener) ? screener : [])
    const seen = new Set<string>()
    const out = r.filter(x => {
      const t = String(x.ticker || '').toUpperCase()
      if (!t || seen.has(t)) return false
      seen.add(t); return true
    })
    const s = search.trim().toUpperCase()
    return s ? out.filter(x => String(x.ticker || '').toUpperCase().includes(s)) : out
  }, [screener, search])

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const clampedPage = Math.min(page, totalPages - 1)
  const pageRows = rows.slice(clampedPage * PAGE_SIZE, clampedPage * PAGE_SIZE + PAGE_SIZE)

  return (
    <div className="space-y-3">
      {/* Filter bar */}
      <div className="flex items-center gap-3 flex-wrap bg-surface border border-border rounded-lg px-3 py-2">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-neutral">Latest News</span>
          <select value={recentDays} onChange={e => setRecentDays(e.target.value)}
            className="bg-bg border border-border text-sm text-neutral rounded px-2 py-1 focus:outline-none focus:border-accent">
            {LATEST_NEWS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-neutral">News Keywords</span>
          <input value={keyword} onChange={e => setKeyword(e.target.value)} placeholder="filter headlines…"
            className="w-[180px] bg-bg border border-border text-sm text-white rounded px-2 py-1 focus:outline-none focus:border-accent" />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-neutral">Stock</span>
          <input value={search} onChange={e => { setSearch(e.target.value.toUpperCase()); setPage(0) }} placeholder="ticker…"
            className="w-[110px] bg-bg border border-border text-sm text-white rounded px-2 py-1 font-mono focus:outline-none focus:border-accent" />
        </div>

        {/* Pagination */}
        <div className="ml-auto flex items-center gap-2 text-xs">
          <span className="text-neutral">{rows.length} stocks · Page {clampedPage + 1} / {totalPages}</span>
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={clampedPage === 0}
            className="px-2 py-1 rounded border border-border text-neutral hover:text-white disabled:opacity-40">←</button>
          <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={clampedPage >= totalPages - 1}
            className="px-2 py-1 rounded border border-border text-neutral hover:text-white disabled:opacity-40">→</button>
        </div>
      </div>

      {/* Mirror cards — one per stock */}
      {pageRows.length ? (
        <div className="space-y-3">
          {pageRows.map(row => (
            <MirrorCard key={row.ticker} row={row} recentDays={recentDays} keyword={keyword} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-neutral text-sm">
          {screener ? 'No stocks match your search.' : 'Loading stocks…'}
        </div>
      )}

      {/* Bottom pager */}
      {pageRows.length > 0 && (
        <div className="flex items-center justify-center gap-2 text-xs py-2">
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={clampedPage === 0}
            className="px-3 py-1 rounded border border-border text-neutral hover:text-white disabled:opacity-40">← Prev</button>
          <span className="text-neutral">Page {clampedPage + 1} / {totalPages}</span>
          <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={clampedPage >= totalPages - 1}
            className="px-3 py-1 rounded border border-border text-neutral hover:text-white disabled:opacity-40">Next →</button>
        </div>
      )}
    </div>
  )
}
