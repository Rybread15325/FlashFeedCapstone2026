'use client'
import useSWR from 'swr'
import { useMemo } from 'react'

const fetcher = (u: string) => fetch(u).then(r => r.json())

// Shared alphabetical list of every screener ticker (deduped, uppercased).
export function useAllTickers(): string[] {
  const { data } = useSWR('/api/screener?limit=2000', fetcher, { revalidateOnFocus: false, dedupingInterval: 60_000 })
  return useMemo(() => {
    const rows: any[] = data?.rows ?? data?.data ?? (Array.isArray(data) ? data : [])
    const set = new Set<string>()
    for (const r of rows) {
      const t = (r?.ticker || r?.symbol || '').toString().toUpperCase().trim()
      if (t) set.add(t)
    }
    return Array.from(set).sort()
  }, [data])
}

// A native dropdown to pick any stock. Reused across News View, Grok, etc.
export function StockSelect({
  value,
  onChange,
  className,
}: {
  value: string
  onChange: (t: string) => void
  className?: string
}) {
  const tickers = useAllTickers()
  const v = (value || '').toUpperCase()
  const has = tickers.includes(v)
  return (
    <select
      value={has ? v : ''}
      onChange={e => e.target.value && onChange(e.target.value)}
      title="Select any stock"
      className={className ?? 'bg-bg border border-border text-sm text-white rounded px-2 py-1.5 font-mono focus:outline-none focus:border-accent max-w-[150px] cursor-pointer'}
    >
      <option value="" disabled>{tickers.length ? 'Select stock…' : 'Loading…'}</option>
      {!has && v && <option value={v}>{v}</option>}
      {tickers.map(t => <option key={t} value={t}>{t}</option>)}
    </select>
  )
}
