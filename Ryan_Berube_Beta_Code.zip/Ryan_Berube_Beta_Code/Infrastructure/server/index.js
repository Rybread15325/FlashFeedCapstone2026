import 'dotenv/config'
import express from 'express'
import cors    from 'cors'
import { connectDB } from './db.js'

import articlesRouter    from './routes/articles.js'
import screenerRouter    from './routes/screener.js'
import socialRouter      from './routes/social.js'
import correlationRouter from './routes/correlation.js'
import settingsRouter    from './routes/settings.js'

const app  = express()
const PORT = process.env.PORT || 3001

// ── Middleware ────────────────────────────────────────────
app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173'] }))
app.use(express.json({ limit: '2mb' }))

// ── Routes ────────────────────────────────────────────────
app.use('/api/articles',    articlesRouter)
app.use('/api/screener',    screenerRouter)
app.use('/api/social',      socialRouter)
app.use('/api/correlation', correlationRouter)
app.use('/api/settings',    settingsRouter)

// ── Health check ──────────────────────────────────────────
app.get('/api/health', (req, res) => {
  const { readyState } = require('mongoose').connection
  const states = { 0:'disconnected', 1:'connected', 2:'connecting', 3:'disconnecting' }
  res.json({
    status:  'ok',
    db:      states[readyState] || 'unknown',
    time:    new Date().toISOString(),
  })
})

// ── Start ─────────────────────────────────────────────────
async function start() {
  await connectDB()
  app.listen(PORT, () => {
    console.log()
    console.log('  ⚡ FlashFeed API')
    console.log('  ─────────────────────────────────────')
    console.log('  Server  →  http://localhost:' + PORT)
    console.log('  Health  →  http://localhost:' + PORT + '/api/health')
    console.log('  Docs    →  README-MONGODB.md')
    console.log()
  })
}

start()
